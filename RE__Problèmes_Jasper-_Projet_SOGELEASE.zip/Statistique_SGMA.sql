SELECT * FROM 
  ( 
    SELECT AGR.AGRVALUE , AGR.AGRGCOCODE , AGR.AGRORDREPARENT
          FROM ARAGRID AGR, ANALYSIS ANA
         WHERE     ANA.DOSID= $P{dosid} 
               AND ANA.DPRVERSION =F_DERNIEREVERSIONDOSSIER (ANA.DOSID)
                and AGR.ANAID = ANA.ANAID
                  AND ANA.ANAID = (SELECT MAX (ANAID)
                                  FROM ANALYSIS A 
                                 WHERE A.DOSID = ANA.DOSID and ANA.DPRVERSION= A.DPRVERSION  and ANMID=5 )
               AND AGR.RATID = 7000
) 
  PIVOT ( 
    max(AGRVALUE) 
FOR AGRGCOCODE 
in ('CATTC' "CA TTC" , 'MVTCDNET' "Mouvement credit", 'SLDMOY' Solde_Moy, 'AUT' AUTO)
) where AGRORDREPARENT is not null