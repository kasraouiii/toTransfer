select ac.actnom AS Nom,ac.actcode AS Code  from actrelation acr ,acteur ac 
  where acr.actid in
   (select dprac.actid from dpracteur dprac,acteur ac where dosid= $P{P_dosid}  and rolcode in ('CLIENT','GARANT')
          and ac.Actid=dprac.actid)
          AND acr.actidrelation=ac.actid
          AND acr.TRECODE IN ('DIRIGEANT','GROUPE','SHAREHOLDER')