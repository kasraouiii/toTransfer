SELECT * FROM 
  ( 
    SELECT AGR.AGRVALUE , AGR.AGRGCOCODE,'Engagement ' || AGR.AGRORDREPARENT "Num_ENG" , AGR.AGRORDREPARENT
          FROM ARAGRID AGR, ANALYSIS ANA
         WHERE     ANA.DOSID=   $P{DOSID} 
               AND ANA.DPRVERSION  =F_DERNIEREVERSIONDOSSIER (ANA.DOSID)
                and AGR.ANAID = ANA.ANAID
                  AND ANA.ANAID = (SELECT MAX (ANAID)
                                FROM ANALYSIS A 
                                 WHERE A.DOSID = ANA.DOSID and ANA.DPRVERSION= A.DPRVERSION  and ANMID=5 )
               AND AGR.RATID = 5003
) 
  PIVOT ( 
    max(AGRVALUE) 
FOR AGRGCOCODE 
in ('Mntdip' "Montant Dispo" , 'Mntaut' "Montant Aut", 'DtEche' Date_ECH, 'RefAut' REF_AUTO)
) where AGRORDREPARENT is not null