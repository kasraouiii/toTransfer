select RIBCOMPTE FROM RIB RIB,actrib actri where 
             Actid=  $P{ACTID}
            AND RIB.ribid=actri.RIBID