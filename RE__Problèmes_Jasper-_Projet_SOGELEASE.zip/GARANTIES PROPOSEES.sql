select  LTG.TGALIBELLE TYPE_GAR
  , ACT.ACTNOM NOM_GAR,
   pfiig.PFGMTGUARANTEE MT_GAR
           from dprpropfinance dprf, pfiguarantee pfiig , lantgarantie LTG , ACTEUR ACT where 
           dprf.dosid= $P{P_dosid} 
           AND dprf.dprversion = F_DERNIEREVERSIONDOSSIER (dprf.DOSID)
           AND dprf.pfiid=pfiig.pfiid
           AND LTG.tgacode = pfiig.TGACODE AND LTG.LANCODE = 'FR'
           AND ACT.ACTID = PFIIG.ACTID