SELECT * FROM 
  ( 
    SELECT AGR.AGRVALUE , AGR.AGRGCOCODE,'Engagement ' || AGR.AGRORDREPARENT "Num_ENG" , AGR.AGRORDREPARENT
          FROM ARAGRID AGR, ANALYSIS ANA
         WHERE     ANA.DOSID=  $P{P_dosid} 
               AND ANA.DPRVERSION =F_DERNIEREVERSIONDOSSIER (ANA.DOSID)
                and AGR.ANAID = ANA.ANAID
                  AND ANA.ANAID = (SELECT MAX (ANAID)
                                  FROM ANALYSIS A 
                                 WHERE A.DOSID = ANA.DOSID and ANA.DPRVERSION= A.DPRVERSION  and ANMID=5 )
               AND AGR.RATID = 8002 
) 
  PIVOT ( 
    max(AGRVALUE) 
FOR AGRGCOCODE 
in ('A1' A1, 'A2' A2, 'A3' A3 , 'A4' A4 , 'A5' A5 , 'A6' A6 , 'VR' VR ,'CHARGE CB HI' CHARGECBHI) 
) where AGRORDREPARENT is not null