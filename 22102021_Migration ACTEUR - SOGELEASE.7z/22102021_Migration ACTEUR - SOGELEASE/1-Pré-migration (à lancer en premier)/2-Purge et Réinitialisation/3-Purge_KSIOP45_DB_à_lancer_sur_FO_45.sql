set lines 132
set serveroutput on size 1000000
set verify off
col ACTLIBCOURT form a30

--------------------------------------------------------------------------------------------------------------------
-- ATTENTION : VERIFIER LES ACTID DES SOCIETES DE GESTION SUR LES DELETE DES TABLEs AVEC ACTID et RIB + RIBINFO) --
--------------------------------------------------------------------------------------------------------------------
-- A) La logique du paragraphe '-- DELETE DES TABLES SUR ACTID HORS ACTIDGESTION --' doit etre modifiee pour ne
--     contenir que les numeros des acteurs de gestion que l'on desire conserver.
-- B) Il faut supprimer les commentaires qui encadrent la logique du paragraphe '-- DELETE DES ADRESSES INUTILES -- ATTENTION PAS TESTE'
-- C) Preconisation concernant le paragraphe '-- DELETE DES TABLES SUR ACTID HORS ACTIDGESTION --' 
--     Pour les versions de Cassiopee ulterieures, 
--     la liste des tables devra etre enrichie des eventuelles tables de parametrage liees aux societes de gestion.
---------------------------------------------------
-- Suivi des versions
---------------------------------------------------
-- 1.2	Version Initiale 4.5
-- 1.3	IRJ		DD/MM/YYYY	Version mis � jour
-- 1.4	IRJ		23/04/2015	Version mis � jour pour la version 4.0 : Tests effectu�s sur HERMES, RIVDEV et FINDEV 
-- 1.5	IRJ		27/05/2015	Ajout du message d'erreur lors du remont� des contraintes
--							Lancement direct sur le sch�ma � purger.
-- 1.6	IRJ		08/06/2015	Ajout des tables REGIMPUTATION et TBATCH
---------------------------------------------------
-- count initial before purge
---------------------------------------------------
declare
  cnt NUMBER;
begin
  begin 
  DBMS_OUTPUT.PUT_LINE('Sch�ma � purger '|| user);
  if (SUBSTR(user,0,2) = 'AV') then
  DBMS_OUTPUT.PUT_LINE('TYPE de SCHEMA : FRONT OFFICE');
  else
  DBMS_OUTPUT.PUT_LINE('TYPE de SCHEMA : BACK OFFICE');
  end if;
    execute immediate 'create table KSIOPPURGE (table_name VARCHAR2(30), nbcount NUMBER, run VARCHAR2(10))';
  exception
    when others then
       execute immediate 'truncate table KSIOPPURGE';
      DBMS_OUTPUT.PUT_LINE('TRUNCATE KSIOPPURGE');
      
  end;
  for c1 in (select table_name from user_tables order by table_name)
  loop
    cnt := 0;
    execute immediate 'select count(1) from ' || c1.table_name into cnt;
    execute immediate 'insert into KSIOPPURGE values (:1, :2, ''BEFORE'')' using c1.table_name, cnt; 
  end loop;
  execute immediate 'select count(1) from user_indexes' into cnt;
  execute immediate 'insert into KSIOPPURGE values (''INDEXES'', :1, ''BEFORE'')' using cnt; 
   commit;
end;
/

---------------------------------------------------
PROMPT *** CHECK OF PARSYSTEME
---------------------------------------------------
set serveroutput on;
declare
  sPsyVoir VARCHAR2(32) := null;
  sPsyAndromede VARCHAR2(32) := null;
begin
  execute immediate 'select psyvoir, psyandromede from parsysteme' into sPsyVoir, sPsyAndromede;
  DBMS_OUTPUT.PUT_LINE(sPsyVoir || '-' || sPsyAndromede || '-' || user);
  
end;
/   
select actid, actlibcourt from acteur where actid in (select actid from acteurgestion) order by actid;

-----------------------------------------
PROMPT *** PASSAGE DES CONTRAINTES EN DISABLED
------------------------------------------
set serveroutput on;
begin
     execute immediate 'truncate table utirecententity drop storage';
    DBMS_OUTPUT.PUT_LINE('TRUNCATE UTIRECENTENTITY');
    exception
      when others then null;
end;
/

declare
  ncount number := 0;
begin
  select count(1) into ncount
  from user_tables where table_name = 'RIBBALANCE';
  if ncount != 0 then
     execute immediate 'truncate table ribbalance drop storage';
    DBMS_OUTPUT.PUT_LINE('TRUNCATE RIBBALANCE ==>' || to_char(ncount));
  end if;
  select count(1) into ncount
  from user_tables where table_name = 'MONITEUR';
  if ncount != 0 then
     execute immediate 'truncate table moniteur drop storage';
    DBMS_OUTPUT.PUT_LINE('TRUNCATE MONITEUR ==>' || to_char(ncount));
  end if;
end;
/

DECLARE
	n integer ;
  CURSOR C1 IS SELECT  constraint_name, table_name FROM  user_constraints 
            WHERE owner = user and Constraint_type = 'R' AND status = 'ENABLED' ;	
BEGIN
  n := dbms_sql.open_cursor;
  for c1rec in c1 loop
    begin
     dbms_sql.parse(n, 'alter table ' || c1rec.table_name || ' disable constraint ' || c1rec.constraint_name, dbms_sql.native);
    exception
     when others then
	null;
     end;
  end loop;
  dbms_sql.close_cursor (n);
END;
/
-------------------------------------------------------
PROMPT *** TRUNCATE DES TABLES HORS PILOTAGE, ACTID et ADRID
-- -----------------------------------------------------

DECLARE
   TYPE   nested_nbr_type IS TABLE OF VARCHAR2(30);
   FullListTables     nested_nbr_type;
   ListDosIdTables    nested_nbr_type := nested_nbr_type();
   ListDepIdTables    nested_nbr_type := nested_nbr_type();
   ListAssIdTables    nested_nbr_type := nested_nbr_type();
   
   SelectListTables   nested_nbr_type;
   i                  PLS_INTEGER;
BEGIN
  select  table_name bulk collect 
  into    FullListTables 
  from    user_tab_columns
  join    user_tables using (table_name) 
  where   column_name in (
                          'AECID','AGGID','BIMID','BUDID',
                          'CHAID','CEXID','CINID','COMID','CONID','CREID','CROID',
                          'DEDID','DOSIDPRET','EPKID',
                          'IMAID','IREID','ITRID',
                          'KEYID',/*'MAKID',*/'MARID','OPTCODE',
                          'PFIID','POOID','RBOID','REGID',
                          'SDEID','SFAID','SHORT_ID','SINID',
                          'TBAID','TCPID','TRBID','TTFID','TTTID')
  minus 
  select  distinct table_name 
  from    user_tab_columns 
  where   column_name in ('ACTID','ADRID','CKEID','MANID') -- To manage Compagnies
  minus 
  select  table_name 
  from    user_tables 
  where   table_name in ('CREVT','DEPARTMENT','FTVPHASE','PVEPHASE','REVPHASE','TBATCH','TDEADLINE','TSCHEDULE')
  order by table_name;
  for c in (select table_name from user_tab_columns join user_tables using (table_name) where column_name = 'DOSID')
  loop
    begin
        execute immediate 'select count(1) from ' ||c.table_name into i;
      if i>0 THEN
        ListDosIdTables.extend;
        ListDosIdTables(ListDosIdTables.last) := c.table_name;
        DBMS_OUTPUT.PUT_LINE('Tables Dossier : ' || i ||'	'|| c.table_name);
      end if;
      i:=0;
    exception
      when others then
        DBMS_OUTPUT.PUT_LINE(c.table_name || sqlcode);
    end;
  end loop;
 
  if (SUBSTR(user,0,2)) = 'TR' then
  for c in (select table_name from user_tab_columns join user_tables using (table_name) where column_name = 'DEPID')
  loop
    begin
        execute immediate 'select count(1) from ' ||c.table_name into i;
      if i>0 THEN
        ListDepIdTables.extend;
        ListDepIdTables(ListDepIdTables.last) := c.table_name;
        DBMS_OUTPUT.PUT_LINE('Tables Depenses : ' || i ||'	'|| c.table_name);
      end if;
      i:=0;
    exception
      when others then
        DBMS_OUTPUT.PUT_LINE(c.table_name || sqlcode);
    
    end;
  end loop;

  
  for c in (select table_name from user_tab_columns join user_tables using (table_name) where column_name = 'ASSID')
  loop
    begin
      execute immediate 'select count(1) from ' ||c.table_name into i;
      if i > 0 THEN
        ListAssIdTables.extend;
        ListAssIdTables(ListAssIdTables.last) := c.table_name;
        DBMS_OUTPUT.PUT_LINE('Tables Assurance : ' || i ||'	'|| c.table_name);
      end if;
      i:=0;
    exception
      when others then
        DBMS_OUTPUT.PUT_LINE(c.table_name || sqlcode);
    end;
  end loop;
  end if;
  
  SelectListTables := FullListTables MULTISET EXCEPT DISTINCT ListDosIdTables;
  SelectListTables := SelectListTables MULTISET EXCEPT DISTINCT ListDepIdTables;
  SelectListTables := SelectListTables MULTISET EXCEPT DISTINCT ListAssIdTables;
  
  if SelectListTables.count != 0 then
    for i in SelectListTables.FIRST..SelectListTables.LAST
    loop
          execute immediate 'truncate table ' || SelectListTables(i);
         DBMS_OUTPUT.PUT_LINE('Truncate table  : '|| SelectListTables(i));
    end loop;
  end if;
END;
/
---------------------------------------------------
PROMPT *** DELETE DES TABLES SUR ACTID HORS ACTIDGESTION
-- -------------------------------------------------
declare
Stmt VARCHAR2(4000);
cursor c1 is select distinct user_tables.table_name from user_tab_columns, user_tables where user_tab_columns.table_name=user_tables.table_name
  and user_tab_columns.column_name in ('ACTID') 
  and user_tables.table_name not in ('UTITSM','CCHVALUE', 'CONFIGURATIONKEY', 'CREVT', 'DEPARTMENT', 'DATATRANSCODING', 'MAKE', 'MAKMODEL', 'MAKMODTRIMLEVEL' ) order by 1;

begin
  for truc in c1 loop
    begin
    if truc.table_name != 'IMMOTRANCHE' then
    Stmt := 'delete ' || truc.table_name || ' where nvl(actid,0) not in (select actid from acteurgestion where actid = 1) AND actid not in (select actid from actrole where rolcode like ''AGENCE'')';
    else 
    Stmt := 'delete ' || truc.table_name ;
    end if;
    --OLD : For 4.5
    --Stmt := 'delete ' || truc.table_name || ' where nvl(actid,0) not in (select actid from acteurgestion join actphase using (actid) where phacode=''ACTIVE'' and APHDTFIN is null union select actid from department where actid is not null UNION SELECT ACTID FROM ACTROLE WHERE ROLCODE in (''COURT'', ''TAX'') union select actid from actphase where phacode=''INI'' and jalcode=''MOD'' union select 210 from dual union select actid from dosacteur dac join dosphase dph using (dosid) where dph.phacode = ''INI'' and dph.jalcode = ''MOD'' union select actid from actrole join actphase using (actid) where rolcode = ''ASSUR'' and phacode = ''ACTIVE'' and aphdtfin is null union select actidsubrogator from actsubrogation)';
    dbms_output.put_line(stmt||';');
    execute immediate stmt;
     commit;
    exception
	  when others then  
          dbms_output.put_line('ERREUR sur ' || truc.table_name||'==>'||sqlcode||' '||sqlerrm);
    end;
  end loop;
  
  -- **** delete REGLEMENT_TEST;
  -- **** delete CRO_SAV;
  
   commit;
  --dbms_sql.close_cursor (n);

-- role on acteurgestion which no more exists
delete aagrve a where not exists ( select 1 from acteurgestion b where b.actid = a.actidgestion) and a.actidgestion is not null
and not exists ( select 1 from actrole b where b.actid = a.actidgestion and rolcode like 'AGENCE');
dbms_output.put_line('DELETE AAGRVE');
 commit;
delete aroage a where not exists ( select 1 from acteurgestion b where b.actid = a.actidgestion) and a.actidgestion is not null
and not exists ( select 1 from actrole b where b.actid = a.actidgestion and rolcode like 'AGENCE');
dbms_output.put_line('DELETE AROAGE');
 commit;
if (SUBSTR(user,0,2)='TR') then 
  Stmt := 'delete aroagetmpfee a where not exists (select 1 from acteurgestion b where b.actid = a.actidgestion) and a.actidgestion is not null and not exists ( select 1 from actrole b where b.actid = a.actidgestion and rolcode like ''AGENCE'')';
  execute immediate Stmt;
  dbms_output.put_line('DELETE AROAGETMPFEE');
  
end if;
 commit;
end;
/
-- subrogator on acteur which no more exists
-- For 4.5
-- delete actsubrogation a where not exists (select 1 from acteur b where b.actid = a.actid) and a.actid is not null;
 commit;
declare
  type tbl_vchar is table of varchar2(30);
  ListOfColumn tbl_vchar := tbl_vchar('DOSID','DEPID','ASSID','MANID');
  MasterTableName varchar2(30);
  PhaseTableName  varchar2(30);
  Stmt            varchar2(4000);
  begin
    for i in ListOfColumn.first..ListOfColumn.last
    loop
      MasterTableName := NULL;
      case ListOfColumn(i)
        when 'ASSID' then 
          MasterTableName := 'ASSURANCE';
          PhaseTableName  := 'ASSPHASE';
        when 'DEPID' then 
          MasterTableName := 'DEPENSE';
          PhaseTableName  := 'DEPPHASE';
        when 'DOSID' then 
        if (SUBSTR(user,0,2)) = 'TR' then
          MasterTableName := 'DOSSIER';
          PhaseTableName  := 'DOSPHASE';
        else 
          MasterTableName := 'DOSSIERPROSPECT';
          PhaseTableName  := 'DPRPHASE';
        end if;  
        when 'MANID' then 
          MasterTableName := 'MANDAT';
          PhaseTableName  := 'MANPHASE';
      end case;
      
      if (SUBSTR(user,0,2) = 'TR') or ((SUBSTR(user,0,2) = 'AV') and MasterTableName = 'DOSSIERPROSPECT')  then
        Stmt := 'DELETE FROM '||MasterTableName;
        execute immediate Stmt;
        dbms_output.put_line(Stmt);
      end if;

       commit;
    
      for c in (select table_name from user_tab_columns join user_tables using (table_name) where column_name=ListOfColumn(i)
                minus 
                select table_name from user_tables where table_name in ('FACTURE','FACECHEANCE','FACLIGNE','CREVT','CASHFLOW','MV_CCATARGET_DOSS','MV_UNPAID_DOSS','MV_CONTRACTUNPAIDCONSO','MV_CTRTUNPAIDPRINCIPALCONSO'))
      loop
      begin
        stmt := 'delete from '||c.table_name||' t1 where not exists ( select null from '||mastertablename||' t2 where t2.'||listofcolumn(i)||'= t1.'||listofcolumn(i)||') '; --and t1.'||listofcolumn(i)||' is not null
        execute immediate Stmt;
        dbms_output.put_line(Stmt);
         commit;
        exception
          when others then  
          dbms_output.put_line('ERREUR sur ' || c.table_name||'==>'||sqlcode||' '||sqlerrm);
      end ;   
      end loop;
    end loop;
    
end;
/
------
-- clean ACTRELATION and other tables (HY specific)
-----
delete from actrelation where actidrelation in (
select actidrelation from actrelation
minus
select actid from acteur);
--delete document where not exists (
--select null from acteurgestion where actid = document.actidgestion) and actidgestion is not null;
delete landocument f where not exists (
select null from document d where d.docid=f.docid) and docid is not null;
delete forfiche f where not exists (
select null from document d where d.docid=f.docid) and docid is not null;
/*update  pvetable set actidbeneficiary=null where actidbeneficiary in (
select actidbeneficiary from pvetable where actidbeneficiary is not null
minus
select actid from acteur);*/
update rib set actidowner=null where actidowner in (
select actidowner from rib where actidowner is not null
minus
select actid from acteur);
DELETE
FROM cchvalue cva
WHERE NOT EXISTS
  (select null from acteur a where a.actid=cva.actid);
  
declare
nrows number;
Stmt varchar2(250);
begin
  Begin
  Stmt := 'delete cchvalgrid cch where  not exists (select null from cchvalue cva where cva.cvaid = cch.cvaid)';
  execute immediate Stmt;
  nrows:=sql%rowcount;
  if nrows > 0 then
      dbms_output.put_line('cchvalgrid==>'|| to_char(nrows));
  end if;
   commit;
  exception
      when others then  
        dbms_output.put_line('ERREUR sur CCHVALGRID ==>'||sqlcode||' '||sqlerrm);
  end;
end;
/
---------------------------------------------------
prompt *** delete des tables sur creid out of special actors
----------------------------------------------------
declare
cursor c1 is select table_name from user_tables where table_name in ('CREVT', 'CREDATA', 'CREVALID') order by 1;
n integer;
nrows number;
begin
  n := dbms_sql.open_cursor;
  for truc in c1 loop
    begin
      nrows := 0;
      dbms_sql.parse(n, 'delete ' || truc.table_name || ' T where T.creid not in 
         (select c1.creid from crevt c1 join acteur using (actid) union 
          select c2.creid from crevt c2 join depense using (depid) union
          select c3.creid from crevt c3 join DOSSIER using (dosid) union 
          select c4.creid from crevt c4 join assurance using (assid) union 
          select c5.creid from crevt c5 join administratif adm on (c5.creid = adm.creid) union 
          select c6.creid from crevt c6 join aagrve aag on (c6.creid = aag.creid) union
          select c7.creid from crevt c7 join manphase mph on (c7.creid = mph.creid)) and T.creid is not null', dbms_sql.native);
      nrows := dbms_sql.execute(n);
      if nrows > 0 then
        dbms_output.put_line('DELETE' || truc.table_name||'==>'|| to_char(nrows));
      end if;
       commit;	
    exception
      when others then  
        dbms_output.put_line('ERREUR sur ' || truc.table_name||'==>'||sqlcode||' '||sqlerrm);
    end;
  end loop;
  dbms_sql.close_cursor (n);
end;
/
---------------------------------------------------
PROMPT *** specific deletes
----------------------------------------------------
declare
nrows number;
Stmt            varchar2(4000);
begin
  delete tbatch tba where not exists (select 1 from crevt cre where tba.tbaid = cre.tbaid);
  nrows := sql%rowcount;
  if nrows > 0 then
      dbms_output.put_line('TBATCH==>'|| to_char(nrows));
  end if;
   commit;

  Stmt := 'delete tbadetail tde where not exists (select 1 from tbatch tba where tba.tbaid = tde.tbaid)';
  execute immediate Stmt;
  dbms_output.put_line('DELETE TBADETAIL');
  Stmt := 'delete tbadetdata tda where not exists (select 1 from tbatch tba where tba.tbaid = tda.tbaid)';
  execute immediate Stmt;
  dbms_output.put_line('DELETE TBADETDATA');
   commit;
  exception
	  when others then  
          dbms_output.put_line(sqlcode||' '||sqlerrm);
end;
/
--------------------------------------------------------------
PROMPT *** DELETE DES LIENS VERS ADRESSE HORS ACTEUR, ADRESSE elle-meme et BANQUEGUICHET
-- ------------------------------------------------------------
set serveroutput on size 1000000
declare
cursor c1 is select distinct table_name from user_tab_columns join user_tables using (table_name) where column_name = 'ADRID' and table_name not in ('ACTADRESSE', 'ADRESSE', 'BANQUEGUICHET');
n integer;
nrows number;
begin
  n := dbms_sql.open_cursor;
  for c1rec in c1 loop
    begin
    nrows:=0;
    dbms_sql.parse(n, 'delete ' || c1rec.table_name, dbms_sql.native);
    nrows:=dbms_sql.execute(n);
    if nrows > 0 then
       dbms_output.put_line('DELETE '||c1rec.table_name||'==>'|| to_char(nrows));
    end if;
    exception
	  when others then 
          if (to_number(sqlcode) != -1702) then
            dbms_output.put_line(c1rec.table_name||'==>'||sqlcode||'**'||sqlerrm);
          end if;
    end;
     commit;
  end loop;
  
  dbms_sql.close_cursor (n);
end;
/
--------------------------------------------------------------
PROMPT *** DELETE DES ADRESSES INUTILES
-- ------------------------------------------------------------
set serveroutput on size 1000000
declare
n integer;
nrows number;
begin
  n := dbms_sql.open_cursor;
    nrows:=0;
    DBMS_SQL.PARSE(N, 
  'delete adresse where adrid not in (select adrid from actadresse union select adrid from banqueguichet where adrid is not null)', dbms_sql.native);
    nrows:=dbms_sql.execute(n);
    dbms_output.put_line('DELETE ADRESSE==>'|| to_char(nrows));
   commit;
  dbms_sql.close_cursor (n);
end;
/
---------------------------------------------------------------
PROMPT *** DELETE DES TABLES RIB et RIBINFO HORS RIBID ACTIDGESTION
-- ------------------------------------------------------------
set serveroutput on size 1000000
declare
cursor c1 is select distinct table_name from user_tables where table_name in ('RIB','RIBINFO');
n integer;
nrows number;
begin
  n := dbms_sql.open_cursor;
  for c1rec in c1 loop
    begin
    nrows:=0;
 	  dbms_sql.parse(n, 'delete ' || c1rec.table_name || ' where ribid not in (select ribid from actrib )', dbms_sql.native);
    nrows:=dbms_sql.execute(n);
    if nrows > 0 then
       dbms_output.put_line('DELETE '||c1rec.table_name||'==>'|| to_char(nrows));
    end if;
     commit;
    exception
	  when others then dbms_output.put_line(c1rec.table_name||'==>'||sqlcode||' '||sqlerrm);
    end;
  end loop;
  dbms_sql.close_cursor (n);
end;
/
---------------------------------------------
-- TRUNCATE SPECIFIC
---------------------------------------------
declare
  type tbl_vchar is table of varchar2(30);
  j integer;
  cursor c1 is select distinct table_name from user_tables where table_name like 'IMA%';
  cursor c2 is select distinct a.table_name from user_ind_columns a, user_constraints b where a.column_name like '%VARID%' and b.index_name = a.index_name and b.table_name = a.table_name and b.constraint_type = 'P';
  ListOfTablesBack tbl_vchar := tbl_vchar('AUDITECRITURE', 'ACTASSATTRIBUTE', 'ACTASSENT', 'ACTCONTOPIC', 'ACTCONTACT', 'ACTPROCEDUREEXT', 'ACTPROCEDURE', 'ACTPROJUGEMENTEXT', 'ACTPROJUGEMENT', 'ACTPROMEMO', 'ACTPROPHASE', 'ACTTCOVALEUR', 
                                      'ADMINISTRATIF', 'ADMRECIPIENT', 'BIMACTOR', 
                                      'CCHVALGRID', 'COLACTEUR', 'COLOBJECT', 'COMMANDE', 'COPPRICE', 'CRO', 'CROREJDETAIL', 'CUTOFF', 'DOCUMENTMANAGEMENT', 'DOCUMENTMANAGEMENTEXT',
                                      'FACECHEANCE', 'FACLIGACT', 'FRAUD', 
                                      'ITRRUBPHASE', 'ITRRUBREPOSSESSION', 
                                      'PLAN_TABLE', 'POOACTEUR',
                                      'RAPPORTCTL', 'RCTMSG', 'RCTMSGDATA', 'REGBORDEREAU', 'REGLEMENT', 'REGIMPUTATION', 'RIMFLA', 'SASPLANCOMPTABLE', 'SASREGLEMENT');
  ListOfTablesFront tbl_vchar := tbl_vchar('PFIGUARANTEE', 'PFITGR', 'PFIBASACTOR', 'PFCARO', 'LKAROPFR', 'PFPACTEUR', 'PFICOMMISSION', 'PROPOSITIONFINANCIERE',
                                           'ROACONST', 'ROAGENFLOW', 'ROASYNTHPARAM', 'SASRBMS');
begin
  if (SUBSTR(user,0,2)) = 'TR' then
    for i in ListOfTablesBack.first..ListOfTablesBack.last
    loop
      execute immediate 'select count(1) from user_tables where table_name like '''||ListOfTablesBack(i)||'''' into j;
      if j > 0 Then
         execute immediate 'truncate table ' || ListOfTablesBack(i);
        dbms_output.put_line('TRUNCATE '||ListOfTablesBack(i)||'==>'|| to_char(j));
      end if;
    end loop;
    for c1r in c1 loop
      begin
         execute immediate 'truncate table ' || c1r.table_name;
        dbms_output.put_line('TRUNCATE '||c1r.table_name);
      exception
	  when others then dbms_output.put_line(c1r.table_name||'==>'||sqlcode||' '||sqlerrm);
      end;
    end loop;
    for c2r in c2 loop
      begin
         execute immediate 'truncate table ' || c2r.table_name;
        dbms_output.put_line('TRUNCATE '||c2r.table_name);
      exception
	  when others then dbms_output.put_line(c2r.table_name||'==>'||sqlcode||' '||sqlerrm);
      end;
    end loop;
  end if;
  if (SUBSTR(user,0,2)) = 'AV' then
    for i in ListOfTablesFront.first..ListOfTablesFront.last
    loop
      execute immediate 'select count(1) from user_tables where table_name like '''||ListOfTablesFront(i)||'''' into j;
      if j > 0 Then
         execute immediate 'truncate table ' || ListOfTablesFront(i);
        dbms_output.put_line('TRUNCATE '||ListOfTablesFront(i)||'==>'|| to_char(j));
      end if;
    end loop;
  end if;
end;
/
-----------------------------------------
PROMPT *** FINAL DELETE
-----------------------------------------
declare 
  Stmt varchar2(4000);
begin
  for c1 in (select table_name, column_name from user_tab_columns join user_tables using (table_name) where column_name in ('ADMID', 'ANAID', 'CCAID', 'COLID', 'FACID', 'NOTID') and table_name not in ('MV_CCATARGET_DOSS'))
  loop
    stmt:= 'delete ' || c1.table_name || ' T where ' || c1.column_name || ' is not null and ' || c1.column_name || ' != 0';
    dbms_output.put_line(Stmt);
    execute immediate Stmt;
     commit;
  end loop;
end;
/
-----------------------------------------
PROMPT *** REMONTEE DES CONTRAINTES EN ENABLED
-- ---------------------------------------
DECLARE
	CURSOR C1 IS SELECT  constraint_name, table_name FROM  user_constraints WHERE  owner =
                     user AND  Constraint_type = 'R' AND status = 'DISABLED';
	n integer;
BEGIN
  n := dbms_sql.open_cursor;
  for c1rec in c1 loop
    begin
     dbms_sql.parse(n, 'alter table ' || c1rec.table_name || ' enable constraint ' || c1rec.constraint_name, dbms_sql.native);
    exception
     when others then
		dbms_output.put_line('Error : '|| c1rec.table_name || '-' || c1rec.constraint_name);
     end;
  end loop;
  dbms_sql.close_cursor (n);
END;
/
---------------------------------------------------
-- count final
---------------------------------------------------
declare
  cnt NUMBER;
begin
  for c1 in (select table_name from user_tables order by table_name)
  loop
    cnt := 0;
    execute immediate 'select count(1) from ' || c1.table_name into cnt;
    execute immediate 'insert into KSIOPPURGE values (:1, :2, ''AFTER'')' using c1.table_name, cnt; 
  end loop;
  execute immediate 'select count(1) from user_indexes' into cnt;
  execute immediate 'insert into KSIOPPURGE values (''INDEXES'', :1, ''AFTER'')' using cnt;
   commit;
end;
/
 exit;
/

