1- Réinitialiser le statut de migration de chaque ligne (FLAG_TRT) à null, pour qu'ils puissent être considérés dans prochain lancement.
=> Doit être refait sur la source 4.0 à chaque exercice de lancement

2- Purge des Acteur dans la DB cible 4.5
=> à lancer sur la cible 4.5

3- Purge des éléments FO 4.5 (dossiers prospects, etc.) car reliés aux acteurs purgés
=> à lancer sur la cible 4.5