delete from crevt where actid is not null;
delete from actrib where actid <> 2;
delete from actrib where actid in (select actid from actrole where rolcode<>'AGENCE' and actid<>2);
delete from ACTTCOVALEUR where actid in (select actid from actrole where rolcode<>'AGENCE' and actid<>2);
delete from LKACTTELCOR where actid in (select actid from actrole where rolcode<>'AGENCE' and actid<>2);
delete from LKACTCORADR where actid in (select actid from actrole where rolcode<>'AGENCE' and actid<>2);
delete from acttelecom where actid in (select actid from actrole where rolcode<>'AGENCE' and actid<>2);
delete from actcorrespondant where actid in (select actid from actrole where rolcode<>'AGENCE' and actid<>2);
delete from rib where ribid not in (select ribid from actrib where actid=2);
delete from adresse where adrid in (select adrid from actadresse where actid in (select actid from actrole where rolcode<>'AGENCE' and actid<>2));delete from actrib where actid in (select actid from actrole where rolcode<>'AGENCE' and actid<>2);
delete from actadresse where actid in (select actid from actrole where rolcode<>'AGENCE' and actid<>2);
delete from aroage where actid in (select actid from actrole where rolcode<>'AGENCE' and actid<>2);
delete from actrole where actid in (select actid from actrole where rolcode<>'AGENCE' and actid<>2);
delete from acteurparticulier where actid not in (select actid from actrole where rolcode='AGENCE' and actid=2);
delete from actphase where actid not in (select actid from actrole where rolcode='AGENCE' and actid=2);
delete from cchvalue where actid <> 2;
delete from LKACTUTITSM where  actid not in (select actid from actrole where rolcode='AGENCE' and actid=2) AND TSMMETIER in ('SGM12','SGM20') ;
delete from acteur where  actid not in (select actid from actrole where rolcode='AGENCE' and actid=2);


COMMIT;