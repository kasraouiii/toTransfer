00_ALTER_TRV4_ADD_FLAG_TRT_COLUMN.sql à lancer sur la source 4.0
=> Ajout d'une colonne statut nommée FLAG_TRT, dans les tables sources 4.0 relatives au module acteur.
=> Cette colonne peut être supprimée après succès injection