A lancer après la migration.
Affiche quelque statistiques sur la migration Acteur table par table :
- Eléments non considérés (hors scope tel que acteur de gestion ou en cours de migration)
- Eléménts migrés
- Eléments avec erreurs :
	. ayant généré des erreur lors de leur migration
	. il faut toujours vérifier les éléments avec le statut FLAG_TRT = 'E'
	. Certains éléments avec flag_trt = E sont quand-même injectés : exemple des ADRESSE partagées par plusieurs acteurs, ou les CREDATA.