--------------------------------------------------------
--  Fichier cr�� - lundi-octobre-25-2021   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package Body PAV4_JASPER_FO
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE PACKAGE BODY "PAV4_JASPER_FO" 
AS

FUNCTION F_GET_ACTOR_NAME (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                               nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
        nType     VARCHAR2 (4);
    BEGIN
        SELECT MAX (ACT.ACTTYPE)
          INTO nType
          FROM ACTEUR ACT, DPRACTEUR DAC, DOSSIERPROSPECT DPR
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND ACT.ACTID = DAC.ACTID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID;

        IF nType = 'P'
        THEN
            SELECT APA.APAPRENOM || ' ' || APA.APANOMPATRONYMIQUE
              INTO nResult
              FROM ACTEURPARTICULIER APA, DPRACTEUR DAC, DOSSIERPROSPECT DPR
             WHERE     DPR.DOSID = DAC.DOSID
                   AND DPR.DPRVERSION = DAC.DPRVERSION
                   AND APA.ACTID = DAC.ACTID
                   AND DPR.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                          FROM DUAL)
                   AND DAC.ROLCODE = nROLCODE
                   AND DPR.DOSID = nDOSID;
        ELSE
            SELECT MAX (ACT.ACTNOM)
              INTO nResult
              FROM ACTEUR ACT, DPRACTEUR DAC, DOSSIERPROSPECT DPR
             WHERE     DPR.DOSID = DAC.DOSID
                   AND DPR.DPRVERSION = DAC.DPRVERSION
                   AND ACT.ACTID = DAC.ACTID
                   AND DPR.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                          FROM DUAL)
                   AND DAC.ROLCODE = nROLCODE
                   AND DPR.DOSID = nDOSID;
        END IF;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ACTOR_NAME;
-----Utilise dans SGM45
    FUNCTION F_GET_ACTOR_NAME2 (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                               nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
        nType     VARCHAR2 (4);
    BEGIN
        SELECT MAX (ACT.ACTTYPE)
          INTO nType
          FROM ACTEUR ACT, DPRACTEUR DAC, DOSSIERPROSPECT DPR
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND ACT.ACTID = DAC.ACTID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID;

        IF nType = 'P'
        THEN
            SELECT APA.APAPRENOM || ' ' || APA.APANOMPATRONYMIQUE
              INTO nResult
              FROM ACTEURPARTICULIER APA, DPRACTEUR DAC, DOSSIERPROSPECT DPR
             WHERE     DPR.DOSID = DAC.DOSID
                   AND DPR.DPRVERSION = DAC.DPRVERSION
                   AND APA.ACTID = DAC.ACTID
                   AND DPR.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                          FROM DUAL)
                   AND DAC.ROLCODE = nROLCODE
                   AND DPR.DOSID = nDOSID;
        ELSE
            SELECT  (ACT.ACTNOM)
              INTO nResult
              FROM ACTEUR ACT, DPRACTEUR DAC, DOSSIERPROSPECT DPR
             WHERE     DPR.DOSID = DAC.DOSID
                   AND DPR.DPRVERSION = DAC.DPRVERSION
                   AND ACT.ACTID = DAC.ACTID
                   AND DPR.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                          FROM DUAL)
                   AND DAC.ROLCODE = nROLCODE
                   AND DPR.DOSID = nDOSID;
        END IF;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ACTOR_NAME2;

    --------------------------------------------------------------------------------------
    FUNCTION F_GET_ACTOR_NAME2 (nACTID        DPRACTEUR.ACTID%TYPE,
                                nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
        nType     VARCHAR2 (4);
    BEGIN
        SELECT MAX (ACT.ACTTYPE)
          INTO nType
          FROM ACTEUR ACT, DPRACTEUR DAC, DOSSIERPROSPECT DPR
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND ACT.ACTID = DAC.ACTID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID
               AND ACT.ACTID = nACTID;

        IF nType = 'EI'
        THEN
            SELECT MAX (APA.ACTNOM)
              INTO nResult
              FROM ACTEUR APA, DPRACTEUR DAC, DOSSIERPROSPECT DPR
             WHERE     DPR.DOSID = DAC.DOSID
                   AND DPR.DPRVERSION = DAC.DPRVERSION
                   AND APA.ACTID = DAC.ACTID
                   AND DPR.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                          FROM DUAL)
                   AND DAC.ROLCODE = nROLCODE
                   AND DPR.DOSID = nDOSID
                   AND APA.ACTID = nACTID;
        ELSE
            SELECT MAX (ACT.ACTNOM)
              INTO nResult
              FROM ACTEUR ACT, DPRACTEUR DAC, DOSSIERPROSPECT DPR
             WHERE     DPR.DOSID = DAC.DOSID
                   AND DPR.DPRVERSION = DAC.DPRVERSION
                   AND ACT.ACTID = DAC.ACTID
                   AND DPR.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                          FROM DUAL)
                   AND DAC.ROLCODE = nROLCODE
                   AND DPR.DOSID = nDOSID
                   AND ACT.ACTID = nACTID;
        END IF;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ACTOR_NAME2;

    --------------------------------------------------------------------------------
    FUNCTION F_GET_ACTOR_ADRESSE (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                  nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (4000);
    BEGIN
        SELECT    DECODE (ADR.ADRVOIE, NULL, '', ADR.ADRVOIE || ', ')
               || DECODE (ADR.ADRLIEUDIT, NULL, '', ADR.ADRLIEUDIT || ', ')
               || DECODE (ADR.ADRVILLE, NULL, '', ADR.ADRVILLE || ', ')
               || DECODE (ADR.ADRCODEPOST, NULL, '', ADR.ADRCODEPOST || ', ')
               || DECODE (ADR.ADRSUBREGION, NULL, '', ADR.ADRSUBREGION)
          INTO nResult
          FROM ADRESSE ADR
         WHERE ADR.ADRID =
               (SELECT MAX (ADR.ADRID)
                  FROM DOSSIERPROSPECT  DPR,
                       DPRACTEUR        DAC,
                       ADRESSE          ADR,
                       ACTADRESSE       AAD,
                       CODEPOSTAL       COP
                 WHERE     DPR.DOSID = DAC.DOSID
                       AND DPR.DPRVERSION = DAC.DPRVERSION
                       AND DPR.DPRVERSION =
                           (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                              FROM DUAL)
                       AND AAD.ACTID = DAC.ACTID
                       AND AAD.AADFLAGSIEGE = 1
                       AND ADR.ADRID = AAD.ADRID
                       AND ADR.ADRCODEPOST = COP.CPOCODE(+)
                       AND ADR.PAYCODE = COP.PAYCODE(+)
                       AND DAC.ROLCODE = nROLCODE
                       AND DPR.DOSID = nDOSID);


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ACTOR_ADRESSE;

    --------------------------------------------------------------------------------
    FUNCTION F_GET_ACTOR_ADRESSE (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                  nROLCODE      DPRACTEUR.ROLCODE%TYPE,
                                  sFLAG         VARCHAR2)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (4000);
    BEGIN
        SELECT    DECODE (ADR.ADRVOIE, NULL, '', ADR.ADRVOIE || ', ')
               || DECODE (ADR.ADRLIEUDIT, NULL, '', ADR.ADRLIEUDIT || ', ')
               || DECODE (ADR.ADRVILLE, NULL, '', ADR.ADRVILLE || ', ')
               || DECODE (ADR.ADRCODEPOST, NULL, '', ADR.ADRCODEPOST || ', ')
               || DECODE (ADR.ADRSUBREGION, NULL, '', ADR.ADRSUBREGION)
          INTO nResult
          FROM ADRESSE ADR
         WHERE ADR.ADRID =
               (SELECT MAX (ADR.ADRID)
                  FROM DOSSIERPROSPECT  DPR,
                       DPRACTEUR        DAC,
                       ADRESSE          ADR,
                       ACTADRESSE       AAD,
                       CODEPOSTAL       COP
                 WHERE     DPR.DOSID = DAC.DOSID
                       AND DPR.DPRVERSION = DAC.DPRVERSION
                       AND DPR.DPRVERSION =
                           (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                              FROM DUAL)
                       AND AAD.ACTID = DAC.ACTID
                       AND DECODE (sFLAG,
                                   'FACTURATION', AAD.AADFLAGFACTURATION,
                                   'SIEGE', AAD.AADFLAGSIEGE,
                                   'COURRIER', AAD.AADFLAGCOURRIER,
                                   'LIVRAISON', AAD.AADFLAGLIVRAISON) =
                           1
                       AND ADR.ADRID = AAD.ADRID
                       AND ADR.ADRCODEPOST = COP.CPOCODE(+)
                       AND ADR.PAYCODE = COP.PAYCODE(+)
                       AND DAC.ROLCODE = nROLCODE
                       AND DPR.DOSID = nDOSID);


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ACTOR_ADRESSE;

    ------------------------------------------------------------------------------------------
    ------------------------------------------------------------------------------------------
    FUNCTION F_GET_ACTOR_MATRICULE_FISC (
        nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
        nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT MAX (ACT.ACTSIRET)
          INTO nResult
          FROM DOSSIERPROSPECT DPR, DPRACTEUR DAC, ACTEUR ACT
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND ACT.ACTID = DAC.ACTID
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ACTOR_MATRICULE_FISC;

    --------------------------------------------------------------------------------------
    FUNCTION F_GET_ACTOR_CAPITAL (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                  nROLCODE   IN DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT ACT.ACTCAPITAL
          INTO nResult
          FROM ACTEUR ACT, DPRACTEUR DAC, DOSSIERPROSPECT DPR
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND ACT.ACTID = DAC.ACTID
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ACTOR_CAPITAL;


    ---------------------------------------------------------------------------------------
    FUNCTION F_GET_NUM_RC (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                           nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT ACT.ACTNUMRCM
          INTO nResult
          FROM DOSSIERPROSPECT DPR, DPRACTEUR DAC, ACTEUR ACT
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND ACT.ACTID = DAC.ACTID
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_NUM_RC;

    ---------------------------------------------------------------------------------------

    FUNCTION F_GET_TYPE_RC (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                            nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT LTR.TTPLIBELLE
          INTO nResult
          FROM DOSSIERPROSPECT  DPR,
               DPRACTEUR        DAC,
               ACTEUR           ACT,
               LANTTRPARAM      LTR
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND ACT.ACTID = DAC.ACTID
               AND LTR.TTRNOM = 'RCRM'
               AND LTR.LANCODE = 'FR'
               AND LTR.TTPCODE = ACT.ACTCODERCM
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_TYPE_RC;

    ------------------------------------------------------------------------------------------
    FUNCTION F_GET_ACTOR_VILLE (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT MAX (ADR.ADRSUBREGION)
          INTO nResult
          FROM DOSSIERPROSPECT  DPR,
               DPRACTEUR        DAC,
               ADRESSE          ADR,
               ACTADRESSE       AAD,
               CODEPOSTAL       COP
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND AAD.ACTID = DAC.ACTID
               AND AAD.AADFLAGSIEGE = 1
               AND ADR.ADRID = AAD.ADRID
               AND ADR.ADRCODEPOST = COP.CPOCODE
               AND ADR.PAYCODE = COP.PAYCODE
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ACTOR_VILLE;

    -------------------------------------------------------------------------------------------
    FUNCTION F_GET_ACTOR_CONTACT (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                  nROLCODE      DPRACTEUR.ROLCODE%TYPE,
                                  nTUPCODE      LANTUSPARAM.TUPCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        IF nTUPCODE IS NULL
        THEN
            SELECT ACC.ACOPRENOM || ' ' || ACC.ACONOM
              INTO nResult
              FROM DOSSIERPROSPECT   DPR,
                   DPRACTEUR         DAC,
                   ACTEUR            ACT,
                   LANTUSPARAM       LAN,
                   ACTCORRESPONDANT  ACC
             WHERE     DPR.DOSID = DAC.DOSID
                   AND DPR.DPRVERSION = DAC.DPRVERSION
                   AND DPR.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                          FROM DUAL)
                   AND ACT.ACTID = DAC.ACTID
                   AND LAN.TUSNOM = 'QUALITE'
                   AND LAN.LANCODE = 'FR'
                   AND ACT.ACTID = ACC.ACTID
                   AND ACT.ACTID = DAC.ACTID
                   AND ACC.ACOQUALITE = LAN.TUPCODE
                   AND ACC.ACOFLAGPREFERE = 1
                   --AND ACC.ACOORDRE = (SELECT MIN(ACC2.ACOORDRE) FROM ACTCORRESPONDANT ACC2 WHERE ACC2.ACTID=ACC.ACTID AND ACC2.ACOFLAGPREFERE=1)
                   AND DAC.ROLCODE = nROLCODE
                   AND DPR.DOSID = nDOSID;
        ELSE
            SELECT ACC.ACOPRENOM || ' ' || ACC.ACONOM
              INTO nResult
              FROM DOSSIERPROSPECT   DPR,
                   DPRACTEUR         DAC,
                   ACTEUR            ACT,
                   LANTUSPARAM       LAN,
                   ACTCORRESPONDANT  ACC
             WHERE     DPR.DOSID = DAC.DOSID
                   AND DPR.DPRVERSION = DAC.DPRVERSION
                   AND DPR.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                          FROM DUAL)
                   AND ACT.ACTID = DAC.ACTID
                   AND LAN.TUSNOM = 'QUALITE'
                   AND LAN.LANCODE = 'FR'
                   AND ACT.ACTID = ACC.ACTID
                   --AND ACC.ACOORDRE= (SELECT MAX(ACOORDRE) FROM ACTCORRESPONDANT WHERE ACTID=ACC.ACTID AND ACOQUALITE=ACC.ACOQUALITE AND ACOFLAGPREFERE=1)
                   AND ACC.ACOQUALITE = LAN.TUPCODE
                   --AND ACC.ACOFLAGPREFERE=1
                   AND LAN.TUPCODE = nTUPCODE
                   AND DAC.ROLCODE = nROLCODE
                   AND DPR.DOSID = nDOSID;
        END IF;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ACTOR_CONTACT;

    ------------------------------------------------------------------------------------------
    FUNCTION F_GET_ACTOR_QUALITE (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                  nROLCODE      DPRACTEUR.ROLCODE%TYPE,
                                  nTUPCODE      LANTUSPARAM.TUPCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT LAN.TUPLIBELLE
          INTO nResult
          FROM DOSSIERPROSPECT   DPR,
               DPRACTEUR         DAC,
               ACTEUR            ACT,
               LANTUSPARAM       LAN,
               ACTCORRESPONDANT  ACC
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND ACT.ACTID = DAC.ACTID
               AND LAN.TUSNOM = 'QUALITE'
               AND LAN.LANCODE = 'FR'
               AND ACT.ACTID = ACC.ACTID
               AND ACC.ACOQUALITE = LAN.TUPCODE
               AND LAN.TUPCODE = nTUPCODE
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ACTOR_QUALITE;

    -------------------------------------------------------------------------------------------
    FUNCTION F_GET_ACTOR_TYPE (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                               nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT ACT.ACTTYPE
          INTO nResult
          FROM DOSSIERPROSPECT DPR, DPRACTEUR DAC, ACTEUR ACT
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND ACT.ACTID = DAC.ACTID
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ACTOR_TYPE;

    ----------------------------------------------------------------------------------------------
    FUNCTION F_GET_ACTOR_CODE (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                               nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT ACT.ACTCODE
          INTO nResult
          FROM DOSSIERPROSPECT DPR, DPRACTEUR DAC, ACTEUR ACT
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND ACT.ACTID = DAC.ACTID
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ACTOR_CODE;

    ----------------------------------------------------------------------------------------
    FUNCTION F_GET_ACTOR_JOB (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                              nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT LAN.TUPLIBELLE
          INTO nResult
          FROM ACTEUR            ACT,
               LANTUSPARAM       LAN,
               DPRACTEUR         DACT,
               DOSSIERPROSPECT   DPR,
               ACTCORRESPONDANT  ACC
         WHERE     LAN.TUSNOM = 'PROFESSION'
               AND LAN.LANCODE = 'FR'
               AND ACT.ACTID = ACC.ACTID
               AND ACC.ACOQUALITE = LAN.TUPCODE
               AND ACT.ACTID = DACT.ACTID
               AND DACT.DOSID = DPR.DOSID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (nDOSID)) FROM DUAL)
               AND DPR.DPRVERSION = DACT.DPRVERSION
               AND DACT.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ACTOR_JOB;

    -------------------------------------------------------------------------------------------
    FUNCTION F_GET_ACTOR_BIRTHDATE (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                    nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
        nType     VARCHAR2 (4);
    BEGIN
        SELECT ACT.ACTTYPE
          INTO nType
          FROM ACTEUR ACT, DPRACTEUR DAC, DOSSIERPROSPECT DPR
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND ACT.ACTID = DAC.ACTID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID;

        IF nType = 'EI'
        THEN
            SELECT TO_CHAR (APA.APADTNAISS, 'DD/MM/YYYY')
              INTO nResult
              FROM ACTEURPARTICULIER APA, DPRACTEUR DAC, DOSSIERPROSPECT DPR
             WHERE     DPR.DOSID = DAC.DOSID
                   AND DPR.DPRVERSION = DAC.DPRVERSION
                   AND APA.ACTID = DAC.ACTID
                   AND DPR.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                          FROM DUAL)
                   AND DAC.ROLCODE = nROLCODE
                   AND DPR.DOSID = nDOSID;
        ELSE
            SELECT TO_CHAR (ACT.ACTDTCREAT, 'DD/MM/YYYY')
              INTO nResult
              FROM ACTEUR ACT, DPRACTEUR DAC, DOSSIERPROSPECT DPR
             WHERE     DPR.DOSID = DAC.DOSID
                   AND DPR.DPRVERSION = DAC.DPRVERSION
                   AND ACT.ACTID = DAC.ACTID
                   AND DPR.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                          FROM DUAL)
                   AND DAC.ROLCODE = nROLCODE
                   AND DPR.DOSID = nDOSID;
        END IF;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ACTOR_BIRTHDATE;

    -------------------------------------------------------------------------------------------
    FUNCTION F_GET_ACTOR_BIRTHPLACE (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                     nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
        nType     VARCHAR2 (4);
    BEGIN
        SELECT ACT.ACTTYPE
          INTO nType
          FROM ACTEUR ACT, DPRACTEUR DAC, DOSSIERPROSPECT DPR
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND ACT.ACTID = DAC.ACTID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID;

        IF nType = 'EI'
        THEN
            SELECT APA.APAVILLENAISS
              INTO nResult
              FROM ACTEURPARTICULIER APA, DPRACTEUR DAC, DOSSIERPROSPECT DPR
             WHERE     DPR.DOSID = DAC.DOSID
                   AND DPR.DPRVERSION = DAC.DPRVERSION
                   AND APA.ACTID = DAC.ACTID
                   AND DPR.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                          FROM DUAL)
                   AND DAC.ROLCODE = nROLCODE
                   AND DPR.DOSID = nDOSID;
        END IF;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ACTOR_BIRTHPLACE;

    --------------------------------------------------------------------------------------------
    FUNCTION F_GET_ACTOR_TRADE_NAME (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                     nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT ACT.ACTLIBCOURT
          INTO nResult
          FROM DOSSIERPROSPECT DPR, DPRACTEUR DAC, ACTEUR ACT
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND ACT.ACTID = DAC.ACTID
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ACTOR_TRADE_NAME;

    ---------------------------------------------------------------------------------------------
    FUNCTION F_GET_CC (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                       nROLCODE      DPRACTEUR.ROLCODE%TYPE,
                       nCCHSID       CAS_CCHVALUE.CCHSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult    VARCHAR2 (100);
        nResult1   VARCHAR2 (100);
        sType      customcharacteristic.comtype%TYPE;
        sTusnom    tusparam.tusnom%TYPE;
    BEGIN
        SELECT comtype
          INTO sType
          FROM customcharacteristic
         WHERE cchsid = nCCHSID;

        SELECT CCH.CVASTRINGVALUE
          INTO nResult1
          FROM DOSSIERPROSPECT  DPR,
               DPRACTEUR        DAC,
               ACTEUR           ACT,
               CCHVALUE         CCH
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND ACT.ACTID = DAC.ACTID
               AND CCH.ACTID = ACT.ACTID
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID
               AND CCH.CCHSID = nCCHSID;


        IF stype = 'COMBOTUSPARAM'
        THEN
            SELECT MAX (ccpvalue)
              INTO sTusnom
              FROM lkcchcpr
             WHERE cchsid = nCCHSID AND cprpropertyname = 'tableCode';

            SELECT MAX (tuplibelle)
              INTO nResult
              FROM lantusparam
             WHERE tusnom = sTusnom AND tupcode = nResult1 AND lancode = 'FR';
        ELSE
            nResult := nResult1;
        END IF;



        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_CC;

    ---------------------------------------------------------------------------------------------
    FUNCTION F_GET_CC_ACT (nACTID    IN ACTEUR.ACTID%TYPE,
                           nCCHSID      CCHVALUE.CCHSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult    VARCHAR2 (100);
        nResult1   VARCHAR2 (100);
        sType      customcharacteristic.comtype%TYPE;
        sTusnom    tusparam.tusnom%TYPE;
    BEGIN
        SELECT comtype
          INTO sType
          FROM customcharacteristic
         WHERE cchsid = nCCHSID and ENTCODE='ACTEUR';

        SELECT DECODE (sType,
                       'DECIMAL', TO_CHAR (CCH.CVANUMERICVALUE),
                       CCH.CVASTRINGVALUE)
          INTO nResult1
          FROM ACTEUR ACT, CCHVALUE CCH
         WHERE     CCH.ACTID = ACT.ACTID
               AND ACT.ACTID = nACTID
               AND CCH.CCHSID = nCCHSID;


        IF stype = 'COMBOTUSPARAM'
        THEN
            SELECT MAX (ccpvalue)
              INTO sTusnom
              FROM lkcchcpr
             WHERE cchsid = nCCHSID AND cprpropertyname = 'tableCode';

            SELECT MAX (tuplibelle)
              INTO nResult
              FROM lantusparam
             WHERE tusnom = sTusnom AND tupcode = nResult1 AND lancode = 'FR';
        ELSE
            nResult := nResult1;
        END IF;



        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_CC_ACT;

    ---------------------------------------------------------------------------------------------
    FUNCTION F_GET_CC_DT_ACT (nACTID    IN ACTEUR.ACTID%TYPE,
                              nCCHSID      CCHVALUE.CCHSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT TO_CHAR (CCH.CVADTVALUE, 'DD/MM/YYYY')
          INTO nResult
          FROM ACTEUR ACT, CAS_CCHVALUE CCH
         WHERE     CCH.ACTID = ACT.ACTID
               AND ACT.ACTID = nACTID
               AND CCH.CCHSID = nCCHSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_CC_DT_ACT;

    ---------------------------------------------------------------------------------------------
    FUNCTION F_GET_CC_DOS (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                           nROLCODE      DPRACTEUR.ROLCODE%TYPE,
                           nCCHSID       CAS_CCHVALUE.CCHSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult    VARCHAR2 (100);
        nResult1   VARCHAR2 (100);
        sType      customcharacteristic.comtype%TYPE;
        sTusnom    tusparam.tusnom%TYPE;
    BEGIN
        SELECT comtype
          INTO sType
          FROM customcharacteristic
         WHERE cchsid = nCCHSID;

        SELECT CCH.CVASTRINGVALUE
          INTO nResult1
          FROM DOSSIERPROSPECT  DPR,
               DPRACTEUR        DAC,
               ACTEUR           ACT,
               CCHVALUE         CCH
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND ACT.ACTID = DAC.ACTID
               AND CCH.DOSIDPROSPECT = DPR.DOSID
               AND CCH.DPRVERSION = DPR.DPRVERSION
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID
               AND CCH.CCHSID = nCCHSID;


        IF stype = 'COMBOTUSPARAM'
        THEN
            SELECT MAX (ccpvalue)
              INTO sTusnom
              FROM lkcchcpr
             WHERE cchsid = nCCHSID AND cprpropertyname = 'tableCode';

            SELECT MAX (tuplibelle)
              INTO nResult
              FROM lantusparam
             WHERE tusnom = sTusnom AND tupcode = nResult1 AND lancode = 'FR';
        ELSE
            nResult := nResult1;
        END IF;



        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_CC_DOS;

    ---------------------------------------------------------------------------------------------
    FUNCTION F_GET_CC_DT (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                          nROLCODE      DPRACTEUR.ROLCODE%TYPE,
                          nCCHSID       CAS_CCHVALUE.CCHSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT TO_CHAR (CCH.CVADTVALUE, 'DD/MM/YYYY')
          INTO nResult
          FROM DOSSIERPROSPECT  DPR,
               DPRACTEUR        DAC,
               ACTEUR           ACT,
               CAS_CCHVALUE     CCH
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND ACT.ACTID = DAC.ACTID
               AND CCH.ACTID = ACT.ACTID
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID
               AND CCH.CCHSID = nCCHSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_CC_DT;

    --------------------------------------------------------------------------------------------------

    FUNCTION F_GET_DESIGN_TOUS_COMPOSANT (
        nDOSID   IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (1000);
    BEGIN
        nResult := '';

        FOR REC
            IN (SELECT DPR.DPMLIBELLE AS MAT
                  FROM DPRMATERIEL DPR
                 WHERE     DPR.DOSID = nDOSID
                       AND DPR.dprversion =
                           (SELECT MAX (F_DERNIEREVERSIONDOSSIER (dosid))
                              FROM DUAL))
        LOOP
            IF REC.MAT IS NOT NULL
            THEN
                nResult := nResult || REC.MAT || ',';
            END IF;
        END LOOP;

        IF LENGTH (nResult) > 1
        THEN
            SELECT SUBSTR (nResult, 1, LENGTH (nResult) - 1)
              INTO nResult
              FROM DUAL;
        END IF;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_DESIGN_TOUS_COMPOSANT;


    FUNCTION F_GET_DESIGN_COMPOSANT (
        nITRID      IN ITRRUBCOMPOSANT.ITRID%TYPE,
        nIRUORDRE      ITRRUBCOMPOSANT.IRUORDRE%TYPE,
        nIRCORDRE      ITRRUBCOMPOSANT.IRCORDRE%TYPE)
        RETURN VARCHAR2
    IS
        sResult   VARCHAR2 (500);
    BEGIN
        SELECT IRC.IRCDESIGN
          INTO sResult
          FROM itrrubcomposant IRC
         WHERE     IRC.itrid = nITRID
               AND IRC.iruordre = nIRUORDRE
               AND IRC.ircordre = nIRCORDRE;

        RETURN sResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_DESIGN_COMPOSANT;



    FUNCTION F_GET_CC_IMMO (nDOSID      IN DOSSIERPROSPECT.DOSID%TYPE,
                            nCCHSID        CAS_CCHVALUE.CCHSID%TYPE,
                            nDPMORDRE   IN DPRMATERIEL.DPMORDRE%TYPE)
        RETURN VARCHAR2
    IS
        sResult1   VARCHAR2 (100);
        sResult    VARCHAR2 (100);
        sType      VARCHAR2 (100);
    BEGIN
        SELECT comtype
          INTO sType
          FROM customcharacteristic
         WHERE cchsid = nCCHSID;

        SELECT CCH.CVASTRINGVALUE
          INTO sResult1
          FROM CCHVALUE CCH
         WHERE     CCH.DOSIDPROSPECT = nDOSID
               AND CCH.CCHSID = nCCHSID
               AND CCH.CVAID =
                   (SELECT MAX (CVAID)
                      FROM CCHVALUE
                     WHERE     CCHSID = nCCHSID
                           AND DOSIDPROSPECT = nDOSID
                           AND CCH.DPRVERSION =
                               (SELECT MAX (
                                           F_DERNIEREVERSIONDOSSIER (
                                               CCH.DOSIDPROSPECT))
                                  FROM DUAL)
                           AND CVAPKEYVALUE =
                                  'Dosid-'
                               || nDOSID
                               || '||Dprversion-'
                               || CCH.DPRVERSION
                               || '||Dpmordre-'
                               || nDPMORDRE
                               || '||');

        IF sType = 'COMBOTUSPARAM'
        THEN
            SELECT lantusparam.tuplibelle
              INTO sResult
              FROM lkcchcpr, lantusparam
             WHERE     lkcchcpr.cchsid = nCCHSID
                   AND lkcchcpr.cprpropertyname = 'tableCode'
                   AND lantusparam.lancode = 'FR'
                   AND lantusparam.tusnom = ccpvalue
                   AND lantusparam.tupcode = sResult1;
        ELSE
            sResult := sResult1;
        END IF;

        RETURN sResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_CC_IMMO;

    --------------------------------------------------------------------------------------------------
    FUNCTION F_GET_CC_NUM_IMMO (nDOSID      IN DOSSIERPROSPECT.DOSID%TYPE,
                                nCCHSID        CAS_CCHVALUE.CCHSID%TYPE,
                                nDPMORDRE   IN DPRMATERIEL.DPMORDRE%TYPE)
        RETURN NUMBER
    IS
        sResult1   NUMBER;
        sResult    VARCHAR2 (100);
        sType      VARCHAR2 (100);
    BEGIN
        SELECT comtype
          INTO sType
          FROM customcharacteristic
         WHERE cchsid = nCCHSID;

        SELECT CCH.CVANUMERICVALUE
          INTO sResult1
          FROM CCHVALUE CCH
         WHERE     CCH.DOSIDPROSPECT = nDOSID
               AND CCH.CCHSID = nCCHSID
               AND CCH.CVAID =
                   (SELECT MAX (CVAID)
                      FROM CCHVALUE
                     WHERE     CCHSID = nCCHSID
                           AND DOSIDPROSPECT = nDOSID
                           AND CCH.DPRVERSION =
                               (SELECT MAX (
                                           F_DERNIEREVERSIONDOSSIER (
                                               CCH.DOSIDPROSPECT))
                                  FROM DUAL)
                           AND CVAPKEYVALUE =
                                  'Dosid-'
                               || nDOSID
                               || '||Dprversion-'
                               || CCH.DPRVERSION
                               || '||Dpmordre-'
                               || nDPMORDRE
                               || '||');

        IF sType = 'COMBOTUSPARAM'
        THEN
            SELECT lantusparam.tuplibelle
              INTO sResult
              FROM lkcchcpr, lantusparam
             WHERE     lkcchcpr.cchsid = nCCHSID
                   AND lkcchcpr.cprpropertyname = 'tableCode'
                   AND lantusparam.lancode = 'FR'
                   AND lantusparam.tusnom = ccpvalue
                   AND lantusparam.tupcode = sResult1;
        ELSE
            sResult := sResult1;
        END IF;

        RETURN sResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_CC_NUM_IMMO;

    --------------------------------------------------------------------------------------------------
    FUNCTION F_GET_CC_IMMO_BOOLEAN (nDOSID      IN DOSSIERPROSPECT.DOSID%TYPE,
                                    nCCHSID        CAS_CCHVALUE.CCHSID%TYPE,
                                    nDPMORDRE   IN DPRMATERIEL.DPMORDRE%TYPE)
        RETURN VARCHAR2
    IS
        sResult   VARCHAR2 (100);
    BEGIN
        SELECT CCH.CVABOOLEANVALUE
          INTO sResult
          FROM CCHVALUE CCH
         WHERE     CCH.DOSIDPROSPECT = nDOSID
               AND CCH.CCHSID = nCCHSID
               AND CCH.CVAID =
                   (SELECT MAX (CVAID)
                      FROM CCHVALUE
                     WHERE     CCHSID = nCCHSID
                           AND DOSIDPROSPECT = nDOSID
                           AND CCH.DPRVERSION =
                               (SELECT MAX (
                                           F_DERNIEREVERSIONDOSSIER (
                                               CCH.DOSIDPROSPECT))
                                  FROM DUAL)
                           AND CVAPKEYVALUE =
                                  'Dosid-'
                               || nDOSID
                               || '||Dprversion-'
                               || CCH.DPRVERSION
                               || '||Dpmordre-'
                               || nDPMORDRE
                               || '||');

        RETURN sResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_CC_IMMO_BOOLEAN;

    ------------------------------------------------------------------------------------------------------
    FUNCTION F_GET_CC_DT_IMMO (nDOSID      IN DOSSIERPROSPECT.DOSID%TYPE,
                               nCCHSID        CAS_CCHVALUE.CCHSID%TYPE,
                               nDPMORDRE   IN DPRMATERIEL.DPMORDRE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT TO_CHAR (CCH.CVADTVALUE, 'DD/MM/YYYY')
          INTO nResult
          FROM CCHVALUE CCH
         WHERE     CCH.DOSIDPROSPECT = nDOSID
               AND CCH.CCHSID = nCCHSID
               AND CCH.CVAID =
                   (SELECT MAX (CVAID)
                      FROM CCHVALUE
                     WHERE     CCHSID = nCCHSID
                           AND DOSIDPROSPECT = nDOSID
                           AND CCH.DPRVERSION =
                               (SELECT MAX (
                                           F_DERNIEREVERSIONDOSSIER (
                                               CCH.DOSIDPROSPECT))
                                  FROM DUAL)
                           AND CVAPKEYVALUE =
                                  'Dosid-'
                               || nDOSID
                               || '||Dprversion-'
                               || CCH.DPRVERSION
                               || '||Dpmordre-'
                               || nDPMORDRE
                               || '||');



        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_CC_DT_IMMO;

    --------------------------------------------------------------------------------------------------------

    FUNCTION F_GET_NB_LOYERS (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT PRO.PFINBPERIODES
          INTO nResult
          FROM PROPOSITIONFINANCIERE PRO, DPRPROPFINANCE DPR
         WHERE     DPR.PFIID = PRO.PFIID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND DPR.DPFORDRE = (SELECT MAX (DPFORDRE)
                                     FROM DPRPROPFINANCE
                                    WHERE DOSID = DPR.DOSID)
               AND DPR.DPFFLAGRETENUE = 1
               AND DPR.DOSID = nDOSID;


        /*SELECT COUNT(PFI.PECDTDUE)
        INTO nResult
               FROM PFIRUBECHEANCIER  PFI, DPRPROPFINANCE DPR
               WHERE DPR.PFIID=PFI.PFIID
               AND DPR.DPRVERSION = (SELECT MAX(F_DERNIEREVERSIONDOSSIER(DPR.DOSID)) FROM DUAL)
               AND DPR.DPFORDRE = (SELECT MAX(DPFORDRE) FROM DPRPROPFINANCE DPR WHERE DPR.DOSID=nDOSID)
               AND PFI.PECTYPEELEMENT='LOYER'
               AND DPR.DPFFLAGRETENUE=1
               AND DPR.DOSID=nDOSID;
    */

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_NB_LOYERS;

    ---------------------------------------------------------------------------------------------

    FUNCTION F_GET_NB_LOYERS_HORS_1ER (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult    VARCHAR2 (100);
        nPremier   NUMBER;
    BEGIN
        SELECT NVL (PFIMTPREMIERLOYER, 0)
          INTO nPremier
          FROM PROPOSITIONFINANCIERE PFI, DPRPROPFINANCE DPR
         WHERE     DPR.PFIID = PFI.PFIID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND DPR.DPFFLAGRETENUE = 1
               AND DPR.DOSID = nDOSID;

        SELECT PFINBPERIODES
          INTO nResult
          FROM PROPOSITIONFINANCIERE PFI, DPRPROPFINANCE DPR
         WHERE     DPR.PFIID = PFI.PFIID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND DPR.DPFFLAGRETENUE = 1
               AND DPR.DOSID = nDOSID;

        IF nPremier = 0
        THEN
            RETURN nResult;
        ELSE
            RETURN nResult - 1;
        END IF;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN 0;
    /*  nResult varchar2(100) ;

        BEGIN

        SELECT PRO.PFINBPERIODES-1
        INTO nResult
               FROM PROPOSITIONFINANCIERE  PRO, DPRPROPFINANCE DPR
               WHERE DPR.PFIID=PRO.PFIID
               AND DPR.DPRVERSION = (SELECT MAX(F_DERNIEREVERSIONDOSSIER(DPR.DOSID)) FROM DUAL)
               AND DPR.DPFORDRE = (SELECT MAX(DPFORDRE) FROM DPRPROPFINANCE WHERE DOSID=DPR.DOSID)
               AND DPR.DPFFLAGRETENUE=1
               AND DPR.DOSID=nDOSID;
        */

    /*SELECT COUNT(PFI.PECDTDUE)-1
    INTO nResult
           FROM PFIRUBECHEANCIER  PFI, DPRPROPFINANCE DPR
           WHERE DPR.PFIID=PFI.PFIID
           AND DPR.DPRVERSION = (SELECT MAX(F_DERNIEREVERSIONDOSSIER(DPR.DOSID)) FROM DUAL)
          -- AND DPR.DPFORDRE = (SELECT MAX(DPFORDRE) FROM DPRPROPFINANCE DPR WHERE DPR.DOSID=nDOSID)
           AND DPR.DPFFLAGRETENUE=1
           AND PFI.PECTYPEELEMENT='LOYER'
           AND DPR.DOSID=nDOSID;*/
    /*

        RETURN nResult;

        EXCEPTION WHEN OTHERS THEN
          RETURN null;*/

    END F_GET_NB_LOYERS_HORS_1ER;


    ---------------------------------------------------------------------------------------------
    FUNCTION F_GET_JOUR_PAIEMENT (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT EXTRACT (DAY FROM MIN (PFI.PECDTDUE))
          INTO nResult
          FROM PFIRUBECHEANCIER PFI, DPRPROPFINANCE DPR
         WHERE     DPR.PFIID = PFI.PFIID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND DPR.DPFORDRE =
                   (SELECT MAX (DPFORDRE)
                      FROM DPRPROPFINANCE DPR
                     WHERE DPR.DOSID = nDOSID AND DPR.DPFFLAGRETENUE = 1)
               AND PFI.PECTYPEELEMENT = 'LOYER'
               AND DPR.DPFFLAGRETENUE = 1
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_JOUR_PAIEMENT;

    ----------------------------------------------------------------------------------------------

    FUNCTION F_GET_SUM_LOYERS_TTC (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT SUM (PFI.PECMTBASIC) + SUM (PFI.PECMTTAX)
          INTO nResult
          FROM PFIRUBECHEANCIER PFI, DPRPROPFINANCE DPR
         WHERE     DPR.PFIID = PFI.PFIID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               -- AND DPR.DPFORDRE = (SELECT MAX(DPFORDRE) FROM DPRPROPFINANCE DPR WHERE DPR.DOSID=nDOSID)
               AND PFI.PECTYPEELEMENT = 'LOYER'
               AND DPR.DPFFLAGRETENUE = 1
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN 0;
    END F_GET_SUM_LOYERS_TTC;


    ----------------------------------------------------------------------------------------------
    FUNCTION F_GET_1ER_LOYER (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE ,nCONTEXT varchar2)
        RETURN NUMBER
    IS
        nResult   VARCHAR2 (100);
    BEGIN
       IF nCONTEXT = 'FO'

       THEN

        SELECT (  (PFIMTPREMIERLOYER + NVL (PPR.PFPMT, 0))
                * ((TTAVAL + 100) / 100))
          INTO nResult
          FROM DPRPROPFINANCE         DPR,
               PROPOSITIONFINANCIERE  PRO,
               PFIRUBRIQUE            PFI,
               PFIPRESTATION          PPR,
               DOSSIERPROSPECT        DOS,
               TAXTAUX                TXT
         WHERE     PRO.PFIID = DPR.PFIID
               AND PFI.PFIID = DPR.PFIID
               AND DPR.PFIID = PPR.PFIID(+)
               AND DOS.TAXCODE = TXT.TAXCODE
               AND DOS.DOSID = DPR.DOSID
               AND DOS.DPRVERSION = DPR.DPRVERSION
               AND DPR.DOSID = nDOSID
               AND DPR.DPRVERSION = (SELECT DPRVERSION
                                       FROM V_DEAL VDE
                                      WHERE VDE.DOSID = DPR.DOSID)
               AND TTADTFIN IS NULL
               AND DPR.DPFFLAGRETENUE = 1;
         ELSIF  nCONTEXT ='BO'
         THEN
         SELECT NVL (
                  DRF.DRFMT
                + (DRF.DRFMT * NVL (F_GETTAUXTAXE (DRU.TAXCODE), 0)),
                0)
        INTO nResult
        FROM DOSRUBRIQUE DRU, DOSRUBFLUX DRF
       WHERE     DRU.DOSID = nDOSID
             AND DRU.DRUORDRE =
                    (SELECT MIN (DRUORDRE)
                       FROM DOSRUBRIQUE
                      WHERE     DOSID = DRU.DOSID
                            AND RUBID IN (SELECT RUBID
                                            FROM RUBACCES
                                           WHERE RACACCES = 'REDFIN'))
             AND DRU.DOSID = DRF.DOSID
             AND DRU.DRUORDRE = DRF.DRUORDRE
             AND DRF.DRFNBPERIODE = 1;
        END IF ;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_1ER_LOYER;

    ----------------------------------------------------------------------------------------------
    FUNCTION F_GET_1ER_LOYER_HORS_TAXE (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT NVL(PFIMTPREMIERLOYER,0)
          INTO nResult
          FROM PROPOSITIONFINANCIERE PFI, DPRPROPFINANCE DPR
         WHERE     DPR.PFIID = PFI.PFIID
               AND DPR.DPRVERSION = F_DERNIEREVERSIONDOSSIER(DPR.DOSID)
               AND DPR.DPFFLAGRETENUE = 1
               AND DPR.DOSID = nDOSID;

        /*SELECT SUM(PFI.PECMTBASIC)+SUM(PFI.PECMTINCIDENTAL)
        INTO nResult
               FROM PFIRUBECHEANCIER  PFI, DPRPROPFINANCE DPR
               WHERE DPR.PFIID=PFI.PFIID
               AND DPR.DPRVERSION = (SELECT MAX(F_DERNIEREVERSIONDOSSIER(DPR.DOSID)) FROM DUAL)
              -- AND DPR.DPFORDRE = (SELECT MAX(DPFORDRE) FROM DPRPROPFINANCE DPR WHERE DPR.DOSID=nDOSID)
               AND PFI.PECTYPEELEMENT='LOYER'
               AND PFI.PECDTDUE = (SELECT MIN(PECDTDUE) FROM PFIRUBECHEANCIER
                               where PFIID=PFI.PFIID and PECTYPEELEMENT='LOYER')
               AND DPR.DOSID=nDOSID;*/


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_1ER_LOYER_HORS_TAXE;

    ---------------------------------------------------------------------------------------------
    FUNCTION F_GET_TAXE_1ER_LOYER (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        /*    SELECT  NVL(PFIMTPREMIERLOYER * NVL(F_GETTAUXTAXE(DPR.TAXCODE)/100, 0),0)
         INTO nResult
                  FROM PROPOSITIONFINANCIERE PFI, DPRPROPFINANCE DPF, DOSSIERPROSPECT DPR
                  WHERE DPF.PFIID=PFI.PFIID
                  AND DPR.DOSID=DPF.DOSID
                  AND DPR.DPRVERSION=DPF.DPRVERSION
                  AND DPR.DPRVERSION = (SELECT DPRVERSION FROM V_DEAL VDE WHERE VDE.DOSID = DPR.DOSID )
                  AND DPF.DPFFLAGRETENUE=1
                  AND DPR.DOSID=nDOSID;*/



        SELECT   (  PAV4_JASPER_FO.F_GET_1ER_LOYER_HORS_TAXE (nDOSID)
                  + NVL (PAV4_JASPER_FO.F_GET_FRAIS_ASSUR (nDOSID), 0))
               * (TTAVAL / 100)
          INTO nResult
          FROM DPRPROPFINANCE DPR, DOSSIERPROSPECT DOS, TAXTAUX TXT
         WHERE     DPR.DOSID = nDOSID
               AND DOS.TAXCODE = TXT.TAXCODE
               AND DOS.DOSID = DPR.DOSID
               AND DOS.DPRVERSION = DPR.DPRVERSION
               AND DPR.DPRVERSION = (SELECT DPRVERSION
                                       FROM V_DEAL VDE
                                      WHERE VDE.DOSID = DPR.DOSID)
               AND TXT.TTADTFIN IS NULL
               AND DPR.DPFFLAGRETENUE = 1;


        /*SELECT SUM(PFI.PECMTTAX)
        INTO nResult
               FROM PFIRUBECHEANCIER  PFI, DPRPROPFINANCE DPR
               WHERE DPR.PFIID=PFI.PFIID
               AND DPR.DPRVERSION = (SELECT MAX(F_DERNIEREVERSIONDOSSIER(DPR.DOSID)) FROM DUAL)
              -- AND DPR.DPFORDRE = (SELECT MAX(DPFORDRE) FROM DPRPROPFINANCE DPR WHERE DPR.DOSID=nDOSID)
               AND PFI.PECTYPEELEMENT='LOYER'
               AND PFI.PECDTDUE = (SELECT MIN(PECDTDUE) FROM PFIRUBECHEANCIER
                               where PFIID=PFI.PFIID and PECTYPEELEMENT='LOYER')
               AND DPR.DOSID=nDOSID;*/


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_TAXE_1ER_LOYER;

    ----------------------------------------------------------------------------------------------
    FUNCTION F_GET_MT_LOYERS_HT_HORS_1ER (
        nDOSID   IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT PFRMTLOYER
          INTO nResult
          FROM PFIRUBRIQUE PFI, DPRPROPFINANCE DPR
         WHERE     DPR.PFIID = PFI.PFIID
               AND DPR.DPRVERSION = (SELECT DPRVERSION
                                       FROM V_DEAL VDE
                                      WHERE VDE.DOSID = DPR.DOSID)
               AND DPR.DPFFLAGRETENUE = 1
               AND DPR.DOSID = nDOSID;

        /*SELECT SUM(PFI.PECMTBASIC)+SUM(PFI.PECMTINCIDENTAL) - PAV4_JASPER_FO.F_GET_1ER_LOYER_HORS_TAXE(nDOSID)
        INTO nResult
               FROM PFIRUBECHEANCIER  PFI, DPRPROPFINANCE DPR
               WHERE DPR.PFIID=PFI.PFIID
               AND DPR.DPRVERSION = (SELECT MAX(F_DERNIEREVERSIONDOSSIER(DPR.DOSID)) FROM DUAL)
               --AND DPR.DPFORDRE = (SELECT MAX(DPFORDRE) FROM DPRPROPFINANCE DPR WHERE DPR.DOSID=nDOSID)
               AND PFI.PECTYPEELEMENT='LOYER'
               AND DPR.DOSID=nDOSID;*/


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_MT_LOYERS_HT_HORS_1ER;

    ----------------------------------------------------------------------------------------------
    FUNCTION F_GET_MT_LOYERS_TTC_HORS_1ER (
        nDOSID   IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        /*SELECT nvl(PFRMTLOYER +(PFRMTLOYER * NVL(F_GETTAUXTAXE(DPR.TAXCODE), 0)/100),0)
        INTO nResult
               FROM PROPOSITIONFINANCIERE  PFI, DPRPROPFINANCE DF,DOSSIERPROSPECT DPR,PFIRUBRIQUE PF
               WHERE
               DPR.DOSID=DF.DOSID AND DPR.DPRVERSION=DF.DPRVERSION
               AND DF.PFIID=PFI.PFIID
               AND DPR.DPRVERSION = (SELECT MAX(F_DERNIEREVERSIONDOSSIER(DPR.DOSID)) FROM DUAL)
               AND DF.DPFORDRE = (SELECT MAX(DPFORDRE) FROM DPRPROPFINANCE WHERE DOSID=DPR.DOSID AND DPFFLAGRETENUE=1)
               and DF.DPFFLAGRETENUE=1
               AND DPR.DOSID=nDOSID
               AND PFI.PFIID=PF.PFIID;

    */
        SELECT   PAV4_JASPER_FO.F_GET_MT_LOYERS_HT_HORS_1ER (nDOSID)
               + PAV4_JASPER_FO.F_GET_TAXE_LOYERS_HORS_1ER (nDOSID)
          INTO nResult
          FROM DUAL;


        /*SELECT SUM(PFI.PECMTBASIC)+SUM(PFI.PECMTINCIDENTAL)+SUM(PFI.PECMTTAX) - PAV4_JASPER_FO.F_GET_1ER_LOYER(nDOSID)
        INTO nResult
               FROM PFIRUBECHEANCIER  PFI, DPRPROPFINANCE DPR
               WHERE DPR.PFIID=PFI.PFIID
               AND DPR.DPRVERSION = (SELECT MAX(F_DERNIEREVERSIONDOSSIER(DPR.DOSID)) FROM DUAL)
               --AND DPR.DPFORDRE = (SELECT MAX(DPFORDRE) FROM DPRPROPFINANCE DPR WHERE DPR.DOSID=nDOSID)
               AND PFI.PECTYPEELEMENT='LOYER'
               AND DPR.DOSID=nDOSID;
    */

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_MT_LOYERS_TTC_HORS_1ER;

    ----------------------------------------------------------------------------------------------
    FUNCTION F_GET_TAXE_LOYERS_HORS_1ER (
        nDOSID   IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        /*  SELECT SUM(PFI.PECMTTAX) - PAV4_JASPER_FO.F_GET_TAXE_1ER_LOYER(nDOSID)
           INTO nResult
                  FROM PFIRUBECHEANCIER  PFI, DPRPROPFINANCE DPR
                  WHERE DPR.PFIID=PFI.PFIID
                  AND DPR.DPRVERSION = (SELECT MAX(F_DERNIEREVERSIONDOSSIER(DPR.DOSID)) FROM DUAL)
                  AND DPR.DPFORDRE = (SELECT MAX(DPFORDRE) FROM DPRPROPFINANCE DPR WHERE DPR.DOSID=nDOSID)
                  AND PFI.PECTYPEELEMENT='LOYER'
                  and DPR.DPFFLAGRETENUE=1
                  AND DPR.DOSID=nDOSID;
           */

        SELECT   (  F_GET_MT_LOYERS_HT_HORS_1ER (nDOSID)
                  + NVL (PAV4_JASPER_FO.F_GET_FRAIS_ASSUR (nDOSID), 0))
               * (TTAVAL / 100)
          INTO nResult
          FROM DPRPROPFINANCE DPR, DOSSIERPROSPECT DOS, TAXTAUX TXT
         WHERE     DPR.DOSID = nDOSID
               AND DOS.TAXCODE = TXT.TAXCODE
               AND DOS.DOSID = DPR.DOSID
               AND DOS.DPRVERSION = DPR.DPRVERSION
               AND DPR.DPRVERSION = (SELECT DPRVERSION
                                       FROM V_DEAL VDE
                                      WHERE VDE.DOSID = DPR.DOSID)
               AND TXT.TTADTFIN IS NULL
               AND DPR.DPFFLAGRETENUE = 1;


        /*SELECT SUM(PFI.PECMTTAX) - PAV4_JASPER_FO.F_GET_TAXE_1ER_LOYER(nDOSID)
        INTO nResult
               FROM PFIRUBECHEANCIER  PFI, DPRPROPFINANCE DPR
               WHERE DPR.PFIID=PFI.PFIID
               AND DPR.DPRVERSION = (SELECT MAX(F_DERNIEREVERSIONDOSSIER(DPR.DOSID)) FROM DUAL)
              -- AND DPR.DPFORDRE = (SELECT MAX(DPFORDRE) FROM DPRPROPFINANCE DPR WHERE DPR.DOSID=nDOSID)
               AND PFI.PECTYPEELEMENT='LOYER'
               AND DPR.DOSID=nDOSID;

    */
        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_TAXE_LOYERS_HORS_1ER;

    ----------------------------------------------------------------------------------------------
    FUNCTION F_GET_DUREE (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT PRO.PFINBPERIODES
          INTO nResult
          FROM PROPOSITIONFINANCIERE PRO, DPRPROPFINANCE DPR
         WHERE     DPR.PFIID = PRO.PFIID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND DPR.DPFORDRE = (SELECT MAX (DPFORDRE)
                                     FROM DPRPROPFINANCE DPR
                                    WHERE DPR.DOSID = nDOSID)
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_DUREE;

    ----------------------------------------------------------------------------------------------
    FUNCTION F_GET_TERME (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
        nTerme    VARCHAR2 (1);
    BEGIN
        SELECT PRO.PFITERME
          INTO nTerme
          FROM PROPOSITIONFINANCIERE PRO, DPRPROPFINANCE DPR
         WHERE     DPR.PFIID = PRO.PFIID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND DPR.DPFORDRE = (SELECT MAX (DPFORDRE)
                                     FROM DPRPROPFINANCE DPR
                                    WHERE DPR.DOSID = nDOSID)
               AND DPR.DOSID = nDOSID;


        IF nTerme = 'A'
        THEN
            nResult := 'Avance ou ? ?choir';
        ELSIF nTerme = 'E'
        THEN
            nResult := 'Echu';
        END IF;



        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_TERME;

    ----------------------------------------------------------------------------------------------
    FUNCTION F_GET_PERIODICITE (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT DECODE (PRO.PFIPERIODICITE,
                       '030', 'Mensuelle',
                       '090', 'Trimestrielle',
                       '180', 'Semestrielle',
                       '360', 'Annuelle',
                       NULL)
          INTO nResult
          FROM PROPOSITIONFINANCIERE PRO, DPRPROPFINANCE DPR
         WHERE     DPR.PFIID = PRO.PFIID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND DPR.DPFORDRE = (SELECT MAX (DPFORDRE)
                                     FROM DPRPROPFINANCE DPR
                                    WHERE DPR.DOSID = nDOSID)
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_PERIODICITE;

    ----------------------------------------------------------------------------------------------
    FUNCTION F_GET_RESIDUAL_VALUE (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    IS
        nResult   NUMBER;
    BEGIN
        SELECT                                      /*PRO.PFIMTRESIDUALVALUE*/
               ROUND (PFR.PFRVR, 2)
          INTO nResult
          FROM PROPOSITIONFINANCIERE PRO, DPRPROPFINANCE DPR, PFIRUBRIQUE PFR
         WHERE     DPR.PFIID = PRO.PFIID
               AND PFR.PFIID = PRO.PFIID
               AND DPR.DPFFLAGRETENUE = 1
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND DPR.DPFORDRE = (SELECT MAX (DPFORDRE)
                                     FROM DPRPROPFINANCE DPR
                                    WHERE DPR.DOSID = nDOSID)
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN 0;
    END F_GET_RESIDUAL_VALUE;

    ----------------------------------------------------------------------------------------------
    FUNCTION F_GET_PCT_RESIDUAL_VALUE (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT ROUND (PRO.PFIMTRESIDUALVALUE / PRO.PFIINVESTISSEMENT, 2)
          INTO nResult
          FROM PROPOSITIONFINANCIERE PRO, DPRPROPFINANCE DPR
         WHERE     DPR.PFIID = PRO.PFIID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND DPR.DPFORDRE = (SELECT MAX (DPFORDRE)
                                     FROM DPRPROPFINANCE DPR
                                    WHERE DPR.DOSID = nDOSID)
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_PCT_RESIDUAL_VALUE;

    ----------------------------------------------------------------------------------------------
    FUNCTION F_GET_NB_ECH_FLUX (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT PFR.PRPNBPERIODES
          INTO nResult
          FROM PFRPALIER PFR, PROPOSITIONFINANCIERE PRO, DPRPROPFINANCE DPR
         WHERE     PFR.PFIID = PRO.PFIID
               AND DPR.PFIID = PRO.PFIID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND DPR.DPFORDRE = (SELECT MAX (DPFORDRE)
                                     FROM DPRPROPFINANCE DPR
                                    WHERE DPR.DOSID = nDOSID)
               AND PFR.PFRORDRE = (SELECT MAX (PFRORDRE)
                                     FROM PFRPALIER PFR2
                                    WHERE PFR2.PFIID = PFR.PFIID)
               AND DPR.DOSID = nDOSID;



        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_NB_ECH_FLUX;

    ----------------------------------------------------------------------------------------------
    FUNCTION F_GET_MT_HT_FLUX (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT PFR.PRPMT
          INTO nResult
          FROM PFRPALIER PFR, PROPOSITIONFINANCIERE PRO, DPRPROPFINANCE DPR
         WHERE     PFR.PFIID = PRO.PFIID
               AND DPR.PFIID = PRO.PFIID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND DPR.DPFORDRE = (SELECT MAX (DPFORDRE)
                                     FROM DPRPROPFINANCE DPR
                                    WHERE DPR.DOSID = nDOSID)
               AND PFR.PFRORDRE = (SELECT MAX (PFRORDRE)
                                     FROM PFRPALIER PFR2
                                    WHERE PFR2.PFIID = PFR.PFIID)
               AND DPR.DOSID = nDOSID;



        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_MT_HT_FLUX;

    ----------------------------------------------------------------------------------------------------
    FUNCTION F_GET_BAREME (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
        nBareme   VARCHAR2 (100);
    BEGIN
        SELECT   SUM (PFI.PECMTBASIC)
               + SUM (PFI.PECMTTAX)
               + SUM (PFI.PECMTINCIDENTAL)
          INTO nBareme
          FROM PFIRUBECHEANCIER PFI, DPRPROPFINANCE DPR
         WHERE     DPR.PFIID = PFI.PFIID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND DPR.DPFORDRE = (SELECT MAX (DPFORDRE)
                                     FROM DPRPROPFINANCE DPR
                                    WHERE DPR.DOSID = nDOSID)
               AND PFI.PECTYPEELEMENT = 'LOYER'
               AND PECDTDUE =
                   (SELECT MIN (PECDTDUE)
                      FROM PFIRUBECHEANCIER
                     WHERE PFIID = PFI.PFIID AND PECTYPEELEMENT = 'LOYER')
               AND DPR.DOSID = nDOSID;


        IF nBareme < 2000000
        THEN
            nResult := '4 340,00';
        ELSIF nBareme >= 2000000 AND nBareme < 10000000
        THEN
            nResult := '6 340,00';
        ELSE
            nResult := '12 340,00';
        END IF;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_BAREME;

    ----------------------------------------------------------------------------------------------
    FUNCTION F_GET_F_GET_LISTE_GARANTIES (
        nDOSID   IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        nResult := '';

        FOR REC
            IN (SELECT PFGDESCRIPTION AS GAR
                  FROM LANTGARANTIE TGA, PFIGUARANTEE PFG, DPRPROPFINANCE DPR
                 WHERE     DPR.PFIID = PFG.PFIID
                       AND TGA.TGACODE = PFG.TGACODE
                       AND TGA.LANCODE = 'FR'
                       AND DPR.DPRVERSION =F_DERNIEREVERSIONDOSSIER (DPR.DOSID)
                       AND DPR.DPFORDRE = (SELECT MAX (DPFORDRE)
                                             FROM DPRPROPFINANCE DPR
                                            WHERE DPR.DOSID = nDOSID)
                       AND DPR.DOSID = nDOSID)
        LOOP
            IF REC.GAR IS NOT NULL
            THEN
                nResult := nResult || REC.GAR || ',';
            END IF;
        END LOOP;

        IF LENGTH (nResult) > 1
        THEN
            SELECT SUBSTR (nResult, 1, LENGTH (nResult) - 1)
              INTO nResult
              FROM DUAL;
        END IF;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_F_GET_LISTE_GARANTIES;

    --------------------------------------------------------------------------------------------------
    FUNCTION F_GET_QUANTITE (nDOSID      IN DOSSIERPROSPECT.DOSID%TYPE,
                             nDPMORDRE   IN DPRMATERIEL.DPMORDRE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT SUM (DMDQUANTITE)
          INTO nResult
          FROM DPMDETAIL
         WHERE     DPMORDRE = nDPMORDRE
               AND DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (nDOSID)) FROM DUAL)
               AND DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_QUANTITE;

    -----------------------------------------------------------------------------------------------------
    FUNCTION F_GET_DESIGNATION (nDOSID      IN DOSSIERPROSPECT.DOSID%TYPE,
                                nDPMORDRE   IN DPRMATERIEL.DPMORDRE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT DPMLIBELLE
          INTO nResult
          FROM DPRMATERIEL
         WHERE     DPMORDRE = nDPMORDRE
               AND DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (nDOSID)) FROM DUAL)
               AND DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_DESIGNATION;

    -----------------------------------------------------------------------------------------------------
    FUNCTION F_GET_PRIX_UNIT_MAT (nDOSID      IN DOSSIERPROSPECT.DOSID%TYPE,
                                  nDPMORDRE   IN DPRMATERIEL.DPMORDRE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT DPMMTINVEST
          INTO nResult
          FROM DPRMATERIEL
         WHERE     DPMORDRE = nDPMORDRE
               AND DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (nDOSID)) FROM DUAL)
               AND DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_PRIX_UNIT_MAT;

    -----------------------------------------------------------------------------------------------------
    FUNCTION F_GET_PRIX_TVA_MAT (nDOSID      IN DOSSIERPROSPECT.DOSID%TYPE,
                                 nDPMORDRE   IN DPRMATERIEL.DPMORDRE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT DPMMTTTC - DPMMTINVEST
          INTO nResult
          FROM DPRMATERIEL
         WHERE     DPMORDRE = nDPMORDRE
               AND DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (nDOSID)) FROM DUAL)
               AND DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_PRIX_TVA_MAT;

    -----------------------------------------------------------------------------------------------------
    FUNCTION F_GET_PRIX_TTC_MAT (nDOSID      IN DOSSIERPROSPECT.DOSID%TYPE,
                                 nDPMORDRE   IN DPRMATERIEL.DPMORDRE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT DPMMTTTC
          INTO nResult
          FROM DPRMATERIEL
         WHERE     DPMORDRE = nDPMORDRE
               AND DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (nDOSID)) FROM DUAL)
               AND DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_PRIX_TTC_MAT;

    -----------------------------------------------------------------------------------------------------
    FUNCTION F_GET_TOT_HT_MAT (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    IS
        nResult   NUMBER;
    BEGIN
        SELECT SUM (DPMMTINVEST)
          INTO nResult
          FROM DPRMATERIEL
         WHERE     DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (nDOSID)) FROM DUAL)
               AND DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN 0;
    END F_GET_TOT_HT_MAT;

    -----------------------------------------------------------------------------------------------------
    FUNCTION F_GET_TOT_TVA_MAT (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    IS
        nResult   NUMBER;
    BEGIN
        SELECT SUM (DPMMTTTC - DPMMTINVEST)
          INTO nResult
          FROM DPRMATERIEL
         WHERE     DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (nDOSID)) FROM DUAL)
               AND DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN 0;
    END F_GET_TOT_TVA_MAT;

    -----------------------------------------------------------------------------------------------------
    FUNCTION F_GET_TOT_TTC_MAT (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    IS
        nResult   NUMBER;
    BEGIN
        SELECT SUM ((DMDPRIXUNITAIRE * DMDQUANTITE) + DMDMTTAX)
          INTO nResult
          FROM DPMDETAIL
         WHERE     DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (nDOSID)) FROM DUAL)
               AND DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN 0;
    END F_GET_TOT_TTC_MAT;

    ------------------------------------------------------------------------------------------------------
    FUNCTION F_GET_NUM_PROFORMA (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT PFR.ENCNUM
          INTO nResult
          FROM PFIRUBRIQUE PFR, DPRPROPFINANCE DPP
         WHERE     DPP.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPP.DOSID))
                      FROM DUAL)
               AND DPP.PFIID = PFR.PFIID
               AND (DPP.DPFDTLIMITE IS NULL OR DPP.DPFDTLIMITE > SYSDATE)
               AND DPP.DOSID = nDOSID;



        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_NUM_PROFORMA;

    -----------------------------------------------------------------------------------------------
    FUNCTION F_GET_DT_PROFORMA (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT PFR.PFRDTACCORDCODEVI
          INTO nResult
          FROM PFIRUBRIQUE PFR, DPRPROPFINANCE DPP
         WHERE     DPP.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPP.DOSID))
                      FROM DUAL)
               AND DPP.PFIID = PFR.PFIID
               AND (DPP.DPFDTLIMITE IS NULL OR DPP.DPFDTLIMITE > SYSDATE)
               AND DPP.DOSID = nDOSID;



        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_DT_PROFORMA;

    -------------------------------------------------------------------------------------------------
    FUNCTION F_GET_BANK_NAME (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                              nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT BQ.BANLIBELLE
          INTO nResult
          FROM BANQUE         BQ,
               BANQUEGUICHET  BGU,
               RIB,
               DPRACTEUR      DAC
         WHERE     BQ.BANCODE = BGU.BGUBANQUE
               AND BQ.PAYCODE = BGU.PAYCODE
               AND BGU.BGUBANQUE = RIB.BGUBANQUE
               AND BGU.BGUGUICHET = RIB.BGUGUICHET
               AND DAC.RIBIDENC = RIB.RIBID
               AND DAC.ROLCODE = nROLCODE
               AND DAC.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DAC.DOSID))
                      FROM DUAL)
               AND DAC.DOSID = nDOSID;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_BANK_NAME;

    -------------------------------------------------------------------------------------------------
    FUNCTION F_GET_AGENCE_BANCAIRE (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                    nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT BGU.BGUAGENCE
          INTO nResult
          FROM BANQUEGUICHET BGU, RIB, DPRACTEUR DAC
         WHERE     BGU.BGUBANQUE = RIB.BGUBANQUE
               AND BGU.BGUGUICHET = RIB.BGUGUICHET
               AND DAC.RIBIDENC = RIB.RIBID
               AND DAC.ROLCODE = nROLCODE
               AND DAC.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DAC.DOSID))
                      FROM DUAL)
               AND DAC.DOSID = nDOSID;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_AGENCE_BANCAIRE;

    ----------------------------------------------------------------------------------
    FUNCTION F_GET_NUM_COMPTE_BANCAIRE (
        nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
        nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (30);
    BEGIN
        SELECT RIB.BGUBANQUE || RIB.BGUGUICHET || RIB.RIBCOMPTE || RIB.RIBCLE
          INTO nResult
          FROM RIB, DPRACTEUR DAC
         WHERE     DAC.RIBIDENC = RIB.RIBID
               AND DAC.ROLCODE = nROLCODE
               AND DAC.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DAC.DOSID))
                      FROM DUAL)
               AND DAC.DOSID = nDOSID;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_NUM_COMPTE_BANCAIRE;

    -----------------------SGM45-------------------------------------------------------------
    FUNCTION F_GET_DT_PREV_MEP (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN DATE
    IS
        nResult   DATE;
    BEGIN
        SELECT MAX (DDCDT)
          INTO nResult
          FROM DPRDATECLE
         WHERE     DOSID = nDOSID
               AND DPRVERSION =F_DERNIEREVERSIONDOSSIER(nDosid)
               AND DCLCODE = 'DTMEP';

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_DT_PREV_MEP;

    -----------------------------------------------------------------------------------
    FUNCTION F_GET_MODE_PAIEMENT (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                  nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT TMP.TMPLIBELLE
          INTO nResult
          FROM LANTMOYENPMT TMP, DPRACTEUR DAC
         WHERE     TMP.TMPCODE = DAC.TMPCODEDEC
               AND DAC.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DAC.DOSID))
                      FROM DUAL)
               AND TMP.LANCODE = 'FR'
               AND DAC.ROLCODE = nROLCODE
               AND DAC.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_MODE_PAIEMENT;

    -------------------------------------------------------------------------------------------------

    FUNCTION F_GET_TAUX_INT_RETARD (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                    nROLCODE   IN DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT NVL (
                   (SELECT MAX (TCITAUX)
                      FROM TCALCULINTERET
                     WHERE TCIID IN
                               (SELECT TCIID
                                  FROM DOSACTEUR
                                 WHERE ROLCODE = nROLCODE AND DOSID = nDOSID)),
                   (SELECT TCAL.TCITAUX
                      FROM TCALCULINTERET TCAL, ACTEURGESTION ACG
                     WHERE ACG.ACTID = 1))
          INTO nResult
          FROM DUAL;



        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_TAUX_INT_RETARD;

    -------------------------------------------------------------------------------------
    FUNCTION F_GET_TAUX_INT_INTERCALAIRE (
        nDOSID   IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT MAX (DRUTAUXFIXE)
          INTO nResult
          FROM DOSRUBRIQUE
         WHERE DRUTYPE = 'P' AND DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_TAUX_INT_INTERCALAIRE;

    ---------------------------------------------------------------------------------------
    FUNCTION F_GET_TAUX_INTERET (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT PFRTOTALNOMINAL
          INTO nResult
          FROM PFIRUBRIQUE PFI, DPRPROPFINANCE DPR
         WHERE     PFI.PFIID = DPR.PFIID
               AND DPR.DPRVERSION = (SELECT DPRVERSION
                                       FROM V_DEAL VDE
                                      WHERE VDE.DOSID = nDOSID)
               AND DPR.DPFORDRE =
                   (SELECT MAX (DPFORDRE)
                      FROM DPRPROPFINANCE
                     WHERE DOSID = DPR.DOSID AND DPRVERSION = DPR.DPRVERSION)
               AND DPR.PFIID = (SELECT MAX (PFIID)
                                  FROM PFIRUBRIQUE
                                 WHERE PFIID = PFI.PFIID)
               AND DPR.DOSID = nDOSID;


        /*SELECT TAU.TVAVAL
        INTO nResult
           FROM TAUVALEUR TAU, PFIRUBRIQUE PFI, PROPOSITIONFINANCIERE PRO, DPRPROPFINANCE DPR
           WHERE TAU.TAUCODE=PFI.TAUCODEREFI
           AND PRO.PFIID=PFI.PFIID
           AND PRO.PFIID=DPR.PFIID
           AND DPR.DPRVERSION = (SELECT MAX(F_DERNIEREVERSIONDOSSIER(nDOSID)) FROM DUAL)
           AND DPR.DOSID=nDOSID;*/

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_TAUX_INTERET;

    ---------------------------------------------------------------------------------------
    FUNCTION F_GET_MARGE_TAUX (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    IS
        nResult   NUMBER;
    BEGIN
        SELECT PFRMARGENOMINALE
          INTO nResult
          FROM PFIRUBRIQUE PFI, DPRPROPFINANCE DPR
         WHERE     PFI.PFIID = DPR.PFIID
               AND DPR.DPRVERSION = (SELECT DPRVERSION
                                       FROM V_DEAL VDE
                                      WHERE VDE.DOSID = nDOSID)
               AND DPR.DPFORDRE =
                   (SELECT MAX (DPFORDRE)
                      FROM DPRPROPFINANCE
                     WHERE DOSID = DPR.DOSID AND DPRVERSION = DPR.DPRVERSION)
               AND DPR.PFIID = (SELECT MAX (PFIID)
                                  FROM PFIRUBRIQUE
                                 WHERE PFIID = PFI.PFIID)
               AND DPR.DOSID = nDOSID;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN 0;
    END F_GET_MARGE_TAUX;

    ---------------------------------------------------------------------------------------
    FUNCTION F_GET_ALL_MAT (nDOSID   IN DOSSIER.DOSID%TYPE,
                            nACTID      ACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (500);
        ncount    NUMBER := 0;
    BEGIN
        nResult := '';

        SELECT COUNT (1)
          INTO ncount
          FROM V_deal v, dprmateriel d
         WHERE     d.dosid = v.dosid
               AND v.dosid = nDOSID
               AND v.dprversion = d.dprversion
               AND d.dpmordre = 1;

        IF (ncount > 0)
        THEN
            FOR REC
                IN (SELECT DECODE (DPR.DPRNUMCASSIOPEE,
                                   NULL, DPR.DPRNUMERO || lk.DPMORDRE,
                                   DPR.DPRNUMCASSIOPEE || lk.DPMORDRE)
                               AS MAT
                      FROM DOSSIERPROSPECT DPR, lkarodpm lk
                     WHERE     DPR.DPRVERSION =
                               F_DERNIEREVERSIONDOSSIER (DPR.DOSID)
                           AND DPR.DOSID = lk.DOSID
                           AND DPR.DPRVERSION = lk.DPRVERSION
                           AND lk.ACTID = nACTID
                           AND DPR.DOSID = nDOSID)
            LOOP
                IF REC.MAT IS NOT NULL
                THEN
                    nResult := nResult || REC.MAT || ',';
                END IF;
            END LOOP;
        ELSE
            FOR REC
                IN (SELECT DECODE (DPR.DPRNUMCASSIOPEE,
                                   NULL, DPR.DPRNUMERO || lk.DPMORDRE - 1,
                                   DPR.DPRNUMCASSIOPEE || lk.DPMORDRE - 1)
                               AS MAT
                      FROM DOSSIERPROSPECT DPR, lkarodpm lk
                     WHERE     DPR.DPRVERSION =
                               F_DERNIEREVERSIONDOSSIER (DPR.DOSID)
                           AND DPR.DOSID = lk.DOSID
                           AND DPR.DPRVERSION = lk.DPRVERSION
                           AND lk.ACTID = nACTID
                           AND DPR.DOSID = nDOSID)
            LOOP
                IF REC.MAT IS NOT NULL
                THEN
                    nResult := nResult || REC.MAT || ',';
                END IF;
            END LOOP;
        END IF;

        IF LENGTH (nResult) > 1
        THEN
            SELECT SUBSTR (nResult, 1, LENGTH (nResult) - 1)
              INTO nResult
              FROM DUAL;
        END IF;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ALL_MAT;

    ---------------------------------------------------------------------------------------
    FUNCTION F_GET_TOUS_MATERIELS (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (500);
    BEGIN
        nResult := '';

        FOR REC
            IN (SELECT DPMLIBELLE AS MAT
                  FROM DPRMATERIEL
                 WHERE     DPRVERSION =
                           (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DOSID))
                              FROM DUAL)
                       AND DOSID = nDOSID)
        LOOP
            IF REC.MAT IS NOT NULL
            THEN
                nResult := nResult || REC.MAT || ',';
            END IF;
        END LOOP;

        IF LENGTH (nResult) > 1
        THEN
            SELECT SUBSTR (nResult, 1, LENGTH (nResult) - 1)
              INTO nResult
              FROM DUAL;
        END IF;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_TOUS_MATERIELS;

    ---------------------------------------------------------------------------------------
    FUNCTION F_GET_EQUIPEMENTS_FINANCES (
        nDOSID   IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (500);
    BEGIN
        nResult := '';

        FOR REC
            IN (SELECT DPMLIBELLE AS MAT
                  FROM DPRMATERIEL
                 WHERE     DPRVERSION =
                           (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DOSID))
                              FROM DUAL)
                       AND DOSID = nDOSID
                       AND DPMMTINVEST <> 0)
        LOOP
            IF REC.MAT IS NOT NULL
            THEN
                nResult := nResult || REC.MAT || ',';
            END IF;
        END LOOP;

        IF LENGTH (nResult) > 1
        THEN
            SELECT SUBSTR (nResult, 1, LENGTH (nResult) - 1)
              INTO nResult
              FROM DUAL;
        END IF;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_EQUIPEMENTS_FINANCES;

    ----------------------------------------------------------------------------------------
    FUNCTION F_GET_USER_NAME (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT UTI.UTIPRENOM || ' ' || UTI.UTINOM
          INTO nResult
          FROM UTILISATEUR UTI, DOCUMENTMANAGEMENT DOC
         WHERE DOC.UTICODE = UTI.UTICODE AND DOC.DOSID = nDOSID;



        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_USER_NAME;

    ---------------------------------------------------------------------------------------
    FUNCTION F_GET_NOM_COMMERCIAL (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
      SELECT UTI.UTINOM||' '||UTI.UTIPRENOM
      into nResult
      FROM DPRINTERVENANT DPI ,UTILISATEUR UTI WHERE DOSID = nDOSID
      AND DPI.DINMETIER = 'COMPRO'
      AND UTI.UTICODE = DPI.UTICODE
      AND DPI.DINORDRE=1
      AND DPI.DPRVERSION = (F_DERNIEREVERSIONDOSSIER(nDOSID)) ;


        /*
          SELECT UTI.UTINOM || ' ' || UTI.UTIPRENOM
          INTO  nResult
                 FROM LKACTUTITSM LKA, UTILISATEUR UTI, DPRACTEUR DPR
                 WHERE LKA.TSMMETIER='COM'
                 AND LKA.UTICODE=UTI.UTICODE
                 AND DPR.ACTID=LKA.ACTID
                 AND DPR.DPRVERSION = (SELECT MAX(F_DERNIEREVERSIONDOSSIER(nDOSID)) FROM DUAL)
                 AND DPR.DOSID=nDOSID;
        */

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_NOM_COMMERCIAL;

    ------------------------------------------------------------------------------------
    FUNCTION F_GET_NOM_COMMERCIAL_RESIDENT (
        nDOSID   IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT UTI.UTINOM || ' ' || UTI.UTIPRENOM
          INTO nResult
          FROM DPRINTERVENANT DPR, UTILISATEUR UTI
         WHERE     DPR.DINMETIER = 'CR'
               AND DPR.DPRVERSION = (SELECT DPRVERSION
                                       FROM V_DEAL VDE
                                      WHERE VDE.DOSID = DPR.DOSID)
               AND DPR.UTICODE = UTI.UTICODE
               AND DPR.DINORDRE =
                   (SELECT MAX (DINORDRE)
                      FROM DPRINTERVENANT
                     WHERE DOSID = DPR.DOSID AND DINMETIER = 'CR')
               AND DPR.DOSID = nDOSID;



        /*
          SELECT UTI.UTINOM || ' ' || UTI.UTIPRENOM
          INTO  nResult
                 FROM LKACTUTITSM LKA, UTILISATEUR UTI, DPRACTEUR DPR
                 WHERE LKA.TSMMETIER='COM'
                 AND LKA.UTICODE=UTI.UTICODE
                 AND DPR.ACTID=LKA.ACTID
                 AND DPR.DPRVERSION = (SELECT MAX(F_DERNIEREVERSIONDOSSIER(nDOSID)) FROM DUAL)
                 AND DPR.DOSID=nDOSID;
        */

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_NOM_COMMERCIAL_RESIDENT;


    ---------------------------------------------------------------------------------------
    FUNCTION F_GET_NOM_ANALYSTE (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
        nCount1   NUMBER;
        nCount2   NUMBER;
    BEGIN
        SELECT COUNT (*)
          INTO nCount1
          FROM DPRINTERVENANT DPR, UTILISATEUR UTI
         WHERE     DPR.DINMETIER = 'ANALYST'
               AND DPR.DPRVERSION = (SELECT DPRVERSION
                                       FROM V_DEAL VDE
                                      WHERE VDE.DOSID = nDOSID)
               AND DPR.UTICODE = UTI.UTICODE
               AND DPR.DOSID = nDOSID;

        SELECT COUNT (*)
          INTO nCount2
          FROM DPRINTERVENANT DPR, UTILISATEUR UTI
         WHERE     DPR.DINMETIER = 'CDC'
               AND DPR.DPRVERSION = (SELECT DPRVERSION
                                       FROM V_DEAL VDE
                                      WHERE VDE.DOSID = nDOSID)
               AND DPR.UTICODE = UTI.UTICODE
               AND DPR.DOSID = nDOSID;

        IF nCount1 > 0
        THEN
            SELECT UTI.UTINOM || ' ' || UTI.UTIPRENOM
              INTO nResult
              FROM DPRINTERVENANT DPR, UTILISATEUR UTI
             WHERE     DPR.DINMETIER = 'ANALYST'
                   AND DPR.DPRVERSION = (SELECT DPRVERSION
                                           FROM V_DEAL VDE
                                          WHERE VDE.DOSID = nDOSID)
                   AND DPR.UTICODE = UTI.UTICODE
                   AND DPR.DOSID = nDOSID;
        ELSE
            IF nCount2 > 0
            THEN
                SELECT UTI.UTINOM || ' ' || UTI.UTIPRENOM
                  INTO nResult
                  FROM DPRINTERVENANT DPR, UTILISATEUR UTI
                 WHERE     DPR.DINMETIER = 'CDC'
                       AND DPR.DPRVERSION = (SELECT DPRVERSION
                                               FROM V_DEAL VDE
                                              WHERE VDE.DOSID = nDOSID)
                       AND DPR.UTICODE = UTI.UTICODE
                       AND DPR.DOSID = nDOSID;
            ELSE
                SELECT PAV4_SUMMARY.F_PLGETRVAMOUNT (nDOSID, 'FR', 'ORFI')
                  INTO nResult
                  FROM DUAL;
            /*nResult := '';*/
            END IF;
        END IF;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_NOM_ANALYSTE;

    ---------------------------------------------------------------------------------------
    FUNCTION F_GET_TYPE_PAIEMENT (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
        nTYPE     VARCHAR2 (50);
    BEGIN
        SELECT PFI.PFIAPPROCHEFLUX
          INTO nTYPE
          FROM PROPOSITIONFINANCIERE PFI, DPRPROPFINANCE DPR
         WHERE     PFI.PFIID = DPR.PFIID
               AND DPR.DPRVERSION = (SELECT MAX (DPRVERSION)
                                       FROM DPRPROPFINANCE
                                      WHERE DOSID = DPR.DOSID)
               AND DPR.PFIID = (SELECT MAX (PFIID)
                                  FROM PROPOSITIONFINANCIERE
                                 WHERE PFIID = PFI.PFIID)
               AND DPR.DOSID = nDOSID;

        IF nTYPE = 'LOYFIX'
        THEN
            nResult := 'fixes';
        ELSE
            nResult := 'paliers';
        END IF;



        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_TYPE_PAIEMENT;

    ---------------------------------------------------------------------------------------
    FUNCTION F_GET_ACTOR_FORME_JURIDIQUE (
        nACTID     IN ACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT CJU.CJULIBELLE
          INTO nResult
          FROM ACTEUR ACT, LANCATJURIDIQUE CJU
         WHERE     CJU.CJUCODE = ACT.CJUCODE
          AND CJU.LANCODE = 'FR'
          AND ACT.ACTID =Nactid ;



        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ACTOR_FORME_JURIDIQUE;

    --------------------------------------------------------------------------------------
    FUNCTION F_GET_ACTOR_ACTIVITY (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                   nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT NAF.NAFLIBELLE
          INTO nResult
          FROM LANNAF NAF, ACTEUR ACT, DPRACTEUR DAC
         WHERE     NAF.NAFCODE = ACT.NAFCODE
               AND NAF.LANCODE = 'FR'
               AND DAC.ACTID = ACT.ACTID
               AND DAC.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DAC.DOSID))
                      FROM DUAL)
               AND DAC.ROLCODE = nROLCODE
               AND DAC.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ACTOR_ACTIVITY;

    ---------------------------------------------------------------------------------------
--    FUNCTION F_GET_COMITE_DECI (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
--        RETURN VARCHAR2
--    IS
--        /*  L_RESULT VARCHAR2(20) := '';*/
--        l_Age                  NUMBER;
--        /*   L_FondsPropres NUMBER;
--        L_MtRisque NUMBER;
--        L_PctMt NUMBER;*/
--        nResult                VARCHAR2 (100);
--        L_LIMITE_INT           NUMBER;
--        L_LIMITE_ENG           NUMBER;
--        L_LIMITE_CAD           NUMBER;
--        L_LIMITE_AGE_STARTUP   NUMBER;
--        L_CODE                 VARCHAR2 (100);
--        l_TPGCODE              VARCHAR2 (100);
--        l_FORMULE              NUMBER;
--    BEGIN
--        BEGIN
--            /* SELECT CVANUMERICVALUE INTO L_FondsPropres FROM cchvalue  WHERE cchsid = 'TFDCCHSID57335' AND actid =1;
--            L_MtRisque := F_GET_MONTANTRISQUE (nDOSID);
--            L_PctMt := L_MtRisque/L_FondsPropres*100;
--            IF (L_PctMt>3 AND L_PctMt<15) THEN
--              L_RESULT := 'ENGAGE';
--
--            ELSIF (L_PctMt>=15 AND L_PctMt<=25) THEN L_RESULT := 'INTERN';
--
--            ELSE*
--              SELECT Trunc(Months_Between(SYSDATE , Max(ACTDTIMMATRICULATION))) INTO l_Age FROM acteur ACT,DPRACTEUR DPA
--              WHERE
--              DOSID = nDOSID AND
--              DPRVERSION     =
--                      (
--                          SELECT DPRVERSION FROM V_DEAL VDE WHERE VDE.DOSID = nDOSID
--                      ) AND
--              DPA.ACTID=ACT.ACTID AND
--              DPA.ROLCODE='CLIENT';
--              IF (l_Age <24) THEN
--                 L_RESULT := 'ENGAGE';
--              END IF;
--
--            END IF;*/
--            SELECT DISTINCT
--                   ROUND (
--                       (  (  R."Encours Groupe"
--                           + R."Encours Client"
--                           + DECODE (
--                                 PAV4_JASPER_FO.F_GET_CODE_DERNIERE_CONCLUSION (
--                                     DOSID),
--                                 'DECI04', 0,
--                                 'DECI01', 0,
--                                   (SELECT NVL (PFIINVESTISSEMENT, 0)
--                                      FROM PROPOSITIONFINANCIERE
--                                     WHERE PFIID =
--                                           (SELECT MAX (PFIID)
--                                              FROM DPRPROPFINANCE
--                                             WHERE     DOSID = nDOSID
--                                                   AND DPRVERSION =
--                                                       (SELECT DPRVERSION
--                                                          FROM V_DEAL VDE
--                                                         WHERE VDE.DOSID =
--                                                               nDOSID)))
--                                 - (SELECT NVL (P."MT 1er Loyer HT", 0)
--                                      FROM v_proposition
--                                     WHERE     dosid = nDOSID
--                                           AND "Role Acteur" = 'CLIENT')))
--                        / R."Fonds Propres Nets (FPN) ALC"),
--                       2)
--              INTO L_FORMULE
--              FROM V_RATIO R, V_PROPOSITION P
--             WHERE R.R_DOSID = nDOSID AND R.R_DOSID = P.DOSID;
--
--
--            SELECT TPGCODE
--              INTO l_TPGCODE
--              FROM DOSSIERPROSPECT
--             WHERE     DOSID = nDOSID
--                   AND DPRVERSION = (SELECT DPRVERSION
--                                       FROM V_DEAL VDE
--                                      WHERE VDE.DOSID = nDOSID);
--
--
--            SELECT PAV4_JASPER_FO.F_GET_CODE_DERN_CONCLU (nDOSID)
--              INTO L_CODE
--              FROM DUAL;
--
--            SELECT NVL (
--                       TRUNC (
--                           MONTHS_BETWEEN (SYSDATE,
--                                           MAX (ACTDTIMMATRICULATION))),
--                       0)
--              INTO l_Age
--              FROM acteur ACT, DPRACTEUR DPA
--             WHERE     DOSID = nDOSID
--                   AND DPRVERSION = (SELECT DPRVERSION
--                                       FROM V_DEAL VDE
--                                      WHERE VDE.DOSID = nDOSID)
--                   AND DPA.ACTID = ACT.ACTID
--                   AND DPA.ROLCODE = 'CLIENT';
--
--            SELECT NVL (TPANOMBRE, 0)
--              INTO L_LIMITE_INT
--              FROM TOPPARAM
--             WHERE     TOPTABLE = 'AVDOSS'
--                   AND TPAPARAM = 'COM_INT'
--                   AND UGECODE = '_ORIG_';
--
--            SELECT NVL (TPANOMBRE, 0)
--              INTO L_LIMITE_ENG
--              FROM TOPPARAM
--             WHERE     TOPTABLE = 'AVDOSS'
--                   AND TPAPARAM = 'COM_ENG'
--                   AND UGECODE = '_ORIG_';
--
--            SELECT NVL (TPANOMBRE, 0)
--              INTO L_LIMITE_CAD
--              FROM TOPPARAM
--             WHERE     TOPTABLE = 'AVDOSS'
--                   AND TPAPARAM = 'COM_CAD'
--                   AND UGECODE = '_ORIG_';
--
--            SELECT NVL (TPANOMBRE, 0)
--              INTO L_LIMITE_AGE_STARTUP
--              FROM TOPPARAM
--             WHERE     TOPTABLE = 'AVDOSS'
--                   AND TPAPARAM = 'COM_STA'
--                   AND UGECODE = '_ORIG_';
--
--            /*
--                IF (l_Age <= 24 AND l_TPGCODE <> 'AUTO' ) THEN
--                    nResult := 'Conseil d''administration';
--
--                ELS*/
--            IF (l_TPGCODE = 'AUTO' AND l_Age <= 12)
--            THEN
--                nResult := 'Comite interne';
--            ELSIF (    (   L_CODE = 'DECI04'
--                        OR L_CODE = 'DECI02'
--                        OR L_CODE = 'DECI01'
--                        OR L_CODE = 'DECI03'
--                        OR L_CODE IS NULL)
--                   AND (   ( /*TO_NUMBER(PAV4_JASPER_FO.F_GET_RATIO(nDOSID, 10030))*/
--                            L_FORMULE < L_LIMITE_INT)
--                        OR (l_TPGCODE = 'AUTO' AND l_Age <= 12)))
--            THEN
--                nResult := 'Comite interne';
--            ELSIF (    /*TO_NUMBER(PAV4_JASPER_FO.F_GET_RATIO(nDOSID, 10030)*/
--                   L_FORMULE < L_LIMITE_ENG)
--            THEN
--                nResult := 'Comite d''engagement';
--            ELSIF (   ( /*TO_NUMBER(PAV4_JASPER_FO.F_GET_RATIO(nDOSID, 10030)*/
--                       L_FORMULE < L_LIMITE_CAD)
--                   OR (l_Age <= L_LIMITE_AGE_STARTUP AND l_TPGCODE <> 'AUTO'))
--            THEN                                             -- Client Startup
--                nResult := 'Conseil d''administration';
--            ELSE
--                nResult := 'Risque non support? par ALC';
--            END IF;
--        END;
--
--        /* RETURN L_RESULT;*/
--        RETURN nResult;
--    /* RETURN 'Comite interne';*/
--
--    END F_GET_COMITE_DECI;

    ----------------------------------------------------------------------------------------

    FUNCTION F_GET_ACTOR_TEL (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                              nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT ATE.ATENUM
          INTO nResult
          FROM ACTTELECOM ATE, DPRACTEUR DAC
         WHERE     ATE.ACTID = DAC.ACTID
               AND ATETYPE = 'TEL'
               AND DAC.ROLCODE = nROLCODE
               AND DAC.DOSID = nDOSID;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ACTOR_TEL;

    ----------------------------------------------------------------------------------------

    FUNCTION F_GET_ACTOR_TELECOM (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                  nROLCODE      DPRACTEUR.ROLCODE%TYPE,
                                  nTYPE         ACTTELECOM.ATETYPE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT MAX (ATE.ATENUM)
          INTO nResult
          FROM ACTTELECOM ATE, DPRACTEUR DAC
         WHERE     ATE.ACTID = DAC.ACTID
               AND ATETYPE = nTYPE
               AND DAC.ROLCODE = nROLCODE
               AND DAC.DOSID = nDOSID;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ACTOR_TELECOM;
----------------------------------------------------
FUNCTION F_GET_RATIO (nDOSID   IN DOSSIERPROSPECT.DOSID%TYPE,
                          nRATID   IN RATIO.RATID%TYPE,
                          nANMID IN ANALYSISMATRIX.ANMID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (4000);
    BEGIN
        /* SELECT LKA.RATVALUE
         INTO nResult
                FROM RATIO RAT, LKANARAT LKA, ANALYSIS ANA
                WHERE RAT.RATID=LKA.RATID
                AND LKA.ANAID=ANA.ANAID
                AND ANA.DPRVERSION = (SELECT MAX(F_DERNIEREVERSIONDOSSIER(ANA.DOSID)) FROM DUAL)
                AND ANA.ANAID = (SELECT MAX(ANAID) FROM ANALYSIS WHERE DOSID=ANA.DOSID)
                AND ANA.DOSID=nDOSID
                AND LKA.RATID=nRATID;*/


      SELECT  decode ( RAT.RATTYPE ,'STRING',case when RATRETURNMSG is not null then RATRETURNMSG else RATVALUE END ,'MEMO', LKA.RATMEMO ,RATVALUE)
          INTO nResult
          FROM LKANARAT LKA, ANALYSIS ANA, RATIO RAT
         WHERE     LKA.ANAID = ANA.ANAID
               AND RAT.RATID = LKA.RATID
               AND ANA.DOSID = nDOSID
               AND LKA.ANAID = (SELECT MAX (ANAID)
                                  FROM ANALYSIS
                                 WHERE DOSID = nDOSID and ANMID=nANMID )
               AND LKA.RATID = nRATID;

        /*
               DPR.DPRVERSION = (
                     SELECT DPRVERSION FROM V_DEAL VDE WHERE VDE.DOSID = dpr.dosid
         )
               */

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_RATIO;


    ---------------------------------------------------------------------------------------
    FUNCTION F_GET_RATIO (nDOSID   IN DOSSIERPROSPECT.DOSID%TYPE,
                          nRATID   IN RATIO.RATID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (4000);
    BEGIN
        /* SELECT LKA.RATVALUE
         INTO nResult
                FROM RATIO RAT, LKANARAT LKA, ANALYSIS ANA
                WHERE RAT.RATID=LKA.RATID
                AND LKA.ANAID=ANA.ANAID
                AND ANA.DPRVERSION = (SELECT MAX(F_DERNIEREVERSIONDOSSIER(ANA.DOSID)) FROM DUAL)
                AND ANA.ANAID = (SELECT MAX(ANAID) FROM ANALYSIS WHERE DOSID=ANA.DOSID)
                AND ANA.DOSID=nDOSID
                AND LKA.RATID=nRATID;*/


        SELECT (DECODE (
                    DECODE (RAT.RATTYPE, 'MEMO', LKA.RATMEMO, LKA.RATVALUE),
                    'N', 'NON',
                    'O', 'OUI',
                    NULL, ' ',
                    -- DECODE (RAT.RATTYPE, 'MEMO', LKA.RATMEMO, LKA.RATVALUE),
                    DECODE (RAT.RATTYPE,
                            'STRING', LKA.RATRETURNMSG,
                            LKA.RATVALUE)))
          INTO nResult
          FROM LKANARAT LKA, ANALYSIS ANA, RATIO RAT
         WHERE     LKA.ANAID = ANA.ANAID
               AND RAT.RATID = LKA.RATID
               AND ANA.DOSID = nDOSID
               AND LKA.ANAID = (SELECT MAX (ANAID)
                                  FROM ANALYSIS
                                 WHERE DOSID = nDOSID  )
               AND LKA.RATID = nRATID;

        /*
               DPR.DPRVERSION = (
                     SELECT DPRVERSION FROM V_DEAL VDE WHERE VDE.DOSID = dpr.dosid
         )
               */

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_RATIO;

    ----------------------------------------------------------------------------------------
    FUNCTION F_GET_AGRVALUE (nDOSID   IN DOSSIERPROSPECT.DOSID%TYPE,
                             nRATID   IN RATIO.RATID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT AGR.AGRVALUE
          INTO nResult
          FROM ARAGRID AGR, ANALYSIS ANA
         WHERE     AGR.ANAID = ANA.ANAID
               AND ANA.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (ANA.DOSID))
                      FROM DUAL)
               AND ANA.ANAID = (SELECT MAX (ANAID)
                                  FROM ANALYSIS
                                 WHERE DOSID = ANA.DOSID)
               AND ANA.DOSID = nDOSID
               AND AGR.RATID = nRATID;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_AGRVALUE;

    ----------------------------------------------------------------------------------------

    FUNCTION F_GET_CONTACT_TEL (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                nROLCODE      DPRACTEUR.ROLCODE%TYPE,
                                nTUPCODE      LANTUSPARAM.TUPCODE%TYPE,
                                nATETYPE   IN ACTTELECOM.ATETYPE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        IF nTUPCODE IS NULL
        THEN
            SELECT ATENUM
              INTO nResult
              FROM DOSSIERPROSPECT   DPR,
                   DPRACTEUR         DAC,
                   ACTEUR            ACT,
                   LANTUSPARAM       LAN,
                   ACTCORRESPONDANT  ACC,
                   ACTTELECOM        ATE
             WHERE     DPR.DOSID = DAC.DOSID
                   AND DPR.DPRVERSION = DAC.DPRVERSION
                   AND DPR.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                          FROM DUAL)
                   AND ACT.ACTID = DAC.ACTID
                   AND LAN.TUSNOM = 'QUALITE'
                   AND LAN.LANCODE = 'FR'
                   AND ACT.ACTID = ACC.ACTID
                   AND ACC.ACOQUALITE = LAN.TUPCODE
                   AND ATE.ACTID = DAC.ACTID
                   AND ATE.ATETYPE = nATETYPE
                   AND ATE.ATEORDRE =
                       (SELECT MAX (ATEORDRE)
                          FROM ACTTELECOM
                         WHERE ACTID = ATE.ACTID AND ATETYPE = ATE.ATETYPE)
                   AND ACC.ACOFLAGPREFERE = 1
                   AND DAC.ROLCODE = nROLCODE
                   AND DPR.DOSID = nDOSID;
        ELSE
            SELECT ATENUM
              INTO nResult
              FROM DOSSIERPROSPECT   DPR,
                   DPRACTEUR         DAC,
                   ACTEUR            ACT,
                   LANTUSPARAM       LAN,
                   ACTCORRESPONDANT  ACC,
                   ACTTELECOM        ATE
             WHERE     DPR.DOSID = DAC.DOSID
                   AND DPR.DPRVERSION = DAC.DPRVERSION
                   AND DPR.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                          FROM DUAL)
                   AND ACT.ACTID = DAC.ACTID
                   AND LAN.TUSNOM = 'QUALITE'
                   AND LAN.LANCODE = 'FR'
                   AND ACT.ACTID = ACC.ACTID
                   AND ACC.ACOQUALITE = LAN.TUPCODE
                   AND ATE.ACTID = DAC.ACTID
                   AND ATE.ATETYPE = nATETYPE
                   AND ATE.ATEORDRE =
                       (SELECT MAX (ATEORDRE)
                          FROM ACTTELECOM
                         WHERE ACTID = ATE.ACTID AND ATETYPE = ATE.ATETYPE)
                   AND ACC.ACOFLAGPREFERE = 1
                   AND LAN.TUPCODE = nTUPCODE
                   AND DAC.ROLCODE = nROLCODE
                   AND DPR.DOSID = nDOSID;
        END IF;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_CONTACT_TEL;

    -----------------------------------------------------------------------------------------
    FUNCTION F_GET_PRODUIT (nDosid DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT TPG.TPGLIBELLE
          INTO nResult
          FROM LANTPROFILGESTION TPG, DOSSIERPROSPECT DPR
         WHERE     DPR.TPGCODE = TPG.TPGCODE
               AND DPR.DPRVERSION = (SELECT DPRVERSION
                                       FROM V_DEAL VDE
                                      WHERE VDE.DOSID = nDosid)
               AND TPG.LANCODE = 'FR'
               AND DPR.DOSID = nDosid;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_PRODUIT;

    ---------------------------------------
    FUNCTION F_GET_BUSINESS_TYPE (nDosid DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT TAC.TACLIBELLE
          INTO nResult
          FROM LANTACTIVITE TAC, DOSSIERPROSPECT DPR
         WHERE     DPR.TACCODE = TAC.TACCODE
               AND DPR.DPRVERSION = (SELECT DPRVERSION
                                       FROM V_DEAL VDE
                                      WHERE VDE.DOSID = nDosid)
               AND TAC.LANCODE = 'FR'
               AND DPR.DOSID = nDosid;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_BUSINESS_TYPE;

    ---------------------------------------------------------------------------------------
    FUNCTION F_GET_PATH_LOGO
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT TPATEXTE
          INTO nResult
          FROM TOPPARAM
         WHERE     TOPTABLE = 'JASPER'
               AND TPAPARAM = 'STANDALONE_DIR'
               AND UGECODE = '_ORIG_';

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_PATH_LOGO;

    -------------------------------------------------------------------------------------
    FUNCTION F_GET_AVIS_ANALYSTE (nDosid DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult    VARCHAR2 (100);
        nResult1   VARCHAR2 (100);
    BEGIN
          SELECT ddecomment
            INTO nResult1
            FROM dprdecision dpd
           WHERE     dosid = nDosid
                 AND EXISTS
                         (SELECT 1
                            FROM utitsm
                           WHERE     tsmmetier = 'ANALYST'
                                 AND dpd.uticodedecision = uticode)
                 AND ROWNUM < 2
        ORDER BY ddeordre DESC;

        IF nResult1 IS NULL
        THEN
            SELECT ddecomment
              INTO nResult
              FROM dprdecision dpd
             WHERE     dosid = nDosid
                   AND EXISTS
                           (SELECT 1
                              FROM utitsm
                             WHERE     tsmmetier = 'CDC'
                                   AND dpd.uticodedecision = uticode)
                   AND ddeordre = 1;
        END IF;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_AVIS_ANALYSTE;

    --------------------------------------------------------------------------------------

    FUNCTION F_GET_ANNEE_REFERENCE (nDosid DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT ANAREFERENCEYEAR
          INTO nResult
          FROM ANALYSIS
         WHERE DOSID = nDosid;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ANNEE_REFERENCE;

    --------------------------------------------------------------------------------------
    FUNCTION F_DERNVERSDOSSIERANALYSIS (P_DOSID ANALYSIS.DOSID%TYPE)
        RETURN VARCHAR2
    AS
        SDPRVERSION   ANALYSIS.DPRVERSION%TYPE;
    BEGIN
        SELECT DECODE (MAX (DECODE (DPRVERSION,  'NEGO', 1,  'FIN', 2,  3)),
                       1, 'NEGO',
                       2, 'FIN',
                       3, 'PROD')
          INTO SDPRVERSION
          FROM ANALYSIS
         WHERE DOSID = P_DOSID;

        RETURN SDPRVERSION;
    END F_DERNVERSDOSSIERANALYSIS;

    ---------------------------------------------------------------------------------------
    FUNCTION F_GET_POURCENTAGE_1ER_LOYER (
        nDOSID   IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN FLOAT
    AS
        nResult   FLOAT;
    BEGIN
        SELECT   (  NVL (
                        TO_NUMBER (
                            PAV4_JASPER_FO.F_GET_RATIO (DPR.DOSID, 10025)),
                        PFIMTPREMIERLOYER)
                  / NVL (
                        TO_NUMBER (
                            PAV4_JASPER_FO.F_GET_RATIO (DPR.DOSID, 10024)),
                        PFIINVESTISSEMENT))
               * 100                            --mod, 18/04/2017, EXTALCFO-48
          --  SELECT   ( PFIMTPREMIERLOYER/(PFIINVESTISSEMENT)*100)
          INTO nResult
          FROM DPRPROPFINANCE         DPR,
               PROPOSITIONFINANCIERE  PRO,
               dossierprospect        dos,
               taxtaux                txt
         WHERE     PRO.PFIID = DPR.PFIID
               AND DPR.DOSID = nDosid
               AND DPR.DPRVERSION = (SELECT DPRVERSION
                                       FROM V_DEAL VDE
                                      WHERE VDE.DOSID = nDosid)
               AND DPR.DPFFLAGRETENUE = 1
               AND dos.taxcode = txt.taxcode
               AND dos.dosid = DPR.dosid
               AND dpr.DPRVERSION = dos.DPRVERSION
               AND TTADTFIN IS NULL;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_POURCENTAGE_1ER_LOYER;

    ---------------------------------------------------------------------------------------
    FUNCTION F_GET_PCT_1ER_LOYER (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN FLOAT
    AS
        nResult   FLOAT;
    BEGIN
        SELECT (PFIMTPREMIERLOYER / (PFIINVESTISSEMENT) * 100)
          INTO nResult
          FROM DPRPROPFINANCE         DPR,
               PROPOSITIONFINANCIERE  PRO,
               dossierprospect        dos,
               taxtaux                txt
         WHERE     PRO.PFIID = DPR.PFIID
               AND DPR.DOSID = nDosid
               AND DPR.DPRVERSION = (SELECT DPRVERSION
                                       FROM V_DEAL VDE
                                      WHERE VDE.DOSID = nDosid)
               AND DPR.DPFFLAGRETENUE = 1
               AND dos.taxcode = txt.taxcode
               AND dos.dosid = DPR.dosid
               AND dpr.DPRVERSION = dos.DPRVERSION
               AND TTADTFIN IS NULL;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_PCT_1ER_LOYER;

    ---------------------------- V_ACTEUR --------------------------------------------------
    FUNCTION F_GET_NOM_ACTEUR (nACTID     IN ACTEUR.ACTID%TYPE,
                               nDOSID     IN DOSACTEUR.DOSID%TYPE,
                               nROLCODE   IN DOSACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
        nType     VARCHAR2 (4);
    BEGIN
        SELECT MAX (ACT.ACTTYPE)
          INTO nType
          FROM ACTEUR ACT, DPRACTEUR DAC, DOSSIERPROSPECT DPR
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND ACT.ACTID = DAC.ACTID
               AND DPR.DPRVERSION =F_DERNIEREVERSIONDOSSIER (DPR.DOSID)
               AND ACT.ACTID = nACTID
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID;

        IF nType = 'P'
        THEN
            SELECT APA.APAPRENOM || ' ' || APA.APANOMPATRONYMIQUE
              INTO nResult
              FROM ACTEURPARTICULIER APA, DPRACTEUR DAC, DOSSIERPROSPECT DPR
             WHERE     DPR.DOSID = DAC.DOSID
                   AND DPR.DPRVERSION = DAC.DPRVERSION
                   AND APA.ACTID = DAC.ACTID
                   AND DPR.DPRVERSION =F_DERNIEREVERSIONDOSSIER (DPR.DOSID)
                   AND APA.ACTID = nACTID
                   AND DAC.ROLCODE = nROLCODE
                   AND DPR.DOSID = nDOSID;
        ELSE
            SELECT MAX (ACT.ACTNOM)
              INTO nResult
              FROM ACTEUR ACT, DPRACTEUR DAC, DOSSIERPROSPECT DPR
             WHERE     DPR.DOSID = DAC.DOSID
                   AND DPR.DPRVERSION = DAC.DPRVERSION
                   AND ACT.ACTID = DAC.ACTID
                   AND DPR.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                          FROM DUAL)
                   AND ACT.ACTID = nACTID
                   AND DAC.ROLCODE = nROLCODE
                   AND DPR.DOSID = nDOSID;
        END IF;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_NOM_ACTEUR;

    --------------------------------------------------------------------------------
    FUNCTION F_GET_TITLE_ACTEUR (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                 nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
        nTitre    VARCHAR2 (5);
        nType     VARCHAR2 (5);
    BEGIN
        SELECT ACT.ACTTYPE
          INTO nType
          FROM ACTEUR ACT, DPRACTEUR DACT, DOSSIERPROSPECT DOS
         WHERE     DOS.DOSID = DACT.DOSID
               AND DOS.DPRVERSION = DACT.DPRVERSION
               AND DOS.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DOS.DOSID))
                      FROM DUAL)
               AND ACT.ACTID = DACT.ACTID
               AND DACT.ROLCODE = nROLCODE
               AND DOS.DOSID = nDOSID;


        IF nType IN ('EI', 'PART')
        THEN
            SELECT APA.APATITRE
              INTO nTitre
              FROM ACTEURPARTICULIER APA, DPRACTEUR DACT, DOSSIERPROSPECT DOS
             WHERE     DOS.DOSID = DACT.DOSID
                   AND DOS.DPRVERSION = DACT.DPRVERSION
                   AND DOS.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DOS.DOSID))
                          FROM DUAL)
                   AND APA.ACTID = DACT.ACTID
                   AND DACT.ROLCODE = nROLCODE
                   AND DOS.DOSID = nDOSID;
        END IF;

        IF nTitre = 'M'
        THEN
            nResult := 'Monsieur';
        ELSIF nTitre = 'MME'
        THEN
            nResult := 'Madame';
        ELSIF nTitre = 'MLLE'
        THEN
            nResult := 'Mademoiselle';
        ELSIF nTitre = 'DR'
        THEN
            nResult := 'Docteur';
        END IF;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN '-';
    END F_GET_TITLE_ACTEUR;


    ----------------------
    FUNCTION F_GET_TITLE_ACTEUR (nACTID        DPRACTEUR.ACTID%TYPE,
                                 nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                 nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
        nTitre    VARCHAR2 (5);
        nType     VARCHAR2 (5);
    BEGIN
        SELECT ACT.ACTTYPE
          INTO nType
          FROM ACTEUR ACT, DPRACTEUR DACT, DOSSIERPROSPECT DOS
         WHERE     DOS.DOSID = DACT.DOSID
               AND DOS.DPRVERSION = DACT.DPRVERSION
               AND DOS.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DOS.DOSID))
                      FROM DUAL)
               AND ACT.ACTID = DACT.ACTID
               AND DACT.ROLCODE = nROLCODE
               AND DOS.DOSID = nDOSID
               AND DACT.ACTID = nACTID;


        IF nType IN ('EI', 'PART')
        THEN
            SELECT APA.APATITRE
              INTO nTitre
              FROM ACTEURPARTICULIER APA, DPRACTEUR DACT, DOSSIERPROSPECT DOS
             WHERE     DOS.DOSID = DACT.DOSID
                   AND DOS.DPRVERSION = DACT.DPRVERSION
                   AND DOS.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DOS.DOSID))
                          FROM DUAL)
                   AND APA.ACTID = DACT.ACTID
                   AND DACT.ROLCODE = nROLCODE
                   AND DOS.DOSID = nDOSID;
        END IF;

        IF nTitre = 'MR'
        THEN
            nResult := 'M';
        ELSIF nTitre = 'MME'
        THEN
            nResult := 'Mme';
        ELSIF nTitre = 'MLLE'
        THEN
            nResult := 'Mlle';
        ELSIF nTitre = 'DR'
        THEN
            nResult := 'Dr';
        END IF;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN '-';
    END F_GET_TITLE_ACTEUR;

    ---------------------------------------------------------------------------------------
    FUNCTION F_GET_CAPITAL_ACTEUR (nACTID     IN ACTEUR.ACTID%TYPE,
                                   nDOSID     IN DOSACTEUR.DOSID%TYPE,
                                   nROLCODE   IN DOSACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT ACT.ACTCAPITAL
          INTO nResult
          FROM ACTEUR ACT, DPRACTEUR DAC, DOSSIERPROSPECT DPR
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND ACT.ACTID = DAC.ACTID
               AND ACT.ACTID = nACTID
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_CAPITAL_ACTEUR;

    ---------------------------------------------------------------------------------------
    FUNCTION F_GET_NIF_ACTEUR (nACTID     IN ACTEUR.ACTID%TYPE,
                               nDOSID     IN DOSACTEUR.DOSID%TYPE,
                               nROLCODE   IN DOSACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT ACT.ACTSIRET
          INTO nResult
          FROM DOSSIERPROSPECT DPR, DPRACTEUR DAC, ACTEUR ACT
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND ACT.ACTID = DAC.ACTID
               AND ACT.ACTID = nACTID
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_NIF_ACTEUR;

    -------------------------------------------------------------------------------------------
    FUNCTION F_GET_DT_NAISS_ACTEUR (nACTID     IN ACTEUR.ACTID%TYPE,
                                    nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                    nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
        nType     VARCHAR2 (4);
    BEGIN
        SELECT ACT.ACTTYPE
          INTO nType
          FROM ACTEUR ACT, DPRACTEUR DAC, DOSSIERPROSPECT DPR
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND ACT.ACTID = DAC.ACTID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID
               AND ACT.ACTID = nACTID;

        IF nType = 'EI'
        THEN
            SELECT TO_CHAR (APA.APADTNAISS, 'DD/MM/YYYY')
              INTO nResult
              FROM ACTEURPARTICULIER APA, DPRACTEUR DAC, DOSSIERPROSPECT DPR
             WHERE     DPR.DOSID = DAC.DOSID
                   AND DPR.DPRVERSION = DAC.DPRVERSION
                   AND APA.ACTID = DAC.ACTID
                   AND DPR.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                          FROM DUAL)
                   AND DAC.ROLCODE = nROLCODE
                   AND DPR.DOSID = nDOSID
                   AND APA.ACTID = nACTID;
        ELSE
            SELECT TO_CHAR (ACT.ACTDTCREAT, 'DD/MM/YYYY')
              INTO nResult
              FROM ACTEUR ACT, DPRACTEUR DAC, DOSSIERPROSPECT DPR
             WHERE     DPR.DOSID = DAC.DOSID
                   AND DPR.DPRVERSION = DAC.DPRVERSION
                   AND ACT.ACTID = DAC.ACTID
                   AND DPR.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                          FROM DUAL)
                   AND DAC.ROLCODE = nROLCODE
                   AND DPR.DOSID = nDOSID
                   AND ACT.ACTID = nACTID;
        END IF;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_DT_NAISS_ACTEUR;

    -------------------------------------------------------------------------------------------
    FUNCTION F_GET_LIEU_NAISS_ACTEUR (nACTID     IN ACTEUR.ACTID%TYPE,
                                      nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                      nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
        nType     VARCHAR2 (4);
    BEGIN
        SELECT ACT.ACTTYPE
          INTO nType
          FROM ACTEUR ACT, DPRACTEUR DAC, DOSSIERPROSPECT DPR
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND ACT.ACTID = DAC.ACTID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID
               AND ACT.ACTID = nACTID;

        IF nType = 'EI'
        THEN
            SELECT APA.APAVILLENAISS
              INTO nResult
              FROM ACTEURPARTICULIER APA, DPRACTEUR DAC, DOSSIERPROSPECT DPR
             WHERE     DPR.DOSID = DAC.DOSID
                   AND DPR.DPRVERSION = DAC.DPRVERSION
                   AND APA.ACTID = DAC.ACTID
                   AND DPR.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                          FROM DUAL)
                   AND DAC.ROLCODE = nROLCODE
                   AND DPR.DOSID = nDOSID
                   AND APA.ACTID = nACTID;
        END IF;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_LIEU_NAISS_ACTEUR;

    -------------------------------------------------------------------------------------
    FUNCTION F_GET_TITRE_ACTEUR (nACTID     IN ACTEUR.ACTID%TYPE,
                                 nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                 nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
        nTitre    VARCHAR2 (5);
        nType     VARCHAR2 (5);
    BEGIN
        SELECT ACT.ACTTYPE
          INTO nType
          FROM ACTEUR ACT, DPRACTEUR DACT, DOSSIERPROSPECT DOS
         WHERE     DOS.DOSID = DACT.DOSID
               AND DOS.DPRVERSION = DACT.DPRVERSION
               AND DOS.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DOS.DOSID))
                      FROM DUAL)
               AND ACT.ACTID = DACT.ACTID
               AND DACT.ROLCODE = nROLCODE
               AND DOS.DOSID = nDOSID
               AND ACT.ACTID = nACTID;


        IF nType = 'EI'
        THEN
            SELECT APA.APATITRE
              INTO nTitre
              FROM ACTEURPARTICULIER APA, DPRACTEUR DACT, DOSSIERPROSPECT DOS
             WHERE     DOS.DOSID = DACT.DOSID
                   AND DOS.DPRVERSION = DACT.DPRVERSION
                   AND DOS.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DOS.DOSID))
                          FROM DUAL)
                   AND APA.ACTID = DACT.ACTID
                   AND DACT.ROLCODE = nROLCODE
                   AND DOS.DOSID = nDOSID
                   AND APA.ACTID = nACTID;
        END IF;


        IF nTitre = 'M'
        THEN
            nResult := 'Monsieur';
        ELSIF nTitre = 'MME'
        THEN
            nResult := 'Madame';
        ELSIF nTitre = 'MLLE'
        THEN
            nResult := 'Mademoiselle';
        ELSIF nTitre = 'DR'
        THEN
            nResult := 'Docteur';
        END IF;



        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN ' ';
    END F_GET_TITRE_ACTEUR;

    -------------------------------------------------------------------------------------------
    FUNCTION F_GET_CONTACT_PREFERE (nACTID     IN ACTEUR.ACTID%TYPE,
                                    nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                    nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT ACC.ACOPRENOM || ' ' || ACC.ACONOM
          INTO nResult
          FROM DOSSIERPROSPECT   DPR,
               DPRACTEUR         DAC,
               ACTEUR            ACT,
               LANTUSPARAM       LAN,
               ACTCORRESPONDANT  ACC
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND ACT.ACTID = DAC.ACTID
               AND LAN.TUSNOM = 'QUALITE'
               AND LAN.LANCODE = 'FR'
               AND ACT.ACTID = ACC.ACTID
               AND ACC.ACOQUALITE = LAN.TUPCODE
               AND ACC.ACOFLAGPREFERE = 1
               AND ACC.ACOORDRE = (SELECT MIN (ACC2.ACOORDRE)
                                     FROM ACTCORRESPONDANT ACC2
                                    WHERE ACC2.ACTID = ACC.ACTID)
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID
               AND ACT.ACTID = nACTID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_CONTACT_PREFERE;

    -------------------------------------------------------------------------------------------
    FUNCTION F_GET_CONTACT_PREFERE_DOS (
        nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
        nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT MAX (ACC.ACOPRENOM || ' ' || ACC.ACONOM)
          INTO nResult
          FROM DOSSIERPROSPECT   DPR,
               DPRACTEUR         DAC,
               ACTEUR            ACT,
               LANTUSPARAM       LAN,
               ACTCORRESPONDANT  ACC
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND ACT.ACTID = DAC.ACTID
               AND LAN.TUSNOM = 'QUALITE'
               AND LAN.LANCODE = 'FR'
               AND ACT.ACTID = ACC.ACTID
               AND ACT.ACTID = DAC.ACTID
               AND ACC.ACOQUALITE = LAN.TUPCODE
               --  AND ACC.ACOFLAGPREFERE=1
               AND ACC.ACOORDRE = (SELECT MIN (ACC2.ACOORDRE)
                                     FROM ACTCORRESPONDANT ACC2
                                    WHERE ACC2.ACTID = ACC.ACTID /*AND ACC2.ACOFLAGPREFERE=1*/
                                                                )
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_CONTACT_PREFERE_DOS;

    --------------------------------------------------------------------------------------------
    FUNCTION F_GET_TOUS_CONTACTS (nACTID     IN ACTEUR.ACTID%TYPE,
                                  nDOSID     IN DPRACTEUR.DOSID%TYPE,
                                  nROLCODE   IN DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        nResult := '';

        FOR REC
            IN (SELECT    LAN.TUPLIBELLE
                       || ' '
                       || ACC.ACOTITRE
                       || ' '
                       || ACC.ACOPRENOM
                       || ' '
                       || ACC.ACONOM
                       || ' identifi? au N? '
                       || ACC.ACOQUALIFICATION
                           AS CONTACT
                  FROM ACTEUR            ACT,
                       LANTUSPARAM       LAN,
                       ACTCORRESPONDANT  ACC,
                       DPRACTEUR         DACT,
                       DOSSIERPROSPECT   DPR
                 WHERE     LAN.TUSNOM = 'QUALITE'
                       AND LAN.LANCODE = 'FR'
                       AND ACT.ACTID = ACC.ACTID
                       AND ACC.ACOQUALITE = LAN.TUPCODE
                       AND ACC.ACOFLAGPREFERE = 1
                       AND ACT.ACTID = DACT.ACTID
                       AND DACT.DOSID = DPR.DOSID
                       AND DPR.DPRVERSION =
                           (SELECT MAX (F_DERNIEREVERSIONDOSSIER (nDOSID))
                              FROM DUAL)
                       AND DPR.DPRVERSION = DACT.DPRVERSION
                       AND ACT.ACTID = nACTID
                       AND DACT.ROLCODE = nROLCODE
                       AND DPR.DOSID = nDOSID)
        LOOP
            IF REC.CONTACT IS NOT NULL
            THEN
                nResult := nResult || REC.CONTACT || ',';
            END IF;
        END LOOP;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_TOUS_CONTACTS;

    -------------------------------------------------------------------------------------------------
    FUNCTION F_GET_NUM_REGISTRE (nACTID     IN ACTEUR.ACTID%TYPE,
                                 nDOSID     IN DPRACTEUR.DOSID%TYPE,
                                 nROLCODE   IN DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT ACT.ACTNUMRCM
          INTO nResult
          FROM DOSSIERPROSPECT DPR, DPRACTEUR DAC, ACTEUR ACT
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND ACT.ACTID = DAC.ACTID
               AND ACT.ACTID = nACTID
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_NUM_REGISTRE;

    ---------------------------------------------------------------------------------------

    FUNCTION F_GET_TYPE_REGISTRE (nACTID     IN ACTEUR.ACTID%TYPE,
                                  nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                  nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT LTR.TTPLIBELLE
          INTO nResult
          FROM DOSSIERPROSPECT  DPR,
               DPRACTEUR        DAC,
               ACTEUR           ACT,
               LANTTRPARAM      LTR
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND ACT.ACTID = DAC.ACTID
               AND LTR.TTRNOM = 'RCRM'
               AND LTR.LANCODE = 'FR'
               AND LTR.TTPCODE = ACT.ACTCODERCM
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID
               AND DAC.ACTID = nACTID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_TYPE_REGISTRE;

    ----------------------------------

    FUNCTION F_GET_TOUS_ROLE (nACTID IN ACTROLE.ACTID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (500);
    BEGIN
        nResult := '';

        FOR REC
            IN (SELECT B.ROLLIBELLE AS MAT
                  FROM lanrole b, ACTROLE A
                 WHERE     A.rolcode = B.rolcode
                       AND lancode = 'FR'
                       AND A.ACTID = nACTID)
        LOOP
            IF REC.MAT IS NOT NULL
            THEN
                nResult := nResult || REC.MAT || '/';
            END IF;
        END LOOP;

        IF LENGTH (nResult) > 1
        THEN
            SELECT SUBSTR (nResult, 1, LENGTH (nResult) - 1)
              INTO nResult
              FROM DUAL;
        END IF;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_TOUS_ROLE;

    -----------------------------------------------------
    FUNCTION F_GET_AGE_CONTACT (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                nROLCODE      DPRACTEUR.ROLCODE%TYPE,
                                nTUPCODE      LANTUSPARAM.TUPCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT ROUND ((SYSDATE - a.acodtbirthday) / 365)
          INTO nResult
          FROM actcorrespondant a, lantusparam t, dpracteur d
         WHERE     a.actid = d.actid
               AND d.rolcode = nROLCODE
               AND d.dosid = nDOSID
               AND d.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (d.DOSID)) FROM DUAL)
               AND A.ACOORDRE =
                   (SELECT MIN (ACOORDRE)
                      FROM ACTCORRESPONDANT
                     WHERE ACTID = A.ACTID            /*AND ACOFLAGPREFERE=1*/
                                           AND ACOQUALITE = nTUPCODE)
               AND a.acoqualite = t.tupcode
               AND t.tupcode = nTUPCODE
               /* and a.acoflagprefere = 1*/
               AND t.lancode = 'FR'
               AND t.tusnom = 'QUALITE';


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_AGE_CONTACT;

    ---------------------------- V_ECHEANCIER_FO---------------------------------------------
    FUNCTION F_GET_LOYER_HT (nDPFIID     IN PFIRUBECHEANCIER.PFIID%TYPE,
                             dPECDTDUE   IN PFIRUBECHEANCIER.PECDTDUE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT PECMTBASIC
          INTO nResult
          FROM PFIRUBECHEANCIER
         WHERE     PECTYPEELEMENT = 'LOYER'
               AND PECDTDUE = dPECDTDUE
               AND PFIID = nDPFIID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_LOYER_HT;


    ---------------------------------------------------------------------------------

    FUNCTION F_GET_TVA (nDPFIID     IN PFIRUBECHEANCIER.PFIID%TYPE,
                        dPECDTDUE   IN PFIRUBECHEANCIER.PECDTDUE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT PECMTTAX
          INTO nResult
          FROM PFIRUBECHEANCIER
         WHERE     PECTYPEELEMENT = 'LOYER'
               AND PECDTDUE = dPECDTDUE
               AND PFIID = nDPFIID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_TVA;


    -------------------------------------------------------------------------------
    FUNCTION F_GET_LOYER_TTC (nDPFIID     IN PFIRUBECHEANCIER.PFIID%TYPE,
                              dPECDTDUE   IN PFIRUBECHEANCIER.PECDTDUE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT PECMTBASIC + PECMTTAX + PECMTINCIDENTAL
          INTO nResult
          FROM PFIRUBECHEANCIER
         WHERE     PECTYPEELEMENT = 'LOYER'
               AND PECDTDUE = dPECDTDUE
               AND PFIID = nDPFIID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_LOYER_TTC;

    -----------------------------------------------------------------------------------------------------
    FUNCTION F_GET_SUM_LOYER_HT (nDPFIID IN PFIRUBECHEANCIER.PFIID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT SUM (PECMTBASIC)
          INTO nResult
          FROM PFIRUBECHEANCIER
         WHERE PECTYPEELEMENT = 'LOYER' AND PFIID = nDPFIID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_SUM_LOYER_HT;


    ---------------------------------------------------------------------------------

    FUNCTION F_GET_SUM_TVA (nDPFIID IN PFIRUBECHEANCIER.PFIID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT SUM (PECMTTAX)
          INTO nResult
          FROM PFIRUBECHEANCIER
         WHERE PECTYPEELEMENT = 'LOYER' AND PFIID = nDPFIID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_SUM_TVA;


    -------------------------------------------------------------------------------
    FUNCTION F_GET_SUM_LOYER_TTC (nDPFIID IN PFIRUBECHEANCIER.PFIID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT SUM (PECMTBASIC + PECMTTAX)
          INTO nResult
          FROM PFIRUBECHEANCIER
         WHERE PECTYPEELEMENT = 'LOYER' AND PFIID = nDPFIID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_SUM_LOYER_TTC;

    -------------------------------------------------------------------------------
    FUNCTION F_GET_SUM_ASSUR_TTC (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    IS
        nResult   NUMBER;
    BEGIN
        SELECT SUM (PFI.PECMTINCIDENTAL)
          INTO nResult
          FROM PFIRUBECHEANCIER PFI, DPRPROPFINANCE DPR
         WHERE     DPR.PFIID = PFI.PFIID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               -- AND DPR.DPFORDRE = (SELECT MAX(DPFORDRE) FROM DPRPROPFINANCE DPR WHERE DPR.DOSID=nDOSID)
               AND PFI.PECTYPEELEMENT = 'LOYER'
               AND DPR.DPFFLAGRETENUE = 1
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_SUM_ASSUR_TTC;


    ------------------------------------------------------------------------------

    FUNCTION F_GET_SERVICES (nDPFIID     IN PFIRUBECHEANCIER.PFIID%TYPE,
                             dPECDTDUE   IN PFIRUBECHEANCIER.PECDTDUE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT ROUND (PECMTINCIDENTAL, 2)
          INTO nResult
          FROM PFIRUBECHEANCIER
         WHERE     PECTYPEELEMENT = 'LOYER'
               AND PECDTDUE = dPECDTDUE
               AND PFIID = nDPFIID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_SERVICES;

    ------------------------------------------------------------------------------

    FUNCTION F_GET_SERVICE_HT_DATE (
        nDPFIID     IN PFIRUBECHEANCIER.PFIID%TYPE,
        dPECDTDUE   IN PFIRUBECHEANCIER.PECDTDUE%TYPE,
        sRUBCODE    IN RUBRIQUE.RUBCODE%TYPE)
        RETURN NUMBER
    IS
        nResult   NUMBER;
    BEGIN
        SELECT ROUND (NVL (SUM (PECMTINCIDENTAL), 0), 3)
          INTO nResult
          FROM PFIRUBECHEANCIER PFR, PFIPRESTATION PFP
         WHERE     PFR.PECTYPEELEMENT = 'LOYER'
               AND PFR.PECDTDUE = dPECDTDUE
               AND PFR.PFIID = nDPFIID
               AND PFP.PFPORDRE = PFR.PFPORDRE
               AND PFP.PFIID = PFR.PFIID
               AND PFP.RUBCODE = sRUBCODE;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN 0;
    END F_GET_SERVICE_HT_DATE;

    ------------------------------------------------------------------------------

    FUNCTION F_GET_SERVICE_TTC_DATE (
        nDPFIID     IN PFIRUBECHEANCIER.PFIID%TYPE,
        dPECDTDUE   IN PFIRUBECHEANCIER.PECDTDUE%TYPE,
        sRUBCODE    IN RUBRIQUE.RUBCODE%TYPE)
        RETURN NUMBER
    IS
        nResult   NUMBER;
    BEGIN
        SELECT ROUND (NVL (SUM (PFR.PECMTINCIDENTAL + PFR.PECMTTAX), 0), 3)
          INTO nResult
          FROM PFIRUBECHEANCIER PFR, PFIPRESTATION PFP
         WHERE     PFR.PECTYPEELEMENT = 'LOYER'
               AND PFR.PECDTDUE = dPECDTDUE
               AND PFR.PFIID = nDPFIID
               AND PFP.PFPORDRE = PFR.PFPORDRE
               AND PFP.PFIID = PFR.PFIID
               AND PFP.RUBCODE = sRUBCODE;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN 0;
    END F_GET_SERVICE_TTC_DATE;

    ------------------------------------------------------------------------------

    FUNCTION F_GET_SUM_SERVICES (nDPFIID IN PFIRUBECHEANCIER.PFIID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT SUM (PECMTINCIDENTAL)
          INTO nResult
          FROM PFIRUBECHEANCIER
         WHERE PECTYPEELEMENT = 'LOYER' AND PFIID = nDPFIID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_SUM_SERVICES;

    ---------------------------------------------------------------------------------
    FUNCTION F_GET_AMORTISSEMENT (
        nDPFIID     IN PFIRUBECHEANCIER.PFIID%TYPE,
        dPECDTDUE   IN PFIRUBECHEANCIER.PECDTDUE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT PECMTAMORTIZATION
          INTO nResult
          FROM PFIRUBECHEANCIER
         WHERE     PECTYPEELEMENT = 'LOYER'
               AND PECDTDUE = dPECDTDUE
               AND PFIID = nDPFIID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_AMORTISSEMENT;

    ----------------------------------------------------------------------------------
    FUNCTION F_GET_INTERET (nDPFIID     IN PFIRUBECHEANCIER.PFIID%TYPE,
                            dPECDTDUE   IN PFIRUBECHEANCIER.PECDTDUE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT PECMTINTEREST
          INTO nResult
          FROM PFIRUBECHEANCIER
         WHERE     PECTYPEELEMENT = 'LOYER'
               AND PECDTDUE = dPECDTDUE
               AND PFIID = nDPFIID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_INTERET;

    ----------------------------------------------------------------------------------
    FUNCTION F_GET_RESTANT_DU (nDPFIID     IN PFIRUBECHEANCIER.PFIID%TYPE,
                               dPECDTDUE   IN PFIRUBECHEANCIER.PECDTDUE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT PECMTOUTSTANDING
          INTO nResult
          FROM PFIRUBECHEANCIER
         WHERE     PECTYPEELEMENT = 'LOYER'
               AND PECDTDUE = dPECDTDUE
               AND PFIID = nDPFIID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_RESTANT_DU;

    ---------------------------------------------------------------------------------------
    FUNCTION F_GET_YEAR_ECH (nDPFIID     IN PFIRUBECHEANCIER.PFIID%TYPE,
                             dPECDTDUE   IN PFIRUBECHEANCIER.PECDTDUE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT EXTRACT (YEAR FROM PECDTDUE)
          INTO nResult
          FROM PFIRUBECHEANCIER
         WHERE     PECTYPEELEMENT = 'LOYER'
               AND PECDTDUE = dPECDTDUE
               AND PFIID = nDPFIID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_YEAR_ECH;

    ---------------------------------------------------------------------------------------
    FUNCTION F_GET_MIN_YEAR_ECH (nDPFIID IN PFIRUBECHEANCIER.PFIID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT MIN (EXTRACT (YEAR FROM PECDTDUE))
          INTO nResult
          FROM PFIRUBECHEANCIER
         WHERE PECTYPEELEMENT = 'LOYER' AND PFIID = nDPFIID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_MIN_YEAR_ECH;



    --------------------------------------------------------------------------------------
    FUNCTION F_GET_MONTH_ECH (nDPFIID     IN PFIRUBECHEANCIER.PFIID%TYPE,
                              dPECDTDUE   IN PFIRUBECHEANCIER.PECDTDUE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT EXTRACT (MONTH FROM PECDTDUE)
          INTO nResult
          FROM PFIRUBECHEANCIER
         WHERE     PECTYPEELEMENT = 'LOYER'
               AND PECDTDUE = dPECDTDUE
               AND PFIID = nDPFIID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_MONTH_ECH;

    -----------------------------------------------------------------------------------------------------
    FUNCTION F_GET_MIN_DATE_ECH (nDPFIID IN PFIRUBECHEANCIER.PFIID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT TO_CHAR (MIN (PECDTDUE), 'DD/MM/YYYY')
          INTO nResult
          FROM PFIRUBECHEANCIER
         WHERE PECTYPEELEMENT = 'LOYER' AND PFIID = nDPFIID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_MIN_DATE_ECH;

    ---------------------------- V_MATERIEL_FO --------------------------------------------

    FUNCTION F_GET_MMOLIBELLE (nDosid         DOSSIERPROSPECT.DOSID%TYPE,
                               nDPMORDRE   IN DPRMATERIEL.DPMORDRE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT lma.mmolibelle
          INTO nResult
          FROM lanmakmodel lma, dprmateriel dpm, v_deal v
         WHERE     v.dosid = nDosid
               AND v.dosid = dpm.dosid
               AND dpm.mmocode = lma.mmocode
               AND dpm.makid = lma.makid
               AND dpm.dprversion = v.dprversion
               AND dpm.dpmordre = nDPMORDRE
               AND lma.lancode = 'FR';


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_MMOLIBELLE;

    --------------------------------------------------------------------------
    FUNCTION F_GET_MAKLIBELLE (nDosid         DOSSIERPROSPECT.DOSID%TYPE,
                               nDPMORDRE   IN DPRMATERIEL.DPMORDRE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT lma.maklibelle
          INTO nResult
          FROM lanmake lma, dprmateriel dpm, v_deal v
         WHERE     v.dosid = nDosid
               AND v.dosid = dpm.dosid
               AND dpm.makid = lma.makid
               AND dpm.dprversion = v.dprversion
               AND dpm.dpmordre = nDPMORDRE
               AND lma.lancode = 'FR';


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_MAKLIBELLE;

    -------------------------------------------------------------------------------------------------------
    FUNCTION F_GET_PAYS_ORIGINE (nDosid         DOSSIERPROSPECT.DOSID%TYPE,
                                 nDPMORDRE   IN DPRMATERIEL.DPMORDRE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT TUS.TUPLIBELLE
          INTO nResult
          FROM LANTUSPARAM TUS, DPRMATERIEL DPR
         WHERE     TUS.TUSNOM = 'ASSETORIGIN'
               AND TUS.TUPCODE = DPR.DPMORIGINCODE
               AND DPR.DPMORDRE = nDPMORDRE
               AND DPR.DPRVERSION = (SELECT DPRVERSION
                                       FROM V_DEAL VDE
                                      WHERE VDE.DOSID = nDosid)
               AND DPR.DOSID = nDosid;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_PAYS_ORIGINE;

    ---------------------------------------------------------------Jasper report--------------------------
    FUNCTION f_get_Date_Approved (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN DATE
    IS
    BEGIN
        DECLARE
            sResult       DATE := NULL;
            nDPRVERSION   VARCHAR2 (10);
        BEGIN
            SELECT PA_AVCOMMUN.F_DERNIEREVERSIONDOSSIER (nDOSID)
              INTO nDPRVERSION
              FROM DUAL;

            SELECT MAX (DPH.DPHDTEFFECT)
              INTO sResult
              FROM DOSSIERPROSPECT DPR, DPRPHASE DPH, CREVT CRE
             WHERE     DPR.DOSID = DPH.DOSID
                   AND DPR.DOSID = nDOSID
                   AND DPR.DPRVERSION = nDPRVERSION
                   AND EXISTS
                           (SELECT 1
                              FROM dprphase a
                             WHERE     jalcode IN ('D_VALID')
                                   AND a.dosid = dph.dosid)
                   AND DPR.DPRDTCLASSEMENT IS NULL
                   AND dph.creid = cre.creid
                   AND cre.uticodevalid IS NOT NULL
                   AND cre.uticodesup IS NULL
                   AND CRE.TMFFONCTION IN ('EVF_DEM_CONCLU', 'EVF_VALIDER');

            RETURN sResult;
        END;
    END f_get_Date_Approved;

    -----------------------------------------------------
    ---------------------------------------------------------------------------------
    FUNCTION f_get_trade_name_actor_prop (
        nDosid     IN DOSSIERPROSPECT.DOSID%TYPE,
        sRolcode   IN VARCHAR2)
        RETURN VARCHAR2
    IS
    BEGIN
        DECLARE
            sReturn       VARCHAR2 (100);
            nDPRVERSION   VARCHAR2 (10);
        BEGIN
            SELECT PA_AVCOMMUN.F_DERNIEREVERSIONDOSSIER (nDOSID)
              INTO nDPRVERSION
              FROM DUAL;

            SELECT MAX (ACTNOM)
              INTO sReturn
              FROM ACTEUR ACT, DPRACTEUR DPR
             WHERE     DPR.DOSID = nDOSID
                   AND ACT.ACTID = DPR.ACTID
                   AND DPR.DPRVERSION = nDPRVERSION
                   AND DPR.ROLCODE = sRolcode;

            RETURN sReturn;
        EXCEPTION
            WHEN OTHERS
            THEN
                RETURN NULL;
        END;
    END f_get_trade_name_actor_prop;

    ----------------------------------------------------
    -------------------------------------------------------------------------------------------
    FUNCTION f_get_involved_user_actid (
        nDOSID                 DOSSIERPROSPECT.DOSID%TYPE,
        sMetier             IN VARCHAR2,
        nDINFLAGPRINCIPAL      NUMBER)
        RETURN VARCHAR2
    IS
        sUser         VARCHAR2 (100);
        sUticode      UTILISATEUR.UTICODE%TYPE;
        nDPRVERSION   VARCHAR2 (50);
    BEGIN
        SELECT PA_AVCOMMUN.F_DERNIEREVERSIONDOSSIER (nDOSID)
          INTO nDPRVERSION
          FROM DUAL;

        SELECT MAX (uticode)
          INTO sUticode
          FROM dprintervenant
         WHERE     dosid = nDOSID
               AND dinmetier = sMetier
               AND dprversion = nDPRVERSION
               AND dinflagprincipal = nDINFLAGPRINCIPAL;

        SELECT utinom || ' ' || utiprenom
          INTO sUser
          FROM utilisateur
         WHERE uticode = sUticode;

        RETURN sUser;
    END f_get_involved_user_actid;

    ---------------------------------------------------------------------
    ----------------------------------- ----------------------------------- -----------------------------------
    FUNCTION F_GET_REASON_REJECT (nDOSID DOSSIERPROSPECT.DOSID%TYPE /*,nDPRVERSION DOSSIERPROSPECT.DPRVERSION%TYPE*/
                                                                   )
        RETURN VARCHAR2
    AS
        SRETURN      VARCHAR2 (500) := NULL;
        SRETURN1     VARCHAR2 (500) := NULL;
        CLASSEMENT   VARCHAR2 (500) := NULL;
    BEGIN
        /*  SELECT
          CASE WHEN dprdtclassement IS NOT NULL THEN  (SELECT Nvl(max (TCSLIBELLE||': '||(SELECT Nvl(Max(TCSLIBELLE),' ')  FROM lkdprtcs lkd, lantclassesanssuite lan WHERE dosid = dpr.dosid
                                                              and lkd.TCSCODE = lan.TCSCODE AND lancode ='FR' AND  DTCNIVEAU =2)),' ') INTO SRETURN
                                                                FROM lkdprtcs lkd, lantclassesanssuite lan WHERE dosid = dpr.dosid
                                                                and lkd.TCSCODE = lan.TCSCODE AND lancode ='FR' AND DTCNIVEAU = 1)
          ELSE (SELECT Nvl(Max(Decode (DPC.adecode,'DECI04',DPC.DCOCOMMENT,' ')),' ')  INTO SRETURN FROM dprworstep dpw, dprconclusion dpc, lanavtdecision lan WHERE
                    DPC.dosid = dpr.dosid AND
                    ((WORCODE = 'WFANA' AND WSTORDER = 8) OR (WORCODE = 'WFQUICK' AND WSTORDER = 2)) AND
                    wststatus ='TER' AND
                    dpc.adecode = lan.adecode AND
                    DPC.creid = DPW.creid
                    )
          END
          FROM dossierprospect dpr WHERE dosid = nDOSID
          AND DPRVERSION = (
                                    SELECT DPRVERSION FROM V_DEAL VDE WHERE VDE.DOSID = dpr.dosid
                        );

        */


        SELECT NVL (
                   MAX (
                          TCSLIBELLE
                       || ': '
                       || (SELECT NVL (MAX (TCSLIBELLE), ' ')
                             FROM lkdprtcs lkd, lantclassesanssuite lan
                            WHERE     dosid = nDOSID
                                  AND lkd.TCSCODE = lan.TCSCODE
                                  AND lancode = 'FR'
                                  AND DTCNIVEAU = 2)),
                   ' ')
          INTO SRETURN
          FROM lkdprtcs lkd, lantclassesanssuite lan
         WHERE     dosid = nDOSID
               AND lkd.TCSCODE = lan.TCSCODE
               AND lancode = 'FR'
               AND DTCNIVEAU = 1;

        SELECT NVL (
                   MAX (DECODE (DPC.adecode, 'DECI04', DPC.DCOCOMMENT, ' ')),
                   ' ')
          INTO SRETURN1
          FROM dprworstep dpw, dprconclusion dpc, lanavtdecision lan
         WHERE     DPC.dosid = nDOSID
               AND (   (WORCODE = 'WFANA' AND WSTORDER = 8)
                    OR (WORCODE = 'WFQUICK' AND WSTORDER = 2))
               AND wststatus = 'TER'
               AND dpc.adecode = lan.adecode
               AND DPC.creid = DPW.creid;


        SELECT dprdtclassement
          INTO CLASSEMENT
          FROM dossierprospect dpr
         WHERE     dosid = nDOSID
               AND DPRVERSION = (SELECT DPRVERSION
                                   FROM V_DEAL VDE
                                  WHERE VDE.DOSID = dpr.dosid);

        IF CLASSEMENT IS NOT NULL
        THEN
            RETURN SRETURN;
        ELSE
            RETURN SRETURN1;
        END IF;
    /*declare
      SRETURN VARCHAR2(500) := NULL;
      SIMPU   VARCHAR2(500) := NULL;
      CURSOR CIMPU IS

      select LTC.TCSLIBELLE
      from LKDPRTCS TCS, LANTCLASSESANSSUITE LTC
      where TCS.TCSCODE=LTC.TCSCODE
      and LTC.LANCODE='FR'
      and TCS.DOSID=NDOSID
      AND TCS.DPRVERSION=nDPRVERSION;

    BEGIN

        OPEN cIMPU;
        LOOP
          FETCH cIMPU
            INTO SIMPU;
          EXIT WHEN cIMPU%NOTFOUND;
          IF (SIMPU IS NOT NULL) THEN
            sreturn := sIMPU || ' / ' || sreturn;
          else
            sreturn := sreturn;
          END IF;

        END LOOP;
        CLOSE CIMPU;
         sReturn := substr(sreturn, 1, length(sreturn) - 3);

      IF (sReturn = ' / ') then
        sReturn := null;
      end if;
      RETURN SRETURN;
    END;*/



    END F_GET_REASON_REJECT;

    --------------------------------------------------------------------------------------
    FUNCTION F_GET_MT_APPROBATION (
        nDOSID        IN DOSSIERPROSPECT.DOSID%TYPE,
        nDPRVERSION   IN DOSSIERPROSPECT.DPRVERSION%TYPE)
        RETURN NUMBER
    IS
        nResult   NUMBER;
    BEGIN
        SELECT PFI.PFIINVESTISSEMENT
          INTO nResult
          FROM DPRCOMPLEMENT          DCM,
               DOSSIERPROSPECT        DPRAUTO,
               PROPOSITIONFINANCIERE  PFI,
               DPRPROPFINANCE         DPF
         WHERE     DCM.DOSID = nDOSID
               AND DCM.DOSIDAUTORISATION = DPRAUTO.DOSID
               AND DCM.DPRVERSION =
                   PA_AVCOMMUN.F_DERNIEREVERSIONDOSSIER (DCM.DOSID)
               AND DCM.DPRVERSION = DPRAUTO.DPRVERSION
               AND DPRAUTO.DOSID = DPF.DOSID
               AND DPRAUTO.DPRVERSION = DPF.DPRVERSION
               AND DPF.DPFORDRE =
                   (SELECT MAX (DPF1.DPFORDRE)
                      FROM DPRPROPFINANCE DPF1
                     WHERE     DPRAUTO.DOSID = DPF1.DOSID
                           AND DPRAUTO.DPRVERSION = DPF1.DPRVERSION)
               AND DPF.PFIID = PFI.PFIID;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN 0;
    END F_GET_MT_APPROBATION;

    ----------------------------------------------------------------------------------
---UTILISE DANS SGM45
    FUNCTION F_GET_MONTANT_APPROB (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    IS
        nResult   NUMBER;
    BEGIN
        SELECT PFIINVESTISSEMENT
          INTO nResult
          FROM PROPOSITIONFINANCIERE
         WHERE pfiid IN
                   (SELECT pfiid
                      FROM dprpropfinance
                     WHERE     dosid = nDOSID
                           AND dpfflagretenue = 1
                           AND DPRVERSION =F_DERNIEREVERSIONDOSSIER(dosid)
                           AND DPFORDRE =
                               (SELECT MAX (DPFORDRE)
                                  FROM DPRPROPFINANCE
                                 WHERE dosid = nDOSID  AND DPRVERSION =F_DERNIEREVERSIONDOSSIER(dosid)
                                 and dpfflagretenue = 1));

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN 0;
    END F_GET_MONTANT_APPROB;


    --------------------------------------------------------------------------------------
    FUNCTION F_GET_DT_APPROBATION (
        nDOSID        IN DOSSIERPROSPECT.DOSID%TYPE,
        nDPRVERSION   IN DOSSIERPROSPECT.DPRVERSION%TYPE)
        RETURN DATE
    IS
        nResult   DATE;
    BEGIN
        SELECT DPRAUTO.DPRDTCREATION
          INTO nResult
          FROM DPRCOMPLEMENT          DCM,
               DOSSIERPROSPECT        DPRAUTO,
               PROPOSITIONFINANCIERE  PFI,
               DPRPROPFINANCE         DPF
         WHERE     DCM.DOSID = nDOSID
               AND DCM.DOSIDAUTORISATION = DPRAUTO.DOSID
               AND DCM.DPRVERSION =
                   PA_AVCOMMUN.F_DERNIEREVERSIONDOSSIER (DCM.DOSID)
               AND DCM.DPRVERSION = DPRAUTO.DPRVERSION
               AND DPRAUTO.DOSID = DPF.DOSID
               AND DPRAUTO.DPRVERSION = DPF.DPRVERSION
               AND DPF.DPFORDRE =
                   (SELECT MAX (DPF1.DPFORDRE)
                      FROM DPRPROPFINANCE DPF1
                     WHERE     DPRAUTO.DOSID = DPF1.DOSID
                           AND DPRAUTO.DPRVERSION = DPF1.DPRVERSION)
               AND DPF.PFIID = PFI.PFIID;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_DT_APPROBATION;

    --------------------------------------------------------------------------------------
    FUNCTION F_GET_DT_LIMITE_APPRO (
        nDOSID        IN DOSSIERPROSPECT.DOSID%TYPE,
        nDPRVERSION   IN DOSSIERPROSPECT.DPRVERSION%TYPE)
        RETURN DATE
    IS
        nResult   DATE;
    BEGIN
        SELECT DPF.DPFDTLIMITE
          INTO nResult
          FROM DPRCOMPLEMENT          DCM,
               DOSSIERPROSPECT        DPRAUTO,
               PROPOSITIONFINANCIERE  PFI,
               DPRPROPFINANCE         DPF
         WHERE     DCM.DOSID = nDOSID
               AND DCM.DOSID = DPRAUTO.DOSID
               AND DCM.DPRVERSION =
                   PA_AVCOMMUN.F_DERNIEREVERSIONDOSSIER (DCM.DOSID)
               AND DCM.DPRVERSION = DPRAUTO.DPRVERSION
               AND DPRAUTO.DOSID = DPF.DOSID
               AND DPRAUTO.DPRVERSION = DPF.DPRVERSION
               AND DPF.DPFORDRE =
                   (SELECT MAX (DPF1.DPFORDRE)
                      FROM DPRPROPFINANCE DPF1
                     WHERE     DPRAUTO.DOSID = DPF1.DOSID
                           AND DPRAUTO.DPRVERSION = DPF1.DPRVERSION)
               AND DPF.PFIID = PFI.PFIID;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_DT_LIMITE_APPRO;

    --------------------------------------------------------------------------------------
    FUNCTION F_GET_SOMME_TIRAGE (
        NDOSID        IN DOSSIERPROSPECT.DOSID%TYPE,
        NDPRVERSION   IN DOSSIERPROSPECT.DPRVERSION%TYPE)
        RETURN NUMBER
    IS
        nResult   NUMBER;
    BEGIN
        SELECT SUM (PFI.PFIINVESTISSEMENT)
          INTO nResult
          FROM PROPOSITIONFINANCIERE PFI, DPRPROPFINANCE DPF
         WHERE     DPF.PFIID = PFI.PFIID
               AND DPF.DPFORDRE =
                   (SELECT MAX (DPF1.DPFORDRE)
                      FROM DPRPROPFINANCE DPF1
                     WHERE     DPF1.DOSID = DPF.DOSID
                           AND DPF1.DPRVERSION = DPF.DPRVERSION)
               AND DPF.DOSID IN (SELECT DOSID
                                   FROM DPRCOMPLEMENT
                                  WHERE DOSIDAUTORISATION = NDOSID)
               AND DPF.DPRVERSION =
                   PA_AVCOMMUN.F_DERNIEREVERSIONDOSSIER (DPF.DOSID);

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN 0;
    END F_GET_SOMME_TIRAGE;

    --------------------------------------------------------------------------------------
    FUNCTION F_GET_DERNIER_CONC (
        nDOSID         DOSSIERPROSPECT.DOSID%TYPE,
        nDPRVERSION    DOSSIERPROSPECT.DPRVERSION%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (200);
    BEGIN
        SELECT LAN.ADELIBELLE
          INTO nResult
          FROM DPRCONCLUSION DPR, LANAVTDECISION LAN
         WHERE     DPR.DOSID = nDOSID
               AND DPR.DPRVERSION = nDPRVERSION
               AND DPR.DCOORDRE =
                   (SELECT MAX (DCOORDRE)
                      FROM DPRCONCLUSION
                     WHERE DOSID = DPR.DOSID AND DPRVERSION = DPR.DPRVERSION)
               AND LAN.ADECODE = DPR.ADECODE
               AND LAN.LANCODE = 'FR';


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_DERNIER_CONC;

    --------------------------------------------------------------------------------------
    FUNCTION F_GET_FOURNISSEUR (
        NDOSID         DOSSIERPROSPECT.DOSID%TYPE,
        NDPRVERSION    DOSSIERPROSPECT.DPRVERSION%TYPE,
        nDPMORDRE      NUMBER)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (50);
    BEGIN
        SELECT ACT.ACTNOM
          INTO nResult
          FROM ACTEUR ACT, LKARODPM LAM
         WHERE     LAM.ACTID = ACT.ACTID
               AND LAM.DOSID = NDOSID
               AND LAM.DPRVERSION = NDPRVERSION
               AND LAM.DPMORDRE = nDPMORDRE;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_FOURNISSEUR;

    --------------------------------------------------------------------------------------
    FUNCTION F_GET_ID_FOURN (NDOSID         DOSSIERPROSPECT.DOSID%TYPE,
                             NDPRVERSION    DOSSIERPROSPECT.DPRVERSION%TYPE,
                             NDPMORDRE      NUMBER)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (50);
    BEGIN
        SELECT ACT.ACTID
          INTO nResult
          FROM ACTEUR ACT, LKARODPM LAM
         WHERE     LAM.ACTID = ACT.ACTID
               AND LAM.DOSID = NDOSID
               AND LAM.DPRVERSION = NDPRVERSION
               AND LAM.DPMORDRE = nDPMORDRE;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ID_FOURN;


    ---------------------------------------------------------------------------------------
    /*  FUNCTION F_GET_AGRVALUE_TYPE_TABLE(nDOSID IN DOSSIERPROSPECT.DOSID%TYPE, nRATID IN RATIO.RATID%TYPE, nAGRLINE IN ARAGRID.AGRLINE%TYPE)RETURN VARCHAR2 IS

       nResult VARCHAR2(100);

        BEGIN

       SELECT AGR.AGRVALUE
       INTO nResult
              FROM ARAGRID AGR, ANALYSIS ANA
              WHERE AGR.ANAID=ANA.ANAID
              --AND ANA.DPRVERSION = (SELECT MAX(F_DERNIEREVERSIONDOSSIER(ANA.DOSID)) FROM DUAL)
              AND ANA.ANAID = (SELECT MAX(ANAID) FROM ANALYSIS WHERE DOSID=ANA.DOSID)
              AND AGR.AGRLINE=nAGRLINE
              AND ANA.DOSID=nDOSID
              AND AGR.RATID=nRATID;

             RETURN nResult;

         EXCEPTION
           WHEN OTHERS THEN
           RETURN null;

       END F_GET_AGRVALUE_TYPE_TABLE;*/

    ---------------------------------------------------------------------------------------
    FUNCTION F_GET_AGRVALUE_TYPE_TABLE (
        nDOSID      IN DOSSIERPROSPECT.DOSID%TYPE,
        nRATID      IN RATIO.RATID%TYPE,
        nAGRCODE    IN ARAGRID.AGRGCOCODE%TYPE,
        nAGRORDRE      ARAGRID.AGRORDRE%TYPE,
        nAGRLINE       ARAGRID.AGRLINE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT AGR.AGRVALUE
          INTO nResult
          FROM ARAGRID AGR, ANALYSIS ANA
         WHERE     AGR.ANAID = ANA.ANAID
               AND ANA.DPRVERSION =
                   (SELECT MAX (
                               PAV4_JASPER_FO.F_DERNVERSDOSSIERANALYSIS (
                                   ANA.DOSID))
                      FROM DUAL)
               AND ANA.ANAID = (SELECT MAX (ANAID)
                                  FROM ANALYSIS
                                 WHERE DOSID = ANA.DOSID)
               AND AGR.agrgcocode = nAGRCODE
               AND AGR.AGRORDRE = nAGRORDRE
               AND AGR.AGRLINE = nAGRLINE
               AND ANA.DOSID = nDOSID
               AND AGR.RATID = nRATID;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_AGRVALUE_TYPE_TABLE;

    ----------------------------------------------------------------------------------------

    FUNCTION F_GET_ADRESSE_ACTEUR (nACTID     IN ACTEUR.ACTID%TYPE,
                                   nDOSID     IN DPRACTEUR.DOSID%TYPE,
                                   nROLCODE   IN DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT    DECODE (ADR.ADRVOIE, NULL, '', ADR.ADRVOIE || ', ')
               || DECODE (ADR.ADRLIEUDIT, NULL, '', ADR.ADRLIEUDIT || ', ')
               || DECODE (ADR.ADRVILLE, NULL, '', ADR.ADRVILLE || ', ')
               || DECODE (ADR.ADRCODEPOST, NULL, '', ADR.ADRCODEPOST || ', ')
               || DECODE (ADR.ADRSUBREGION, NULL, '', ADR.ADRSUBREGION)
          INTO nResult
          FROM ADRESSE ADR
         WHERE ADR.ADRID IN
                   (SELECT MAX (ADR.ADRID)
                      FROM DOSSIERPROSPECT  DPR,
                           DPRACTEUR        DAC,
                           ADRESSE          ADR,
                           ACTADRESSE       AAD,
                           CODEPOSTAL       COP
                     WHERE     DPR.DOSID = DAC.DOSID
                           AND DPR.DPRVERSION = DAC.DPRVERSION
                           AND DPR.DPRVERSION =
                               (SELECT MAX (
                                           F_DERNIEREVERSIONDOSSIER (
                                               DPR.DOSID))
                                  FROM DUAL)
                           AND AAD.ACTID = DAC.ACTID
                           AND AAD.AADFLAGSIEGE = 1
                           AND ADR.ADRID = AAD.ADRID
                           AND ADR.ADRCODEPOST = COP.CPOCODE
                           AND ADR.PAYCODE = COP.PAYCODE
                           AND DAC.ACTID = nACTID
                           AND DAC.ROLCODE = nROLCODE
                           AND DPR.DOSID = nDOSID);



        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN '-';
    END F_GET_ADRESSE_ACTEUR;

    ----------------------------------------------------------------------------------------------
    FUNCTION F_GET_CODE_ACTEUR (nACTID     IN ACTEUR.ACTID%TYPE,
                                nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                nROLCODE      DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT ACT.ACTCODE
          INTO nResult
          FROM DOSSIERPROSPECT DPR, DPRACTEUR DAC, ACTEUR ACT
         WHERE     DPR.DOSID = DAC.DOSID
               AND DPR.DPRVERSION = DAC.DPRVERSION
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND DAC.ACTID = ACT.ACTID
               AND ACT.ACTID = nACTID
               AND DAC.ROLCODE = nROLCODE
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_CODE_ACTEUR;

    ---------------------------------------------------------------------------------------------
    FUNCTION F_GET_NB_GARANT (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                              sTGACODE   IN TGARANTIE.TGACODE%TYPE)
        RETURN NUMBER
    IS
        nreturn   NUMBER;
    BEGIN
        SELECT COUNT (*)
          INTO nreturn
          FROM DOSSIERPROSPECT P, DPRPROPFINANCE DP, PFIGUARANTEE PG
         WHERE     P.DOSID = nDOSID
               AND P.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (P.DOSID)) FROM DUAL)
               AND DP.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (P.DOSID)) FROM DUAL)
               AND P.DOSID = DP.DOSID
               AND DP.DPFFLAGRETENUE = 1
               AND DP.PFIID = PG.PFIID
               AND PG.TGACODE = sTGACODE
               AND PG.ROLCODE = 'GARANT';

        RETURN nRETURN;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN 0;
    END F_GET_NB_GARANT;

    ----------------------------------------------------------------------------------------------
    FUNCTION F_GET_LISTE_GARANTS_CAUT_SOLID (
        nDOSID   IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    AS
        SRETURN     VARCHAR2 (500) := NULL;
        sGarantie   VARCHAR2 (500) := NULL;

        CURSOR cGarantie
        IS
            SELECT    PAV4_JASPER_FO.F_GET_TITRE_ACTEUR (DAC.ACTID,
                                                         DPR.DOSID,
                                                         'GARANT')
                   || ' '
                   || PAV4_JASPER_FO.F_GET_NOM_ACTEUR (DAC.ACTID,
                                                       DPR.DOSID,
                                                       'GARANT')
              FROM LANTGARANTIE    TGA,
                   PFIGUARANTEE    PFG,
                   DPRPROPFINANCE  DPR,
                   DPRACTEUR       DAC
             WHERE     DPR.PFIID = PFG.PFIID
                   AND TGA.TGACODE = PFG.TGACODE
                   AND TGA.LANCODE = 'FR'
                   AND DPR.DOSID = DAC.DOSID
                   AND DAC.ROLCODE = 'GARANT'
                   AND DAC.ACTID = PFG.ACTID
                   AND DPR.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                          FROM DUAL)
                   AND DAC.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DAC.DOSID))
                          FROM DUAL)
                   AND DPR.DPRVERSION = DAC.DPRVERSION
                   AND DPR.DPFORDRE =
                       (SELECT MAX (DPFORDRE)
                          FROM DPRPROPFINANCE DPR2
                         WHERE     DPR2.DOSID = DPR.DOSID
                               AND DPR2.DPRVERSION = DPR.DPRVERSION)
                   AND PFG.TGACODE = '101'
                   AND DPR.DOSID = nDOSID
            UNION ALL
            SELECT    PAV4_JASPER_FO.F_GET_TITRE_ACTEUR (DAC.ACTID,
                                                         DPR.DOSID,
                                                         'CLIENT')
                   || ' '
                   || PAV4_JASPER_FO.F_GET_NOM_ACTEUR (DAC.ACTID,
                                                       DPR.DOSID,
                                                       'CLIENT')
              FROM LANTGARANTIE    TGA,
                   PFIGUARANTEE    PFG,
                   DPRPROPFINANCE  DPR,
                   DPRACTEUR       DAC
             WHERE     DPR.PFIID = PFG.PFIID
                   AND TGA.TGACODE = PFG.TGACODE
                   AND TGA.LANCODE = 'FR'
                   AND DPR.DOSID = DAC.DOSID
                   AND DAC.ROLCODE = 'CLIENT'
                   AND DAC.ACTID = PFG.ACTID
                   AND DPR.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                          FROM DUAL)
                   AND DAC.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DAC.DOSID))
                          FROM DUAL)
                   AND DPR.DPRVERSION = DAC.DPRVERSION
                   AND DPR.DPFORDRE =
                       (SELECT MAX (DPFORDRE)
                          FROM DPRPROPFINANCE DPR2
                         WHERE     DPR2.DOSID = DPR.DOSID
                               AND DPR2.DPRVERSION = DPR.DPRVERSION)
                   AND PFG.TGACODE = '101'
                   AND DPR.DOSID = nDOSID;
    BEGIN
        OPEN cGarantie;

        LOOP
            FETCH cGarantie INTO sGarantie;

            EXIT WHEN cGarantie%NOTFOUND;

            IF (SGARANTIE IS NOT NULL)
            THEN
                sreturn := sGarantie || ' , ' || sreturn;
            ELSE
                sreturn := sreturn;
            END IF;
        END LOOP;

        CLOSE CGARANTIE;

        sReturn := SUBSTR (sreturn, 1, LENGTH (sreturn) - 3);

        IF (sReturn = ' / ')
        THEN
            sReturn := NULL;
        END IF;

        RETURN sReturn;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_LISTE_GARANTS_CAUT_SOLID;


    ---------------------------------------------------------------------------
    FUNCTION F_GET_LISTE_GARANTIES_AUTRES (
        nDOSID   IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    AS
        SRETURN     VARCHAR2 (500) := NULL;
        sGarantie   VARCHAR2 (500) := NULL;

        CURSOR cGarantie
        IS
            SELECT TGA.TGALIBELLE
              FROM LANTGARANTIE TGA, PFIGUARANTEE PFG, DPRPROPFINANCE DPR
             WHERE     DPR.PFIID = PFG.PFIID
                   AND TGA.TGACODE = PFG.TGACODE
                   AND TGA.LANCODE = 'FR'
                   AND DPR.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                          FROM DUAL)
                   AND DPR.DPFORDRE = (SELECT MAX (DPFORDRE)
                                         FROM DPRPROPFINANCE DPR2
                                        WHERE DPR2.DOSID = DPR.DOSID)
                   AND PFG.TGACODE <> '101'
                   AND DPR.DOSID = nDOSID;
    BEGIN
        OPEN cGarantie;

        LOOP
            FETCH cGarantie INTO sGarantie;

            EXIT WHEN cGarantie%NOTFOUND;

            IF (SGARANTIE IS NOT NULL)
            THEN
                sreturn := sGarantie || ' , ' || sreturn;
            ELSE
                sreturn := sreturn;
            END IF;
        END LOOP;

        CLOSE CGARANTIE;

        sReturn := SUBSTR (sreturn, 1, LENGTH (sreturn) - 3);

        IF (sReturn = ' / ')
        THEN
            sReturn := NULL;
        END IF;

        RETURN sReturn;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_LISTE_GARANTIES_AUTRES;

    ----------------------------------------------------------------------------------------------------
    FUNCTION F_GET_CONDITION_SUSPENSIVE (
        nDOSID         DOSSIERPROSPECT.DOSID%TYPE,
        nDPRVERSION    DOSSIERPROSPECT.DPRVERSION%TYPE)
        RETURN VARCHAR2
    AS
    BEGIN
        DECLARE
            SRETURN   VARCHAR2 (4000) := NULL;
            SIMPU     VARCHAR2 (4000) := NULL;

            CURSOR CIMPU
            IS
                SELECT forl.FORLIBELLE
                  FROM lanformalite forl
                 WHERE     forl.lancode = 'FR'
                       AND forid IN
                               (SELECT forid
                                  FROM administratif ad
                                 WHERE     EXISTS
                                               (SELECT *
                                                  FROM administratif ad2
                                                 WHERE     ad2.admid =
                                                           ad.admidparent
                                                       AND ad2.forid = 5106)
                                       AND DOSIDPROSPECT = nDOSID);
        BEGIN
            OPEN cIMPU;

            LOOP
                FETCH cIMPU INTO SIMPU;

                EXIT WHEN cIMPU%NOTFOUND;

                IF (SIMPU IS NOT NULL)
                THEN
                    sreturn := CHR (10) || '- ' || sIMPU || sreturn;
                ELSE
                    sreturn := sreturn;
                END IF;
            END LOOP;

            CLOSE CIMPU;

            sReturn := SUBSTR (sreturn, 1, LENGTH (sreturn) - 1);

            IF (sReturn = ' / ')
            THEN
                sReturn := NULL;
            END IF;

            RETURN SRETURN;
        END;
    END F_GET_CONDITION_SUSPENSIVE;

    ----------------------------------------------------------------------------------------------------
    FUNCTION F_GET_OBSERVATIONS_COND_SUSP (nDOSID DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    AS
    BEGIN
        DECLARE
            SRETURN   VARCHAR2 (4000) := NULL;
            SIMPU     VARCHAR2 (4000) := NULL;

            CURSOR CIMPU
            IS
                SELECT ADMCOMMENT
                  FROM administratif ad
                 WHERE     EXISTS
                               (SELECT *
                                  FROM administratif ad2
                                 WHERE     ad2.admid = ad.admidparent
                                       AND ad2.forid = 5106)
                       AND DOSIDPROSPECT = nDOSID;
        BEGIN
            OPEN cIMPU;

            LOOP
                FETCH cIMPU INTO SIMPU;

                EXIT WHEN cIMPU%NOTFOUND;

                IF (SIMPU IS NOT NULL)
                THEN
                    sreturn := CHR (10) || '- ' || sIMPU || sreturn;
                ELSE
                    sreturn := sreturn;
                END IF;
            END LOOP;

            CLOSE CIMPU;

            sReturn := SUBSTR (sreturn, 1, LENGTH (sreturn) - 1);

            IF (sReturn = ' / ')
            THEN
                sReturn := NULL;
            END IF;

            RETURN SRETURN;
        END;
    END F_GET_OBSERVATIONS_COND_SUSP;

    ------------------------------------------------------------------------------------------------

    FUNCTION F_GET_DESIGN_MAT (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    AS
    BEGIN
        DECLARE
            SRETURN   VARCHAR2 (4000) := NULL;
            SIMPU     VARCHAR2 (4000) := NULL;



            CURSOR CIMPU
            IS
                SELECT DPMLIBELLE
                  FROM DPRMATERIEL
                 WHERE     DPRVERSION =
                           (SELECT MAX (F_DERNIEREVERSIONDOSSIER (nDOSID))
                              FROM DUAL)
                       AND DOSID = nDOSID;
        BEGIN
            OPEN cIMPU;

            LOOP
                FETCH cIMPU INTO SIMPU;

                EXIT WHEN cIMPU%NOTFOUND;

                IF (SIMPU IS NOT NULL)
                THEN
                    sreturn := CHR (10) || '- ' || sIMPU || sreturn;
                ELSE
                    sreturn := sreturn;
                END IF;
            END LOOP;

            CLOSE CIMPU;

            sReturn := SUBSTR (sreturn, 1, LENGTH (sreturn));

            IF (sReturn = ' / ')
            THEN
                sReturn := NULL;
            END IF;

            RETURN SRETURN;
        END;
    END F_GET_DESIGN_MAT;

    ------------------------------------------------------------------------------------------------

    FUNCTION F_GET_ORIGINE_BIEN (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    AS
    BEGIN
        DECLARE
            SRETURN   VARCHAR2 (4000) := NULL;
            SIMPU     VARCHAR2 (4000) := NULL;



            CURSOR CIMPU
            IS
                SELECT CCH.CVASTRINGVALUE
                  FROM DPRMATERIEL DPR, CCHVALUE CCH
                 WHERE     DPR.DOSID = CCH.DOSIDPROSPECT
                       AND DPR.DPRVERSION = CCH.DPRVERSION
                       AND CCH.CCHSID = 'CMBCCHSID57317'
                       AND DPR.DPRVERSION =
                           (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                              FROM DUAL)
                       AND CCH.CVAPKEYVALUE =
                           (   'Dosid-'
                            || DPR.DOSID
                            || '||Dprversion-'
                            || DPR.DPRVERSION
                            || '||Dpmordre-'
                            || DPR.DPMORDRE
                            || '||')
                       AND DPR.DOSID = nDOSID;
        BEGIN
            OPEN cIMPU;

            LOOP
                FETCH cIMPU INTO SIMPU;

                EXIT WHEN cIMPU%NOTFOUND;

                IF (SIMPU IS NOT NULL)
                THEN
                    sreturn := CHR (10) || '- ' || sIMPU || sreturn;
                ELSE
                    sreturn := sreturn;
                END IF;
            END LOOP;

            CLOSE CIMPU;

            sReturn := SUBSTR (sreturn, 1, LENGTH (sreturn));

            IF (sReturn = ' / ')
            THEN
                sReturn := NULL;
            END IF;

            RETURN SRETURN;
        END;
    END F_GET_ORIGINE_BIEN;

    ------------------------------------------------------------------------------------------------

    FUNCTION F_GET_QUANTITE_MAT (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    AS
    BEGIN
        DECLARE
            SRETURN   VARCHAR2 (4000) := NULL;
            SIMPU     VARCHAR2 (4000) := NULL;



            CURSOR CIMPU
            IS
                SELECT DMDQUANTITE
                  FROM DPMDETAIL
                 WHERE     DPRVERSION =
                           (SELECT MAX (F_DERNIEREVERSIONDOSSIER (nDOSID))
                              FROM DUAL)
                       AND DOSID = nDOSID;
        BEGIN
            OPEN cIMPU;

            LOOP
                FETCH cIMPU INTO SIMPU;

                EXIT WHEN cIMPU%NOTFOUND;

                IF (SIMPU IS NOT NULL)
                THEN
                    sreturn := CHR (10) || sIMPU || sreturn;
                ELSE
                    sreturn := sreturn;
                END IF;
            END LOOP;

            CLOSE CIMPU;

            sReturn := SUBSTR (sreturn, 1, LENGTH (sreturn));

            IF (sReturn = ' / ')
            THEN
                sReturn := NULL;
            END IF;

            RETURN SRETURN;
        END;
    END F_GET_QUANTITE_MAT;

    ------------------------------------------------------------------------------------------------

    FUNCTION F_GET_MT_UNIT (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    AS
    BEGIN
        DECLARE
            SRETURN   VARCHAR2 (4000) := NULL;
            SIMPU     VARCHAR2 (4000) := NULL;



            CURSOR CIMPU
            IS
                SELECT DMDPRIXUNITAIRE
                  FROM DPMDETAIL
                 WHERE     DPRVERSION =
                           (SELECT MAX (F_DERNIEREVERSIONDOSSIER (nDOSID))
                              FROM DUAL)
                       AND DOSID = nDOSID;
        BEGIN
            OPEN cIMPU;

            LOOP
                FETCH cIMPU INTO SIMPU;

                EXIT WHEN cIMPU%NOTFOUND;

                IF (SIMPU IS NOT NULL)
                THEN
                    sreturn := CHR (10) || sIMPU || sreturn;
                ELSE
                    sreturn := sreturn;
                END IF;
            END LOOP;

            CLOSE CIMPU;

            sReturn := SUBSTR (sreturn, 1, LENGTH (sreturn));

            IF (sReturn = ' / ')
            THEN
                sReturn := NULL;
            END IF;

            RETURN SRETURN;
        END;
    END F_GET_MT_UNIT;

    ------------------------------------------------------------------------------------------------

    FUNCTION F_GET_FOURN (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    AS
    BEGIN
        DECLARE
            SRETURN   VARCHAR2 (4000) := NULL;
            SIMPU     VARCHAR2 (4000) := NULL;



            CURSOR CIMPU
            IS
                SELECT PAV4_JASPER_FO.F_GET_ACTOR_NAME (nDOSID, 'FOURN')
                  FROM DUAL;
        BEGIN
            OPEN cIMPU;

            LOOP
                FETCH cIMPU INTO SIMPU;

                EXIT WHEN cIMPU%NOTFOUND;

                IF (SIMPU IS NOT NULL)
                THEN
                    sreturn := CHR (10) || '- ' || sIMPU || sreturn;
                ELSE
                    sreturn := sreturn;
                END IF;
            END LOOP;

            CLOSE CIMPU;

            sReturn := SUBSTR (sreturn, 1, LENGTH (sreturn));

            IF (sReturn = ' / ')
            THEN
                sReturn := NULL;
            END IF;

            RETURN SRETURN;
        END;
    END F_GET_FOURN;



    -------------------------------------------------------------------------------------------------
    FUNCTION F_GET_DERNIERE_CONCLUSION (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        /*SELECT ADELIBELLE
        INTO nResult
            FROM LANAVTDECISION LAN, DPRCONCLUSION DPR, DPRWORSTEP WOR
            WHERE LANCODE='FR'
            AND LAN.ADECODE=DPR.ADECODE
            AND DPR.DOSID=nDOSID
            AND DPR.DPRVERSION = (SELECT DPRVERSION FROM V_DEAL VDE WHERE VDE.DOSID = nDOSID )
            AND DPR.DCOORDRE = (SELECT MAX(DCOORDRE) FROM DPRCONCLUSION WHERE DOSID=DPR.DOSID AND DPRVERSION=DPR.DPRVERSION )
            AND DPR.DOSID=WOR.DOSID
            AND DPR.DPRVERSION=WOR.DPRVERSION
            AND DPR.CREID=WOR.CREID
            and worcode ='WFANA' and wstorder= 8
            and wststatus ='TER';
       */
        SELECT LAN.ADELIBELLE
          INTO nResult
          FROM dprworstep dpw, dprconclusion dpc, lanavtdecision lan
         WHERE     DPC.dosid = nDOSID
               AND dpw.creid =
                   (SELECT MAX (dpw2.creid)
                      FROM dprworstep dpw2
                     WHERE     dpw2.dosid = dpw.dosid
                           AND dpw2.dprversion = dpw.dprversion
                           AND (   (WORCODE = 'WFANA' AND WSTORDER = 8)
                                OR (WORCODE = 'WFQUICK' AND WSTORDER = 2))
                           AND wststatus = 'TER')
               AND dpc.adecode = lan.adecode
               AND DPC.creid = DPW.creid;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_DERNIERE_CONCLUSION;

    -------------------------------------------------------------------------------------------------
    FUNCTION F_GET_CODE_DERNIERE_CONCLUSION (
        nDOSID   IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        /*SELECT LAN.ADECODE
        INTO nResult
            FROM LANAVTDECISION LAN, DPRCONCLUSION DPR, DPRWORSTEP WOR
            WHERE LANCODE='FR'
            AND LAN.ADECODE=DPR.ADECODE
            AND DPR.DOSID=nDOSID
            AND DPR.DPRVERSION = (SELECT DPRVERSION FROM V_DEAL VDE WHERE VDE.DOSID = nDOSID )
            AND DPR.DCOORDRE = (SELECT MAX(DCOORDRE) FROM DPRCONCLUSION WHERE DOSID=DPR.DOSID AND DPRVERSION=DPR.DPRVERSION )
            AND DPR.DOSID=WOR.DOSID
            AND DPR.DPRVERSION=WOR.DPRVERSION
            AND DPR.CREID=WOR.CREID
            and worcode ='WFANA' and wstorder= 8
            and wststatus ='TER';*/


        SELECT LAN.ADECODE
          INTO nResult
          FROM dprworstep dpw, dprconclusion dpc, lanavtdecision lan
         WHERE     DPC.dosid = nDOSID
               AND (   (WORCODE = 'WFANA' AND WSTORDER = 8)
                    OR (WORCODE = 'WFQUICK' AND WSTORDER = 2))
               AND wststatus = 'TER'
               AND dpc.adecode = lan.adecode
               AND DPC.creid = DPW.creid;



        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_CODE_DERNIERE_CONCLUSION;

    -------------------------------------------------------------------------------------------------
    FUNCTION F_GET_CODE_DERN_CONCLU (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT LAN.ADECODE
          INTO nResult
          FROM dprworstep dpw, dprconclusion dpc, lanavtdecision lan
         WHERE     DPC.dosid = nDOSID
               AND dpw.creid =
                   (SELECT MAX (dpw2.creid)
                      FROM dprworstep dpw2
                     WHERE     dpw2.dosid = dpw.dosid
                           AND dpw2.dprversion = dpw.dprversion
                           AND (   (    WORCODE = 'WFANA'
                                    AND WSTORDER IN (71,
                                                     72,
                                                     73,
                                                     74))
                                OR (WORCODE = 'WFQUICK' AND WSTORDER = 2)))
               AND wststatus = 'TER'
               AND dpc.adecode = lan.adecode
               AND dpc.creid = dpw.creid;



        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_CODE_DERN_CONCLU;

    -------------------------------------------------------------------------------------------------
    FUNCTION F_GET_COMMENT_DECISION_FINALE (
        nDOSID   IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (500);
    BEGIN
        SELECT DCOCOMMENT
          INTO nResult
          FROM DPRCONCLUSION DPR
         WHERE     DPR.DOSID = nDOSID
               AND DPR.DPRVERSION = (SELECT DPRVERSION
                                       FROM V_DEAL VDE
                                      WHERE VDE.DOSID = nDOSID)
               AND DPR.DPFORDRE =
                   (SELECT MAX (DPFORDRE)
                      FROM DPRCONCLUSION
                     WHERE DOSID = DPR.DOSID AND DPRVERSION = DPR.DPRVERSION);


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_COMMENT_DECISION_FINALE;

    ------------------------------------------------------------------------------------------------

    FUNCTION F_GET_COMMENT_COND_SUSP (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (500);
    BEGIN
        SELECT ADMCOMMENT
          INTO nResult
          FROM administratif ad
         WHERE     EXISTS
                       (SELECT *
                          FROM administratif ad2
                         WHERE     ad2.admid = ad.admidparent
                               AND ad2.forid = 5106)
               AND DOSIDPROSPECT = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_COMMENT_COND_SUSP;

    ---------------------------------------------------------------------------------------------------
    FUNCTION F_GET_TSMMETIER (nDOSID      IN DOSSIERPROSPECT.DOSID%TYPE,
                              nWSTORDER   IN DPRWORSTEP.WSTORDER%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (500);
    BEGIN
        SELECT UTI.TSMMETIER
          INTO nResult
          FROM DPRCONCLUSION DPR, DPRWORSTEP WOR, UTITSM UTI
         WHERE     DPR.DOSID = nDOSID
               AND DPR.DPRVERSION = (SELECT DPRVERSION
                                       FROM V_DEAL VDE
                                      WHERE VDE.DOSID = nDOSID)
               AND DPR.DOSID = WOR.DOSID
               AND DPR.DPRVERSION = WOR.DPRVERSION
               AND DPR.CREID = WOR.CREID
               AND UTI.UTICODE = DPR.UTICODE
               AND UTI.TSMMETIER IN ('CDC',
                                     'DC',
                                     'DG',
                                     'DGA')
               AND WOR.WORCODE = 'WFANA'
               AND WOR.WSTORDER IN (71,
                                    72,
                                    73,
                                    74)
               AND TSMFLAGDEFAUT = 1
               AND WOR.WSTORDER = nWSTORDER;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_TSMMETIER;

    -----------------------------------------------------------------------------------------------
    FUNCTION F_GET_MT_DEMANDE (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    IS
        nResult   NUMBER;
    BEGIN
        /*SELECT CRE.CDADATANUMBER
        INTO nResult
             FROM CREDATA CRE, CREVT CVT, DOSSIERPROSPECT DPR
             WHERE DPR.DOSID=nDOSID
             AND CRE.CDACOLONNE='INITIALMT'
             AND CRE.CDATABLE='EVF_DEM_CONCLU'
             AND CVT.CREID=CRE.CREID
             AND CVT.TMFFONCTION=CRE.CDATABLE
             AND CVT.DOSIDPROSPECT = DPR.DOSID
             AND DPR.DPRVERSION = (SELECT DPRVERSION FROM V_DEAL VDE WHERE VDE.DOSID = DPR.DOSID )
             AND CVT.CREDTCREAT =(SELECT MIN(CVT1.CREDTCREAT) FROM CREVT CVT1
                                 WHERE CVT1.DOSIDPROSPECT=CVT.DOSIDPROSPECT
                                 AND CVT1.UTICODEVALID IS NOT NULL
                                 AND CVT1.UTICODESUP IS NULL AND CVT1.TMFFONCTION=CVT.TMFFONCTION);
      */
        SELECT PFIINVESTISSEMENT
          INTO nResult
          FROM PROPOSITIONFINANCIERE PFI, DPRPROPFINANCE DPR
         WHERE     DPR.DOSID = nDOSID
               AND DPR.DPRVERSION = (SELECT MAX (DPRVERSION)
                                       FROM V_DEAL VDE
                                      WHERE VDE.DOSID = DPR.DOSID)
               AND PFI.PFIID = DPR.PFIID
               AND DPR.DPFFLAGRETENUE = 1
               AND DPR.PFIID =
                   (SELECT MAX (PFIID)
                      FROM DPRPROPFINANCE
                     WHERE     DOSID = DPR.DOSID
                           AND DPRVERSION = DPR.DPRVERSION
                           AND DPFFLAGRETENUE = 1);

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_MT_DEMANDE;

    ---------------------------------------------------------------------------------------------
    FUNCTION F_GET_FRAIS_ASSUR (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    IS
        nResult   NUMBER;
    BEGIN
        SELECT PFI.PFPMT
          INTO nResult
          FROM DPRPROPFINANCE DPR, PFIPRESTATION PFI
         WHERE     DPR.DPFFLAGRETENUE = 1
               AND DPR.DPRVERSION = (SELECT MAX (DPRVERSION)
                                       FROM V_DEAL VDE
                                      WHERE VDE.DOSID = DPR.DOSID)
               AND DPR.PFIID = PFI.PFIID
               AND PFI.RUBCODE = 'ASSU'
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_FRAIS_ASSUR;

    -------------------------------------------------------------------------------------------------
    FUNCTION F_GET_PRIX_EN_DEVISE (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    IS
        nResult            NUMBER;
        nb_lignes          NUMBER;
        nb_lignes_devise   NUMBER;
        MT_TOT             NUMBER;
    BEGIN
        SELECT COUNT (*)
          INTO nb_lignes
          FROM V_MATERIEL_FO
         WHERE M_DOSID = nDOSID;

        SELECT COUNT (*)
          INTO nb_lignes_devise
          FROM V_MATERIEL_FO
         WHERE     M_DOSID = nDOSID
               AND "Devise etrangere" IN
                       (SELECT "Devise etrangere"
                          FROM V_MATERIEL_FO
                         WHERE     M_DOSID = nDOSID
                               AND ITRID = (SELECT MIN (ITRID)
                                              FROM V_MATERIEL_FO
                                             WHERE M_DOSID = nDOSID));

        IF nb_lignes = nb_lignes_devise
        THEN
            SELECT SUM ("MT EN DEVISE")
              INTO MT_TOT
              FROM V_MATERIEL_FO
             WHERE M_DOSID = nDOSID;

            nResult := MT_TOT;
        ELSE
            nResult := NULL;
        END IF;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_PRIX_EN_DEVISE;

    ---------------------------------------------------------------------------------

    FUNCTION F_GET_MT_DISPONIBLE (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    IS
        nResult   NUMBER;
    BEGIN
        SELECT f_get_montantdisponible (nDOSID) INTO nResult FROM DUAL;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_MT_DISPONIBLE;

    -------------------------------------------------------------------------------------------------
    FUNCTION F_GET_COMPARE_TYPE_MAT (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult    VARCHAR2 (100);
        nTYPE      VARCHAR2 (100);
        nLIBELLE   VARCHAR2 (100);
        nbTypeM1   NUMBER;
        nbTypeMs   NUMBER;
    BEGIN
        SELECT ACACODE
          INTO nTYPE
          FROM DPRMATERIEL
         WHERE     DOSID = nDOSID
               AND DPRVERSION = (SELECT MAX (DPRVERSION)
                                   FROM V_DEAL VDE
                                  WHERE VDE.DOSID = nDOSID)
               AND DPMORDRE =
                   (SELECT MIN (D.DPMORDRE)
                      FROM DPRMATERIEL D
                     WHERE     D.DOSID = nDOSID
                           AND D.DPRVERSION = (SELECT MAX (DPRVERSION)
                                                 FROM V_DEAL VDE
                                                WHERE VDE.DOSID = nDOSID));

        SELECT ACADESCRIPTION
          INTO nLIBELLE
          FROM DPRMATERIEL M, LANASSETCATEGORY A
         WHERE     M.DOSID = nDOSID
               AND M.ACACODE = A.ACACODE
               AND M.DPRVERSION = (SELECT MAX (DPRVERSION)
                                     FROM V_DEAL VDE
                                    WHERE VDE.DOSID = nDOSID)
               AND M.DPMORDRE =
                   (SELECT MIN (D.DPMORDRE)
                      FROM DPRMATERIEL D
                     WHERE     D.DOSID = nDOSID
                           AND D.DPRVERSION = (SELECT MAX (DPRVERSION)
                                                 FROM V_DEAL VDE
                                                WHERE VDE.DOSID = nDOSID));

        SELECT COUNT (*)
          INTO nbTypeM1
          FROM DPRMATERIEL
         WHERE     DOSID = nDOSID
               AND DPRVERSION = (SELECT MAX (DPRVERSION)
                                   FROM V_DEAL VDE
                                  WHERE VDE.DOSID = nDOSID)
               AND ACACODE = nTYPE;

        SELECT COUNT (*)
          INTO nbTypeMs
          FROM DPRMATERIEL
         WHERE     DOSID = nDOSID
               AND DPRVERSION = (SELECT MAX (DPRVERSION)
                                   FROM V_DEAL VDE
                                  WHERE VDE.DOSID = nDOSID);


        IF (nbTypeM1 = nbTypeMs)
        THEN
            nResult := nLIBELLE;
        ELSE
            nResult := 'Divers';
        END IF;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_COMPARE_TYPE_MAT;

    ----------------------------------------------------------------------------------------------
    FUNCTION F_GET_TYPEPROPOSITION (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (30);
    BEGIN
        SELECT DCODEALTYPE
          INTO nResult
          FROM DPRCOMPLEMENT
         WHERE     DOSID = nDOSID
               AND DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DOSID)) FROM DUAL);


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_TYPEPROPOSITION;

    --------------------------------------------------------------------------------------
    FUNCTION F_GET_RELATION_ACTEUR (nActid     IN ACTEUR.ACTID%TYPE,
                                    nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                    nROLCODE   IN DPRACTEUR.ROLCODE%TYPE)
        RETURN VARCHAR2
    IS
    BEGIN
        DECLARE
            SRETURN   VARCHAR2 (100) := NULL;
            SIMPU     VARCHAR2 (100) := NULL;


            CURSOR CIMPU
            IS
                SELECT    PAV4_JASPER_FO.F_GET_TITRE_ACTEUR (DAC.ACTID,
                                                             DAC.DOSID,
                                                             nROLCODE)
                       || ' '
                       || PAV4_JASPER_FO.F_GET_NOM_ACTEUR (DAC.ACTID,
                                                           DAC.DOSID,
                                                           nROLCODE)
                  FROM V_ACTEUR_FO A, ACTRELATION ARE, DPRACTEUR DAC
                 WHERE     A.A_ACTID = ARE.ACTID
                       AND A.A_ACTID = DAC.ACTID
                       AND ARE.TRECODE = 'DIRIGEANT'
                       AND DAC.DOSID = A.A_DOSID
                       AND DAC.DPRVERSION =
                           (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DAC.DOSID))
                              FROM DUAL)
                       AND A."A_Role Acteur" = nROLCODE
                       AND A.A_ACTID = nACTID
                       AND A.A_DOSID = nDOSID;
        BEGIN
            OPEN cIMPU;

            LOOP
                FETCH cIMPU INTO SIMPU;

                EXIT WHEN cIMPU%NOTFOUND;

                IF (SIMPU IS NOT NULL)
                THEN
                    sreturn := sIMPU || ' ou ' || sreturn;
                ELSE
                    sreturn := sreturn;
                END IF;
            END LOOP;

            CLOSE CIMPU;

            sReturn := SUBSTR (sreturn, 1, LENGTH (sreturn) - 4);

            IF (sReturn = ' ou ')
            THEN
                sReturn := NULL;
            END IF;

            RETURN SRETURN;
        END;
    END F_GET_RELATION_ACTEUR;

    --------------------------------------------------------------------------------------------
    FUNCTION F_GET_FRAIS (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                          nRUBCODE      PFIPRESTATION.RUBCODE%TYPE)
        RETURN NUMBER
    IS
        nResult   NUMBER;
    BEGIN
        SELECT PFI.PFPMT
          INTO nResult
          FROM DPRPROPFINANCE DPR, PFIPRESTATION PFI
         WHERE     DPR.DPFFLAGRETENUE = 1
               AND DPR.DPRVERSION = (SELECT MAX (DPRVERSION)
                                       FROM V_DEAL VDE
                                      WHERE VDE.DOSID = DPR.DOSID)
               AND DPR.PFIID = PFI.PFIID
               AND PFI.RUBCODE = nRUBCODE
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_FRAIS;

    ---------------------------------------------------------------------------------------------
    FUNCTION F_GET_CC_NUMERIQUE (nDOSID    IN DOSSIERPROSPECT.DOSID%TYPE,
                                 nCCHSID      CAS_CCHVALUE.CCHSID%TYPE)
        RETURN NUMBER
    IS
        nResult   NUMBER;
    BEGIN
        SELECT CCH.CVANUMERICVALUE
          INTO nResult
          FROM DOSSIERPROSPECT  DPR,
               CCHVALUE         CCH
         WHERE DPR.DOSID = nDOSID and  DPR.DPRVERSION =F_DERNIEREVERSIONDOSSIER (DPR.DOSID)
               AND CCH.DOSIDPROSPECT = DPR.DOSID
               AND CCH.DPRVERSION = DPR.DPRVERSION
               AND CCH.CCHSID = nCCHSID ;



        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_CC_NUMERIQUE;

    ----------------------------------------------------------------------------------------------

    FUNCTION F_GET_SUM_SERVICE (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    IS
        nResult   NUMBER;
    BEGIN
        SELECT NVL (
                     SUM (NVL (PFI.pecmtincidental, 0))
                   + SUM (NVL (PFI.PECMTTAX, 0)),
                   0)
          INTO nResult
          FROM PFIRUBECHEANCIER PFI, DPRPROPFINANCE DPR
         WHERE     DPR.PFIID = PFI.PFIID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND DPR.pfiid =
                   (SELECT MAX (pfiid)
                      FROM DPRPROPFINANCE
                     WHERE DOSID = dpr.dosid AND DPFFLAGRETENUE = 1)
               AND PFI.PECTYPEELEMENT = 'LOYER'
               AND DPR.DPFFLAGRETENUE = 1
               AND pfi.pfpordre IS NOT NULL
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN 0;
    END F_GET_SUM_SERVICE;

    --------------------------------------------------------------------------------------------------
    FUNCTION F_GET_CC_DOS_DT (nDOSID    IN DOSSIERPROSPECT.DOSID%TYPE,
                              nCCHSID      CCHVALUE.CCHSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT TO_CHAR (CCH.CVADTVALUE, 'DD/MM/YYYY')
          INTO nResult
          FROM CCHVALUE CCH
         WHERE     CCH.DOSIDPROSPECT = nDOSID
               AND CCH.CCHSID = nCCHSID
               AND CCH.CVAID =
                   (SELECT MAX (CVAID)
                      FROM CCHVALUE
                     WHERE     CCHSID = nCCHSID
                           AND DOSIDPROSPECT = nDOSID
                           AND CCH.DPRVERSION =
                               (SELECT MAX (
                                           F_DERNIEREVERSIONDOSSIER (
                                               CCH.DOSIDPROSPECT))
                                  FROM DUAL)
                           AND CVAPKEYVALUE LIKE
                                      'Dosid-'
                                   || nDOSID
                                   || '||Dprversion-'
                                   || CCH.DPRVERSION
                                   || '||%');



        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_CC_DOS_DT;

    -----------------------------------------------------------------------------------------------
    FUNCTION F_GET_TAUX_ACTUALISE (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    IS
        nResult   NUMBER;
    BEGIN
        SELECT MAX (
                   PA_REQUETE_FRONT_TOOL.F_FORMATNUMBERDECIMAL (
                       PAT.PFADOUBLE,
                       3))
          INTO nResult
          FROM PFIATTRIBUT PAT, DPRPROPFINANCE DPR
         WHERE     DPR.DOSID = nDOSID
               AND PAT.PFACODE = 'PFITXAPPARENT'
               AND PAT.PFADOUBLE IS NOT NULL
               AND DPR.PFIID = PAT.PFIID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND DPR.pfiid =
                   (SELECT MAX (pfiid)
                      FROM DPRPROPFINANCE
                     WHERE DOSID = dpr.dosid AND DPFFLAGRETENUE = 1);

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN 0;
    END F_GET_TAUX_ACTUALISE;

    -----------------------------------------------------------------------------------------------
    FUNCTION F_GET_REF_FACT_PROFORMA (nDOSID   IN DOSSIERPROSPECT.DOSID%TYPE,
                                      nACTID   IN ACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (30);
    BEGIN
        SELECT MAX (DPM.DPMEXTERNALREF)
          INTO nResult
          FROM DOSSIERPROSPECT DPR, DPRMATERIEL DPM, LKARODPM LK
         WHERE     DPR.DOSID = nDOSID
               AND DPR.DPRVERSION =
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                      FROM DUAL)
               AND DPR.DOSID = DPM.DOSID
               AND DPR.DPRVERSION = DPM.DPRVERSION
               AND LK.DOSID(+) = DPR.DOSID
               AND LK.DPRVERSION(+) = DPR.DPRVERSION
               AND LK.DPMORDRE(+) = DPM.DPMORDRE
               AND LK.ACTID(+) = nACTID;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_REF_FACT_PROFORMA;

    ---------------------------------------------------------------------------------------------------
    FUNCTION F_GET_ISDEALTRANSFERED (PDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    AS
        LDOSIDTRANSFERED   NUMBER := -1;
    BEGIN
        BEGIN
            SELECT DOSID
              INTO LDOSIDTRANSFERED
              FROM CAS_DOSSIER
             WHERE DOSNUM =
                   (SELECT DISTINCT (DPRNUMCASSIOPEE)
                      FROM DOSSIERPROSPECT
                     WHERE     DOSID = PDOSID
                           AND DPRVERSION =
                               (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DOSID))
                                  FROM DUAL));

            RETURN LDOSIDTRANSFERED;
        EXCEPTION
            WHEN OTHERS
            THEN
                RETURN -1;
        END;
    END F_GET_ISDEALTRANSFERED;

    ------------------------------------------------------------------------------------------------------
    FUNCTION F_GET_NAME_CHARG_COMMERCIAL (nACTID IN ACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT UTI.UTINOM || ' ' || UTI.UTIPRENOM
          INTO nResult
          FROM LKACTUTITSM LKA, UTILISATEUR UTI
         WHERE     LKA.TSMMETIER = 'CC'
               AND LKA.UTICODE = UTI.UTICODE
               AND LKA.ACTID = nACTID;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_NAME_CHARG_COMMERCIAL;


    ---------------------------------------------------------------------
    FUNCTION F_GET_TEL_CHARG_COMMERCIAL (nACTID IN ACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT MAX (UCOREFERENCE)
          INTO nResult
          FROM LKACTUTITSM LK, UTICOORDONNEE UTC
         WHERE     LK.UTICODE = UTC.UTICODE
               AND UTC.UCOTYPE = 'TEL'
               AND LK.TSMMETIER = 'CC'
               AND LK.ACTID = nACTID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_TEL_CHARG_COMMERCIAL;


    FUNCTION F_GET_TEL_CHARG_COMMERCIAL_FO (nACTID IN ACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT MAX (UCOREFERENCE)
          INTO nResult
          FROM LKACTUTITSM LK, UTICOORDONNEE UTC
         WHERE     LK.UTICODE = UTC.UTICODE
               AND UTC.UCOTYPE = 'TEL'
               AND LK.TSMMETIER = 'CA'
               AND LK.ACTID = nACTID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_TEL_CHARG_COMMERCIAL_FO;

    ---------------------------------------------------------------------
    FUNCTION F_GET_EMAIL_CHARG_COMMERCIAL (nACTID IN ACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT MAX (UCOREFERENCE)
          INTO nResult
          FROM LKACTUTITSM LK, UTICOORDONNEE UTC
         WHERE     LK.UTICODE = UTC.UTICODE
               AND UTC.UCOTYPE = 'NET'
               AND LK.TSMMETIER = 'CC'
               AND LK.ACTID = nACTID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_EMAIL_CHARG_COMMERCIAL;

    -----------------------------------------
    FUNCTION F_GET_DPMORDRE_MATERIEL (nDOSID   IN LKARODPM.DOSID%TYPE,
                                      nACTID   IN LKARODPM.ACTID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (1000);
    BEGIN
        nResult := '';

        FOR REC
            IN (SELECT DPR.DPMORDRE AS MAT
                  FROM LKARODPM DPR
                 WHERE     DPR.DOSID = nDOSID
                       AND DPR.ACTID = nACTID
                       AND DPR.dprversion =
                           (SELECT MAX (F_DERNIEREVERSIONDOSSIER (nDOSID))
                              FROM DUAL))
        LOOP
            IF REC.MAT IS NOT NULL
            THEN
                nResult := nResult || REC.MAT || ',';
            END IF;
        END LOOP;

        IF LENGTH (nResult) > 1
        THEN
            SELECT SUBSTR (nResult, 1, LENGTH (nResult) - 1)
              INTO nResult
              FROM DUAL;
        END IF;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_DPMORDRE_MATERIEL;

    FUNCTION F_IMMATRICULATION (
        P_LANCODE       LANGUE.LANCODE%TYPE,
        P_DOSID         DOSSIERPROSPECT.DOSID%TYPE,
        P_DPRVERSION    DOSSIERPROSPECT.DPRVERSION%TYPE,
        P_ORDRE         DPRMATERIEL.DPMORDRE%TYPE)
        RETURN VARCHAR2
    AS
        nSERIE   VARCHAR2 (500);
        nIMMAT   DPRMATERIEL.DPMIMMATRICULATION%TYPE;
        num      DPRMATERIEL.DPMNUMSERIE%TYPE;
    BEGIN
        BEGIN
            SELECT DPM.DPMNUMSERIE
              INTO num
              FROM DPRMATERIEL DPM
             WHERE     DPM.DOSID = P_DOSID
                   AND DPM.DPRVERSION = P_DPRVERSION
                   AND DPM.DPMORDRE = P_ORDRE;
        EXCEPTION
            WHEN OTHERS
            THEN
                num := '';
        END;

        BEGIN
            SELECT DPM.DPMIMMATRICULATION
              INTO nIMMAT
              FROM DPRMATERIEL DPM
             WHERE     DPM.DOSID = P_DOSID
                   AND DPM.DPRVERSION = P_DPRVERSION
                   AND DPM.DPMORDRE = P_ORDRE;
        EXCEPTION
            WHEN OTHERS
            THEN
                nIMMAT := '';
        END;

        BEGIN
            IF nIMMAT IS NOT NULL
            THEN
                IF num IS NOT NULL
                THEN
                    SELECT CONCAT (
                               CONCAT (', N? Immatriculation : ', nIMMAT),
                               CONCAT (', N? Chassis : ', num))
                      INTO nSERIE
                      FROM DUAL;
                ELSE
                    SELECT CONCAT (', N? Immatriculation : ', nIMMAT)
                      INTO nSERIE
                      FROM DUAL;
                END IF;
            ELSE
                IF nIMMAT IS NULL
                THEN
                    IF num IS NOT NULL
                    THEN
                        SELECT CONCAT (', N? Serie : ', num)
                          INTO nSERIE
                          FROM DUAL;
                    END IF;
                END IF;
            END IF;
        EXCEPTION
            WHEN OTHERS
            THEN
                nSERIE := '';
        END;



        RETURN nSERIE;
    END F_IMMATRICULATION;


    FUNCTION F_FACTUREPROFORMA (
        P_DOSID         DOSSIERPROSPECT.DOSID%TYPE,
        P_DPRVERSION    DOSSIERPROSPECT.DPRVERSION%TYPE,
        P_ORDRE         DPRMATERIEL.DPMORDRE%TYPE)
        RETURN VARCHAR2
    AS
        sNumFactpro   VARCHAR2 (50) := '';
    BEGIN
        SELECT CVASTRINGVALUE
          INTO sNumFactpro
          FROM CCHVALUE CCH
         WHERE     CCH.CCHSID = 'TFDCCHSID864'
               AND CCH.DOSIDPROSPECT = P_DOSID
               AND CCH.DPRVERSION = P_DPRVERSION
               AND RTRIM (
                       SUBSTR (CCH.cvapkeyvalue,
                               INSTR (CCH.cvapkeyvalue, 'Dpmordre-') + 9,
                               10),
                       '|') =
                   P_ORDRE;

        RETURN sNumFactpro;
    END F_FACTUREPROFORMA;

    ------------



    FUNCTION F_MODALITEREGFOURN (
        P_LANCODE       LANGUE.LANCODE%TYPE,
        P_DOSID         DOSSIERPROSPECT.DOSID%TYPE,
        P_DPRVERSION    DOSSIERPROSPECT.DPRVERSION%TYPE,
        P_ORDRE         DPRMATERIEL.DPMORDRE%TYPE)
        RETURN VARCHAR2
    AS
        sVal1      VARCHAR2 (250) := '';
        sVal2      VARCHAR2 (250) := '';
        sTUPCODE   VARCHAR2 (250) := '';
        sReturn    VARCHAR2 (250) := '';
        slength    NUMBER;
    BEGIN
        BEGIN
            SELECT CVASTRINGVALUE
              INTO sTUPCODE
              FROM CCHVALUE
             WHERE     CCHSID = 'CMBCCHSID701'
                   AND CVAPKEYVALUE LIKE '%Dpmordre-' || P_ORDRE || '%'
                   AND DOSIDPROSPECT = P_DOSID
                   AND DPRVERSION = P_DPRVERSION
                   AND cvaid =
                       (SELECT MAX (cvaid)
                          FROM CCHVALUE
                         WHERE     CCHSID = 'CMBCCHSID701'
                               AND CVAPKEYVALUE LIKE
                                       '%Dpmordre-' || P_ORDRE || '%'
                               AND DOSIDPROSPECT = P_DOSID
                               AND DPRVERSION = P_DPRVERSION
                               AND CVASTRINGVALUE IS NOT NULL);
        EXCEPTION
            WHEN OTHERS
            THEN
                sTUPCODE := '';
        END;

        BEGIN
            SELECT CVANUMERICVALUE
              INTO sVal1
              FROM CCHVALUE
             WHERE     CCHSID = 'CMBCCHSID2234'
                   AND CVAPKEYVALUE LIKE '%Dpmordre-' || P_ORDRE || '%'
                   AND DOSIDPROSPECT = P_DOSID
                   AND DPRVERSION = P_DPRVERSION
                   AND cvaid =
                       (SELECT MAX (cvaid)
                          FROM CCHVALUE
                         WHERE     CCHSID = 'TFDCCHSID681'
                               AND CVAPKEYVALUE LIKE
                                       '%Dpmordre-' || P_ORDRE || '%'
                               AND DOSIDPROSPECT = P_DOSID
                               AND DPRVERSION = P_DPRVERSION
                               AND CVANUMERICVALUE IS NOT NULL);
        EXCEPTION
            WHEN OTHERS
            THEN
                sVal1 := '';
        END;

        BEGIN
            SELECT TUPLIBELLE
              INTO sVal2
              FROM LANTUSPARAM
             WHERE     TUSNOM = 'REGLFOURN'
                   AND LANCODE = 'FR'
                   AND TUPCODE = sTUPCODE;
        EXCEPTION
            WHEN OTHERS
            THEN
                sVal2 := '';
        END;

        slength := LENGTH (sVal2);

        IF sTUPCODE IN ('REMDOC',
                        'LETCRED',
                        'ALALIV',
                        'TRANSL')
        THEN
            sReturn := sVal2;
        ELSE
            IF sVal1 IS NULL
            THEN
                sReturn := sVal2;
            ELSE
                sReturn :=
                       'A '
                    || sVal1
                    || ' jours de'
                    || SUBSTR (sVal2, 2, LENGTH (sVal2));
            END IF;
        END IF;


        RETURN sReturn;
    END F_MODALITEREGFOURN;



    FUNCTION F_DESIGNATIONMATERIEL (
        P_LANCODE       LANGUE.LANCODE%TYPE,
        P_DOSID         DOSSIERPROSPECT.DOSID%TYPE,
        P_DPRVERSION    DOSSIERPROSPECT.DPRVERSION%TYPE,
        P_ORDRE         DPRMATERIEL.DPMORDRE%TYPE,
        P_DORDRE        DPMDETAIL.DMDORDRE%TYPE)
        RETURN VARCHAR2
    AS
        nMAT           NUMBER;
        sDesignation   VARCHAR2 (2000) := '';
    BEGIN
        /*SELECT Count(*) INTO nMAT FROM DPMDETAIL WHERE DOSID=P_DOSID AND DPRVERSION=P_DPRVERSION AND DPMORDRE = P_ORDRE;

        IF nMAT > 0 then
      SELECT
         (DMDQUANTITE || ' ' || DMDDESIGNATION)
         INTO sDesignation
         FROM DPMDETAIL
         WHERE
         DOSID=P_DOSID
         AND DPRVERSION=P_DPRVERSION
         AND DPMORDRE = P_ORDRE
         AND DMDORDRE = P_DORDRE
        ;
      ELSE */
        SELECT DPMLIBELLE
          INTO sDesignation
          FROM DPRMATERIEL
         WHERE     DOSID = P_DOSID
               AND DPRVERSION = P_DPRVERSION
               AND DPMORDRE = P_ORDRE;

        --END IF;

        sDesignation := SUBSTR (sDesignation, 1, 250);

        RETURN sDesignation;
    END F_DESIGNATIONMATERIEL;



    FUNCTION F_DESCRIP_MAT (P_DOSID         DOSSIERPROSPECT.DOSID%TYPE,
                            P_DPRVERSION    DOSSIERPROSPECT.DPRVERSION%TYPE,
                            P_DPMORDRE      NUMBER)
        RETURN VARCHAR2
    AS
        nMAT     NUMBER;
        nIMMAT   DPRMATERIEL.DPMIMMATRICULATION%TYPE;
        nSERIE   VARCHAR2 (500);
    BEGIN
        BEGIN
            SELECT DPM.DPMIMMATRICULATION
              INTO nIMMAT
              FROM DPRMATERIEL DPM
             WHERE     DPM.DOSID = P_DOSID
                   AND DPM.DPRVERSION = P_DPRVERSION
                   AND DPM.DPMORDRE = P_DPMORDRE;
        EXCEPTION
            WHEN OTHERS
            THEN
                nIMMAT := '';
        END;

        BEGIN
            IF nIMMAT IS NOT NULL
            THEN
                SELECT CONCAT (CONCAT (', N Immatriculation : ', nIMMAT),
                               CONCAT (', N Chassis : ', DPM.DPMNUMSERIE))
                  INTO nSERIE
                  FROM DPRMATERIEL DPM
                 WHERE     DPM.DOSID = P_DOSID
                       AND DPM.DPRVERSION = P_DPRVERSION
                       AND DPM.DPMORDRE = P_DPMORDRE;
            ELSE
                IF nIMMAT IS NULL
                THEN
                    SELECT DECODE (DPM.DPMNUMSERIE,
                                   NULL, NULL,
                                   CONCAT (', N Serie : ', DPM.DPMNUMSERIE))
                      INTO nSERIE
                      FROM DPRMATERIEL DPM
                     WHERE     DPM.DOSID = P_DOSID
                           AND DPM.DPRVERSION = P_DPRVERSION
                           AND DPM.DPMORDRE = P_DPMORDRE;
                END IF;
            END IF;
        EXCEPTION
            WHEN OTHERS
            THEN
                nSERIE := '';
        END;

        RETURN nSERIE;
    END F_DESCRIP_MAT;



    FUNCTION F_modreglement (P_FOURNISSEUR    ACTEUR.ACTID%TYPE,
                             P_DOS            DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    AS
        sMOD   VARCHAR2 (2000) := '';
    BEGIN
        BEGIN
            SELECT MAX (CVASTRINGVALUE)
              INTO sMOD
              FROM CCHVALUE
             WHERE     CCHSID = 'TFDCCHSID702'
                   AND ACTID = P_FOURNISSEUR
                   AND DOSIDPROSPECT = P_DOS
                   AND CVASTRINGVALUE IS NOT NULL;
        EXCEPTION
            WHEN OTHERS
            THEN
                sMOD := NULL;
        END;

        sMOD := SUBSTR (sMOD, 1, 250);

        RETURN sMOD;
    END F_modreglement;



    FUNCTION F_PRIXDEVISE (P_LANCODE       LANGUE.LANCODE%TYPE,
                           P_DOSID         DOSSIERPROSPECT.DOSID%TYPE,
                           P_DPRVERSION    DOSSIERPROSPECT.DPRVERSION%TYPE,
                           P_ORDRE         DPRMATERIEL.DPMORDRE%TYPE)
        RETURN NUMBER
    AS
        nPrixDevise   NUMBER;
    BEGIN
        BEGIN
            SELECT CVANUMERICVALUE
              INTO nPrixDevise
              FROM CCHVALUE CCH
             WHERE     CCH.CCHSID = 'TFDCCHSID731'
                   AND CCH.DOSIDPROSPECT = P_DOSID
                   AND CCH.DPRVERSION = P_DPRVERSION
                   AND RTRIM (
                           SUBSTR (CCH.cvapkeyvalue,
                                   INSTR (CCH.cvapkeyvalue, 'Dpmordre-') + 9,
                                   10),
                           '|') =
                       P_ORDRE;
        EXCEPTION
            WHEN OTHERS
            THEN
                nPrixDevise := '';
        END;

        RETURN nPrixDevise;
    END F_PRIXDEVISE;

    FUNCTION F_DTFACTUREPRO (P_LANCODE       LANGUE.LANCODE%TYPE,
                             P_DOSID         DOSSIERPROSPECT.DOSID%TYPE,
                             P_DPRVERSION    DOSSIERPROSPECT.DPRVERSION%TYPE,
                             P_ORDRE         DPRMATERIEL.DPMORDRE%TYPE)
        RETURN VARCHAR2
    AS
        sDtFactpro   VARCHAR2 (20) := '';
    BEGIN
        BEGIN
            SELECT TO_CHAR (CVADTVALUE, 'DD/MM/YYYY')
              INTO sDtFactpro
              FROM CCHVALUE CCH
             WHERE     CCH.CCHSID = 'TFDCCHSID863'
                   AND CCH.DOSIDPROSPECT = P_DOSID
                   AND CCH.DPRVERSION = P_DPRVERSION
                   AND RTRIM (
                           SUBSTR (CCH.cvapkeyvalue,
                                   INSTR (CCH.cvapkeyvalue, 'Dpmordre-') + 9,
                                   10),
                           '|') =
                       P_ORDRE;
        EXCEPTION
            WHEN OTHERS
            THEN
                sDtFactpro := '';
        END;

        RETURN sDtFactpro;
    END F_DTFACTUREPRO;



    FUNCTION F_DUREEPALIER_ECH (
        P_DOSID         DOSSIERPROSPECT.DOSID%TYPE,
        P_DPRVERSION    DOSSIERPROSPECT.DPRVERSION%TYPE)
        RETURN NUMBER
    AS
        nPFIID    PROPOSITIONFINANCIERE.PFIID%TYPE := NULL;
        nPalier   NUMBER;
    BEGIN
        nPFIID :=
            PA_REQUETE_COMMUN.F_PROPOSITION_RETENUE (P_DOSID,
                                                     P_DPRVERSION,
                                                     NULL);

        SELECT COUNT (*)
          INTO nPalier
          FROM PFRPALIER
         WHERE PFIID = nPFIID;


        RETURN nPalier;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_DUREEPALIER_ECH;

    FUNCTION F_ValPrLoyer (P_DOSID         DOSSIERPROSPECT.DOSID%TYPE,
                           P_DPRVERSION    DOSSIERPROSPECT.DPRVERSION%TYPE)
        RETURN NUMBER
    AS
        nPFIID        PROPOSITIONFINANCIERE.PFIID%TYPE := NULL;
        nValPrLoyer   NUMBER := 0;
    BEGIN
        --nPFIID := PA_REQUETE_COMMUN.F_PROPOSITION_RETENUE( P_DOSID, P_DPRVERSION, NULL );
        SELECT PA_REQUETE_COMMUN.F_PROPOSITION_RETENUE (P_DOSID,
                                                        P_DPRVERSION,
                                                        NULL)
          INTO nPFIID
          FROM DUAL;

        SELECT PFIMTPREMIERLOYER
          INTO nValPrLoyer
          FROM PROPOSITIONFINANCIERE
         WHERE PFIID = nPFIID;


        RETURN nValPrLoyer;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_ValPrLoyer;

    FUNCTION F_PECTX (P_DOSID         DOSSIERPROSPECT.DOSID%TYPE,
                      P_DPRVERSION    DOSSIERPROSPECT.DPRVERSION%TYPE)
        RETURN NUMBER
    AS
        nPFIID   PROPOSITIONFINANCIERE.PFIID%TYPE := NULL;
        nPECTX   NUMBER := 0;
    BEGIN
        --nPFIID := PA_REQUETE_COMMUN.F_PROPOSITION_RETENUE( P_DOSID, P_DPRVERSION, NULL );
        SELECT PA_REQUETE_COMMUN.F_PROPOSITION_RETENUE (P_DOSID,
                                                        P_DPRVERSION,
                                                        NULL)
          INTO nPFIID
          FROM DUAL;

        SELECT PFRTOTALNOMINAL
          INTO nPECTX
          FROM PFIRUBRIQUE
         WHERE PFIID = nPFIID;

        IF nPECTX <= 11
        THEN
            nPECTX := ROUND (11 / 12, 2);
        ELSE
            nPECTX := ROUND (nPECTX / 12, 2);
        END IF;

        RETURN nPECTX;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_PECTX;


    FUNCTION F_MTINVEST (P_DOSID         DOSSIERPROSPECT.DOSID%TYPE,
                         P_DPRVERSION    DOSSIERPROSPECT.DPRVERSION%TYPE)
        RETURN NUMBER
    AS
        nPFIID      PROPOSITIONFINANCIERE.PFIID%TYPE := NULL;
        nMTINVEST   NUMBER := 0;
    BEGIN
        --nPFIID := PA_REQUETE_COMMUN.F_PROPOSITION_RETENUE( P_DOSID, P_DPRVERSION, NULL );
        SELECT PA_REQUETE_COMMUN.F_PROPOSITION_RETENUE (P_DOSID,
                                                        P_DPRVERSION,
                                                        NULL)
          INTO nPFIID
          FROM DUAL;

        SELECT PFIINVESTISSEMENT
          INTO nMTINVEST
          FROM PROPOSITIONFINANCIERE
         WHERE PFIID = nPFIID;


        RETURN nMTINVEST;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_MTINVEST;


    FUNCTION F_VRPOURCENT (P_DOSID         DOSSIERPROSPECT.DOSID%TYPE,
                           P_DPRVERSION    DOSSIERPROSPECT.DPRVERSION%TYPE)
        RETURN NUMBER
    AS
        nPFIID       PROPOSITIONFINANCIERE.PFIID%TYPE := NULL;
        VRPOURCENT   NUMBER := 0;
    BEGIN
        --nPFIID := PA_REQUETE_COMMUN.F_PROPOSITION_RETENUE( P_DOSID, P_DPRVERSION, NULL );
        SELECT PA_REQUETE_COMMUN.F_PROPOSITION_RETENUE (P_DOSID,
                                                        P_DPRVERSION,
                                                        NULL)
          INTO nPFIID
          FROM DUAL;

        SELECT PA_REQUETE_FRONT_TOOL.F_FORMATNUMBERDECIMAL (
                   (  (  PFRVR
                       / (PAV4_JASPER_FO.F_MTINVEST (P_DOSID, P_DPRVERSION)))
                    * 100),
                   3)
          INTO VRPOURCENT
          FROM PFIRUBRIQUE
         WHERE PFIID = nPFIID;

        RETURN VRPOURCENT;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_VRPOURCENT;

    FUNCTION F_MTVR (P_DOSID         DOSSIERPROSPECT.DOSID%TYPE,
                     P_DPRVERSION    DOSSIERPROSPECT.DPRVERSION%TYPE)
        RETURN NUMBER
    AS
        nPFIID   PROPOSITIONFINANCIERE.PFIID%TYPE := NULL;
        MTVR     NUMBER := 0;
    BEGIN
        --nPFIID := PA_REQUETE_COMMUN.F_PROPOSITION_RETENUE( P_DOSID, P_DPRVERSION, NULL );
        SELECT PA_REQUETE_COMMUN.F_PROPOSITION_RETENUE (P_DOSID,
                                                        P_DPRVERSION,
                                                        NULL)
          INTO nPFIID
          FROM DUAL;

        SELECT  PFRVR
          INTO MTVR
          FROM PFIRUBRIQUE
         WHERE PFIID = nPFIID;

        RETURN MTVR;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_MTVR;

    FUNCTION F_VILLERCGARANT (P_GARANT ACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    AS
        sVilleRC   VARCHAR2 (2000) := '';
    BEGIN
        BEGIN
            SELECT CVASTRINGVALUE
              INTO sVilleRC
              FROM CAS_CCHVALUE
             WHERE CCHSID = 'TFDCCHSID1594' AND ACTID = P_GARANT;
        EXCEPTION
            WHEN OTHERS
            THEN
                sVilleRC := NULL;
        END;

        sVilleRC := SUBSTR (sVilleRC, 1, 250);

        RETURN sVilleRC;
    END F_VILLERCGARANT;

    FUNCTION F_DTIDENTITEGARANT (P_GARANT ACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    AS
        dDtIdent   VARCHAR2 (2000) := '';
    BEGIN
        BEGIN
            SELECT TO_CHAR (CVADTVALUE, 'DD/MM/YYYY')
              INTO dDtIdent
              FROM CAS_CCHVALUE
             WHERE cvaid =
                   (SELECT MAX (cvaid)
                      FROM cas_cchvalue
                     WHERE CCHSID = 'TFDCCHSID1695' AND ACTID = P_GARANT);
        EXCEPTION
            WHEN OTHERS
            THEN
                dDtIdent := NULL;
        END;

        dDtIdent := SUBSTR (dDtIdent, 1, 250);

        RETURN dDtIdent;
    END F_DTIDENTITEGARANT;

    FUNCTION F_NUMIDENTITEGARANT (P_GARANT ACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    AS
        nNumIdent   VARCHAR2 (2000) := '';
    BEGIN
        BEGIN
            SELECT CVASTRINGVALUE
              INTO nNumIdent
              FROM CAS_CCHVALUE
             WHERE cvaid =
                   (SELECT MAX (cvaid)
                      FROM cas_cchvalue
                     WHERE CCHSID = 'TFDCCHSID1676' AND ACTID = P_GARANT);
        EXCEPTION
            WHEN OTHERS
            THEN
                nNumIdent := NULL;
        END;

        nNumIdent := SUBSTR (nNumIdent, 1, 250);

        RETURN nNumIdent;
    END F_NUMIDENTITEGARANT;

    FUNCTION F_TYPEIDENTITEGARANT (P_GARANT ACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    AS
        sTypeIdent   VARCHAR2 (2000) := '';
    BEGIN
        BEGIN
            SELECT CVASTRINGVALUE
              INTO sTypeIdent
              FROM CAS_CCHVALUE
             WHERE CVAID =
                   (SELECT MAX (CVAID)
                      FROM CAS_CCHVALUE
                     WHERE CCHSID = 'CMBCCHSID1574' AND ACTID = P_GARANT);
        EXCEPTION
            WHEN OTHERS
            THEN
                sTypeIdent := NULL;
        END;

        sTypeIdent := SUBSTR (sTypeIdent, 1, 250);

        RETURN sTypeIdent;
    END F_TYPEIDENTITEGARANT;

    FUNCTION F_NBGARANT (P_DOSID         DOSSIERPROSPECT.DOSID%TYPE,
                         P_DPRVERSION    DOSSIERPROSPECT.DPRVERSION%TYPE)
        RETURN NUMBER
    AS
        nPFIID    PROPOSITIONFINANCIERE.PFIID%TYPE := NULL;
        nGARANT   NUMBER := 0;
    BEGIN
        --nPFIID := PA_REQUETE_COMMUN.F_PROPOSITION_RETENUE( P_DOSID, P_DPRVERSION, NULL );
        SELECT PA_REQUETE_COMMUN.F_PROPOSITION_RETENUE (P_DOSID,
                                                        P_DPRVERSION,
                                                        NULL)
          INTO nPFIID
          FROM DUAL;

        SELECT COUNT (*)
          INTO nGARANT
          FROM (SELECT ACT.CJUCODE     GARANTNATURE,
                       ACT.ACTNOM      GARANTACTNOM,
                       ACT.ACTLIBCOURT GARANTACTLIB
                  FROM PFIGUARANTEE DGC, ACTEUR ACT
                 WHERE     DGC.ACTID = ACT.ACTID
                       AND DGC.TGACODE IN (39, 31)
                       AND DGC.PFIID = nPFIID);

        RETURN nGARANT;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN 0;
    END F_NBGARANT;


    FUNCTION F_GET_LIB_TMPCODEENC (
        nDOSID        IN DOSSIERPROSPECT.DOSID%TYPE,
        nACTID           DPRACTEUR.ACTID%TYPE,
        nTMPCODEENC      DPRACTEUR.TMPCODEENC%TYPE)
        RETURN VARCHAR2
    IS
        nResult    VARCHAR2 (100);
        nResult1   VARCHAR2 (100);
    BEGIN
        SELECT F_NBGARANT (
                   nDOSID,
                   (SELECT MAX (F_DERNIEREVERSIONDOSSIER (nDOSID)) FROM DUAL))
          INTO nResult1
          FROM DUAL;

        IF nTMPCODEENC = 'EFFET'
        THEN
            IF nResult1 > 1
            THEN
                SELECT 'Effets avalis?s conjointement'
                  INTO nResult
                  FROM DUAL;
            END IF;

            IF nResult1 = 1
            THEN
                SELECT 'Effets avalis?s' INTO nResult FROM DUAL;
            END IF;
        END IF;

        IF nTMPCODEENC = 'PRLAUTO'
        THEN
            IF nResult1 > 1
            THEN
                SELECT 'Titre de cr?dit avalis? conjointement'
                  INTO nResult
                  FROM DUAL;
            END IF;

            IF nResult1 = 1
            THEN
                SELECT 'Titre de cr?dit avalis? par :'
                  INTO nResult
                  FROM DUAL;
            END IF;
        END IF;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            nResult := '';
    END F_GET_LIB_TMPCODEENC;



    FUNCTION f_get_ref_tit_cred_Front (ndosid dossierprospect.dosid%TYPE)
        RETURN VARCHAR2
    IS
    BEGIN
        DECLARE
            l_agence            VARCHAR2 (6);
            l_dprnumcassiopee   VARCHAR2 (10);
            l_client            VARCHAR2 (10);
            nresult             VARCHAR2 (50);
            sCodeInstitut       VARCHAR2 (10);
            l_calc              VARCHAR2 (10);
        BEGIN
            SELECT RPAD ('001', 3, ' ') INTO l_agence FROM DUAL;

            SELECT act.actcode, dpr.dprnumcassiopee
              INTO l_client, l_dprnumcassiopee
              FROM dpracteur dpa, acteur act, dossierprospect dpr
             WHERE     dpa.dosid = ndosid
                   AND DPR.DPRVERSION =
                       (SELECT MAX (F_DERNIEREVERSIONDOSSIER (nDOSID))
                          FROM DUAL)
                   AND DPA.DPRVERSION = DPR.DPRVERSION
                   AND dpa.rolcode = 'CLIENT'
                   AND dpa.actid = act.actid
                   AND dpr.dosid = dpa.dosid
                   AND ROWNUM = 1;

            SELECT TO_CHAR (
                       MAX (f_pldatatransco ('ACTEUR', 'CODENATBQCTL', 'TL')))
              INTO sCodeInstitut
              FROM DUAL;

            l_calc :=
                (  97
                 - (MOD (
                          (   l_client
                           || l_dprnumcassiopee
                           || 1
                           || sCodeInstitut
                           || l_agence)
                        * 100,
                        97)));

            nresult :=
                   l_client
                || l_dprnumcassiopee
                || 1
                || sCodeInstitut
                || l_agence
                || LPAD (l_calc, 2, '00');

            RETURN nresult;
        EXCEPTION
            WHEN OTHERS
            THEN
                RETURN NULL;
        END;
    END f_get_ref_tit_cred_Front;

    FUNCTION F_MTFRAE (P_DOSID         DOSSIERPROSPECT.DOSID%TYPE,
                       P_DPRVERSION    DOSSIERPROSPECT.DPRVERSION%TYPE)
        RETURN NUMBER
    AS
        nPFIID   PROPOSITIONFINANCIERE.PFIID%TYPE := NULL;
        nFRAE    NUMBER := 0;
    BEGIN
        --nPFIID := PA_REQUETE_COMMUN.F_PROPOSITION_RETENUE( P_DOSID, P_DPRVERSION, NULL );
        SELECT PA_REQUETE_COMMUN.F_PROPOSITION_RETENUE (P_DOSID,
                                                        P_DPRVERSION,
                                                        NULL)
          INTO nPFIID
          FROM DUAL;

        SELECT NVL (SUM (PFI.PFPMT + ((PFPMT * TTAVAL) / 100)), 0)
          INTO nFRAE
          FROM PFIPRESTATION PFI, TAXTAUX T
         WHERE     PFIID = nPFIID
               AND PFI.rubcode = 'FRAE'
               AND T.TTADTFIN IS NULL
               AND PFI.TAXCODE = T.TAXCODE;

        RETURN nFRAE;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_MTFRAE;

    FUNCTION F_GET_TITLE_AGENCE (nACTID DPRACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    IS
        nResult    VARCHAR2 (100);
        nTitre     VARCHAR2 (5);
        nType      VARCHAR2 (5);
        sCJUCODE   VARCHAR2 (8);
    BEGIN
        SELECT MAX (CJUCODE)
          INTO sCJUCODE
          FROM ACTEUR
         WHERE ACTID = nACTID;

        IF sCJUCODE = 1000
        THEN
            SELECT APATITRE
              INTO nTitre
              FROM ACTEURPARTICULIER, ACTEUR
             WHERE     ACTEUR.ACTID = nACTID
                   AND ACTEUR.ACTID = ACTEURPARTICULIER.ACTID;

            IF nTitre = 'MR'
            THEN
                nResult := 'Monsieur';
            ELSIF nTitre = 'MME'
            THEN
                nResult := 'Madame';
            ELSIF nTitre = 'MLLE'
            THEN
                nResult := 'Mademoiselle';
            ELSIF nTitre = 'DR'
            THEN
                nResult := 'Docteur';
            END IF;
        ELSE
            SELECT 'Messieurs'
              INTO nResult
              FROM ACTEUR
             WHERE actid = nACTID;
        END IF;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN '-';
    END F_GET_TITLE_AGENCE;



    FUNCTION F_GET_NOM_AGENCE (nACTID DPRACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    IS
        nResult    VARCHAR2 (100);
        nTitre     VARCHAR2 (5);
        nType      VARCHAR2 (5);
        sCJUCODE   VARCHAR2 (8);
    BEGIN
        SELECT MAX (CJUCODE)
          INTO sCJUCODE
          FROM ACTEUR
         WHERE ACTID = nACTID;

        IF sCJUCODE = 1000
        THEN
            SELECT ACTEUR.ACTNOM
              INTO nResult
              FROM ACTEURPARTICULIER, ACTEUR
             WHERE     ACTEUR.ACTID = nACTID
                   AND ACTEUR.ACTID = ACTEURPARTICULIER.ACTID;
        ELSE
            SELECT ACTEUR.ACTNOM
              INTO nResult
              FROM ACTEUR
             WHERE actid = nACTID;
        END IF;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN '-';
    END F_GET_NOM_AGENCE;



    FUNCTION F_GET_PRENOM_AGENCE (nACTID DPRACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    IS
        nResult    VARCHAR2 (100);
        nTitre     VARCHAR2 (5);
        nType      VARCHAR2 (5);
        sCJUCODE   VARCHAR2 (8);
    BEGIN
        SELECT MAX (CJUCODE)
          INTO sCJUCODE
          FROM ACTEUR
         WHERE ACTID = nACTID;

        IF sCJUCODE = 1000
        THEN
            SELECT ACTEURPARTICULIER.APAPRENOM
              INTO nResult
              FROM ACTEURPARTICULIER, ACTEUR
             WHERE     ACTEUR.ACTID = nACTID
                   AND ACTEUR.ACTID = ACTEURPARTICULIER.ACTID;
        ELSE
            SELECT NULL
              INTO nResult
              FROM ACTEUR
             WHERE actid = nACTID;
        END IF;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN '-';
    END F_GET_PRENOM_AGENCE;

    FUNCTION F_GET_ALL_CONTACTS_FO (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                    nROLCODE   IN DPRACTEUR.ROLCODE%TYPE,
                                    nACTID     IN DPRACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (500);
    BEGIN
        nResult := '';

        FOR REC
            IN (SELECT AVU.UCOREFERENCE || ' ' || UTIPRENOM || ' ' || UTINOM
                           AS CONTACT
                  FROM UTILISATEUR UTI, LKACTUTITSM LK, UTICOORDONNEE AVU
                 WHERE     UTI.UTICODE = LK.UTICODE
                       AND AVU.UTICODE = UTI.UTICODE
                       AND LK.ACTID = nACTID
                       AND AVU.UCOTYPE = 'TITRE')
        LOOP
            IF REC.CONTACT IS NOT NULL
            THEN
                nResult := nResult || REC.CONTACT || ', ou ';
            END IF;
        END LOOP;

        nResult := SUBSTR (nResult, 1, LENGTH (nResult) - 5);
        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ALL_CONTACTS_FO;

    FUNCTION F_GET_EMAIL_CA_FO (nACTID IN ACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT MAX (UCOREFERENCE)
          INTO nResult
          FROM LKACTUTITSM LK, UTICOORDONNEE UTC
         WHERE     LK.UTICODE = UTC.UTICODE
               AND UTC.UCOTYPE = 'NET'
               AND LK.TSMMETIER = 'PORTFL'
               AND LK.ACTID = nACTID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_EMAIL_CA_FO;

    FUNCTION F_GET_TEL_CA_FO (nACTID IN ACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT MAX (UCOREFERENCE)
          INTO nResult
          FROM LKACTUTITSM LK, UTICOORDONNEE UTC
         WHERE     LK.UTICODE = UTC.UTICODE
               AND UTC.UCOTYPE = 'TEL'
               AND LK.TSMMETIER = 'PORTFL'
               AND LK.ACTID = nACTID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_TEL_CA_FO;



    FUNCTION F_GET_MOB_CA_FO (nACTID IN ACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT MAX (UCOREFERENCE)
          INTO nResult
          FROM LKACTUTITSM LK, UTICOORDONNEE UTC
         WHERE     LK.UTICODE = UTC.UTICODE
               AND UTC.UCOTYPE = 'MOB'
               AND LK.TSMMETIER = 'PORTFL'
               AND LK.ACTID = nACTID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_MOB_CA_FO;


    FUNCTION F_GET_FAX_CA_FO (nACTID IN ACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT MAX (UCOREFERENCE)
          INTO nResult
          FROM LKACTUTITSM LK, UTICOORDONNEE UTC
         WHERE     LK.UTICODE = UTC.UTICODE
               AND UTC.UCOTYPE = 'FAX'
               AND LK.TSMMETIER = 'PORTFL'
               AND LK.ACTID = nACTID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_FAX_CA_FO;

    FUNCTION F_DEVISE (P_LANCODE       LANGUE.LANCODE%TYPE,
                       P_DOSID         DOSSIERPROSPECT.DOSID%TYPE,
                       P_DPRVERSION    DOSSIERPROSPECT.DPRVERSION%TYPE)
        RETURN VARCHAR2
    AS
        sDevise   VARCHAR2 (50);
    BEGIN
        BEGIN
            SELECT MAX (CVASTRINGVALUE)
              INTO sDevise
              FROM CCHVALUE CCH
             WHERE     CCH.CCHSID = 'CMBCCHSID862'
                   AND CCH.DOSIDPROSPECT = P_DOSID
                   AND CCH.DPRVERSION = P_DPRVERSION;
        EXCEPTION
            WHEN OTHERS
            THEN
                sDevise := '';
        END;

        RETURN sDevise;
    END F_DEVISE;

    FUNCTION F_PRIXDEVISE_OFFRE (
        P_DOSID         DOSSIERPROSPECT.DOSID%TYPE,
        P_DPRVERSION    DOSSIERPROSPECT.DPRVERSION%TYPE)
        RETURN NUMBER
    AS
        nPrixDevise   NUMBER;
    BEGIN
        BEGIN
            SELECT SUM (CVANUMERICVALUE)
              INTO nPrixDevise
              FROM CCHVALUE CCH
             WHERE     CCH.CCHSID = 'TFDCCHSID731'
                   AND CCH.DOSIDPROSPECT = P_DOSID
                   AND CCH.DPRVERSION = P_DPRVERSION;
        EXCEPTION
            WHEN OTHERS
            THEN
                nPrixDevise := '';
        END;

        RETURN nPrixDevise;
    END F_PRIXDEVISE_OFFRE;

    FUNCTION F_nPalier_PFIID (nPFIID PFRPALIER.PFIID%TYPE)
        RETURN INTEGER
    AS
        nPalier   INTEGER;
    BEGIN
        SELECT COUNT (*)
          INTO nPalier
          FROM PFRPALIER
         WHERE PFIID = nPFIID;


        RETURN nPalier;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_nPalier_PFIID;

    FUNCTION F_ValPrLoyer_PFIID (nPFIID PFRPALIER.PFIID%TYPE)
        RETURN NUMBER
    AS
        nValPrLoyer   NUMBER := 0;
    BEGIN
        SELECT PFIMTPREMIERLOYER
          INTO nValPrLoyer
          FROM PROPOSITIONFINANCIERE
         WHERE PFIID = nPFIID;


        RETURN nValPrLoyer;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_ValPrLoyer_PFIID;


    FUNCTION F_GET_LISTE_POUVOIR_SIGNATURE (nACTID IN ACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    AS
        /*SRETURN     VARCHAR2 (500) := NULL;
        sPouvSign   VARCHAR2 (500) := NULL;

        CURSOR cPouvSign
        IS
           SELECT LAN.TUPLIBELLE || ' ' || (select tuplibelle from lantusparam where tusnom='TITRE' and tupcode=ACC.ACOTITRE and lancode='FR') || ' ' || ACC.ACOPRENOM || ' ' || ACC.ACONOM||DECODE(ACC.ACOQUALITE,'28',' '||ACC.ACOMEMO,'')
             FROM LANTUSPARAM LAN, CCHVALUE CCH, ACTCORRESPONDANT ACC
            WHERE     LAN.TUSNOM = 'QUALITE'
                  AND LANCODE = 'FR'
                  AND ACC.ACTID = CCH.ACTID
                  AND CCH.CVABOOLEANVALUE = 1
                  AND ACC.ACOQUALITE = LAN.TUPCODE
                  AND CCH.CCHSID = 'LOGCCHSID70603'
                  AND ACC.ACOORDRE =
                         SUBSTR (
                            SUBSTR (cvapkeyvalue,
                                    INSTR (cvapkeyvalue, '||') + 11),
                            1,
                              INSTR (
                                 SUBSTR (cvapkeyvalue,
                                         INSTR (cvapkeyvalue, '||') + 11),
                                 '||')
                            - 1)
                  AND ACC.ACTID = nACTID
                  ORDER BY ACC.ACODTSTART DESC;
     BEGIN
        OPEN cPouvSign;

        LOOP
           FETCH cPouvSign INTO sPouvSign;

           EXIT WHEN cPouvSign%NOTFOUND;

           IF (sPouvSign IS NOT NULL)
           THEN
              sreturn := sPouvSign || ', et son ' || sreturn;
           ELSE
              sreturn := sreturn;
           END IF;
        END LOOP;

        CLOSE cPouvSign;

        sReturn :=
              ' repr?sent?e par son '
           || SUBSTR (sreturn, 1, LENGTH (sreturn) - 9);


        RETURN sReturn;*/
        SRETURN     VARCHAR2 (500) := NULL;
        sPouvSign   VARCHAR2 (500) := NULL;
        sQualite    VARCHAR2 (10) := NULL;
        sNatSing    VARCHAR (10);
        sComment    VARCHAR2 (100);

        CURSOR cPouvSign
        IS
              SELECT ACC.ACOQUALITE,
                        INITCAP (LAN.TUPLIBELLE)
                     || ' '
                     || (SELECT tuplibelle
                           FROM lantusparam
                          WHERE     tusnom = 'TITRE'
                                AND tupcode = ACC.ACOTITRE
                                AND lancode = 'FR')
                     || ' '
                     || INITCAP (TRIM (ACC.ACOPRENOM))
                     || ' '
                     || UPPER (TRIM (ACC.ACONOM)),
                     DECODE (ACC.ACOQUALITE, '28', ' ' || ACC.ACOMEMO, '')
                FROM LANTUSPARAM LAN, CCHVALUE CCH, ACTCORRESPONDANT ACC
               WHERE     LAN.TUSNOM = 'QUALITE'
                     AND LANCODE = 'FR'
                     AND ACC.ACTID = CCH.ACTID
                     AND CCH.CVABOOLEANVALUE = 1
                     AND ACC.ACOQUALITE = LAN.TUPCODE
                     AND CCH.CCHSID = 'LOGCCHSID70603'
                     AND ACC.ACOORDRE =
                         SUBSTR (
                             SUBSTR (cvapkeyvalue,
                                     INSTR (cvapkeyvalue, '||') + 11),
                             1,
                               INSTR (
                                   SUBSTR (cvapkeyvalue,
                                           INSTR (cvapkeyvalue, '||') + 11),
                                   '||')
                             - 1)
                     AND ACC.ACTID = nACTID
                     AND CCH.CVAID =
                         (SELECT MAX (C.CVAID)
                            FROM CCHVALUE C
                           WHERE     C.ACTID = CCH.ACTID
                                 AND C.CVAPKEYVALUE = CCH.CVAPKEYVALUE
                                 AND C.CCHSID = 'LOGCCHSID70603')
            ORDER BY ACC.ACODTSTART DESC;
    BEGIN
        OPEN cPouvSign;

        LOOP
            FETCH cPouvSign INTO sQualite, sPouvSign, sComment;

            EXIT WHEN cPouvSign%NOTFOUND;

            IF sQualite = '28' AND scomment IS NOT NULL
            THEN
                sreturn :=
                       'son '
                    || sPouvSign
                    || ' par procuration, '
                    || sreturn
                    || sComment;
            ELSE
                sreturn := 'son ' || sPouvSign || ', et ' || sreturn;
            END IF;
        END LOOP;

        CLOSE cPouvSign;

        SELECT CVASTRINGVALUE
          INTO sNatSing
          FROM CCHVALUE
         WHERE cvaid = (SELECT MAX (cvaid)
                          FROM cchvalue
                         WHERE CCHSID = 'CMBCCHSID2774' AND ACTID = nActid);

        IF sNatSing = 'CONJ'
        THEN
            sReturn :=
                   'repr?sent?e par '
                || SUBSTR (sreturn, 1, LENGTH (sreturn) - 5)
                || ' signant cojointement';
        ELSIF sNatSing = 'SEP'
        THEN
            sReturn :=
                   'repr?sent?e par '
                || SUBSTR (sreturn, 1, LENGTH (sreturn) - 5)
                || ' signant separemment';
        ELSE
            sReturn :=
                   'repr?sent?e par '
                || SUBSTR (sreturn, 1, LENGTH (sreturn) - 5);
        END IF;


        RETURN sReturn;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_LISTE_POUVOIR_SIGNATURE;

    FUNCTION f_get_observation_crevt (
        ndosid         IN DOSSIERPROSPECT.DOSID%TYPE,
        stmffonction   IN TEVENEMENT.TMFFONCTION%TYPE)
        RETURN VARCHAR2
    IS
    BEGIN
        DECLARE
            sresult   VARCHAR2 (250) := NULL;
        BEGIN
            SELECT cda.cdadatastring
              INTO sresult
              FROM crevt cre, credata cda
             WHERE     cre.dosid = ndosid
                   AND cre.tmffonction = stmffonction
                   AND cre.creid = cda.creid
                   AND cda.cdacolonne = 'REPORT'
                   AND ROWNUM = 1;

            RETURN sresult;
        END;
    END f_get_observation_crevt;

    FUNCTION F_TITREGARANT (P_GARANT ACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    AS
        sTITRE   VARCHAR2 (2000) := '';
    BEGIN
        BEGIN
            SELECT APATITRE
              INTO sTITRE
              FROM ACTEURPARTICULIER
             WHERE ACTID = P_GARANT;

            IF sTITRE = 'MR'
            THEN
                sTITRE := 'M';
            ELSIF sTITRE = 'MME'
            THEN
                sTITRE := 'Mme';
            ELSIF sTITRE = 'MLLE'
            THEN
                sTITRE := 'Mlle';
            ELSIF sTITRE = 'DR'
            THEN
                sTITRE := 'Dr';
            END IF;
        EXCEPTION
            WHEN OTHERS
            THEN
                sTITRE := NULL;
        END;

        RETURN sTITRE;
    END F_TITREGARANT;

    FUNCTION F_GET_NOM_PORTFL_COM (
        nDOSID        IN DOSSIERPROSPECT.DOSID%TYPE,
        nDPRVERSION   IN DOSSIERPROSPECT.DPRVERSION%TYPE)
        RETURN VARCHAR2
    IS
        nResult       VARCHAR2 (100);
        sTLCCNOM      VARCHAR2 (100);
        sTLCCPRENOM   VARCHAR2 (100);
    BEGIN
        SELECT UTI.UTINOM || ' ' || UTI.UTIPRENOM, UTI.UTINOM, UTI.UTIPRENOM
          INTO nResult, sTLCCNOM, sTLCCPRENOM
          FROM DPRINTERVENANT DPI, UTILISATEUR UTI
         WHERE     DPI.DOSID = nDOSID
               AND DPI.DPRVERSION = nDPRVERSION
               AND DPI.DINMETIER = 'PORTFL' ----Suite TLFII-153 changer le 'COM' par 'PORTFL' et gerer si null
               AND DPI.UTICODE = UTI.UTICODE;



        IF sTLCCNOM IS NULL AND sTLCCPRENOM IS NULL
        THEN
            SELECT UTI.UTINOM || ' ' || UTI.UTIPRENOM,
                   UTI.UTINOM,
                   UTI.UTIPRENOM
              INTO nResult, sTLCCNOM, sTLCCPRENOM
              FROM DPRINTERVENANT DPI, UTILISATEUR UTI
             WHERE     DPI.DOSID = nDOSID
                   AND DPI.DPRVERSION = nDPRVERSION
                   AND DPI.DINMETIER = 'COM'
                   AND DPI.UTICODE = UTI.UTICODE
                   AND DPI.DINORDRE =
                       (SELECT MAX (DPI1.DINORDRE)
                          FROM DPRINTERVENANT DPI1
                         WHERE     DPI1.DOSID = DPI.DOSID
                               AND DPI1.DPRVERSION = nDPRVERSION
                               AND DPI1.DINMETIER = 'COM');
        END IF;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_NOM_PORTFL_COM;


    FUNCTION F_NUMSERIEMATERIEL (
        P_LANCODE       LANGUE.LANCODE%TYPE,
        P_DOSID         DOSSIERPROSPECT.DOSID%TYPE,
        P_DPRVERSION    DOSSIERPROSPECT.DPRVERSION%TYPE,
        P_ORDRE         DPRMATERIEL.DPMORDRE%TYPE)
        RETURN VARCHAR2
    AS
        sNumSerie   VARCHAR2 (500) := '';
    BEGIN
        SELECT DPMNUMSERIE
          INTO sNumSerie
          FROM DPRMATERIEL
         WHERE     DOSID = P_DOSID
               AND DPRVERSION = P_DPRVERSION
               AND DPMORDRE = P_ORDRE;

        IF sNumSerie IS NOT NULL
        THEN
            sNumSerie := CONCAT (', N? Ch?ssis : ', sNumSerie);
        END IF;

        RETURN sNumSerie;
    END F_NUMSERIEMATERIEL;


    FUNCTION f_GETSELECTEDANAID (P_DOSID DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    IS
    BEGIN
        DECLARE
            nAnaid   NUMBER;
        BEGIN
            SELECT MAX (ANAID)
              INTO nAnaid
              FROM analysis
             WHERE dosid = p_dosid AND DPRVERSION = 'FIN' -- AND ANAFLAGRETENUE = 1
                                                         ;

            IF nAnaid IS NULL
            THEN
                SELECT MAX (ANAID)
                  INTO nAnaid
                  FROM analysis
                 WHERE dosid = p_dosid AND DPRVERSION = 'FIN';
            END IF;

            RETURN nAnaid;
        END;
    END f_GETSELECTEDANAID;


    FUNCTION f_TESTRATRETURNMSG (P_DOSID DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    IS
    BEGIN
        DECLARE
            nTest   NUMBER := 0;
        BEGIN
            SELECT COUNT (1)
              INTO nTest
              FROM ratio r, lkanarat l, lanratio lr
             WHERE     anaid = PAV4_JASPER_FO.f_GETSELECTEDANAID (P_DOSID)
                   AND r.ratid = l.ratid
                   AND r.ratid = lr.ratid
                   AND r.ratid = 3009
                   AND l.ratreturnmsg LIKE 'ORA-01403%';

            RETURN nTest;
        END;
    END f_TESTRATRETURNMSG;

    FUNCTION F_GET_TELECOM_ACT (nACTID   IN ACTEUR.ACTID%TYPE,
                                nTYPE    IN ACTTELECOM.ATETYPE%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT ATE.ATENUM
          INTO nResult
          FROM ACTCORRESPONDANT ACO, ACTTELECOM ATE, LKACTTELCOR LK
         WHERE     LK.ATEORDRE = ATE.ATEORDRE
               AND LK.ACOORDRE = ACO.ACOORDRE
               AND ACO.ACTID = LK.ACTID
               AND LK.ACTID = ATE.ACTID
               AND ROWNUM = 1
               AND ATE.ATETYPE = nTYPE
               AND ACO.ACTID = nACTID;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_TELECOM_ACT;

    FUNCTION F_VALNEUFMATERIEL (
        P_LANCODE       LANGUE.LANCODE%TYPE,
        P_DOSID         DOSSIERPROSPECT.DOSID%TYPE,
        P_DPRVERSION    DOSSIERPROSPECT.DPRVERSION%TYPE,
        P_ORDRE         DPRMATERIEL.DPMORDRE%TYPE)
        RETURN VARCHAR2
    AS
        sValNeuf    VARCHAR2 (50) := '';
        sRESULTAT   VARCHAR2 (50) := '';
    BEGIN
        BEGIN
            SELECT CVANUMERICVALUE
              INTO sValNeuf
              FROM CCHVALUE
             WHERE     CCHSID = 'TFDCCHSID732'
                   AND CVAPKEYVALUE LIKE '%Dpmordre-' || P_ORDRE || '%'
                   AND DOSIDPROSPECT = P_DOSID;
        EXCEPTION
            WHEN OTHERS
            THEN
                sValNeuf := '';
        END;

        IF sValNeuf IS NOT NULL
        THEN
            sRESULTAT := sValNeuf;
        ELSE
            SELECT DPMMTTTC
              INTO sRESULTAT
              FROM DPRMATERIEL
             WHERE     DOSID = P_DOSID
                   AND DPRVERSION = P_DPRVERSION
                   AND DPMORDRE = P_ORDRE;
        END IF;

        RETURN sRESULTAT;
    END F_VALNEUFMATERIEL;



    FUNCTION F_GET_MTTIMBRE
        RETURN NUMBER
    IS
    BEGIN
        DECLARE
            nAmountTfx   NUMBER := 0;
        BEGIN
            SELECT tpanombre
              INTO nAmountTfx
              FROM topparam
             WHERE tpaparam = 'MTTIMBRE' AND ugecode = 'BRD';


            RETURN nAmountTfx;
        EXCEPTION
            WHEN OTHERS
            THEN
                RETURN NULL;
        END;
    END F_GET_MTTIMBRE;

    FUNCTION F_GET_ORGANE_DEC (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        sORGANE      VARCHAR2 (100);
        pENVELOPPE   VARCHAR2 (20);
    BEGIN
        SELECT MAX (DOSIDAUTORISATION)
          INTO pENVELOPPE
          FROM DPRCOMPLEMENT
         WHERE     DOSID = nDOSID
               AND DPRVERSION = (SELECT MAX (DPRVERSION)
                                   FROM V_DEAL
                                  WHERE DOSID = nDOSID);

        IF pENVELOPPE IS NOT NULL
        THEN
            SELECT MAX (l.ratreturnmsg)
              INTO sORGANE
              FROM ratio r, lkanarat l
             WHERE     anaid =
                       (SELECT MAX (anaid)
                          FROM analysis
                         WHERE dosid = pENVELOPPE AND DPRVERSION = 'FIN') --MTR
                   AND r.ratid = l.ratid
                   AND r.ratid = 3422;
        ELSE
            SELECT MAX (l.ratreturnmsg)
              INTO sORGANE
              FROM ratio r, lkanarat l
             WHERE     anaid = (SELECT MAX (anaid)
                                  FROM analysis
                                 WHERE dosid = nDOSID AND DPRVERSION = 'FIN') --MTR
                   AND r.ratid = l.ratid
                   AND r.ratid = 3422;
        END IF;

        RETURN sORGANE;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ORGANE_DEC;

    FUNCTION F_GET_DTRSE_DECI (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN DATE
    IS
        nResult    DATE;
        nResult1   DATE;
        nResult2   DATE;
    BEGIN
        SELECT MAX (DPR.DCODT)
          INTO nResult1
          FROM DPRCONCLUSION DPR, LANAVTDECISION LAN
         WHERE     DPR.DOSID = nDOSID
               AND DPR.DPRVERSION = (SELECT MAX (DPRVERSION)
                                       FROM V_DEAL
                                      WHERE DOSID = nDOSID)
               AND DPR.DCOORDRE =
                   (SELECT MAX (DCOORDRE)
                      FROM DPRCONCLUSION
                     WHERE DOSID = DPR.DOSID AND DPRVERSION = DPR.DPRVERSION)
               AND LAN.ADECODE = DPR.ADECODE
               AND LAN.LANCODE = 'FR';

        SELECT WSTDTEND
          INTO nResult2
          FROM dprworstep
         WHERE     worcode = 'WFMOCBAA1'
               AND wstorder = 13
               AND wststatus = 'TER'
               AND dosid = nDOSID;

        IF nResult1 IS NOT NULL
        THEN
            nResult := nResult1;
        ELSE
            nResult := nResult2;
        END IF;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_DTRSE_DECI;


    FUNCTION F_GET_DTDDE_DECI (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN DATE
    IS
        nResult   DATE;
    BEGIN
        SELECT DPR.DPRDTDEMFIN
          INTO nResult
          FROM DOSSIERPROSPECT DPR
         WHERE     (   DPR.DOSID =
                       (SELECT dosidautorisation
                          FROM dprcomplement
                         WHERE dosid = nDOSID AND dprversion = dpr.dprversion)
                    OR dpr.dosid = nDOSID)
               AND dpr.dprversion = (SELECT MAX (DPRVERSION)
                                       FROM V_DEAL
                                      WHERE DOSID = nDOSID);

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_DTDDE_DECI;


    FUNCTION f_mt_dispo_autorisation2 (ndosid IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    IS
    BEGIN
        DECLARE
            sResult        NUMBER := 0;
            mt_tot_tiree   NUMBER := 0;
            mt_env_tot     NUMBER := 0;
        BEGIN
            SELECT NVL (SUM (DM1MTINVESTCHILD), 0)
              INTO mt_tot_tiree
              FROM l1dprmateriel
             WHERE     dosid = ndosid
                   AND dprversion =
                       PA_AVCOMMUN.F_DERNIEREVERSIONDOSSIER (dosid)
                   AND dprversionchild = 'NEGO';

            SELECT SUM (pfiinvestissement)
              INTO mt_env_tot
              FROM propositionfinanciere
             WHERE pfiid =
                   (SELECT pfiid
                      FROM dprpropfinance
                     WHERE     dosid = ndosid
                           AND dprversion =
                               PA_AVCOMMUN.F_DERNIEREVERSIONDOSSIER (dosid)
                           AND dpfflagretenue = 1);


            sResult := mt_env_tot - mt_tot_tiree;

            RETURN sResult;
        END;
    END f_mt_dispo_autorisation2;

    FUNCTION F_GET_DELEG_FRS (nACTID IN ACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT MAX (ACTIDRELATION)
          INTO nResult
          FROM ACTRELATION
         WHERE     TRECODE = 'PAIEMENT'
               AND ACTID = nACTID
               AND AREDTFIN IS NULL
               AND ACTIDRELATION <> 45
               AND ACTIDRELATION <> 57641;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_DELEG_FRS;

    FUNCTION F_GET_ACTOR_ADRESSE_V2 (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                     nROLCODE      DPRACTEUR.ROLCODE%TYPE,
                                     sFLAG         VARCHAR2)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (4000);
    BEGIN
        SELECT    DECODE (ADR.ADRVOIE, NULL, '', ADR.ADRVOIE || ' ')
               || DECODE (ADR.ADRLIEUDIT, NULL, '', ADR.ADRLIEUDIT || ' ')
               || '<BR>'
               || DECODE (ADR.ADRCODEPOST, NULL, '', ADR.ADRCODEPOST || ' ')
               || DECODE (ADR.ADRVILLE, NULL, '', ADR.ADRVILLE || ' ')
               || DECODE (ADR.ADRSUBREGION, NULL, '', ADR.ADRSUBREGION)
          INTO nResult
          FROM ADRESSE ADR
         WHERE ADR.ADRID =
               (SELECT MAX (ADR.ADRID)
                  FROM DOSSIERPROSPECT  DPR,
                       DPRACTEUR        DAC,
                       ADRESSE          ADR,
                       ACTADRESSE       AAD,
                       CODEPOSTAL       COP
                 WHERE     DPR.DOSID = DAC.DOSID
                       AND DPR.DPRVERSION = DAC.DPRVERSION
                       AND DPR.DPRVERSION =
                           (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                              FROM DUAL)
                       AND AAD.ACTID = DAC.ACTID
                       AND DECODE (sFLAG,
                                   'FACTURATION', AAD.AADFLAGFACTURATION,
                                   'SIEGE', AAD.AADFLAGSIEGE,
                                   'COURRIER', AAD.AADFLAGCOURRIER,
                                   'LIVRAISON', AAD.AADFLAGLIVRAISON) =
                           1
                       AND ADR.ADRID = AAD.ADRID
                       AND ADR.ADRCODEPOST = COP.CPOCODE(+)
                       AND ADR.PAYCODE = COP.PAYCODE(+)
                       AND DAC.ROLCODE = nROLCODE
                       AND DPR.DOSID = nDOSID);


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ACTOR_ADRESSE_V2;


    FUNCTION F_GET_RATIO_2 (nDOSID    IN DOSSIERPROSPECT.DOSID%TYPE,
                            nVALMSG      VARCHAR2,
                            nRATID    IN RATIO.RATID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (4000);
    BEGIN
        SELECT /*DECODE(RAT.RATTYPE,'MEMO',LKA.RATMEMO,
               'INTEGER',LKA.RATVALUE,
               'STRING',DECODE(nVALMSG,'VAL',DECODE(LKA.RATVALUE,'N','NON','O','OUI',LKA.RATVALUE),
               'MSG',LKA.RATRETURNMSG,
               DECODE(LKA.RATVALUE,'N','NON','O','OUI',LKA.RATVALUE))
               ,NULL,DECODE(nVALMSG,'RVAL',DECODE(LKA.RATVALUE,'N','NON','O','OUI',LKA.RATVALUE),
               'RMSG',LKA.RATRETURNMSG,DECODE(LKA.RATVALUE,'N','NON','O','OUI',LKA.RATVALUE)))*/
               REPLACE (
                   DECODE (
                       RAT.RATTYPE,
                       'MEMO', NVL (LKA.RATMEMO, ' '),
                       'DATE', NVL (TO_CHAR (LKA.RATVALUE), ' '),
                       'INTEGER', DECODE (nVALMSG,
                                          'VAL', NVL (LKA.RATVALUE, 0),
                                          'MSG', NVL (LKA.RATRETURNMSG, ' '),
                                          NVL (LKA.RATVALUE, 0)),
                       'STRING', (DECODE (
                                      nVALMSG,
                                      'VAL', DECODE (LKA.RATVALUE,
                                                     'N', 'NON',
                                                     'O', 'OUI',
                                                     NVL (LKA.RATVALUE, ' ')),
                                      'MSG', NVL (LKA.RATRETURNMSG, ' '),
                                      DECODE (LKA.RATVALUE,
                                              'N', 'NON',
                                              'O', 'OUI',
                                              NVL (LKA.RATVALUE, ' ')))),
                       'DECIMAL', (DECODE (
                                       nVALMSG,
                                       'VAL', NVL (LKA.RATVALUE, 0),
                                       'MSG', NVL (LKA.RATRETURNMSG, ' '),
                                       NVL (LKA.RATVALUE, 0))),
                       NVL (LKA.RATVALUE, 0)),
                   '^p',
                   '<BR>')
          INTO nResult
          FROM LKANARAT LKA, ANALYSIS ANA, RATIO RAT
         WHERE     LKA.ANAID = ANA.ANAID
               AND RAT.RATID = LKA.RATID
               AND ANA.DOSID = nDOSID
               AND LKA.ANAID = (SELECT MAX (ANAID)
                                  FROM ANALYSIS
                                 WHERE DOSID = nDOSID)
               AND LKA.RATID = nRATID;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            SELECT DECODE (RATTYPE,  'INTEGER', '0',  'DECIMAL', '0',  ' ')
              INTO nResult
              FROM ratio
             WHERE ratid = Nratid;

            RETURN nResult;
    END F_GET_RATIO_2;

    FUNCTION F_TITRE_ACTEUR_2 (P_ACTID ACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    AS
        sTITRE   VARCHAR2 (2000) := '';
    BEGIN
        BEGIN
            SELECT MAX (APATITRE)
              INTO sTITRE
              FROM ACTEURPARTICULIER
             WHERE ACTID = P_ACTID;
        EXCEPTION
            WHEN OTHERS
            THEN
                sTITRE := NULL;
        END;

        sTITRE := SUBSTR (sTITRE, 1, 250);

        RETURN sTITRE;
    END F_TITRE_ACTEUR_2;

    -------------------------------------------------------------------------------------------------

    FUNCTION F_GET_LISTE_SIGNATAIRE_ACTEUR (nACTID IN ACTEUR.ACTID%TYPE)
        RETURN VARCHAR2
    AS
        SRETURN     VARCHAR2 (500) := NULL;
        sPouvSign   VARCHAR2 (500) := NULL;
        sQualite    VARCHAR2 (10) := NULL;
        sNatSing    VARCHAR (10);
        sComment    VARCHAR2 (100);
        nb          INTEGER;

        CURSOR cPouvSign
        IS
              SELECT ACC.ACOQUALITE,
                        INITCAP (LAN.TUPLIBELLE)
                     || ' '
                     || DECODE (ACC.ACOTITRE,
                                'MR', 'M. ',
                                INITCAP (ACC.ACOTITRE) || '. ')
                     || INITCAP (TRIM (ACC.ACOPRENOM))
                     || ' '
                     || UPPER (TRIM (ACC.ACONOM)),
                     DECODE (ACC.ACOQUALITE, '28', ' ' || ACC.ACOMEMO, '')
                FROM LANTUSPARAM LAN, CCHVALUE CCH, ACTCORRESPONDANT ACC
               WHERE     LAN.TUSNOM = 'QUALITE'
                     AND LANCODE = 'FR'
                     AND ACC.ACTID = CCH.ACTID
                     AND CCH.CVABOOLEANVALUE = 1
                     AND ACC.ACOQUALITE = LAN.TUPCODE
                     AND CCH.CCHSID = 'LOGCCHSID70603'
                     AND ACC.ACOORDRE =
                         SUBSTR (
                             SUBSTR (cvapkeyvalue,
                                     INSTR (cvapkeyvalue, '||') + 11),
                             1,
                               INSTR (
                                   SUBSTR (cvapkeyvalue,
                                           INSTR (cvapkeyvalue, '||') + 11),
                                   '||')
                             - 1)
                     AND ACC.ACTID = nACTID
                     AND CCH.CVAID =
                         (SELECT MAX (C.CVAID)
                            FROM CCHVALUE C
                           WHERE     C.ACTID = CCH.ACTID
                                 AND C.CVAPKEYVALUE = CCH.CVAPKEYVALUE
                                 AND C.CCHSID = 'LOGCCHSID70603')
            -- ORDER BY To_Number(ACC.ACOQUALITE) desc
            ORDER BY ACC.ACODTSTART DESC;
    BEGIN
        OPEN cPouvSign;

        LOOP
            FETCH cPouvSign INTO sQualite, sPouvSign, sComment;

            EXIT WHEN cPouvSign%NOTFOUND;

            IF sQualite = '28' AND scomment IS NOT NULL
            THEN
                sreturn :=
                       'son '
                    || sPouvSign
                    || ' par procuration, '
                    || sreturn
                    || sComment;
            ELSE
                sreturn := 'son ' || sPouvSign || ', et ' || sreturn;
            END IF;
        END LOOP;

        nb := cPouvSign%ROWCOUNT;

        CLOSE cPouvSign;

        SELECT f_recherche_customchar_act (acteur.actid, 'CMBCCHSID2774')
          INTO sNatSing
          FROM acteur
         WHERE actid = nActid;

        IF nb <= 1
        THEN
            sReturn :=
                   'repr?sent?e par '
                || SUBSTR (sreturn, 1, LENGTH (sreturn) - 5);
        ELSE
            IF sNatSing = 'CONJ'
            THEN
                sReturn :=
                       'repr?sent?e par '
                    || SUBSTR (sreturn, 1, LENGTH (sreturn) - 5)
                    || ', signant conjointement';
            ELSE
                sReturn :=
                       'repr?sent?e par '
                    || SUBSTR (sreturn, 1, LENGTH (sreturn) - 5)
                    || ', signant s?paremment';
            END IF;
        END IF;

        RETURN sReturn;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_LISTE_SIGNATAIRE_ACTEUR;



    ----------------------------------------------------------------------------------------------------
    FUNCTION f_recherche_customchar_act (nactid    IN ACTEUR.ACTID%TYPE,
                                         ncchsid      VARCHAR2)
        RETURN VARCHAR2
    IS
    BEGIN
        DECLARE
            sResult   VARCHAR2 (20) := NULL;
        BEGIN
            SELECT DECODE (cc.comtype,
                           'ALPHAN', cch.cvastringvalue,
                           'COMBOTUSPARAM', cch.cvastringvalue,
                           'DATE', cch.cvadtvalue,
                           'DECIMAL', cch.cvanumericvalue,
                           'ENTIER', cch.cvanumericvalue,
                           'LOGIQUE', cch.cvabooleanvalue,
                           'MEMO', cch.cvastringvalue,
                           'CPANEL', cch.cvastringvalue,
                           'CPANELGROUP', cch.cvastringvalue,
                           'CPANELHEADER', cch.cvastringvalue,
                           cch.cvastringvalue)
              INTO sResult
              FROM customcharacteristic cc, cchvalue cch
             WHERE     cch.cchsid = ncchsid
                   AND cc.cchsid = ncchsid
                   AND (   cch.cvapkeyvalue =
                           'Actid-' || nactid || '||Ugecode-BRD||'
                        OR cch.cvapkeyvalue = 'Actid-' || nactid || '||');



            RETURN sResult;
        EXCEPTION
            WHEN OTHERS
            THEN
                RETURN NULL;
        END;
    END f_recherche_customchar_act;

    ----------------------------------------------------------------------------------

    FUNCTION f_recherche_customchar_dossier (nDosid         NUMBER,
                                             nDprversion    VARCHAR,
                                             ncchsid        VARCHAR2)
        RETURN VARCHAR2
    IS
    BEGIN
        DECLARE
            sResult   VARCHAR2 (20) := NULL;
        BEGIN
            SELECT MAX (
                       DECODE (cc.comtype,
                               'ALPHAN', cch.cvastringvalue,
                               'COMBOTUSPARAM', cch.cvastringvalue,
                               'DATE', cch.cvadtvalue,
                               'DECIMAL', cch.cvanumericvalue,
                               'ENTIER', cch.cvanumericvalue,
                               'LOGIQUE', cch.cvabooleanvalue,
                               'MEMO', cch.cvastringvalue,
                               'CPANEL', cch.cvastringvalue,
                               'CPANELGROUP', cch.cvastringvalue,
                               'CPANELHEADER', cch.cvastringvalue))
              INTO sResult
              FROM customcharacteristic cc, cchvalue cch
             WHERE     cch.cchsid = ncchsid
                   AND cc.cchsid = ncchsid
                   AND DOSIDPROSPECT = nDosid
                   AND Dprversion = nDprversion;

            RETURN sResult;
        EXCEPTION
            WHEN OTHERS
            THEN
                RETURN NULL;
        END;
    END f_recherche_customchar_dossier;

    -------------------------------------------------------------------------------------------------------

    FUNCTION f_recherche_customchar_dos (nDosid         NUMBER,
                                         nDprversion    VARCHAR,
                                         nDPMORDRE      VARCHAR,
                                         ncchsid        VARCHAR2)
        RETURN VARCHAR2
    IS
    BEGIN
        DECLARE
            sResult   VARCHAR2 (20) := NULL;
        BEGIN
            SELECT MAX (
                       DECODE (cc.comtype,
                               'ALPHAN', cch.cvastringvalue,
                               'COMBOTUSPARAM', cch.cvastringvalue,
                               'DATE', cch.cvadtvalue,
                               'DECIMAL', cch.cvanumericvalue,
                               'ENTIER', cch.cvanumericvalue,
                               'LOGIQUE', cch.cvabooleanvalue,
                               'MEMO', cch.cvastringvalue,
                               'CPANEL', cch.cvastringvalue,
                               'CPANELGROUP', cch.cvastringvalue,
                               'CPANELHEADER', cch.cvastringvalue))
              INTO sResult
              FROM customcharacteristic cc, cchvalue cch
             WHERE     cch.cchsid = ncchsid
                   AND cc.cchsid = ncchsid
                   AND CVAPKEYVALUE =
                          'Dosid-'
                       || nDOSID
                       || '||Dprversion-'
                       || nDprversion
                       || '||Dpmordre-'
                       || nDPMORDRE
                       || '||';

            RETURN sResult;
        EXCEPTION
            WHEN OTHERS
            THEN
                RETURN NULL;
        END;
    END f_recherche_customchar_dos;

    -------------------------------------------------------------------------------------------------------
    FUNCTION F_GET_SUM_SERVICES_2 (P_DOSID DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    AS
        sResult   NUMBER;
    BEGIN
        SELECT SUM (ECHSERVICES)
          INTO sResult
          FROM (  SELECT SUM (PFI.PECMTINCIDENTAL + F_GET_MTTIMBRE_2 (P_DOSID))
                             ECHSERVICES
                    FROM PFIRUBECHEANCIER PFI
                   WHERE     PFIID = (SELECT MAX (PA_REQUETE_COMMUN.F_PROPOSITION_RETENUE (
                                                      P_DOSID,
                                                      (SELECT MAX (DPRVERSION)
                                                         FROM V_DEAL
                                                        WHERE dosid = P_DOSID),
                                                      NULL))
                                        FROM DUAL)
                         AND PECTYPEELEMENT = 'LOYER'
                         AND (   pfpordre NOT IN
                                     (SELECT pfpordre
                                        FROM pfiprestation
                                       WHERE     pfiid = pfi.pfiid
                                             AND rubcode = 'FRAE')
                              OR PFPORDRE IS NULL)
                GROUP BY PECDTDUE
                ORDER BY PECDTDUE);


        RETURN sResult;
    END F_GET_SUM_SERVICES_2;

    --------------------------------------------------------------------------------------------------------------------
    FUNCTION F_GET_MTTIMBRE_2 (Ndosid DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    AS
    BEGIN
        DECLARE
            nCountTfx    NUMBER := 0;
            nAmountTfx   NUMBER := 0;
        BEGIN
            SELECT COUNT (1)
              INTO nCountTfx
              FROM pfiprestation pfr, dprpropfinance dpf, v_deal v
             WHERE     dpf.dosid = v.dosid
                   AND pfr.TPrcode = 'TFX'
                   AND dpf.dprversion = v.dprversion
                   AND pfr.pfiid = dpf.pfiid
                   AND v.dosid = Ndosid;                    --231299;--233866;

            IF (nCountTfx <> 0)
            THEN
                nAmountTfx := 0;
            /*select pfpmt
            into nAmountTfx
            from pfiprestation pfr, dprpropfinance dpf, v_deal v
            where dpf.dosid=v.dosid
            and pfr.TPrcode='TFX'
            and dpf.dprversion=v.dprversion
            and pfr.pfiid=dpf.pfiid
            and v.dosid=Ndosid;--231299;--233866;*/
            ELSE
                SELECT tpanombre
                  INTO nAmountTfx
                  FROM topparam
                 WHERE tpaparam = 'MTTIMBRE' AND ugecode = 'BRD';
            END IF;

            RETURN nAmountTfx;
        EXCEPTION
            WHEN OTHERS
            THEN
                RETURN NULL;
        END;
    END F_GET_MTTIMBRE_2;

    -----------------------------------------------------------------------------------------
    FUNCTION F_GET_SUM_TTC2 (P_DOSID DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    AS
        sResult   NUMBER;
    BEGIN
        SELECT SUM (ECHLOYERTTC)
          INTO sResult
          FROM (  SELECT   SUM (PFI.PECMTBASIC)
                         + SUM (PFI.PECMTTAX)
                         + MAX (
                                 PFI.PECMTINCIDENTAL
                               + PAV4_JASPER_FO.F_GET_MTTIMBRE_2 (P_DOSID))
                             ECHLOYERTTC
                    FROM PFIRUBECHEANCIER PFI
                   WHERE     PFIID = (SELECT MAX (PA_REQUETE_COMMUN.F_PROPOSITION_RETENUE (
                                                      P_DOSID,
                                                      (SELECT MAX (DPRVERSION)
                                                         FROM V_DEAL
                                                        WHERE dosid = P_DOSID),
                                                      NULL))
                                        FROM DUAL)
                         AND PECTYPEELEMENT = 'LOYER'
                         --FRA 08/06/2017 TLBO-1451
                         AND (   pfpordre NOT IN
                                     (SELECT pfpordre
                                        FROM pfiprestation
                                       WHERE     pfiid = pfi.pfiid
                                             AND rubcode = 'FRAE')
                              OR PFPORDRE IS NULL)
                         AND PECDTDUE NOT IN (SELECT MIN (PECDTDUE)
                                                FROM PFIRUBECHEANCIER PFI2
                                               WHERE PFI2.PFIID = PFI.PFIID)
                GROUP BY PECDTDUE
                ORDER BY PECDTDUE);

        RETURN sResult;
    END F_GET_SUM_TTC2;

    -------------------------------------------------------------------------------------------------------------------
    -----------------------------------------------------------------------------------------
    FUNCTION F_GET_SUM_TTC (P_DOSID DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    AS
        sResult   NUMBER;
    BEGIN
        SELECT SUM (ECHLOYERTTC)
          INTO sResult
          FROM (  SELECT   SUM (PFI.PECMTBASIC)
                         + SUM (PFI.PECMTTAX)
                         + SUM (
                                 PFI.PECMTINCIDENTAL
                               + PAV4_JASPER_FO.F_GET_MTTIMBRE_2 (P_DOSID))
                             ECHLOYERTTC
                    FROM PFIRUBECHEANCIER PFI
                   WHERE     PFIID = (SELECT MAX (PA_REQUETE_COMMUN.F_PROPOSITION_RETENUE (
                                                      P_DOSID,
                                                      (SELECT MAX (DPRVERSION)
                                                         FROM V_DEAL
                                                        WHERE dosid = P_DOSID),
                                                      NULL))
                                        FROM DUAL)
                         AND PECTYPEELEMENT = 'LOYER'
                         --FRA 08/06/2017 TLBO-1451
                         AND (   pfpordre NOT IN
                                     (SELECT pfpordre
                                        FROM pfiprestation
                                       WHERE     pfiid = pfi.pfiid
                                             AND rubcode = 'FRAE')
                              OR PFPORDRE IS NULL)
                GROUP BY PECDTDUE
                ORDER BY PECDTDUE);

        RETURN sResult;
    END F_GET_SUM_TTC;

    ----------------------------------------
    FUNCTION F_GET_ACTOR_ADRESSE2 (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                   nROLCODE      DPRACTEUR.ROLCODE%TYPE,
                                   sFLAG         VARCHAR2)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (4000);
    BEGIN
        SELECT    DECODE (ADR.ADRVOIE, NULL, '', ADR.ADRVOIE || ' ')
               || DECODE (ADR.ADRLIEUDIT, NULL, '', ADR.ADRLIEUDIT || ' ')
               || DECODE (ADR.ADRCODEPOST, NULL, '', ADR.ADRCODEPOST || ' ')
               || DECODE (ADR.ADRVILLE, NULL, '', ADR.ADRVILLE)
               || DECODE (ADR.ADRSUBREGION, NULL, '', ADR.ADRSUBREGION)
          INTO nResult
          FROM ADRESSE ADR
         WHERE ADR.ADRID =
               (SELECT MAX (ADR.ADRID)
                  FROM DOSSIERPROSPECT  DPR,
                       DPRACTEUR        DAC,
                       ADRESSE          ADR,
                       ACTADRESSE       AAD,
                       CODEPOSTAL       COP
                 WHERE     DPR.DOSID = DAC.DOSID
                       AND DPR.DPRVERSION = DAC.DPRVERSION
                       AND DPR.DPRVERSION =
                           (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                              FROM DUAL)
                       AND AAD.ACTID = DAC.ACTID
                       AND DECODE (sFLAG,
                                   'FACTURATION', AAD.AADFLAGFACTURATION,
                                   'SIEGE', AAD.AADFLAGSIEGE,
                                   'COURRIER', AAD.AADFLAGCOURRIER,
                                   'LIVRAISON', AAD.AADFLAGLIVRAISON) =
                           1
                       AND ADR.ADRID = AAD.ADRID
                       AND ADR.ADRCODEPOST = COP.CPOCODE(+)
                       AND ADR.PAYCODE = COP.PAYCODE(+)
                       AND DAC.ROLCODE = nROLCODE
                       AND DPR.DOSID = nDOSID);


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ACTOR_ADRESSE2;

    -------------------------------------------------------
    FUNCTION F_GET_ACTEUR_ADRESSE_V2 (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE,
                                      nROLCODE      DPRACTEUR.ROLCODE%TYPE,
                                      sFLAG         VARCHAR2)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (4000);
    BEGIN
        SELECT    DECODE (ADR.ADRVOIE, NULL, '', ADR.ADRVOIE || ' ')
               || DECODE (ADR.ADRLIEUDIT, NULL, '', ADR.ADRLIEUDIT || ' ')
               || '<BR>'
               || DECODE (ADR.ADRVILLE, NULL, '', ADR.ADRVILLE || ' ')
               || DECODE (ADR.ADRSUBREGION, NULL, '', ADR.ADRSUBREGION)
               || DECODE (ADR.ADRCODEPOST, NULL, '', ADR.ADRCODEPOST || ' ')
          INTO nResult
          FROM ADRESSE ADR
         WHERE ADR.ADRID =
               (SELECT MAX (ADR.ADRID)
                  FROM DOSSIERPROSPECT  DPR,
                       DPRACTEUR        DAC,
                       ADRESSE          ADR,
                       ACTADRESSE       AAD,
                       CODEPOSTAL       COP
                 WHERE     DPR.DOSID = DAC.DOSID
                       AND DPR.DPRVERSION = DAC.DPRVERSION
                       AND DPR.DPRVERSION =
                           (SELECT MAX (F_DERNIEREVERSIONDOSSIER (DPR.DOSID))
                              FROM DUAL)
                       AND AAD.ACTID = DAC.ACTID
                       AND DECODE (sFLAG,
                                   'FACTURATION', AAD.AADFLAGFACTURATION,
                                   'SIEGE', AAD.AADFLAGSIEGE,
                                   'COURRIER', AAD.AADFLAGCOURRIER,
                                   'LIVRAISON', AAD.AADFLAGLIVRAISON) =
                           1
                       AND ADR.ADRID = AAD.ADRID
                       AND ADR.ADRCODEPOST = COP.CPOCODE(+)
                       AND ADR.PAYCODE = COP.PAYCODE(+)
                       AND DAC.ROLCODE = nROLCODE
                       AND DPR.DOSID = nDOSID);


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_ACTEUR_ADRESSE_V2;
--------------------------------------------
-------UTILISE DANS SGM45
   FUNCTION F_GET_CODE_AGENCE (nDOSID IN DPRACTEUR.DOSID%TYPE,nROLCODE DPRACTEUR.ROLCODE%TYPE)
      RETURN VARCHAR2
   IS
      sReturn   VARCHAR2 (100);
   BEGIN
      SELECT ACTCODE
        INTO sReturn
        FROM ACTEUR ACT, DPRACTEUR DPA
         WHERE  DPA.DOSID = nDOSID and
                ACT.ACTID = DPA.ACTID
               AND DPA.DPRVERSION =F_DERNIEREVERSIONDOSSIER (DPA.DOSID)
                AND DPA.ROLCODE = 'AGENCE'

                  ;

      RETURN sReturn;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END F_GET_CODE_AGENCE;
   --------------UTILISE DANS SGM45
   FUNCTION F_GET_NOM_AGENCE (nDOSID IN DPRACTEUR.DOSID%TYPE,nROLCODE DPRACTEUR.ROLCODE%TYPE)
      RETURN VARCHAR2
   IS
      sReturn   VARCHAR2 (100);
   BEGIN
      SELECT ACTNOM
        INTO sReturn
        FROM ACTEUR ACT, DPRACTEUR DPA
         WHERE  DPA.DOSID = nDOSID and
                ACT.ACTID = DPA.ACTID
               AND DPA.DPRVERSION =F_DERNIEREVERSIONDOSSIER (DPA.DOSID)
                AND DPA.ROLCODE = nROLCODE

                  ;

      RETURN sReturn;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END F_GET_NOM_AGENCE;
---------------------------
   ------UTILISE DANS SGM45
   FUNCTION F_GET_RESEAU_COMM (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT TSNLABEL
          INTO nResult
          FROM DOSSIERPROSPECT DPR, LANTSALENETWORK LAN
        WHERE  DPR.DOSID = nDOSID
               AND DPR.DPRVERSION =F_DERNIEREVERSIONDOSSIER (DPR.DOSID)
                and DPR.DPRRESEAUCIAL= LAN.TSNCODE and lancode='FR';

                  RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_RESEAU_COMM;
------------------------
----UTILISEE DS SGM45
FUNCTION F_GET_DTFIN_DEMANDE (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
      RETURN DATE
   IS
      nResult   DATE;
   BEGIN
   Select DDCDT into nresult from DPRDATECLE DPC
   where DCLCODE='DTFIN'
   and DPRVERSION=F_DERNIEREVERSIONDOSSIER(DPC.DOSID)
   and DPC.DDCORDRE= (SELECT MAX (DDCORDRE)
                                   FROM DPRDATECLE DPD
                                  WHERE DPD.DOSID = nDOSID
                                 and DCLCODE='DTFIN')
  and DPC.DOSID=nDOSID;
       RETURN nResult;
      EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
END F_GET_DTFIN_DEMANDE  ;
----------------------------------
----UTILISE DANS SGM45
FUNCTION F_GET_NOM_ChargeEtude (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT UTI.UTINOM || ' ' || UTI.UTIPRENOM
          INTO nResult
          FROM DPRINTERVENANT DPR, UTILISATEUR UTI
         WHERE     DPR.DINMETIER in ('CEPRO','CECOM','CE')
               AND DPR.DPRVERSION = F_Derniereversiondossier(DPR.Dosid)
               AND DPR.UTICODE = UTI.UTICODE
               AND DPR.DINORDRE =
                   (SELECT MAX (DINORDRE)
                      FROM DPRINTERVENANT
                     WHERE DOSID = DPR.DOSID AND DINMETIER in ('CEPRO','CECOM','CE'))
               AND DPR.DOSID = nDOSID;
       RETURN nResult;
      EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
  END F_GET_NOM_ChargeEtude;
-----------------------
-----Utiliser DANS SGM45
 FUNCTION F_GET_DERNIER_DECISION( nDOSID  DOSSIERPROSPECT.DOSID%TYPE)
            RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (200);
    BEGIN
        SELECT  NVL(LAN.ADELIBELLE,' ')
          INTO nResult
          FROM dprdecision DPR, LANAVTDECISION LAN
         WHERE     DPR.DOSID = nDOSID
               AND DPR.DPRVERSION =F_DERNIEREVERSIONDOSSIER(dosid)
               and dpr.DDEORDRE = (select max(DDEORDRE) from DPRDECISION dcl where dpr.dosid=dcl.dosid
               and dpr.dprversion=dcl.dprversion)
               AND LAN.ADECODE(+) = DPR.ADECODE AND LAN.LANCODE (+)  = 'FR';


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_DERNIER_DECISION;
-------------------
-----------------UTILISEE DANS SGM45
 FUNCTION F_GET_CODE_WORKFLOW( nDOSID  DOSSIERPROSPECT.DOSID%TYPE)
            RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (200);
    BEGIN
       SELECT SUBSTR(WOR.WORCODE,3)
          INTO nResult
          FROM dprworstep dpw, workflow wor
         WHERE     DPw.dosid = nDOSID and dpw.WORCODE=wor.WORCODE
         and DPW.DPRVERSION=F_DERNIEREVERSIONDOSSIER(dosid)
               AND dpw.creid =
                   (SELECT MAX (dpw2.creid)
                      FROM dprworstep dpw2
                     WHERE     dpw2.dosid = dpw.dosid
                           AND dpw2.dprversion = dpw.dprversion
                           )
               ;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_CODE_WORKFLOW;
    ---------------------
----UTILISE DANS SGM45
FUNCTION f_mt_disponible (ndosid IN DOSSIERPROSPECT.DOSID%TYPE)
      RETURN NUMBER
   IS
   BEGIN
      DECLARE
         CURSOR C_dosid_util
         IS
            SELECT dosid
              FROM dprcomplement
             WHERE     dosidautorisation = ndosid
                   AND dprversion =
                          PA_AVCOMMUN.F_DERNIEREVERSIONDOSSIER (dosid);

         sResult         NUMBER := 0;
         mt_transf       NUMBER := 0;
         mt_tot_transf   NUMBER := 0;
         mt_env_tot      NUMBER := 0;
      BEGIN
         FOR C_dosid IN C_dosid_util
         LOOP
            SELECT pfiinvestissement
              INTO mt_transf
              FROM propositionfinanciere
             WHERE pfiid =
                      (SELECT pfiid
                         FROM dprpropfinance
                        WHERE     dosid = C_dosid.dosid
                              AND dprversion =
                                     PA_AVCOMMUN.F_DERNIEREVERSIONDOSSIER (
                                        dosid)
                              AND dpfflagretenue = 1);

            mt_tot_transf := mt_tot_transf + mt_transf;
         END LOOP;

         SELECT pfiinvestissement
           INTO mt_env_tot
           FROM propositionfinanciere
          WHERE pfiid =
                   (SELECT pfiid
                      FROM dprpropfinance
                     WHERE     dosid = ndosid
                           AND dprversion =
                                  PA_AVCOMMUN.F_DERNIEREVERSIONDOSSIER (
                                     dosid)
                           AND dpfflagretenue = 1);


         sResult := mt_env_tot - mt_tot_transf;

         RETURN sResult;
      END;
   END f_mt_disponible;
--------------------------------------------
----UTILISE DANS SGM45
FUNCTION F_GET_DT_DECDACCORD( nDOSID  DOSSIERPROSPECT.DOSID%TYPE)
            RETURN DATE
    IS
        nResult   DATE;
    BEGIN
        SELECT    DPR.DDEDT
          INTO nResult
          FROM dprdecision DPR
         WHERE     DPR.DOSID = nDOSID
               AND DPR.DPRVERSION =F_DERNIEREVERSIONDOSSIER(dosid)
               and dpr.DDEORDRE = (select max(DDEORDRE) from DPRDECISION dcl where dpr.dosid=dcl.dosid
               and dpr.dprversion=dcl.dprversion and ADECODE='ACCORD')
           ;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_DT_DECDACCORD;
--------------------------------------------
---UTILISE DANS SGM45
FUNCTION f_get_classe_sans_suit (nDosid IN DOSSIER.DOSID%TYPE)
      RETURN VARCHAR2
   IS
      sTest     NUMBER := 0;
      sReturn   VARCHAR2 (10);
   BEGIN
      BEGIN
         SELECT COUNT (*)
           INTO sTest
           FROM CREVT CRE
          WHERE     CRE.DOSID = nDosid
                AND CRE.tmffonction IN ('EVD_SSUITE', 'EVF_SSUITE');

         IF sTest = 0
         THEN
            sReturn := 'NON';
         ELSE
            sReturn := 'OUI';
         END IF;
      EXCEPTION
         WHEN OTHERS
         THEN
            sReturn := 'NON';
      END;

      RETURN sreturn;
   END;
---------------------------------------------
-----UTILISE DS SGM45
FUNCTION F_GET_MTTOT_DOS_TIREE (ndosid IN DOSSIERPROSPECT.DOSID%TYPE)
      RETURN NUMBER
   IS
   BEGIN
      DECLARE
         CURSOR C_dosid_TIREE IS
            SELECT dosid
              FROM dprcomplement
             WHERE     dosidautorisation = ndosid
             AND dprversion =F_DERNIEREVERSIONDOSSIER (dosid);

         sResult         NUMBER := 0;
         mt_transf       NUMBER := 0;
         mt_tot_transf   NUMBER := 0;
         mt_env_tot      NUMBER := 0;
      BEGIN
         FOR C_dosid IN C_dosid_TIREE
         LOOP
            SELECT pfiinvestissement
              INTO mt_transf
              FROM propositionfinanciere
             WHERE pfiid =
                      (SELECT pfiid
                         FROM dprpropfinance
                        WHERE     dosid = C_dosid.dosid
                              AND dprversion =
                                     PA_AVCOMMUN.F_DERNIEREVERSIONDOSSIER (
                                        dosid)
                              AND dpfflagretenue = 1);

            mt_tot_transf := mt_tot_transf + mt_transf;
         END LOOP;

         sResult := mt_tot_transf;

         RETURN sResult;
      END;
       EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END F_GET_MTTOT_DOS_TIREE;
   --------------------utlise dans SGM45
   FUNCTION F_GET_Date_DECISION( nDOSID  DOSSIERPROSPECT.DOSID%TYPE)
            RETURN DATE
    IS
        nResult   DATE;
    BEGIN
      SELECT    DPR.DDEDT
          INTO nResult
          FROM dprdecision DPR

         WHERE     DPR.DOSID = nDOSID
               AND DPR.DPRVERSION =F_DERNIEREVERSIONDOSSIER(dosid)
               and dpr.DDEORDRE = (select max(DDEORDRE) from DPRDECISION dcl where dpr.dosid=dcl.dosid
               and dpr.dprversion=dcl.dprversion);


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_Date_DECISION;
------------------------------
FUNCTION F_GET_LABELL_BAREME( nDOSID  DOSSIERPROSPECT.DOSID%TYPE)
            RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (200);
    BEGIN
      SELECT   PCRLIBELLE
          INTO nResult
          FROM PROPOSITIONFINANCIERE PFI, DPRPROPFINANCE DPR,LANPRICINGCRITERIA LAN

         WHERE     DPR.DOSID = nDOSID
               AND DPR.DPRVERSION =F_DERNIEREVERSIONDOSSIER(DPR.dosid)
               and DPR.PFIID = PFI.PFIID
               AND DPR.DPFFLAGRETENUE = 1
               and  LAN.PCRID=PFI.PCRID and lancode='FR';



        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_LABELL_BAREME;
-------------------------------------------------
FUNCTION f_get_cch_dossier (nDosid         DOSSIERPROSPECT.DOSID%TYPE,        ncchsid        VARCHAR2)
      RETURN VARCHAR2
   IS
   BEGIN
      DECLARE
         sResult   VARCHAR2 (200) := NULL;
      BEGIN
         SELECT MAX (
                   DECODE (cc.comtype,
                           'ALPHAN', cch.cvastringvalue,
                           'COMBOTUSPARAM', cch.cvastringvalue,
                           'DATE', cch.cvadtvalue,
                           'DECIMAL', cch.cvanumericvalue,
                           'ENTIER', cch.cvanumericvalue,
                           'LOGIQUE', cch.cvabooleanvalue,
                           'MEMO', cch.cvastringvalue,
                           'CPANEL', cch.cvastringvalue,
                           'CPANELGROUP', cch.cvastringvalue,
                           'CPANELHEADER', cch.cvastringvalue))
           INTO sResult
           FROM customcharacteristic cc, cchvalue cch
          WHERE     cch.cchsid = ncchsid
                AND cc.cchsid = cch.cchsid
                AND DOSIDPROSPECT = nDosid
                AND Dprversion = F_DERNIEREVERSIONDOSSIER(nDosid);

         RETURN sResult;
      EXCEPTION
         WHEN OTHERS
         THEN
            RETURN NULL;
      END;
   END f_get_cch_dossier;
   --------------------------
   FUNCTION f_get_LAD_dossier (nDosid  DOSSIERPROSPECT.DOSID%TYPE)
      RETURN VARCHAR2
   IS
   BEGIN
      DECLARE
         sResult   VARCHAR2 (200) := NULL;
         sreturn  VARCHAR2 (1000) := NULL ;
      BEGIN
         SELECT NVL(f_get_cch_dossier (nDosid,'TFDCCHVAL3009'),' ') into sreturn from dual;
          select NVL(TUPLIBELLE,' ') into sResult from lantusparam where TUSNOM='CLACULLAD' and TUPCODE=sreturn;

         RETURN sResult;
      EXCEPTION
         WHEN OTHERS
         THEN
            RETURN NULL;
      END;
   END f_get_LAD_dossier;
------------------------------
FUNCTION F_GET_NOM_COMM (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT UTI.UTINOM || ' ' || UTI.UTIPRENOM
          INTO nResult
          FROM DPRINTERVENANT DPR, UTILISATEUR UTI
         WHERE     DPR.DINMETIER in ('COMCOM','COMPRO','CE','CESTGE','CNORD','CEST','CSUD')
               AND DPR.DPRVERSION = F_Derniereversiondossier(DPR.Dosid)
               AND DPR.UTICODE = UTI.UTICODE
               AND DPR.DINORDRE =
                   (SELECT MAX (DINORDRE)
                      FROM DPRINTERVENANT
                     WHERE DOSID = DPR.DOSID AND DINMETIER in ('COMCOM','COMPRO','CE','CESTGE','CNORD','CSUD','CEST'))
               AND DPR.DOSID = nDOSID;
       RETURN nResult;
      EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
  END F_GET_NOM_COMM;
  -------------------------
  FUNCTION  F_GET_DUREE_MOIS(nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)RETURN NUMBER IS
-----------utilise SGM45

  nResult NUMBER;

    BEGIN

    SELECT NVL(PRO.PFINBPERIODES,0) * DECODE(PRO.PFIPERIODICITE,'001',0, '030',1, '090', 3, '180',6, '360',12,1)
    INTO nResult
           FROM PROPOSITIONFINANCIERE  PRO, DPRPROPFINANCE DPR
           WHERE   DPR.DOSID=nDOSID AND DPR.PFIID=PRO.PFIID
           AND DPR.DPRVERSION = F_DERNIEREVERSIONDOSSIER(DPR.DOSID)  AND dpr.dpfflagretenue=1
           AND DPR.DPFORDRE = (SELECT MAX(DPFORDRE) FROM DPRPROPFINANCE DPR1 WHERE    DPR.DOSID=DPR1.DOSID  and
           dpr1.dprversion=dpr.dprversion and  dpr1.dpfflagretenue=1)
           ;


    RETURN nResult;

    EXCEPTION WHEN OTHERS THEN
      RETURN 0;

END F_GET_DUREE_MOIS;
---------------
FUNCTION F_GET_TOT_MT_FRAIS (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    IS
        nResult   NUMBER;
    BEGIN
        SELECT SUM(NVL(PFI.PFPMT,0))
          INTO nResult
          FROM DPRPROPFINANCE DPR, PFIPRESTATION PFI
         WHERE     DPR.DPFFLAGRETENUE = 1
               AND DPR.DPRVERSION = F_DERNIEREVERSIONDOSSIER(DPR.dosid)
               AND DPR.PFIID = PFI.PFIID
               AND PFI.RUBCODE  NOT IN ( 'COMENGC' , 'FRADOSS')
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_TOT_MT_FRAIS;

    ------
      FUNCTION F_GET_AGRVALUE_Value (nDOSID   IN DOSSIERPROSPECT.DOSID%TYPE, nANMID IN ANALYSISMATRIX.ANMID%TYPE,
                             nRATID   IN RATIO.RATID%TYPE,nAGROR IN ARAGRID.AGRGCOCODE%TYPE
                             ) RETURN VARCHAR2
    IS
        nResult   VARCHAR2(100) ;
    BEGIN
        SELECT NVL(AGR.AGRVALUE,0)
          INTO nResult
          FROM ARAGRID AGR, ANALYSIS ANA
         WHERE     ANA.DOSID=nDOSID
               AND ANA.DPRVERSION =F_DERNIEREVERSIONDOSSIER (ANA.DOSID)
                and AGR.ANAID = ANA.ANAID
                  AND ANA.ANAID = (SELECT MAX (ANAID)
                                  FROM ANALYSIS A
                                 WHERE A.DOSID = ANA.DOSID and ANA.DPRVERSION= A.DPRVERSION  and ANMID=nANMID )
               AND AGR.RATID = nRATID
               and AGR.AGRGCOCODE=nAGROR
               ;


        RETURN nResult;

    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN 0;
    END F_GET_AGRVALUE_Value;
    ----------
    ----------------------UTILISE DANS SGM45-------------------------------------------------------------------
    FUNCTION F_GET_libelle_ACTIVITE (nDosid DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT TAC.TACLIBELLE
          INTO nResult
          FROM LANTACTIVITE TAC, DOSSIERPROSPECT DPR
         WHERE     DPR.TACCODE = TAC.TACCODE
               AND DPR.DPRVERSION = F_DERNIEREVERSIONDOSSIER (DPR.DOSID)
               AND TAC.LANCODE = 'FR'
               AND DPR.DOSID = nDosid;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_libelle_ACTIVITE;
    ------------------------SGM45
    FUNCTION F_GET_Nature_Materiel (nDOSID      IN DOSSIERPROSPECT.DOSID%TYPE)
     RETURN VARCHAR2
IS
     L_DPMFLAGNEUF   DPRMATERIEL.DPMFLAGNEUF%TYPE;
    L_DPMFLAG       VARCHAR(200);
BEGIN

    SELECT DPMFLAGNEUF
      INTO L_DPMFLAGNEUF
      FROM DPRMATERIEL
     WHERE     DOSID = nDOSID
           AND dpmordre IN
                   (SELECT MIN (dpmordre)
                      FROM DPRMATERIEL
                     WHERE     dosid = nDOSID
                           AND DPRVERSION = F_DERNIEREVERSIONDOSSIER (DOSID))
           AND DPRVERSION = F_DERNIEREVERSIONDOSSIER (DOSID);
            IF (L_DPMFLAGNEUF=1) then
            L_DPMFLAG:='Neuf';
            else
            L_DPMFLAG:='Occasion';
            END IF;

    RETURN L_DPMFLAG;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_Nature_Materiel;
    -----------------------------
    FUNCTION F_GET_libelle_Anciennete (nDosid DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
         -- nReturn   VARCHAR2 (100);

    BEGIN
        SELECT NVL(TUS.TUPLIBELLE,' ')
          INTO nResult
          FROM LANTUSPARAM TUS
         WHERE     TUSNOM='SOGERELATION' and lancode='FR'
               AND TUS.TUPCODE = NVL( PAV4_JASPER_FO.F_GET_RATIO(ndosid ,71020,7000), ' ');


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_libelle_Anciennete;
    --------------------------------
     FUNCTION F_GET_libelle_Anc_profession (nDosid DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
         -- nReturn   VARCHAR2 (100);

    BEGIN
        SELECT NVL(TUS.TUPLIBELLE,' ')
          INTO nResult
          FROM LANTUSPARAM TUS
         WHERE     TUSNOM='SOGEPROF' and lancode='FR'
               AND TUS.TUPCODE = NVL( PAV4_JASPER_FO.F_GET_RATIO(ndosid ,71021,7000), ' ');


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_libelle_Anc_profession;
    ------------------
    FUNCTION F_GET_MT_INV_CTR (nDOSID IN DOSSIER.DOSID%TYPE)
      RETURN NUMBER
   IS
      nResult   NUMBER;
   BEGIN
      SELECT SUM (DRUMTORIGINE)
        INTO nResult
        FROM DOSRUBRIQUE@SGM_LINK DRU
       WHERE     DRUCLASSE = 'F'
             AND RUBID IN (SELECT RUBID
                             FROM RUBACCES
                            WHERE RACACCES = 'REDFIN')

             AND DOSID = nDOSID
			 AND DRU.DRUORDRE NOT IN
                          (SELECT DRUORDREPREC
                             FROM DOSRUBRIQUE
                            WHERE     DOSID = DRU.DOSID
                                  AND DRUORDREPREC IS NOT NULL
                                  )-------
                   AND DRU.DRUDTFIN > SYSDATE;

      RETURN nResult;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END F_GET_MT_INV_CTR;
   -------------
   FUNCTION F_GET_DUREE_CTR (nDosId IN DOSSIER.DOSID%TYPE)
      RETURN NUMBER
   IS
      nResult   NUMBER;
   BEGIN
      SELECT NVL ( SUM ( NVL (DRF.DRFNBPERIODE, 0) * DECODE (drfperiode,'001', 0,'030', 1,
                             '090', 3,'180', 6,'360', 12,1)), 0)
        INTO nResult
        FROM DOSRUBFLUX@SGM_LINK  DRF, DOSRUBRIQUE@SGM_LINK  DRB
       WHERE     DRF.DOSID = DRB.DOSID
             AND DRF.DRUORDRE = DRB.DRUORDRE
             AND DRB.DRUORDRE IN (SELECT  (DRB2.DRUORDRE)
                       FROM DOSRUBRIQUE@SGM_LINK  DRB2
                      WHERE     DRB.DOSID = DRB2.DOSID
                            AND DRB2.DRUCLASSE = 'F'
                            AND rubid IN (SELECT RUBID
                                            FROM RUBACCES@SGM_LINK
                                           WHERE racacces = 'REDFIN')
                            AND DRB2.DRUORDRE NOT IN
                            (SELECT NVL(DRUORDREPREC,-1)
                             FROM DOSRUBRIQUE@SGM_LINK  d
                            WHERE     DOSID = DRB2.DOSID
                                  AND DRUORDREPREC IS NOT NULL
                                  ))
             AND DRF.DOSID = nDosId;

      RETURN nResult;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END F_GET_DUREE_CTR;
-------------------SGM45
 FUNCTION F_GET_MT_LOYERHT_CTR (nDOSID IN DOSSIER.DOSID%TYPE)
      RETURN NUMBER
   IS
      nResult   NUMBER;
   BEGIN
      SELECT SUM(NVL(DRF.DRFMULTIPLE,0))
        INTO nResult
        FROM DOSRUBFLUX@SGM_LINK  DRF, DOSRUBRIQUE@SGM_LINK  DRB
       WHERE     DRF.DOSID = DRB.DOSID
             AND DRF.DRUORDRE = DRB.DRUORDRE
             AND DRB.DRUORDRE IN (SELECT  (DRB2.DRUORDRE)
                       FROM DOSRUBRIQUE@SGM_LINK  DRB2
                      WHERE     DRB.DOSID = DRB2.DOSID
                            AND DRB2.DRUCLASSE = 'F'
                            AND rubid IN (SELECT RUBID
                                            FROM RUBACCES@SGM_LINK
                                           WHERE racacces = 'REDFIN')
                            AND DRB2.DRUORDRE NOT IN
                            (SELECT NVL(DRUORDREPREC,-1)
                             FROM DOSRUBRIQUE@SGM_LINK  d
                            WHERE     DOSID = DRB2.DOSID
                                  AND DRUORDREPREC IS NOT NULL
                                  ))
             AND DRF.DOSID = nDosId;

      RETURN nResult;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END F_GET_MT_LOYERHT_CTR;
   ----------------------SGM45
    FUNCTION f_get_mt_vr_dos (ndosid IN DOSSIER.DOSID%TYPE)
      RETURN NUMBER
   IS
      sreturn   NUMBER := 0;
   BEGIN
      SELECT SUM (NVL(drumtresiduel,0))
        INTO sreturn
        FROM DOSRUBRIQUE@SGM_LINK
       WHERE     dosid = ndosid
             AND druclasse = 'F'
             AND drusens = '+'
             AND druordre NOT IN
                    (SELECT NVL (druordreprec, -1)
                       FROM DOSRUBRIQUE@SGM_LINK
                      WHERE     dosid = ndosid
                            AND druclasse = 'F'
                            AND drusens = '+'
                             );

      RETURN sreturn;


  EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;

   END f_get_mt_vr_dos;
--------------------
FUNCTION F_GET_LIST_TYPEBIEN (nDOSID IN LKDOSRUBITRRUB.DOSID%TYPE)
      RETURN VARCHAR2
   AS
   BEGIN
      DECLARE
         SRETURN   VARCHAR2 (1000) := NULL;
         SIMPU     VARCHAR2 (1000) := NULL;
         ST        VARCHAR2 (500);

         CURSOR CIMPU
         IS
           SELECT '('|| Count (*)||') ' || LAN.NAPLIBELLE
              FROM  ITRRUBRIQUE@SGM_LINK ITR, lannap@SGM_LINK LAN
             WHERE ITR.ITRID IN (SELECT DISTINCT ITRID FROM LKDOSRUBITRRUB@SGM_LINK WHERE DOSID=nDOSID)
             and ITR.NAPCODE=LAN.NAPCODE(+) and lancode(+)='FR'
              GROUP BY LAN.NAPLIBELLE;
      BEGIN
         OPEN cIMPU;

         LOOP

            FETCH cIMPU INTO SIMPU;

            EXIT WHEN cIMPU%NOTFOUND;

            IF (SIMPU IS NOT NULL)
            THEN
               sreturn := sIMPU || ' , ' || sreturn;
            ELSE
               sreturn := sreturn;
            END IF;
         END LOOP;

         CLOSE CIMPU;


         IF LENGTH (sreturn) > 1
      THEN
         RETURN SUBSTR (sreturn, 1, LENGTH (sreturn) - 3);
      END IF;
          RETURN SRETURN;

      END;

  END F_GET_LIST_TYPEBIEN;
  --------------------
   FUNCTION F_GET_TOUS_FOURNISSEURS (nDOSID IN DOSSIER.DOSID%TYPE)
      RETURN VARCHAR2
   IS
      nResult   VARCHAR2 (1000);
   BEGIN
      nResult := '';

      FOR REC
         IN (SELECT PAV4_JASPER_FO.F_GET_ACTOR_NAME2 (DOSID, 'FOURN') AS FOURN
               FROM DOSSIER@SGM_LINK
              WHERE DOSID = nDOSID)
      LOOP
         IF REC.FOURN IS NOT NULL
         THEN
            nResult := nResult || REC.FOURN || ',';
         END IF;
      END LOOP;

      IF LENGTH (nResult) > 1
      THEN
         SELECT SUBSTR (nResult, 1, LENGTH (nResult) - 1)
           INTO nResult
           FROM DUAL;
      END IF;

      RETURN nResult;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END F_GET_TOUS_FOURNISSEURS;
   -----------------
  FUNCTION F_GET_IMPAYE_DOSSIER (nDOSID IN DOSSIER.DOSID%TYPE, vDate DATE)
      RETURN NUMBER
   IS
      nreturn   NUMBER;
   BEGIN
      SELECT SUM (F_PlRestantFacture_date2@SGM_LINK(FAC.FACID, NULL, vDate))
        INTO nreturn
        FROM FACTURE@SGM_LINK FAC, FACREFERENCE@SGM_LINK FRE
       WHERE FAC.FACID = FRE.FACID AND FRE.freDOSID = nDOSID;

      RETURN nRETURN;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END F_GET_IMPAYE_DOSSIER;
------
FUNCTION F_GET_PERIODICITE_CTR (nDOSID IN DOSSIER.DOSID%TYPE)
      RETURN VARCHAR2
   IS
      nResult   VARCHAR2 (100);
   BEGIN
      SELECT DECODE (MAX (DRF.DRFPERIODE),
                     '1', 'Jounaliere',
                     '001', 'Jounaliere',
                     '30', 'Mensuelle',
                     '030', 'Mensuelle',
                     '090', 'Trimestrielle',
                     '180', 'Semestrielle',
                     '360', 'Annuelle',
                     NULL)
        INTO nResult
        FROM DOSRUBFLUX DRF, DOSRUBRIQUE DRB
       WHERE    DRF.DOSID = DRB.DOSID
             AND DRF.DRUORDRE = DRB.DRUORDRE
             AND DRB.DRUORDRE IN (SELECT  (DRB2.DRUORDRE)
                       FROM DOSRUBRIQUE@SGM_LINK  DRB2
                      WHERE     DRB.DOSID = DRB2.DOSID
                            AND DRB2.DRUCLASSE = 'F'
                            AND rubid IN (SELECT RUBID
                                            FROM RUBACCES@SGM_LINK
                                           WHERE racacces = 'REDFIN')
                            AND DRB2.DRUORDRE NOT IN
                            (SELECT NVL(DRUORDREPREC,-1)
                             FROM DOSRUBRIQUE@SGM_LINK  d
                            WHERE     DOSID = DRB2.DOSID
                                  AND DRUORDREPREC IS NOT NULL
                                  ))
             AND DRF.DOSID = nDosId;

      RETURN nResult;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END F_GET_PERIODICITE_CTR;
-------------
FUNCTION F_GET_NOM_RECOUVREUR (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT UTI.UTINOM || ' ' || UTI.UTIPRENOM
          INTO nResult
          FROM DPRINTERVENANT DPR, UTILISATEUR UTI
         WHERE     DPR.DINMETIER ='REC'
               AND DPR.DPRVERSION = F_Derniereversiondossier(DPR.Dosid)
               AND DPR.UTICODE = UTI.UTICODE
               AND DPR.DINORDRE =
                   (SELECT MAX (DINORDRE)
                      FROM DPRINTERVENANT
                     WHERE DOSID = DPR.DOSID AND DINMETIER ='REC')
               AND DPR.DOSID = nDOSID;
       RETURN nResult;
      EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
  END F_GET_NOM_RECOUVREUR;
-----------------------------------------------------------------------------------
   FUNCTION f_mt_dispo_autorisation (ndosid IN DOSSIERPROSPECT.DOSID%TYPE)
      RETURN NUMBER
   IS
   BEGIN
      DECLARE
         CURSOR C_dosid_util
         IS
            SELECT dosid
              FROM dprcomplement
             WHERE     dosidautorisation = ndosid
                   AND dprversion =
                          PA_AVCOMMUN.F_DERNIEREVERSIONDOSSIER (dosid);

         sResult         NUMBER := 0;
         mt_transf       NUMBER := 0;
         mt_tot_transf   NUMBER := 0;
         mt_env_tot      NUMBER := 0;
      BEGIN
         FOR C_dosid IN C_dosid_util
         LOOP
            SELECT pfiinvestissement
              INTO mt_transf
              FROM propositionfinanciere
             WHERE pfiid =
                      (SELECT pfiid
                         FROM dprpropfinance
                        WHERE     dosid = C_dosid.dosid
                              AND dprversion =
                                     PA_AVCOMMUN.F_DERNIEREVERSIONDOSSIER (
                                        dosid)
                              AND dpfflagretenue = 1);

            mt_tot_transf := mt_tot_transf + mt_transf;
         END LOOP;

         SELECT pfiinvestissement
           INTO mt_env_tot
           FROM propositionfinanciere
          WHERE pfiid =
                   (SELECT pfiid
                      FROM dprpropfinance
                     WHERE     dosid = ndosid
                           AND dprversion =
                                  PA_AVCOMMUN.F_DERNIEREVERSIONDOSSIER (
                                     dosid)
                           AND dpfflagretenue = 1);


         sResult := mt_env_tot - mt_tot_transf;

         RETURN sResult;
      END;
   END f_mt_dispo_autorisation;
---------------------------------------------------------------------------
 FUNCTION F_GET_DT_DERNIER_TIRAGE (
        nDOSID        IN DOSSIERPROSPECT.DOSID%TYPE,
        nDPRVERSION   IN DOSSIERPROSPECT.DPRVERSION%TYPE)
        RETURN DATE
    IS
        nResult   DATE;
    BEGIN
       SELECT max(CREDTEFFET)
       INTO nResult
       FROM CREVT CRE , DOSSIERPROSPECT DPR
       WHERE DPR.DOSID = CRE.DOSIDPROSPECT
       AND CRE.TMFFONCTION = 'EVF_TIRAGE'
       AND DPR.DOSID =nDOSID
       AND DPR.DPRVERSION = nDPRVERSION;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_DT_DERNIER_TIRAGE;
------------------------------------------
 FUNCTION F_GET_Utilisation_PART_TOATL ( nDOSID  IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
        ntest Number := 0 ;
    BEGIN
     SELECT f_mt_dispo_autorisation(Ndosid ) INTO
      ntest
     FROM DUAL ;
      IF ntest = 0 THEN nResult :='Totalement' ;
      ELSE nResult := 'Partiellement'  ;
      end if ;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_Utilisation_PART_TOATL;
---------------------------------------------------------------------------
FUNCTION F_GET_TEST_ENV ( nDOSID  IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (10);
    BEGIN
     SELECT      CASE WHEN TPGCODE LIKE 'AUT%' THEN 'OUI' ELSE 'NON'

      END
      INTO nResult
      FROM DOSSIERPROSPECT

       WHERE DOSID = nDOSID
        AND DPRVERSION=F_DERNIEREVERSIONDOSSIER (DOSID) ;
        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_TEST_ENV;
----------------------------------------------------------------------------------------
FUNCTION F_GET_LIST_BANK_ACT (nACTID IN ACTEUR.ACTID%TYPE)RETURN VARCHAR2
   AS
   BEGIN
      DECLARE
         SRETURN   VARCHAR2 (1000) := NULL;
         SBANK     VARCHAR2 (1000) := NULL;

         CURSOR CBANK
         IS
           SELECT DISTINCT BNQ.BANLIBELLE FROM ACTRIB ACR ,RIB ,BANQUEGUICHET BGU ,BANQUE BNQ
           WHERE ACR. ACTID = nACTID
           AND ACR.RIBID = RIB.RIBID
           AND BGU.BGUBANQUE = RIB.BGUBANQUE
           AND BGU.BGUGUICHET = RIB.BGUGUICHET
           AND BNQ.BANCODE = BGU.BGUBANQUE
           AND BNQ.PAYCODE = BGU.PAYCODE ;
      BEGIN
         OPEN cBANK;

         LOOP

            FETCH cBANK INTO SBANK;

            EXIT WHEN cBANK%NOTFOUND;

            IF (SBANK IS NOT NULL)
            THEN
               sreturn := sBANK || ' , ' || sreturn;
            ELSE
               sreturn := sreturn;
            END IF;
         END LOOP;

         CLOSE CBANK;



          RETURN SUBSTR(sreturn, 0, LENGTH(sreturn) - 2)
;

      END;

  END F_GET_LIST_BANK_ACT;
---------------------------SGM45-------------------------------------------------------------------
FUNCTION F_GET_Gestionnaire ( nDOSID  IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (1000);
    BEGIN
                 SELECT DECODE (DPRRESEAUCIAL ,'SGMA' ,
                 CASE WHEN(PAV4_JASPER_FO.f_get_cch_dossier(DPR.DOSID,'TFDCCHSID93')is not null)
                 then PAV4_JASPER_FO.f_get_cch_dossier(DPR.DOSID,'TFDCCHSID93')
                 ELSE UTI.UTINOM ||' '||UTI.UTIPRENOM END,NULL)
                 INTO nResult
                 FROM DOSSIERPROSPECT DPR  , UTILISATEUR UTI
                 WHERE DPR.UTICODECREATION = UTI.UTICODE
                AND DOSID = nDOSID ;
        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_Gestionnaire;
--------------------------------------
FUNCTION F_GET_NOM_COMM_FICHP ( nDOSID  IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (1000);
    BEGIN
                SELECT UTI.UTIPRENOM || ' ' || UTI.UTINOM
                INTO nResult
                FROM ANALYSIS ANA ,UTILISATEUR UTI WHERE DOSID = nDOSID
                 AND  ANA.UTICODE = UTI.UTICODE
                 AND ANA .DPRVERSION =F_Derniereversiondossier(ANA.Dosid)
                AND ANA.ANAID = (SELECT MAX(ANA2.ANAID) FROM ANALYSIS ANA2 WHERE ANA2.DOSID = ANA.DOSID AND ANA.DPRVERSION =ANA2.DPRVERSION
                AND ANA.ANMID = ANA2.ANMID)
            AND ANA.ANMID = 5 ;
        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_NOM_COMM_FICHP;
--------------------------------------------------------------------------------------
FUNCTION F_GET_APPORT_PERC ( nDOSID  IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    IS
        nResult   number := 0;
    BEGIN
                    SELECT nvl( ((PFIPCTDOWNPAYMENT / NULLIF ((PFIPCTDOWNPAYMENT + PFADOUBLE), 0)) * 100),0)
          INTO nResult
          FROM DPRPROPFINANCE DPF  , propositionfinanciere PFI , PFIATTRIBUT PFA
          WHERE DPF.DOSID = nDOSID
          AND DPFFLAGRETENUE = 1
          AND DPF.dprversion= F_DERNIEREVERSIONDOSSIER ( DPF.DOSID)
         AND PFI.PFIID = DPF.PFIID
         AND PFA.PFACODE = 'FINANCEDVALUE' AND PFA.PFIID = PFI.PFIID ;
        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_APPORT_PERC;
--------------------------------------------------------------------------
 FUNCTION F_GET_ENCOURS_ACTEUR_CTRACTIF (Nactid IN ACTEUR.ACTID%TYPE)
      RETURN NUMBER
   IS
      nResult   NUMBER;
   BEGIN
      SELECT SUM(DREMTECF)
      INTO nResult
      						 FROM   DOSRUBRIQUE@SGM_LINK DRU , DOSACTEUR@SGM_LINK DAC , DOSRUBECHEANCIER@SGM_LINK DRE , DOSPHASE@SGM_LINK DPH
      						 WHERE  DAC.DOSID = DRU.DOSID AND DAC.ROLCODE = 'CLIENT'
                   AND DAC.ACTID = Nactid
      						 AND    DRU.DRUCLASSE = 'F'
      						 AND ( DRU.DRUTYPE = 'F')
                   AND NOT EXISTS (SELECT 1
                   FROM DOSRUBRIQUE@SGM_LINK
                                    WHERE DOSID = DRU.DOSID
                                      AND DRUORDREPREC = DRU.DRUORDRE )
                AND DRE.DRUORDRE = DRU.DRUORDRE AND DRE.DOSID = DRU.DOSID
                AND DRE.DREORDRE =
                    (SELECT MAX (DREORDRE)
                       FROM DOSRUBECHEANCIER@SGM_LINK
                      WHERE     ((FACID IS NOT NULL  AND DRETYPE = 'LOYER') OR (FACID IS null   AND DRETYPE = 'INV'))
                            AND DOSID = DRE.DOSID
                            AND DRUORDRE = DRE.DRUORDRE
                            AND DRETYPE = 'LOYER')
                AND DPH.DOSID = DAC.DOSID AND DPH.DPHDTFIN IS NULL AND DPH.PHACODE = 'ES'

               ;


      RETURN nResult;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END F_GET_ENCOURS_ACTEUR_CTRACTIF;
-----------------------------------------------------------------------------------------
FUNCTION F_GET_MTINI_CTRACTIF_ACTEUR (Nactid IN ACTEUR.ACTID%TYPE)
      RETURN NUMBER
   IS
      nResult   NUMBER;
   BEGIN
               SELECT SUM(DRU.DRUMTORIGINE)
               INTO nResult
               FROM DOSACTEUR@SGM_LINK DAC , DOSRUBRIQUE@SGM_LINK DRU , DOSPHASE@SGM_LINK  DPH
               WHERE DAC.ACTID =Nactid AND DAC.ROLCODE = 'CLIENT'
                AND DRU.DOSID = DAC.DOSID
                AND    DRU.DRUCLASSE = 'F' AND   DRU.RUBID IN (SELECT RUBID
                             FROM RUBACCES@SGM_LINK
                            WHERE RACACCES = 'REDFIN')

                AND NOT EXISTS (SELECT 1
                   FROM DOSRUBRIQUE@SGM_LINK
                                    WHERE DOSID = DRU.DOSID
                                      AND DRUORDREPREC = DRU.DRUORDRE )

AND DPH.DOSID = DAC.DOSID AND DPH.DPHDTFIN IS NULL
AND DPH.PHACODE = 'ES';



      RETURN nResult;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END F_GET_MTINI_CTRACTIF_ACTEUR;
-------------------------------------------------------------------------------------------------
FUNCTION F_GET_DTENCOURS_ACTEUR_CTRACTIF (Nactid IN ACTEUR.ACTID%TYPE)
      RETURN DATE
   IS
      nResult   DATE;
   BEGIN
      SELECT MAX(DREDTECH)
      INTO nResult
      						 FROM   DOSRUBRIQUE@SGM_LINK DRU , DOSACTEUR@SGM_LINK DAC , DOSRUBECHEANCIER@SGM_LINK DRE , DOSPHASE@SGM_LINK DPH
      						 WHERE  DAC.DOSID = DRU.DOSID AND DAC.ROLCODE = 'CLIENT'
                   AND DAC.ACTID = Nactid
      						 AND    DRU.DRUCLASSE = 'F'
      						 AND ( DRU.DRUTYPE = 'F')
                   AND NOT EXISTS (SELECT 1
                   FROM DOSRUBRIQUE@SGM_LINK
                                    WHERE DOSID = DRU.DOSID
                                      AND DRUORDREPREC = DRU.DRUORDRE )
                AND DRE.DRUORDRE = DRU.DRUORDRE AND DRE.DOSID = DRU.DOSID
                AND DRE.DREORDRE =
                    (SELECT MAX (DREORDRE)
                       FROM DOSRUBECHEANCIER@SGM_LINK
                      WHERE     ((FACID IS NOT NULL  AND DRETYPE = 'LOYER') OR (FACID IS null   AND DRETYPE = 'INV'))
                            AND DOSID = DRE.DOSID
                            AND DRUORDRE = DRE.DRUORDRE
                            AND DRETYPE = 'LOYER')
                AND DPH.DOSID = DAC.DOSID AND DPH.DPHDTFIN IS NULL AND DPH.PHACODE = 'ES'

               ;


      RETURN nResult;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END F_GET_DTENCOURS_ACTEUR_CTRACTIF;
-----------------------------------------------------------------------
FUNCTION F_GET_DTCREATION_BO (Ndosid IN DOSSIER.DOSID%TYPE)
      RETURN DATE
   IS
      nResult   DATE;
   BEGIN

            SELECT DPHDTEFFET
            INTO nResult
            FROM DOSPHASE@SGM_LINK DPH
           WHERE DPH.PHACODE = 'ENG'
           AND DPH.DOSID = Ndosid ;
      RETURN nResult;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END F_GET_DTCREATION_BO;
--------------------------------------------------------------------------------------------
FUNCTION F_GET_ENCOURS_ACTEUR_CTRENG (Nactid IN ACTEUR.ACTID%TYPE)
      RETURN NUMBER
   IS
      nResult   NUMBER;
   BEGIN
               SELECT sum(ENCOURS)
               INTO nResult
                FROM (
                  SELECT SUM(DRE.DREMTECF) "ENCOURS" FROM DOSACTEUR@SGM_LINK DAC , DOSPHASE@SGM_LINK DPH
               , DOSRUBRIQUE@SGM_LINK DRU , DOSRUBECHEANCIER@SGM_LINK DRE
                      WHERE
                      DAC.ACTID = Nactid
                      AND DAC.ROLCODE ='CLIENT'
                      AND DPH.DOSID = DAC.DOSID
                      AND DPH.PHACODE IN ('ENG' ,'EC') AND DPH.DPHDTFIN IS NULL
                      AND MONTHS_BETWEEN (sysdate,PAV4_JASPER_FO.F_GET_DTCREATION_BO(DAC.DOSID))< 6
                      AND DRU.DOSID = DAC.DOSID AND DRU.DRUTYPE ='F' AND DRU.DRUCLASSE = 'F'
                      AND    DRU.DRUCLASSE = 'F'
      						 AND ( DRU.DRUTYPE = 'F')
                   AND NOT EXISTS (SELECT 1
                   FROM DOSRUBRIQUE@SGM_LINK
                                    WHERE DOSID = DRU.DOSID
                                      AND DRUORDREPREC = DRU.DRUORDRE )
                AND DRE.DRUORDRE = DRU.DRUORDRE AND DRE.DOSID = DRU.DOSID
                AND DRE.DREORDRE =
                    (SELECT MAX (DREORDRE)
                       FROM DOSRUBECHEANCIER@SGM_LINK
                      WHERE     ((FACID IS NOT NULL  AND DRETYPE = 'LOYER') OR (FACID IS null   AND DRETYPE = 'INV'))
                            AND DOSID = DRE.DOSID
                            AND DRUORDRE = DRE.DRUORDRE
                            AND DRETYPE = 'LOYER')
 UNION
                SELECT SUM(DRE.DREMTECF) "ENCOURS"
                FROM DOSACTEUR@SGM_LINK DAC , DOSPHASE@SGM_LINK DPH , DOSRUBRIQUE@SGM_LINK DRU ,
                DOSRUBECHEANCIER@SGM_LINK DRE
                WHERE
                DAC.ACTID = Nactid
                AND DAC.ROLCODE ='CLIENT'
                AND DPH.DOSID = DAC.DOSID
                 AND DPH.PHACODE IN ('ENG' ,'EC')
                  AND DPH.DPHDTFIN IS NULL
                AND EXISTS (SELECT 1 FROM LKDOSRUBITRRUB@SGM_LINK LK , DEPLIGNE@SGM_LINK DLI
                WHERE LK.DOSID= DAC.DOSID AND DLI.ITRID = LK.ITRID
                AND EXISTS (SELECT 1 FROM REGIMPUTATION@SGM_LINK RIM WHERE RIM.DEPID = DLI.DEPID)
                )
                AND MONTHS_BETWEEN (sysdate,PAV4_JASPER_FO.F_GET_DTCREATION_BO(DAC.DOSID)) > 6
                AND DRU.DOSID = DAC.DOSID AND DRU.DRUTYPE ='F' AND DRU.DRUCLASSE = 'F'
                 AND    DRU.DRUCLASSE = 'F'
                                   AND ( DRU.DRUTYPE = 'F')
                                   AND NOT EXISTS (SELECT 1
                                   FROM DOSRUBRIQUE@SGM_LINK
                                                    WHERE DOSID = DRU.DOSID
                                                      AND DRUORDREPREC = DRU.DRUORDRE )
                                AND DRE.DRUORDRE = DRU.DRUORDRE AND DRE.DOSID = DRU.DOSID
                                AND DRE.DREORDRE =
                                    (SELECT MAX (DREORDRE)
                                       FROM DOSRUBECHEANCIER@SGM_LINK
                                      WHERE     ((FACID IS NOT NULL  AND DRETYPE = 'LOYER') OR (FACID IS null   AND DRETYPE = 'INV'))
                                            AND DOSID = DRE.DOSID
                                            AND DRUORDRE = DRE.DRUORDRE
                                            AND DRETYPE = 'LOYER')
                                            )

;

      RETURN nResult;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END F_GET_ENCOURS_ACTEUR_CTRENG;

------------------------------------------------------------------------------------------
FUNCTION F_GET_DTENCOURS_ACTEUR_CTRENG (Nactid IN ACTEUR.ACTID%TYPE)
      RETURN DATE
   IS
      nResult   DATE;
   BEGIN
               SELECT MAX(DTENCOURS)
               INTO nResult
                FROM (
                  SELECT MAX(DRE.DREDTECH) "DTENCOURS" FROM DOSACTEUR@SGM_LINK DAC , DOSPHASE@SGM_LINK DPH
               , DOSRUBRIQUE@SGM_LINK DRU , DOSRUBECHEANCIER@SGM_LINK DRE
                      WHERE
                      DAC.ACTID = Nactid
                      AND DAC.ROLCODE ='CLIENT'
                      AND DPH.DOSID = DAC.DOSID
                      AND DPH.PHACODE IN ('ENG' ,'EC') AND DPH.DPHDTFIN IS NULL
                      AND MONTHS_BETWEEN (sysdate,PAV4_JASPER_FO.F_GET_DTCREATION_BO(DAC.DOSID))< 6
                      AND DRU.DOSID = DAC.DOSID AND DRU.DRUTYPE ='F' AND DRU.DRUCLASSE = 'F'
                      AND    DRU.DRUCLASSE = 'F'
      						 AND ( DRU.DRUTYPE = 'F')
                   AND NOT EXISTS (SELECT 1
                   FROM DOSRUBRIQUE@SGM_LINK
                                    WHERE DOSID = DRU.DOSID
                                      AND DRUORDREPREC = DRU.DRUORDRE )
                AND DRE.DRUORDRE = DRU.DRUORDRE AND DRE.DOSID = DRU.DOSID
                AND DRE.DREORDRE =
                    (SELECT MAX (DREORDRE)
                       FROM DOSRUBECHEANCIER@SGM_LINK
                      WHERE     ((FACID IS NOT NULL  AND DRETYPE = 'LOYER') OR (FACID IS null   AND DRETYPE = 'INV'))
                            AND DOSID = DRE.DOSID
                            AND DRUORDRE = DRE.DRUORDRE
                            AND DRETYPE = 'LOYER')
 UNION
                SELECT MAX(DRE.DREDTECH) "DTENCOURS"
                FROM DOSACTEUR@SGM_LINK DAC , DOSPHASE@SGM_LINK DPH , DOSRUBRIQUE@SGM_LINK DRU ,
                DOSRUBECHEANCIER@SGM_LINK DRE
                WHERE
                DAC.ACTID = Nactid
                AND DAC.ROLCODE ='CLIENT'
                AND DPH.DOSID = DAC.DOSID
                 AND DPH.PHACODE IN ('ENG' ,'EC')
                  AND DPH.DPHDTFIN IS NULL
                AND EXISTS (SELECT 1 FROM LKDOSRUBITRRUB@SGM_LINK LK , DEPLIGNE@SGM_LINK DLI
                WHERE LK.DOSID= DAC.DOSID AND DLI.ITRID = LK.ITRID
                AND EXISTS (SELECT 1 FROM REGIMPUTATION@SGM_LINK RIM WHERE RIM.DEPID = DLI.DEPID)
                )
                AND MONTHS_BETWEEN (sysdate,PAV4_JASPER_FO.F_GET_DTCREATION_BO(DAC.DOSID)) > 6
                AND DRU.DOSID = DAC.DOSID AND DRU.DRUTYPE ='F' AND DRU.DRUCLASSE = 'F'
                 AND    DRU.DRUCLASSE = 'F'
                                   AND ( DRU.DRUTYPE = 'F')
                                   AND NOT EXISTS (SELECT 1
                                   FROM DOSRUBRIQUE@SGM_LINK
                                                    WHERE DOSID = DRU.DOSID
                                                      AND DRUORDREPREC = DRU.DRUORDRE )
                                AND DRE.DRUORDRE = DRU.DRUORDRE AND DRE.DOSID = DRU.DOSID
                                AND DRE.DREORDRE =
                                    (SELECT MAX (DREORDRE)
                                       FROM DOSRUBECHEANCIER@SGM_LINK
                                      WHERE     ((FACID IS NOT NULL  AND DRETYPE = 'LOYER') OR (FACID IS null   AND DRETYPE = 'INV'))
                                            AND DOSID = DRE.DOSID
                                            AND DRUORDRE = DRE.DRUORDRE
                                            AND DRETYPE = 'LOYER')
                                            )

;

      RETURN nResult;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END F_GET_DTENCOURS_ACTEUR_CTRENG;
------------------------------------------------------------------------------------------------------
FUNCTION F_GET_MTINI_CTRACENG_ACTEUR (Nactid IN ACTEUR.ACTID%TYPE)
      RETURN NUMBER
   IS
      nResult   NUMBER;
   BEGIN


                      SELECT sum(MT_INI)
                      into nResult
            FROM (
            SELECT SUM(DRU.DRUMTORIGINE) "MT_INI" FROM DOSACTEUR@SGM_LINK DAC , DOSPHASE@SGM_LINK DPH
            , DOSRUBRIQUE@SGM_LINK DRU WHERE
            DAC.ACTID = Nactid
            AND DAC.ROLCODE ='CLIENT'
            AND DPH.DOSID = DAC.DOSID
            AND DPH.PHACODE IN ('ENG' ,'EC') AND DPH.DPHDTFIN IS NULL
            AND MONTHS_BETWEEN (sysdate,PAV4_JASPER_FO.F_GET_DTCREATION_BO(DAC.DOSID))< 6
            AND DRU.DOSID = DAC.DOSID
            AND DRU.RUBID IN (SELECT RUBID
                             FROM RUBACCES@SGM_LINK
                            WHERE RACACCES = 'REDFIN')

             AND    DRU.DRUCLASSE = 'F'
                               AND NOT EXISTS (SELECT 1
                               FROM DOSRUBRIQUE@SGM_LINK
                                                WHERE DOSID = DRU.DOSID
                                                  AND DRUORDREPREC = DRU.DRUORDRE )

                            UNION
            SELECT SUM(DRU.DRUMTORIGINE) "MT_INI"
            FROM DOSACTEUR@SGM_LINK DAC , DOSPHASE@SGM_LINK DPH , DOSRUBRIQUE@SGM_LINK DRU
            WHERE
            DAC.ACTID = Nactid
            AND DAC.ROLCODE ='CLIENT'
            AND DPH.DOSID = DAC.DOSID
            AND DPH.PHACODE IN ('ENG' ,'EC')
            AND DPH.DPHDTFIN IS NULL
            AND EXISTS (SELECT 1 FROM LKDOSRUBITRRUB@SGM_LINK LK , DEPLIGNE@SGM_LINK DLI
            WHERE LK.DOSID= DAC.DOSID AND DLI.ITRID = LK.ITRID
            AND EXISTS (SELECT 1 FROM REGIMPUTATION@SGM_LINK RIM WHERE RIM.DEPID = DLI.DEPID)
            )
            AND MONTHS_BETWEEN (sysdate,PAV4_JASPER_FO.F_GET_DTCREATION_BO(DAC.DOSID)) > 6
            AND DRU.DOSID = DAC.DOSID AND   DRU.DRUCLASSE = 'F'
             AND      DRU.RUBID IN (SELECT RUBID
                             FROM RUBACCES@SGM_LINK
                            WHERE RACACCES = 'REDFIN')
                               AND NOT EXISTS (SELECT 1
                               FROM DOSRUBRIQUE@SGM_LINK
                                                WHERE DOSID = DRU.DOSID
                                                  AND DRUORDREPREC = DRU.DRUORDRE ) ) ;





      RETURN nResult;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END F_GET_MTINI_CTRACENG_ACTEUR;
-------------------------------------------------------------------------------------------
 FUNCTION F_GET_IMPAYE_ACTEUR (nACTID IN ACTEUR.ACTID%TYPE, vDate DATE)
      RETURN NUMBER
   IS
      nreturn   NUMBER;
   BEGIN
      SELECT SUM (F_PlRestantFacture_date2@SGM_LINK(FAC.FACID, NULL, vDate))
        INTO nreturn
        FROM FACTURE@SGM_LINK FAC, ACTEUR@SGM_LINK ACT
       WHERE FAC.ACTIDCLIENT = ACT.ACTID AND ACT.ACTID = nACTID;

      RETURN nRETURN;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END F_GET_IMPAYE_ACTEUR;
------
 FUNCTION F_GET_COUNT_CTR_ECHU (nACTID IN ACTEUR.ACTID%TYPE)
      RETURN NUMBER
   IS
      nreturn   NUMBER;
   BEGIN
               SELECT COUNT(DISTINCT DOSID)
               INTO nreturn
               FROM ACTEUR@SGM_LINK ACT, FACTURE@SGM_LINK FAC , DOSACTEUR@SGM_LINK DAC
                WHERE ACT.ACTID = FAC.ACTIDCLIENT
                AND F_PlRestantFacture_date2@SGM_LINK(FAC.FACID, NULL, SYSDATE) > 0
                AND DAC.ACTID = ACT.ACTID AND DAC.ROLCODE ='CLIENT' AND DAC.DACDTFIN IS NULL
                AND DAC.ACTID = nACTID;

      RETURN nRETURN;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END F_GET_COUNT_CTR_ECHU;
---------------------------------------------------------------------------
FUNCTION F_GET_MT_INV_CTR_ECH (nACTID IN ACTEUR.ACTID%TYPE)
      RETURN NUMBER
   IS
      nreturn   NUMBER;
   BEGIN
               SELECT SUM(DRU.DRUMTORIGINE)
               INTO nreturn
               FROM ACTEUR@SGM_LINK ACT, FACTURE@SGM_LINK FAC , DOSACTEUR@SGM_LINK DAC ,DOSRUBRIQUE@SGM_LINK DRU
                WHERE ACT.ACTID = FAC.ACTIDCLIENT
                AND F_PlRestantFacture_date2@SGM_LINK(FAC.FACID, NULL, SYSDATE) > 0
                AND DRU.DOSID = DAC.DOSID
                AND  DRU.DRUCLASSE = 'F'
                   AND DRU.RUBID IN (SELECT RUBID
                                      FROM RUBACCES@SGM_LINK
                                      WHERE RACACCES = 'REDFIN')
                                      AND NOT EXISTS (SELECT 1
                                      FROM DOSRUBRIQUE@SGM_LINK
                                                        WHERE DOSID = DRU.DOSID
                                                          AND DRUORDREPREC = DRU.DRUORDRE )
                AND DAC.ACTID = ACT.ACTID AND DAC.ROLCODE ='CLIENT' AND DAC.DACDTFIN IS NULL
                AND DAC.ACTID = nACTID;

      RETURN nRETURN;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END F_GET_MT_INV_CTR_ECH;
--------------------------------------------------------------------------------------------
 FUNCTION F_GET_COUNT_CTR (nACTID IN ACTEUR.ACTID%TYPE)
      RETURN NUMBER
   IS
      nreturn   NUMBER;
   BEGIN
               SELECT COUNT(DOSID)
               INTO nreturn
               FROM  DOSACTEUR@SGM_LINK DAC
                WHERE DAC.ROLCODE ='CLIENT' AND DAC.DACDTFIN IS NULL
                AND DAC.ACTID = nACTID;

      RETURN nRETURN;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END F_GET_COUNT_CTR;
--------------------------------------------------------------------------------------------
FUNCTION F_GET_MT_INV_ACT (nACTID IN ACTEUR.ACTID%TYPE)
      RETURN NUMBER
   IS
      nreturn   NUMBER;
   BEGIN
            SELECT NVL (SUM (DRU.drumtorigine), 0)
              INTO nReturn
              FROM DOSRUBRIQUE@SGM_LINK DRU , DOSACTEUR@SGM_LINK DAC
             WHERE     DRU.dosid = DAC.DOSID AND DAC.ROLCODE ='CLIENT'
             AND DAC.ACTID = nACTID
                   AND DRU.DRUORDRE NOT IN
                          (SELECT DRUORDREPREC
                             FROM DOSRUBRIQUE
                            WHERE     DOSID = DRU.DOSID
                                  AND DRUORDREPREC IS NOT NULL) ;

      RETURN nRETURN;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END F_GET_MT_INV_ACT;
  ----------------------------------------------------
  FUNCTION F_GET_RILIQ_ENV_ACT (nACTID IN ACTEUR.ACTID%TYPE)
      RETURN NUMBER
   IS
      nreturn   NUMBER;
   BEGIN
          SELECT

                SUM(F_PLGETDOSQPAVAILABLE@SGM_LINK(DOS.DOSID,'FR','ORFI'))
                INTO nreturn
                FROM
                DOSACTEUR@SGM_LINK DAC , DOSSIER@SGM_LINK DOS , DOSPHASE@SGM_LINK DPH
                WHERE DAC.ACTID = nACTID AND DAC.ROLCODE = 'CLIENT'
                AND DOS.DOSID = DAC.DOSID AND DOS.TPGCODE = 'AUT02'
                AND DPH.DOSID = DOS.DOSID AND DPH.DPHDTFIN IS NULL AND DPH.PHACODE !='TER';

      RETURN nRETURN;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END F_GET_RILIQ_ENV_ACT;
----------------------------------------------------------------
 FUNCTION F_GET_MT_TIRE (ndosid IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    IS
    BEGIN
        DECLARE
            sResult        NUMBER := 0;
            mt_tot_tiree   NUMBER := 0;
            mt_env_tot     NUMBER := 0;
        BEGIN
            SELECT NVL (SUM (DM1MTINVESTCHILD), 0)
              INTO mt_tot_tiree
              FROM l1dprmateriel
             WHERE     DOSID = ndosid
                   AND dprversion =
                       PA_AVCOMMUN.F_DERNIEREVERSIONDOSSIER (dosid)
                   AND dprversionchild = 'NEGO';



            sResult :=  mt_tot_tiree;

            RETURN sResult;
        END;
    END F_GET_MT_TIRE;
----      --------------UTILISE DANS SGM45
-----------------------------------------------------------------------------------
  FUNCTION f_get_nb_dossier_tire (ndosid IN DOSSIERPROSPECT.DOSID%TYPE)
      RETURN NUMBER
   IS
   BEGIN
      DECLARE
         sResult   NUMBER;
      BEGIN
         BEGIN
            SELECT COUNT (distinct(dpc.dosid))
              INTO sResult
              FROM dprcomplement dpc
             WHERE     dosidautorisation = ndosid
                   ;
         EXCEPTION
            WHEN OTHERS
            THEN
               sResult := NULL;
         END;

         RETURN sResult;
      END;
   END f_get_nb_dossier_tire;
---------------------------------------------------------------------------------------
FUNCTION F_GET_DT_IMPAYE_ACTEUR (nACTID IN ACTEUR.ACTID%TYPE, vDate DATE)
      RETURN DATE
   IS
      nreturn   DATE;
   BEGIN
      SELECT MAX (FAC.FACDTTRAIT)
        INTO nreturn
        FROM FACTURE@SGM_LINK FAC, ACTEUR@SGM_LINK ACT
       WHERE FAC.ACTIDCLIENT = ACT.ACTID AND ACT.ACTID = nACTID
       AND F_PlRestantFacture_date2@SGM_LINK(FAC.FACID, NULL, vDate) <> 0 ;

      RETURN nRETURN;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END F_GET_DT_IMPAYE_ACTEUR;
------------------------------------------------SGM45-----------------------------------
FUNCTION F_GET_OBJECT_CONTRAT (ndosid IN dossierprospect.dosid%TYPE)
      RETURN VARCHAR2
   IS
      objet   VARCHAR2 (1000);
   BEGIN
      SELECT DDECOMMENT
        INTO objet
        FROM dprdecision
       WHERE DOSID = ndosid AND dprversion=f_derniereversiondossier(dosid) AND adecode = 'MOTIFI'
       AND DDEORDRE = (SELECT MAX(DDEORDRE) FROM dprdecision DDE2 WHERE DDE2.DOSID =ndosid and DDE2.adecode = 'MOTIFI' );

      RETURN objet;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END F_GET_OBJECT_CONTRAT;
  ------------------------------------------------SGM45-----------------------------------
FUNCTION F_GET_DT_TRAITEMENT (ndosid IN dossierprospect.dosid%TYPE , nWORCODE varchar2 , nWstorder Number)
      RETURN DATE
   IS
      Nresult   DATE ;
   BEGIN
           SELECT WST.WSTDTEXEC
           into Nresult
           FROM DPRWORSTEP WST
          WHERE
                 WST.DOSID = ndosid
                AND dprversion=f_derniereversiondossier(dosid)
                AND WST.WORCODE = nWORCODE
                AND WST.Wstorder = nWstorder ;

      RETURN Nresult;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END F_GET_DT_TRAITEMENT;
FUNCTION F_GET_Dt_decision (ndosid IN dossierprospect.dosid%TYPE )
      RETURN DATE
   IS
      Nresult   DATE ;
   BEGIN
           SELECT WST.WSTDTEXEC
           into Nresult
           FROM DPRWORSTEP WST
          WHERE
                 WST.DOSID = ndosid
                AND dprversion=f_derniereversiondossier(dosid)
                AND WST.WORCODE = 'WFCLIPRO'
                AND WST.Wstorder in (9,11,14,18,20,19 );

      RETURN Nresult;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END F_GET_Dt_decision;
------------------------------------
FUNCTION F_GET_NOM_CHRG_CLIENT_SGMA (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
        SELECT UTI.UTINOM ||' '|| UTI.UTIPRENOM
        INTO nResult
        FROM DPRINTERVENANT DPR ,UTILISATEUR UTI WHERE DOSID = nDOSID
                  AND DPR.DINSALESNETWORK ='SGMA' AND DPR.DINMETIER ='CHARCLI'
                   AND UTI.UTICODE = DPR.UTICODE
                   AND DPR.DPRVERSION = F_Derniereversiondossier(DPR.Dosid);
       RETURN nResult;
      EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
  END F_GET_NOM_CHRG_CLIENT_SGMA;
----------SGM45
FUNCTION F_GET_MT_CTR_BO (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    IS
        nResult   NUMBER ;
    BEGIN
        SELECT SUM (DRUMTORIGINE)
        INTO nResult
        FROM DOSRUBRIQUE@SGM_LINK DRU WHERE DOSID = nDOSID
          AND   Druclasse = 'F'
          AND DRUTYPE = 'F'
           AND DRU.DRUDTFIN > SYSDATE ;
       RETURN nResult;
      EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
  END F_GET_MT_CTR_BO;
  --------SGM45-----------
  FUNCTION F_GET_DT_TRAITEMENT_BO (ndosid IN dossierprospect.dosid%TYPE , nTMFFONCTION varchar2 )
      RETURN DATE
   IS
      Nresult   DATE ;
   BEGIN
   SELECT CREDTEFFET
   INTO Nresult
   FROM CREVT@SGM_LINK  WHERE TMFFONCTION = nTMFFONCTION and DOSID = NDOSID

;

      RETURN Nresult;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END F_GET_DT_TRAITEMENT_BO;
----------------------------------------------------------------------
 FUNCTION F_GET_NOM_VENDOR (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
     SELECT  UTI.UTINOM||' '||UTI.UTIPRENOM
     into nResult
           FROM DOSSIERPROSPECT DPR , UTILISATEUR UTI
           WHERE DOSID = nDOSID
            and DPRRESEAUCIAL = 'VEND'
              AND DPR.UTICODECREATION = UTI.UTICODE ;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_NOM_VENDOR;
-------------------------------------------------------------------------
 FUNCTION F_GET_NOM_COMMERCIAL_SGMA (nDOSID IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2 (100);
    BEGIN
     SELECT   UTI.UTINOM||' '||UTI.UTIPRENOM INTO nResult
     from DPRINTERVENANT DPI,utilisateur UTI
     where DPI.uticode in ('CLICOM','CLIPRO')
     AND DPI.UTICODE=UTI.UTICODE
     AND DPI.DOSID=nDOSID
     AND DPI.DPRVERSION=F_DERNIEREVERSIONDOSSIER (DPI.DOSID);

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_NOM_COMMERCIAL_SGMA;
------------------------------------------------------------------------------------------
FUNCTION F_GET_DTENCOURS_ACTEUR_CTRAECHUS(Nactid IN ACTEUR.ACTID%TYPE)
      RETURN DATE
   IS
      nResult   DATE;
   BEGIN
      SELECT MAX(DREDTECH)
      INTO nResult
      						 FROM   DOSRUBRIQUE@SGM_LINK DRU , DOSACTEUR@SGM_LINK DAC , DOSRUBECHEANCIER@SGM_LINK DRE
      						 WHERE  DAC.DOSID = DRU.DOSID AND DAC.ROLCODE = 'CLIENT'
                   AND DAC.ACTID = Nactid
      						 AND    DRU.DRUCLASSE = 'F'
      						 AND ( DRU.DRUTYPE = 'F')
                   AND NOT EXISTS (SELECT 1
                   FROM DOSRUBRIQUE@SGM_LINK
                                    WHERE DOSID = DRU.DOSID
                                      AND DRUORDREPREC = DRU.DRUORDRE )
                AND DRE.DRUORDRE = DRU.DRUORDRE AND DRE.DOSID = DRU.DOSID
                AND DRE.DREORDRE =
                    (SELECT MAX (DREORDRE)
                       FROM DOSRUBECHEANCIER@SGM_LINK
                      WHERE     ((FACID IS NOT NULL  AND DRETYPE = 'LOYER') OR (FACID IS null   AND DRETYPE = 'INV'))
                            AND DOSID = DRE.DOSID
                            AND DRUORDRE = DRE.DRUORDRE
                            AND DRETYPE = 'LOYER')
                AND F_PlRestantFacture_date2@SGM_LINK(FACID, NULL, SYSDATE) > 0


               ;


      RETURN nResult;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END F_GET_DTENCOURS_ACTEUR_CTRAECHUS;
------------------------------------------------
 FUNCTION F_GET_MT_AUT_BO (nDosId IN DOSSIER.DOSID%TYPE)
      RETURN NUMBER
   IS
      nResult   NUMBER;
   BEGIN
      SELECT DOSMTCOMITE
      INTO nResult
      FROM DOSSIER@SGM_LINK DOS
      where DOS.TPGCODE = 'AUT02'
      AND DOS.DOSID = nDosId;

      RETURN nResult;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END F_GET_MT_AUT_BO;
   FUNCTION F_GET_DT_AUT_BO (nDosId IN DOSSIER.DOSID%TYPE)
      RETURN DATE
   IS
      nResult   DATE;
   BEGIN
      SELECT DOSDTCOMITE
      INTO nResult
      FROM DOSSIER@SGM_LINK DOS
      where DOS.TPGCODE = 'AUT02'
      AND DOS.DOSID = nDosId;

      RETURN nResult;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END F_GET_DT_AUT_BO;

   ---HME DOS DT FIN
      FUNCTION F_GET_DT_FIN_BO (nDosId IN DOSSIER.DOSID%TYPE)
      RETURN DATE
   IS
      nResult   DATE;
   BEGIN
      SELECT DOSDTFIN
      INTO nResult
      FROM DOSSIER@SGM_LINK DOS
      where DOS.TPGCODE = 'AUT02'
      AND DOS.DOSID = nDosId;

      RETURN nResult;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END F_GET_DT_FIN_BO;
-----------------------------------SGM45--------
FUNCTION F_GET_TOT_MT_FRAIS_DOS (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN NUMBER
    IS
        nResult   NUMBER;
    BEGIN
        SELECT SUM(NVL(PFI.PFPMT,0))
          INTO nResult
          FROM DPRPROPFINANCE DPR, PFIPRESTATION PFI
         WHERE     DPR.DPFFLAGRETENUE = 1
               AND DPR.DPRVERSION = F_DERNIEREVERSIONDOSSIER(DPR.dosid)
               AND DPR.PFIID = PFI.PFIID
               AND PFI.RUBCODE   = 'FRADOSS'
               AND DPR.DOSID = nDOSID;


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_TOT_MT_FRAIS_DOS;
-----------------------------------------------------------------------------
FUNCTION F_GET_UTI_IMPRESSION (nDOSID     IN DOSSIERPROSPECT.DOSID%TYPE)
        RETURN VARCHAR2
    IS
        nResult   VARCHAR2(100);
    BEGIN


 select UTI.UTINOM || ' ' || UTI.UTIPRENOM
      into nResult
      FROM dossierprospect DPR , UTILISATEUR UTI
       WHERE DPR.DOSID = nDOSID  
        AND UTI.UTICODE = DPR.UTICODECREATION
        AND DPRVERSION ='NEGO';


        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_UTI_IMPRESSION;
FUNCTION F_GET_DUREE_SIMULATION (nPFIID IN PROPOSITIONFINANCIERE.PFIMTPREMIERLOYER%TYPE , nAvance IN PFISIMULATION.PFSPREMIERLOYERPCT%TYPE ,Nordre IN PFISIMULATION.PFSORDRE%type) RETURN NUMBER
    IS
        nResult   VARCHAR2 (100);
        nPREMIERLOYER   NUMBER := 0; 
        Tordre NUMBER := 0 ;
    BEGIN
       SELECT PFIMTPREMIERLOYER INTO nPREMIERLOYER  FROM PROPOSITIONFINANCIERE PFI 
        WHERE PFI.PFIID = nPFIID ;
      SELECT 
        MIN (PFSORDRE) 
        INTO  Tordre
        FROM PFISIMULATION PFS , DPRPROPFINANCE DPF 
      where DPF.PFIID = nPFIID   AND PFSPREMIERLOYERPCT=  nAvance 
      AND PFS.PFIID = DPF.PFIID 
      AND DPF.DPRVERSION =F_DERNIEREVERSIONDOSSIER (DPF.DOSID)
      AND DPF.DPFFLAGRETENUE = 1 ;
      IF  Tordre = Nordre THEN 
        IF (nPREMIERLOYER > 0 )
        THEN
            SELECT 
          PFSNBPERIODE -1 
          INTO nResult
          FROM PFISIMULATION PFS , DPRPROPFINANCE DPF 
          where  DPF.PFIID = nPFIID  AND PFSPREMIERLOYERPCT=  nAvance 
          AND PFS.PFIID = DPF.PFIID 
          AND DPF.DPRVERSION =F_DERNIEREVERSIONDOSSIER (DPF.DOSID)
          AND DPF.DPFFLAGRETENUE = 1
          and PFSORDRE = Nordre;
          ELSE 
           SELECT 
          PFSNBPERIODE INTO nResult
          FROM PFISIMULATION PFS , DPRPROPFINANCE DPF 
          where  DPF.PFIID = nPFIID  AND PFSPREMIERLOYERPCT=  nAvance 
          AND PFS.PFIID = DPF.PFIID 
          AND DPF.DPRVERSION =F_DERNIEREVERSIONDOSSIER (DPF.DOSID)
          AND DPF.DPFFLAGRETENUE = 1
          and PFSORDRE = Nordre;
          END IF ;
        ELSE
                SELECT 
          PFSNBPERIODE INTO nResult
          FROM PFISIMULATION PFS , DPRPROPFINANCE DPF 
          where  DPF.PFIID = nPFIID  AND PFSPREMIERLOYERPCT=  nAvance 
          AND PFS.PFIID = DPF.PFIID 
          AND DPF.DPRVERSION =F_DERNIEREVERSIONDOSSIER (DPF.DOSID)
          AND DPF.DPFFLAGRETENUE = 1
          and PFSORDRE = Nordre;
        END IF;

        RETURN nResult;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END F_GET_DUREE_SIMULATION;
END PAV4_JASPER_FO;
