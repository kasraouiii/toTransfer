
---EXTSGMAFOT-103

-----bouton add module acteur 
----- LKCKEGRE
Insert into LKCKEGRE (CKEID,GRECODE,EGRFLAGHIDDEN,EGRFLAGMANDATORY,EGRFLAGDISABLED,EGRFLAGCOLLAPSED,EGRMASKCODE) 
values ('1884','frmListeActeur.tblActeurList.btnNew','1','0','0','0',null);



----bouton ajout adresss

Insert into LKCKEGRE (CKEID,GRECODE,EGRFLAGHIDDEN,EGRFLAGMANDATORY,EGRFLAGDISABLED,EGRFLAGCOLLAPSED,EGRMASKCODE) 
values ('1884','frmActeurDetail.acteurDetailBody.pnlGrp.rootSectionContainer.secAddresses.secActAdr.tblAdresse.btnNew','1','0','0','0',null);

---bouton ajout rib 

Insert into LKCKEGRE (CKEID,GRECODE,EGRFLAGHIDDEN,EGRFLAGMANDATORY,EGRFLAGDISABLED,EGRFLAGCOLLAPSED,EGRMASKCODE) 
values ('1884','frmActeurDetail.acteurDetailBody.pnlGrp.rootSectionContainer.secBankAccounts.secBankAccountsList.tblActRib.btnNew','1','0','0','0',null);


-------bouton  Ajout contact 


Insert into LKCKEGRE (CKEID,GRECODE,EGRFLAGHIDDEN,EGRFLAGMANDATORY,EGRFLAGDISABLED,EGRFLAGCOLLAPSED,EGRMASKCODE) 
values ('1884','frmActeurDetail.acteurDetailBody.pnlGrp.rootSectionContainer.secContacts.secActCorres.tblCorresp.btnNew','1','0','0','0',null);

---role


Insert into LKCKEGRE (CKEID,GRECODE,EGRFLAGHIDDEN,EGRFLAGMANDATORY,EGRFLAGDISABLED,EGRFLAGCOLLAPSED,EGRMASKCODE) 
values ('1884','frmActeurDetail.acteurDetailBody.pnlGrp.rootSectionContainer.secRole.secListRole.pnlGrpFrmActRole.tblRole.btnNew','1','0','0','0',null);

----document mngt

Insert into LKCKEGRE (CKEID,GRECODE,EGRFLAGHIDDEN,EGRFLAGMANDATORY,EGRFLAGDISABLED,EGRFLAGCOLLAPSED,EGRMASKCODE) 
values ('1884','frmActeurDetail.acteurDetailBody.pnlGrp.rootSectionContainer.secDocManagement.secDocManagementMaster.tblDocManagement.btnNew','1','0','0','0',null);


---intervenant 
Insert into LKCKEGRE (CKEID,GRECODE,EGRFLAGHIDDEN,EGRFLAGMANDATORY,EGRFLAGDISABLED,EGRFLAGCOLLAPSED,EGRMASKCODE) 
values ('1884','frmActeurDetail.acteurDetailBody.pnlGrp.rootSectionContainer.secInvolvedUsers.tblIntervenant.btnNew','1','0','0','0',null);

commit ;