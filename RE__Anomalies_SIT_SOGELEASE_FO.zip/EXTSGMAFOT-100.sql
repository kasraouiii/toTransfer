

---EXTSGMAFOT-100

delete  from filtreparamprofil   where fppnom = 'AVTPRESTATION'  and fppcode =  'ETUD' and tpgcode in ('AUT02','CBM01' ,'CBI01', 'AUT' );

delete  from filtreparamprofil   where fppnom = 'AVTPRESTATION'  and fppcode =  'FDIV' and tpgcode in ('AUT02','CBM01' ,'CBI01', 'AUT' );


commit ;