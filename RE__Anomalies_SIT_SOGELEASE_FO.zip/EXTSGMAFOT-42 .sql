----EXTSGMAFOT-42


update lkckegre   set egrflagmandatory =0 where ckeid  =1690 and 
grecode='frmActeurDetail.acteurDetailBody.pnlGrp.rootSectionContainer.secIdentite.pnlGrpTabIdentite.pnlTabIdentite1.tfdActNumRCM';



commit ;


