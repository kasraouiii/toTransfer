
---EXTSGMAFOT-140



  Insert into LKPCRRUL (PCRID,PCRORDRE,RULID,PRUDTSTART,PRUDTEND,PRUFLAGFORCING) values ('4','1','300758 ',to_date('01/01/20','DD/MM/RR'),null,null);
   ---Barème standard Sogecontact, vendors et SGMA CLIPRO : Leasing mobilier
    Insert into LKPCRRUL (PCRID,PCRORDRE,RULID,PRUDTSTART,PRUDTEND,PRUFLAGFORCING) values ('8','1','300759 ',to_date('01/01/20','DD/MM/RR'),null,null);
 -- ---Barème standard Sogecontact, vendors et SGMA CLICOM : Leasing mobilier


    Insert into LKPCRRUL (PCRID,PCRORDRE,RULID,PRUDTSTART,PRUDTEND,PRUFLAGFORCING) values ('16','1','300758 ',to_date('01/01/20','DD/MM/RR'),null,null);
   ---Barème standard Sogecontact, vendors et SGMA CLIPRO ---CBI
     Insert into LKPCRRUL (PCRID,PCRORDRE,RULID,PRUDTSTART,PRUDTEND,PRUFLAGFORCING) values ('20','1','300759 ',to_date('01/01/20','DD/MM/RR'),null,null);
   ---Barème standard Sogecontact, vendors et SGMA CLICOM ---CBI
   
   
    Insert into LKPCRRUL (PCRID,PCRORDRE,RULID,PRUDTSTART,PRUDTEND,PRUFLAGFORCING) values ('1','1','300758 ',to_date('01/01/20','DD/MM/RR'),null,null);
   ---Barème linéaire SGL CLIPRO ---CBM

   Insert into LKPCRRUL (PCRID,PCRORDRE,RULID,PRUDTSTART,PRUDTEND,PRUFLAGFORCING) values ('2','1','300758 ',to_date('01/01/20','DD/MM/RR'),null,null);
   ---BBarème linéaire avec franchise SGL CLIPRO : CBM
   
     Insert into LKPCRRUL (PCRID,PCRORDRE,RULID,PRUDTSTART,PRUDTEND,PRUFLAGFORCING) values ('3','1','300758 ',to_date('01/01/20','DD/MM/RR'),null,null);
   ---Barème dégressif /Progressif SGL CLIPRO : CBM
   
       Insert into LKPCRRUL (PCRID,PCRORDRE,RULID,PRUDTSTART,PRUDTEND,PRUFLAGFORCING) values ('5','1','300759 ',to_date('01/01/20','DD/MM/RR'),null,null);
   ---Barème linéaire SGL CLICOM : Leasing mobilier

   Insert into LKPCRRUL (PCRID,PCRORDRE,RULID,PRUDTSTART,PRUDTEND,PRUFLAGFORCING) values ('6','1','300759 ',to_date('01/01/20','DD/MM/RR'),null,null);
   ---Barème linéaire avec franchise SGL CLICOM : Leasing mobilier
   
     Insert into LKPCRRUL (PCRID,PCRORDRE,RULID,PRUDTSTART,PRUDTEND,PRUFLAGFORCING) values ('7','1','300759 ',to_date('01/01/20','DD/MM/RR'),null,null);
   ---Barème  dégressif /Progressif SGL CLICOM : Leasing mobilier 
    Insert into LKPCRRUL (PCRID,PCRORDRE,RULID,PRUDTSTART,PRUDTEND,PRUFLAGFORCING) values ('9','1','300758 ',to_date('01/01/20','DD/MM/RR'),null,null);
   ---Barème standard SGL CLIPRO : Leasing mobilier
   
   Insert into LKPCRRUL (PCRID,PCRORDRE,RULID,PRUDTSTART,PRUDTEND,PRUFLAGFORCING) values ('11','1','300759 ',to_date('01/01/20','DD/MM/RR'),null,null);
   ---Barème standard SGL CLICOM : Leasing mobilier
   
     Insert into LKPCRRUL (PCRID,PCRORDRE,RULID,PRUDTSTART,PRUDTEND,PRUFLAGFORCING) values ('10','1','300758 ',to_date('01/01/20','DD/MM/RR'),null,null);
   ---Barème standard SGMA CLIPRO : Leasing mobilier

   Insert into LKPCRRUL (PCRID,PCRORDRE,RULID,PRUDTSTART,PRUDTEND,PRUFLAGFORCING) values ('12','1','300759 ',to_date('01/01/20','DD/MM/RR'),null,null);
   ---Barème standard SGMA CLICOM : Leasing mobilier
   
   
      Insert into LKPCRRUL (PCRID,PCRORDRE,RULID,PRUDTSTART,PRUDTEND,PRUFLAGFORCING) values ('14','1','300758 ',to_date('01/01/20','DD/MM/RR'),null,null);
   ---Barème linéaire avec franchise SGL CLIPRO : Leasing immobilier

   Insert into LKPCRRUL (PCRID,PCRORDRE,RULID,PRUDTSTART,PRUDTEND,PRUFLAGFORCING) values ('18','1','300759 ',to_date('01/01/20','DD/MM/RR'),null,null);
   ---Barème linéaire avec franchise SGL CLICOM : Leasing immobilier
   
   Insert into LKPCRRUL (PCRID,PCRORDRE,RULID,PRUDTSTART,PRUDTEND,PRUFLAGFORCING) values ('19','1','300759 ',to_date('01/01/20','DD/MM/RR'),null,null);
   
   
  
	
	delete from lkpcrrul  where  pcrid =1  and rulid =300758;
	delete from lkpcrrul  where  pcrid =2  and rulid =300758;
	delete from lkpcrrul  where  pcrid =3  and rulid =300758;



	delete from lkpcrrul  where  pcrid =5  and rulid =300759;
	delete from lkpcrrul  where  pcrid =6  and rulid =300759;
	delete from lkpcrrul  where  pcrid =7  and rulid =300759;
   
   
	delete from lkpcrrul  where  pcrid =9  and rulid =300758;
	delete from lkpcrrul  where  pcrid =11  and rulid =300759;
	
	delete from lkpcrrul  where  pcrid =18  and rulid =300759;
	delete from lkpcrrul  where  pcrid =19  and rulid =300759;
    delete  from lkpcrrul where pcrid =14 and rulid =300758 ;
	
commit ;

