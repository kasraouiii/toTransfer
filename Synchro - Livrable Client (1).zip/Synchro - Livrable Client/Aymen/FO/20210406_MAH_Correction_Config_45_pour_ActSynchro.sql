---- Date valitié carte d'identité : aligner CCHVALUECODE entre 4.0 et 4.5 qui étaient différents
UPDATE customcharacteristic@sgm_link SET CCHVALUECODE = 'TFDCCHVAL65' where cchsid = 'TFDCCHSID65';
COMMIT;