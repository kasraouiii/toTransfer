SET SERVEROUTPUT ON SIZE 900000;
/
BEGIN
    DECLARE
            
        -- Set a strong plain text password to the following variable before executing this script.
        SNEWBATCHPASSWORD VARCHAR2(100) := '<ENTER_STRONG_PASSWORD_HERE>';
    
        -- Set the user id of the technical account to the following variable before executing this script.
        SUTICODE VARCHAR2(30) := '<TECHNICAL_ACCOUNT>';
     
        -- If spring bean with id authenticationOptions is defined in customer-ext-options.xml then value of interationPwdSecurity property should be used.
        -- If above bean is present but interationPwdSecurity is not present, then the value should be -1
   
        INTERATIONPWDSECURITY NUMBER := 1000;
  
        TOPPARAM_UTIPWDALGO_NOT_FOUND EXCEPTION;
        HASHALGOINTOPPARAM VARCHAR2(20);
        
        TXTTOHASH VARCHAR2(100);
        HASHEDPWD VARCHAR2(100);
        PWDSALT VARCHAR2(100);
        RNDSALT VARCHAR2(100);
         
        CURSOR C1
        IS
            SELECT UTICODE, UTIPWDSALT, UTIPWD, UTIFLAGPASSWORD, UTIDTUPD, UTIPWDDTCHGD FROM UTILISATEUR WHERE UTICODE = SUTICODE;
    BEGIN
            
        FOR C1R IN C1
        LOOP
            -- Check if entry for UTIPWDHASHALGO is found in TOPPARAM or not
            BEGIN
                SELECT TPATEXTE INTO HASHALGOINTOPPARAM from TOPPARAM WHERE TOPTABLE = 'AUTHENTICATION' AND TPAPARAM = 'UTIPWDHASHALGO' AND UGECODE = ( SELECT UGECODE FROM UTILISATEUR WHERE UTICODE = SUTICODE );
            EXCEPTION
                WHEN OTHERS THEN
                    HASHALGOINTOPPARAM := 'SHA-256';
            END;
                 
            IF HASHALGOINTOPPARAM is null OR HASHALGOINTOPPARAM = ''  THEN
                HASHALGOINTOPPARAM := 'SHA-256';
            END IF;
            IF C1R.UTIPWDSALT IS NOT NULL THEN
                PWDSALT := UTL_RAW.CAST_TO_VARCHAR2( UTL_ENCODE.BASE64_DECODE( UTL_RAW.CAST_TO_RAW( C1R.UTIPWDSALT ) ) );
            ELSE
                SELECT DBMS_RANDOM.STRING('A',8) INTO RNDSALT from dual;
                PWDSALT := RNDSALT;
            END IF;
             
            TXTTOHASH := PWDSALT || SNEWBATCHPASSWORD || SUTICODE;
            HASHEDPWD := Lower( RAWTOHEX( DBMS_CRYPTO.HASH( UTL_RAW.CAST_TO_RAW( TXTTOHASH ) , 4) ) );
              
            FOR COUNTER IN 1..INTERATIONPWDSECURITY
            LOOP
                HASHEDPWD := Lower(RAWTOHEX( DBMS_CRYPTO.HASH( HASHEDPWD, 4 )));
            END LOOP;
            UPDATE
                UTILISATEUR
            SET
                  UTIPWD              = HASHEDPWD
                , UTIDTUPD            = SYSDATE
                , UTIPWDDTCHGD        = SYSDATE
                , UTIFLAGPASSWORD     = C1R.UTIFLAGPASSWORD
                , UTIPWDHASHALGORITHM = UPPER(TRIM(HASHALGOINTOPPARAM))
            WHERE
                UTICODE = SUTICODE ;
                 
            -- update UTIPWDSALT column with generated salt in case of SALT not present
            IF C1R.UTIPWDSALT IS NULL THEN
               UPDATE UTILISATEUR SET UTIPWDSALT = UTL_RAW.CAST_TO_VARCHAR2( UTL_ENCODE.BASE64_ENCODE( UTL_RAW.CAST_TO_RAW( PWDSALT ) ) ) WHERE UTICODE = C1R.UTICODE;
            END IF;
     
        END LOOP;
         
    COMMIT;
        
    EXCEPTION
        WHEN TOPPARAM_UTIPWDALGO_NOT_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('TOPPARAM entry for UTIPWDHASHALGO is not found');
        WHEN OTHERS THEN
            ROLLBACK;
    END;    
END;
/