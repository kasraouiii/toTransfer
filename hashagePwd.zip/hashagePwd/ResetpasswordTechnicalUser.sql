SET SERVEROUTPUT ON SIZE 900000;
/
BEGIN
    DECLARE
           
        -- Set a strong plain text password to the following variable before executing this script.
        SNEWBATCHPASSWORD VARCHAR2(100) := '<ENTER_STRONG_PASSWORD_HERE>';
   
        -- Set the user id of the technical account to the following variable before executing this script.
        SUTICODE VARCHAR2(30) := '<ORFI>';
   
        -- Set value of salt used during hashing of password of technical account. If set to blank then new password will be hashed without salt and null will be set in database correcponding to column UTIPWDSALT. Value of SUTIPWDSALT  must be 8 character long
        SUTIPWDSALT VARCHAR2(8) := '<SALT_USED_IN_HASHING_OF_TECHNICAL_ACCOUNT>';
 
        -- If spring bean with id authenticationOptions is defined in customer-ext-options.xml then value of interationPwdSecurity property should be used.
        -- If above bean is present but interationPwdSecurity is not present, then the value should be -1
  
        INTERATIONPWDSECURITY NUMBER := 1000;
 
        TOPPARAM_UTIPWDALGO_NOT_FOUND EXCEPTION;
        HASHALGOINTOPPARAM VARCHAR2(20);
       
        TXTTOHASH VARCHAR2(100);
        HASHEDPWD VARCHAR2(100);
        PWDSALT VARCHAR2(100);
    BEGIN
           
        -- Check if entry for UTIPWDHASHALGO is found in TOPPARAM or not
        SELECT max(TPATEXTE) INTO HASHALGOINTOPPARAM from TOPPARAM WHERE TOPTABLE = 'AUTHENTICATION' AND TPAPARAM = 'UTIPWDHASHALGO';
           
        IF(HASHALGOINTOPPARAM IS NULL) THEN
            RAISE TOPPARAM_UTIPWDALGO_NOT_FOUND;
        END IF;
         
        TXTTOHASH := SUTIPWDSALT || SNEWBATCHPASSWORD || SUTICODE;
        HASHEDPWD := Lower( RAWTOHEX( DBMS_CRYPTO.HASH( UTL_RAW.CAST_TO_RAW( TXTTOHASH ) , 4) ) );
        IF  SUTIPWDSALT IS NOT NULL THEN   
            PWDSALT := UTL_RAW.CAST_TO_VARCHAR2( UTL_ENCODE.BASE64_ENCODE( UTL_RAW.CAST_TO_RAW( SUTIPWDSALT )));
        ELSE
            PWDSALT := NULL;
        END IF;
         
        FOR COUNTER IN 1..INTERATIONPWDSECURITY
        LOOP
            HASHEDPWD := Lower(RAWTOHEX( DBMS_CRYPTO.HASH( HASHEDPWD, 4 )));
        END LOOP;
        UPDATE
            UTILISATEUR
        SET
              UTIPWD              = HASHEDPWD
            , UTIDTUPD            = SYSDATE
            , UTIPWDDTCHGD        = SYSDATE
            , UTIFLAGPASSWORD     = 0
            , UTIPWDSALT          = PWDSALT
            , UTIPWDHASHALGORITHM = UPPER(TRIM(HASHALGOINTOPPARAM))
        WHERE
            UTICODE = SUTICODE ; 
    COMMIT;
       
    EXCEPTION
        WHEN TOPPARAM_UTIPWDALGO_NOT_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('TOPPARAM entry for UTIPWDHASHALGO is not found');
        WHEN OTHERS THEN
            ROLLBACK;
    END;     
END;
/