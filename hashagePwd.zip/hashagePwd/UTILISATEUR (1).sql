-- Ajout colonne UTIPWDHASHALGORITHM dans table utilisateur
BEGIN
	    EXECUTE IMMEDIATE 'ALTER TABLE UTILISATEUR ADD UTIPWDHASHALGORITHM VARCHAR2(15 CHAR)';
	    EXECUTE IMMEDIATE 'COMMENT ON COLUMN UTILISATEUR.UTIPWDHASHALGORITHM IS ''The code of the hashing algorithm using which the user''s password is currently hashed''';
EXCEPTION
	    WHEN OTHERS THEN
	        NULL;
END;
