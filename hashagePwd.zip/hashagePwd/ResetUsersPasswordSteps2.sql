SET SERVEROUTPUT ON SIZE 900000;
/
BEGIN
    DECLARE
        TOPPARAM_UTIPWDALGO_NOT_FOUND EXCEPTION;
        HASHALGOINTOPPARAM VARCHAR2(20);
        RNDPWD VARCHAR2(10);
        HASHEDPWD VARCHAR2(100);
        PWDSALT VARCHAR2(100);
        UTIPWDSALT VARCHAR2(100);
        TXTTOHASH VARCHAR2(100);
        INTERATIONPWDSECURITY NUMBER;
        UTIDTUPD VARCHAR2(100);
        UTIPWDDTCHGD VARCHAR2(100);
        RNDSALT VARCHAR2(8);
            
        -- Fetch all UTICODE from UTILISATEUR whose password has to be updated
        CURSOR C1
        IS
            SELECT UTICODE, UTIPWDSALT, UTIPWD, UTIFLAGPASSWORD, UTIDTUPD, UTIPWDDTCHGD FROM UTILISATEUR;
        
    BEGIN
           
        -- If spring bean with id authenticationOptions is defined in customer-ext-options.xml then value of interationPwdSecurity property should be used.
        -- If above bean is present but interationPwdSecurity is not present, then the value should be 0
    
        INTERATIONPWDSECURITY := 1000;
           
            
        -- Create update script with old data to rollback in case of any issue
        DBMS_OUTPUT.PUT_LINE('==================================================================================');   
        DBMS_OUTPUT.PUT_LINE('UPDATE SCRIPTS TO ROLLBACK IN CASE OF ISSUE');   
        DBMS_OUTPUT.PUT_LINE('==================================================================================');   
        DBMS_OUTPUT.NEW_LINE();
        DBMS_OUTPUT.PUT_LINE('UPDATE TOPPARAM SET TPATEXTE = ''MD5'' WHERE TOPTABLE = ''AUTHENTICATION'' AND TPAPARAM = ''UTIPWDHASHALGO'';');
        FOR C2R IN C1
        LOOP
               
            IF C2R.UTIPWDSALT IS NULL THEN
                UTIPWDSALT := ', UTIPWDSALT = NULL';
            ELSE
                UTIPWDSALT := ', UTIPWDSALT = ''' || C2R.UTIPWDSALT || '''';
            END IF;
               
            IF C2R.UTIDTUPD IS NULL THEN
                UTIDTUPD := 'NULL';
            ELSE
                UTIDTUPD := 'TO_DATE(''' || C2R.UTIDTUPD || ''', ''dd-MON-yy'')';
            END IF;
            IF C2R.UTIPWDDTCHGD IS NULL THEN
                UTIPWDDTCHGD := 'NULL';
            ELSE
                UTIPWDDTCHGD := 'TO_DATE(''' || C2R.UTIPWDDTCHGD || ''', ''dd-MON-yy'')';
            END IF;
            DBMS_OUTPUT.PUT_LINE('UPDATE UTILISATEUR SET UTIPWD = '''|| C2R.UTIPWD ||''', UTIDTUPD = ' || UTIDTUPD || ', UTIPWDDTCHGD = ' || UTIPWDDTCHGD || ', UTIFLAGPASSWORD = ' || C2R.UTIFLAGPASSWORD || UTIPWDSALT || ' WHERE UTICODE = ''' || C2R.UTICODE || ''';');
        END LOOP;
        DBMS_OUTPUT.PUT_LINE('==================================================================================');   
           
        DBMS_OUTPUT.NEW_LINE(); 
        DBMS_OUTPUT.NEW_LINE();
        DBMS_OUTPUT.PUT_LINE('==================================================================================');   
        DBMS_OUTPUT.PUT_LINE('UPDATED PASSWORD HASHED WITH SHA-256 CORRESPONDING TO USERNAME ( UTICODE )');   
        DBMS_OUTPUT.PUT_LINE('==================================================================================');   
        DBMS_OUTPUT.NEW_LINE();
                   
        -- Loop on all UTICODE fetched from UTILISATEUR table and update the password with a randomly generated string of length 10 chanacters.
        FOR C1R IN C1
        LOOP
            -- Check if entry for UTIPWDHASHALGO is found in TOPPARAM or not
            BEGIN
                SELECT TPATEXTE INTO HASHALGOINTOPPARAM from TOPPARAM WHERE TOPTABLE = 'AUTHENTICATION' AND TPAPARAM = 'UTIPWDHASHALGO' AND UGECODE = ( SELECT UGECODE FROM UTILISATEUR WHERE UTICODE = C1R.UTICODE );
            EXCEPTION
                WHEN OTHERS THEN
                    HASHALGOINTOPPARAM := 'SHA-256';
            END;
                 
            IF HASHALGOINTOPPARAM is null OR HASHALGOINTOPPARAM = ''  THEN
                HASHALGOINTOPPARAM := 'SHA-256';
            END IF;
            IF C1R.UTIPWDSALT IS NOT NULL THEN
                PWDSALT := UTL_RAW.CAST_TO_VARCHAR2( UTL_ENCODE.BASE64_DECODE( UTL_RAW.CAST_TO_RAW( C1R.UTIPWDSALT ) ) );
            ELSE
                SELECT DBMS_RANDOM.STRING('A',8) INTO RNDSALT from dual;
                PWDSALT := RNDSALT;
            END IF;
               
            TXTTOHASH := PWDSALT || C1R.UTICODE || C1R.UTICODE;
            HASHEDPWD := Lower( RAWTOHEX( DBMS_CRYPTO.HASH( UTL_RAW.CAST_TO_RAW( TXTTOHASH ) , 4) ) );
               
            FOR COUNTER IN 1..INTERATIONPWDSECURITY
            LOOP
                HASHEDPWD := Lower(RAWTOHEX( DBMS_CRYPTO.HASH( HASHEDPWD, 4 )));
            END LOOP;
               
            UPDATE
                  UTILISATEUR
            SET
                  UTIPWD              = HASHEDPWD
                , UTIDTUPD            = SYSDATE
                , UTIPWDDTCHGD        = SYSDATE
                , UTIFLAGPASSWORD     = C1R.UTIFLAGPASSWORD
                , UTIPWDHASHALGORITHM = UPPER(TRIM(HASHALGOINTOPPARAM))
            WHERE
                  UTICODE = C1R.UTICODE;
               
            -- update UTIPWDSALT column with generated salt in case of SALT not present
            IF C1R.UTIPWDSALT IS NULL THEN
               UPDATE UTILISATEUR SET UTIPWDSALT = UTL_RAW.CAST_TO_VARCHAR2( UTL_ENCODE.BASE64_ENCODE( UTL_RAW.CAST_TO_RAW( PWDSALT ) ) ) WHERE UTICODE = C1R.UTICODE;
            END IF;
               
            DBMS_OUTPUT.PUT_LINE(C1R.UTICODE || ' - ' || C1R.UTICODE);   
        END LOOP;
        DBMS_OUTPUT.PUT_LINE('==================================================================================');   
            
    COMMIT;
        
    EXCEPTION
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('Error executing script. Error code - ' || SQLERRM);
            ROLLBACK;
    END;    
END;
/