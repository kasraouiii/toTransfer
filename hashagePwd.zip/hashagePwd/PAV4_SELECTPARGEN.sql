CREATE OR REPLACE PACKAGE TRSGM45.PAV4_SELECTPARGEN
AS
    TYPE T_CURSOR IS REF CURSOR;

    PROCEDURE S_LISTE_UTITSM_DEPT (SUTICODE           UTITSM.UTICODE%TYPE,
                                   PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_CONTACT_PERSON (NACTID IN NUMBER, PC_RETURN IN OUT T_CURSOR);

    PROCEDURE S_CONTACT_TYPE (NACTID IN NUMBER, PC_RETURN IN OUT T_CURSOR);

    PROCEDURE S_ROLE_TYPE (NACTID      IN     NUMBER,
                           SLANCODE    IN     VARCHAR2,
                           PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_GRADE (PC_RETURN IN OUT T_CURSOR);

    PROCEDURE S_GRADE_DEPT (SDEPTCODE IN VARCHAR2, PC_RETURN IN OUT T_CURSOR);

    PROCEDURE S_GRADE_DEPT_DATE (
        SDEPTCODE     IN     VARCHAR2,
        DDGRDTSTART          DPTGRADE.DGRDTSTART%TYPE,
        PC_RETURN     IN OUT T_CURSOR);

    PROCEDURE S_GRADE_DATE (DDGRDTSTART          DPTGRADE.DGRDTSTART%TYPE,
                            PC_RETURN     IN OUT T_CURSOR);

    PROCEDURE S_GRADEHISTORY (SDGRCODE    IN     DPTGRADE.DGRCODE%TYPE,
                              PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_CMBTSMSECTGESTION (SLANGUE     IN     VARCHAR2,
                                   PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_CMBPOSITION (SDEPTCODE   IN     VARCHAR2,
                             PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_COLPOSITION (PC_RETURN IN OUT T_CURSOR);

    PROCEDURE S_DEPARTMENT (PC_RETURN IN OUT T_CURSOR);

    PROCEDURE S_LANDEPARTMENT (SDPTCODE    IN     LANDEPARTMENT.DPTCODE%TYPE,
                               SLANCODE    IN     LANDEPARTMENT.LANCODE%TYPE,
                               PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_APPROVALLINE_RULE (
        SRULTARGET   IN     RULE.RULTARGET%TYPE,
        SLANCODE     IN     VARCHAR2,
        SUTICODE     IN     RULPREFERENCE.UTICODE%TYPE,
        PC_RETURN    IN OUT T_CURSOR);

    PROCEDURE S_APPROVALSTEP_RULE_ASSIGNED (
        SALICODE    IN     LKASTRUL.ALICODE%TYPE,
        SASTORDER   IN     LKASTRUL.ASTORDER%TYPE,
        SLANCODE    IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_APPROVALSTEP_RULE (
        SALICODE     IN     LKASTRUL.ALICODE%TYPE,
        SASTORDER    IN     LKASTRUL.ASTORDER%TYPE,
        SRULTARGET   IN     RULE.RULTARGET%TYPE,
        SLANCODE     IN     VARCHAR2,
        SUTICODE     IN     RULPREFERENCE.UTICODE%TYPE,
        PC_RETURN    IN OUT T_CURSOR);

    PROCEDURE S_APPROVALLINE_TARGET (   -- sTtrnom IN LANTTRPARAM.TTRNOM%TYPE,
                                     SLANCODE    IN     VARCHAR2,
                                     PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_APPROVALLINE_TARGET_RULE (
        SALICODE    IN     LKALIRUL.ALICODE%TYPE,
        SLANCODE    IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_APPROVALLINE_RULE_ASSIGNED (
        SALICODE    IN     LKALIRUL.ALICODE%TYPE,
        SLANCODE    IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_APPROVALLINE_CODE (NRULID      IN     RULE.RULID%TYPE,
                                   PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_TASK (SLANCODE IN VARCHAR2, PC_RETURN IN OUT T_CURSOR);

    PROCEDURE GET_PAYTEL (NPAYCODE   IN     PAYS.PAYCODE%TYPE,
                          NPAYTEL       OUT PAYS.PAYTEL%TYPE);

    FUNCTION GET_UTICODELINKED (
        SUTICODE           UTIUSERLINK.UTICODE%TYPE,
        STSMSECTGESTION    UTIUSERLINK.ULISECTGEST%TYPE,
        STSMMETIER         UTIUSERLINK.ULIMETIER%TYPE)
        RETURN VARCHAR2;

    FUNCTION F_CALCULATE_NO_GUARANTEE_RV (NDOSID DOSSIER.DOSID%TYPE)
        RETURN NUMBER;

    FUNCTION F_CALCULATE_NO_GUARANTEE (NDOSID     DOSSIER.DOSID%TYPE,
                                       SFILTER    VARCHAR2)
        RETURN NUMBER;

    FUNCTION GET_UTIEXTERNALREFERENCE (SUTICODE UTIUSERLINK.UTICODE%TYPE)
        RETURN VARCHAR2;

    PROCEDURE S_CROLIGAFFECTATION_COUNT (
        NACTID              CROLIGAFFECTATION.ACTID%TYPE,
        SCJOCOMPTA          CROLIGAFFECTATION.CJOCOMPTA%TYPE,
        STCRCODE            CROLIGAFFECTATION.TCRCODE%TYPE,
        NTCLORDRE           CROLIGAFFECTATION.TCLORDRE%TYPE,
        NCLIORDRE           CROLIGAFFECTATION.CLIORDRE%TYPE,
        NCOUNT       IN OUT NUMBER);

    PROCEDURE S_ACCEVGRP_TBLDROITGRP (SGROUPE     IN     VARCHAR2,
                                      SMODULE     IN     VARCHAR2,
                                      SLANGUE     IN     VARCHAR2,
                                      SLIBELLE    IN     VARCHAR2,
                                      PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_RUBRIQUE (SFILTRE            RUBACCES.RACACCES%TYPE,
                          SUGECODE           RUBRIQUE.UGECODE%TYPE,
                          SLANGUE            LANGUE.LANCODE%TYPE,
                          PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_RUBRIQUE (sLangue            LANGUE.LANCODE%TYPE,
                          nRubId             RUBRIQUE.RUBID%TYPE,
                          PC_Return   IN OUT T_CURSOR);

    PROCEDURE D_GROUPACCESS (
        STMFFONCTION          LKGROTMFDROIT.TMFFONCTION%TYPE,
        STMOMODULE            LKGROTMFDROIT.TMOMODULE%TYPE,
        SGROCODE              LKGROTMFDROIT.GROCODE%TYPE,
        NRETURNCODE    IN OUT NUMBER);

    PROCEDURE U_GROUPACCESS (
        SGFDMODIFIER           LKGROTMFDROIT.GFDMODIFIER%TYPE,
        SGFDSUPPRIMER          LKGROTMFDROIT.GFDSUPPRIMER%TYPE,
        STMFFONCTION           LKGROTMFDROIT.TMFFONCTION%TYPE,
        STMOMODULE             LKGROTMFDROIT.TMOMODULE%TYPE,
        SGROCODE               LKGROTMFDROIT.GROCODE%TYPE,
        NRETURNCODE     IN OUT NUMBER);

    PROCEDURE S_RUBACCES (NRUBID             RUBACCES.RUBID%TYPE,
                          SLANGUE            LANGUE.LANCODE%TYPE,
                          PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_CMBSECCRE_UNITEGESTION (PC_RETURN IN OUT T_CURSOR);

    PROCEDURE S_TMOYENPMT (SLANGUE IN VARCHAR2, PC_RETURN IN OUT T_CURSOR);

    -- for internal Tables Screen
    PROCEDURE S_PARAMORFI_TABLELIST (
        SNAME              LANTTRAITEMENT.TTRLIBELLE%TYPE,
        SCODE              LANTTRAITEMENT.TTRNOM%TYPE,
        SLANCODE           LANGUE.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_PARAMORFI_TABLELCONTENT (
        SNAME              LANTTRPARAM.TTPLIBELLE%TYPE,
        SCODE              LANTTRPARAM.TTPCODE%TYPE,
        STTRNOM     IN     LANTTRPARAM.TTRNOM%TYPE,
        SLANCODE    IN     LANGUE.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR);

    -- for external Tables screen
    PROCEDURE S_PARAMUSER_TABLELIST (
        SLANCODE           LANGUE.LANCODE%TYPE,
        SNAME              TUSER.TUSNOM%TYPE,
        SCODE              LANTUSER.TUSLIBELLE%TYPE,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_PARAMUSER_TABLELCONTENT (
        STUSNOM     IN     TUSPARAM.TUSNOM%TYPE,
        SLANCODE    IN     LANGUE.LANCODE%TYPE,
        SCODE       IN     TUSPARAM.TUPCODE%TYPE,
        SNAME       IN     LANTUSPARAM.TUPLIBELLE%TYPE,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_SELTBLPROFIL (
        STACCODE                  TPROFILGESTION.TACCODE%TYPE,
        STPGCODEPARENT            TPROFILGESTION.TPGCODEPARENT%TYPE,
        STPGFLAGFACILITY          TPROFILGESTION.TPGFLAGFACILITY%TYPE,
        SLANGUE                   LANGUE.LANCODE%TYPE,
        PC_RETURN          IN OUT T_CURSOR);

    PROCEDURE S_ROLDEL_COLROLCODEEXTERNE (SLANGUE     IN     VARCHAR2,
                                          PC_RETURN   IN OUT T_CURSOR);

    -- Company Options
    PROCEDURE S_TOPTIONSOCIETE (
        STOSCODE           TOPTIONSOCIETE.TOSCODE%TYPE,
        SLANGUE     IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_AGEOPTION (NACTID             AGEOPTION.ACTID%TYPE,
                           SLANGUE     IN     VARCHAR2,
                           PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_TOPTIONSOCIETERECORD (SLANGUE     IN     VARCHAR2,
                                      PC_RETURN   IN OUT T_CURSOR);

    -- Policy TYPEs
    PROCEDURE S_PASSTYPEPOLICE (SUGECODE           UNITEGESTION.UGECODE%TYPE,
                                SLANGUE     IN     VARCHAR2,
                                PC_RETURN   IN OUT T_CURSOR);

    -- Deliquency
    PROCEDURE S_GETGRECODES (SGLANGUE           LANPHASE.LANCODE%TYPE,
                             PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_IMPAYE (NACTID             IMPAYE.ACTID%TYPE,
                        SLANGUE     IN     VARCHAR2,
                        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_SELCOUNT (STPGCODE             LKTTPTACTPG.TPGCODE%TYPE,
                          STACCODE             LKTTPTACTPG.TACCODE%TYPE,
                          NRETURNCODE   IN OUT NUMBER);

    PROCEDURE S_ACCEVUSER_TBLDROITUSER (SWUSER      IN     VARCHAR2,
                                        SWUGRP      IN     VARCHAR2,
                                        SWMODULE    IN     VARCHAR2,
                                        SGLANGUE    IN     VARCHAR2,
                                        NWSTE       IN     NUMBER,
                                        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_ACCEVUSER_TBLDROITUSER_STE (SWUSER      IN     VARCHAR2, --User code
                                            SWUGRP      IN     VARCHAR2,
                                            SWMODULE    IN     VARCHAR2, --module code
                                            SGLANGUE    IN     VARCHAR2, --lancode
                                            PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_TSECTEURMETIER (
        SCODESECTGESTION          TSECTEURMETIER.TSMSECTGESTION%TYPE,
        SLANGUE            IN     VARCHAR2,
        PC_RETURN          IN OUT T_CURSOR);

    PROCEDURE S_TMPATTRIBUTE (STMPCODE           TMPATTRIBUTE.TMPCODE%TYPE,
                              SLANGUE     IN     VARCHAR2,
                              PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_ROLDELEGATION (SROLCODE    IN     ROLDELEGATION.ROLCODE%TYPE,
                               PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_ROLE (SROLCODE    IN     ROLE.ROLCODE%TYPE,
                      PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_TMODULE (STMOMODULE   IN     TMODULE.TMOMODULE%TYPE,
                         SLANGUE      IN     LANTMODULE.LANCODE%TYPE,
                         PC_RETURN    IN OUT T_CURSOR);

    PROCEDURE S_TMOFONCTION (STMOMODULE   IN     TMOFONCTION.TMOMODULE%TYPE,
                             SLANGUE      IN     LANTMOFONCTION.LANCODE%TYPE,
                             PC_RETURN    IN OUT T_CURSOR);

    PROCEDURE S_REJETMOTIF (SPAYCODE           REJETMOTIF.PAYCODE%TYPE,
                            SUGECODE           REJETMOTIF.UGECODE%TYPE,
                            SLANGUE            LANREJETMOTIF.LANCODE%TYPE,
                            PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_TRELANCE (                    --sgLangue  LANGUE.LANCODE%TYPE,
                          SLANGUE IN VARCHAR2, PC_RETURN IN OUT T_CURSOR);

    PROCEDURE S_UTILISATEUR (SUTICODE    IN     UTILISATEUR.UTICODE%TYPE,
                             PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_UTICOORDONNEE (SUTICODE    IN     UTICOORDONNEE.UTICODE%TYPE,
                               PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_UTITSM_ONLY (SUTICODE    IN     UTITSM.UTICODE%TYPE,
                             PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_LBPARAMETERS (STOPTABLE          LANTOPPARAM.TOPTABLE%TYPE,
                              SUGECODE    IN     VARCHAR2,
                              SLANGUE     IN     VARCHAR2,
                              PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_ADDITIONALINFO (STOPTABLE          LANTOPPARAM.TOPTABLE%TYPE,
                                STPAPARAM          LANTOPPARAM.TPAPARAM%TYPE,
                                SUGECODE    IN     VARCHAR2,
                                SLANGUE     IN     VARCHAR2,
                                PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_ADDITIONALINFOPOLULATE (
        STOPTABLE          TOPPARAM.TOPTABLE%TYPE,
        STPAPARAM          TOPPARAM.TPAPARAM%TYPE,
        SUGECODE    IN     VARCHAR2,
        SLANGUE     IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR);

    -- For Prefernce on External Tables Screen
    PROCEDURE S_PREUSERPARAMORFI_ANALYTICAL (
        STUSNOM            TUSPARAM.TUSNOM%TYPE,
        STACCODE           LKTUPTACTPG.TACCODE%TYPE,
        STPGCODE           LKTUPTACTPG.TPGCODE%TYPE,
        SLANGUE            LANGUE.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_PREUSERPARAMORFI_PARAMETER (
        SLANCODE           LANGUE.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR);

    -- For Preference on Internal Tables Screen
    PROCEDURE S_PREPARAMORFI_PARAMETER (
        SLANCODE           LANGUE.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_PREPARAMORFI_VALUES (
        STTRNOM            LKTTPTACTPG.TTRNOM%TYPE,
        STACCODE           LKTTPTACTPG.TACCODE%TYPE,
        STPGCODE           LKTTPTACTPG.TPGCODE%TYPE,
        SLANGUE            LANGUE.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR);

    --- STORED PROC FOR user control paragraphs
    PROCEDURE S_TPARAGRAPHECTL (
        STPCCODE    IN     TPARAGRAPHECTL.TPCCODE%TYPE,
        STPCDEST    IN     TPARAGRAPHECTL.TPCDEST%TYPE,
        SUGECODE    IN     TPCTACCONTROLE.UGECODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_TPCTACCONTROLE (
        STPCDEST    IN     TPCTACCONTROLE.TPCDEST%TYPE,
        STPCCODE    IN     TPCTACCONTROLE.TPCCODE%TYPE,
        SUGECODE    IN     TPCTACCONTROLE.UGECODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_ROLVARIABLE (SROLCODE    IN     ROLVARIABLE.ROLCODE%TYPE,
                             --, sLangue LANROLVARIABLE.LANCODE%TYPE
                             PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_ROLVARVALEUR (SROLCODE    IN     ROLVARVALEUR.ROLCODE%TYPE,
                              SRVACODE    IN     ROLVARVALEUR.RVACODE%TYPE,
                              --, sLangue LANROLVARVALEUR.LANCODE%TYPE
                              PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_LKRVVRUL (SROLCODE    IN     ROLVARVALEUR.ROLCODE%TYPE,
                          SRVACODE    IN     ROLVARVALEUR.RVACODE%TYPE,
                          SRVVCODE    IN     ROLVARVALEUR.RVVCODE%TYPE,
                          PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_BUSTYPE_TREE (SGLANGUE    IN     VARCHAR2,
                              PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_TEVENEMENT (SMTACCODE     IN     TEVENEMENT.TACCODE%TYPE,
                            SMTMOMODULE   IN     TEVENEMENT.TMOMODULE%TYPE,
                            SMTEVDEST     IN     TEVENEMENT.TEVDEST%TYPE,
                            SLANGUE       IN     VARCHAR2,
                            PC_RETURN     IN OUT T_CURSOR);

    PROCEDURE S_TEVENEMENT (
        STMFFONCTION   IN     TEVENEMENT.TMFFONCTION%TYPE,
        SLANGUE        IN     VARCHAR2,
        PC_RETURN      IN OUT T_CURSOR);

    PROCEDURE S_LEGALCATEGORY (SCJUPAYS    IN     CATJURIDIQUE.PAYCODE%TYPE,
                               SLANGUE     IN     VARCHAR2,
                               PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_LANTAMOLOIFISC (SLANGUE            LANGUE.LANCODE%TYPE,
                                --sLangue VARCHAR2,
                                PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_TLFTRFUSAGE (STACCODE    IN     TLFTRFUSAGE.TACCODE%TYPE,
                             STRFCODE    IN     TLFTRFUSAGE.TRFCODE%TYPE,
                             PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_PREFEVENT_LSTPREFEVENTTPG (SACTPREFEVENT   IN     VARCHAR2,
                                           SUGECODE        IN     VARCHAR2,
                                           SLANGUE         IN     VARCHAR2,
                                           PC_RETURN       IN OUT T_CURSOR);

    PROCEDURE S_PREFEVENT_LSTPREFEVENTACT (SUGECODE    IN     VARCHAR2,
                                           SLANGUE     IN     VARCHAR2,
                                           PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_PREEVENT (SPHADEST                 IN     VARCHAR2,
                          SPHAPREFEVENT            IN     VARCHAR2,
                          SACTPREFEVENT            IN     VARCHAR2,
                          STPGPREFEVENT            IN     VARCHAR2,
                          SENTITEMODULEPREFEVENT   IN     VARCHAR2,
                          SLANGUE                  IN     VARCHAR2,
                          PC_RETURN                IN OUT T_CURSOR);

    PROCEDURE S_PARAMNORMEPAYS (SLANGUE     IN     VARCHAR2,
                                PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_PAYREGION (SPAYCODE    IN     PAYS.PAYCODE%TYPE,
                           SLANGUE     IN     VARCHAR2,
                           PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_STEPSHUTTLE (
        SENTITEMAITREJALPHA          PHASE.PHADEST%TYPE,
        SPHAJAL                      PHAJAL.PHACODE%TYPE,
        STPGJAL                      LKTPGTACPHAJAL.TPGCODE%TYPE,
        SACTJAL                      LKTPGTACPHAJAL.TACCODE%TYPE,
        SLANGUE               IN     VARCHAR2,
        PC_RETURN             IN OUT T_CURSOR);

    PROCEDURE S_NAF (SPAYCODE           PAYS.PAYCODE%TYPE,
                     SPAYS              PAYS.PAYCODE%TYPE,
                     SLANGUE     IN     VARCHAR2,
                     PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE EVENT_TBLREPEVENT_DESC (
        STMOMODULE          IN     LANTMOFONCTION.TMOMODULE%TYPE,
        SENTITEMATREEVENT   IN     LANTMOFONCTION.TMOMODULE%TYPE,
        SLANGUE             IN     VARCHAR2,
        PC_RETURN           IN OUT T_CURSOR);

    PROCEDURE EVENT_TBLREPEVENT_DESC (
        STMOMODULE     IN     LANTMOFONCTION.TMOMODULE%TYPE,
        STMFFONCTION   IN     LANTMOFONCTION.TMFFONCTION%TYPE,
        SLANGUE        IN     VARCHAR2,
        PC_RETURN      IN OUT T_CURSOR);

    PROCEDURE S_PHASESLIST (SPCODEDEST    IN     PHASE.PHADEST%TYPE,
                            SMTACCODE     IN     TEVENEMENT.TACCODE%TYPE,
                            SPCODEEVENT   IN     TEVENEMENT.TMFFONCTION%TYPE,
                            SLANGUE       IN     VARCHAR2,
                            PC_RETURN     IN OUT T_CURSOR);

    PROCEDURE S_BUSTYPESLIST (SLANGUE IN VARCHAR2, PC_RETURN IN OUT T_CURSOR);

    PROCEDURE S_PRODUCTLIST (
        SWACTPREFRUB   IN     TPROFILGESTION.TACCODE%TYPE,
        SLANGUE        IN     VARCHAR2,
        PC_RETURN      IN OUT T_CURSOR);

    PROCEDURE S_RELANCE (NACTID      IN     RELANCE.ACTID%TYPE,
                         STACCODE    IN     RELANCE.TACCODE%TYPE,
                         SROLCODE    IN     RELANCE.ROLCODE%TYPE,
                         PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_LKRELFOR (NACTID      IN     LKRELFOR.ACTID%TYPE,
                          SROLCODE    IN     LKRELFOR.ROLCODE%TYPE,
                          NRELORDRE   IN     LKRELFOR.RELORDRE%TYPE,
                          STACCODE    IN     LKRELFOR.TACCODE%TYPE,
                          SRELCODE    IN     LKRELFOR.RELCODE%TYPE,
                          PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_PAYREGION_TREE (SLANGUE     IN     VARCHAR2,
                                PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_PAYREGDEPT (SPAYCODE           PAYREGDEPT.PAYCODE%TYPE,
                            SPRECODE           PAYREGDEPT.PRECODE%TYPE,
                            SPRETYPE           PAYREGDEPT.PRETYPE%TYPE,
                            PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_PRODUCTSLIST (SMTACCODE   IN     TEVENEMENT.TACCODE%TYPE,
                              SLANGUE     IN     VARCHAR2,
                              PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_TAMOLOIFISC (STLFTYPE    IN     TAMOLOIFISC.TLFCODE%TYPE,
                             SLANGUE     IN     VARCHAR2,
                             PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_TREPRODETAIL (
        STRECODE        IN     TREPRODETAIL.TRECODE%TYPE,
        STATATTRIBUTE   IN     TREPRODETAIL.TATATTRIBUTE%TYPE,
        PC_RETURN       IN OUT T_CURSOR);

    PROCEDURE S_TREATTRIBUTE (STRECODE    IN     TREATTRIBUTE.TRECODE%TYPE,
                              PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_TRELATION (PC_RETURN IN OUT T_CURSOR);

    PROCEDURE S_PHACTL_TBLSTATCONTROLE (
        SUGECODE               IN     VARCHAR2,
        SWPARA                 IN     VARCHAR2,
        SWACTIV                IN     VARCHAR2,
        SWENTITEMAITREPHACTL   IN     VARCHAR2,
        SWPHACTL               IN     VARCHAR2,
        SWPROFIL               IN     VARCHAR2,
        SGLANGUE               IN     VARCHAR2,
        PC_RETURN              IN OUT T_CURSOR);

    PROCEDURE S_DLGPARAMNORME_NACE (SGLANGUE           LANGUE.LANCODE%TYPE,
                                    PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_DLGPARAMNORME_LANGUE (SGLANGUE           LANGUE.LANCODE%TYPE,
                                      PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_TUSPARAM (SGLANGUE IN VARCHAR2, PC_RETURN IN OUT T_CURSOR);

    PROCEDURE S_TTRPARAM_SINNATURE (SGLANGUE    IN     VARCHAR2,
                                    PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_TTRPARAM_RHS (STUPCODE    IN     LKTUSTTR.TUPCODE%TYPE,
                              SGLANGUE    IN     VARCHAR2,
                              PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_LKTSMFOR_TREE (NFORID      IN     LKTSMFOR.FORID%TYPE,
                               SLANGUE     IN     VARCHAR2,
                               SUSER       IN     VARCHAR2,
                               PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_BUSINESSTYPE_LHS (SLANGUE     IN     VARCHAR2,
                                  PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_BUSINESSTYPE_RHS (NACTID             ACTEUR.ACTID%TYPE,
                                  SLANGUE     IN     VARCHAR2,
                                  PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_TSECTMET_TREE (SGLANGUE    IN     VARCHAR2,
                               PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_TSECTMETIER_TREE (SGLANGUE    IN     VARCHAR2,
                                  PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_HISTOYPLANCOMPTABLE (
        NPCOID             PLANCOMPTABLE.PCOID%TYPE,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_UTITSM (
        SCODESECTGESTION          TSECTEURMETIER.TSMSECTGESTION%TYPE,
        SCODEMETIER               TSECTEURMETIER.TSMMETIER%TYPE,
        SPUGECODE                 UTILISATEUR.UGECODE%TYPE,
        PC_RETURN          IN OUT T_CURSOR);

    PROCEDURE S_GESFORMALITE (SUGECODE    IN     FORMALITE.UGECODE%TYPE,
                              STACCODE    IN     FORMALITE.TACCODE%TYPE,
                              SFORDEST    IN     FORMALITE.FORDEST%TYPE,
                              SLANCODE    IN     LANGUE.LANCODE%TYPE,
                              PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_LINKEDTASKS (SFORDEST    IN     VARCHAR2,
                             STACCODE    IN     VARCHAR2,
                             NFORID      IN     NUMBER,
                             SUGECODE    IN     VARCHAR2,
                             SLANGUE     IN     VARCHAR2,
                             PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_LINKEDSELECTEDTASKS (NFORID      IN     NUMBER,
                                     SLANGUE     IN     VARCHAR2,
                                     PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_TSECTMET_SELECTED_TREE (NFORID             LKTSMFOR.FORID%TYPE,
                                        SPUSER             UTITSM.UTICODE%TYPE,
                                        SLANGUE            LANGUE.LANCODE%TYPE,
                                        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_LVNAP_LIST (SLANGUE     IN     LANNAP.LANCODE%TYPE,
                            SPAYCODE    IN     LANNAP.PAYCODE%TYPE,
                            PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_TBLLOINAPACTIV (SACTIVITE     IN     TFUNAP.TACCODE%TYPE,
                                SNAP          IN     TFUNAP.NAPCODE%TYPE,
                                SREGIMEFISC   IN     TFUNAP.TRFCODE%TYPE,
                                SCONTEXTE     IN     TFUNAP.TUNCONTEXTE%TYPE,
                                SPAYCODE      IN     TFUNAP.PAYCODE%TYPE,
                                SLANGUE       IN     VARCHAR2,
                                PC_RETURN     IN OUT T_CURSOR);

    PROCEDURE S_SHUTTERALLOCATION (
        SWACTPREFRUB   IN     LKTPGTACRUB.TACCODE%TYPE,
        SWPROFILRUB    IN     LKTPGTACRUB.TPGCODE%TYPE,
        SLANGUE        IN     VARCHAR2,
        PC_RETURN      IN OUT T_CURSOR);

    PROCEDURE S_ASSETCLASS (SLANGUE     IN     VARCHAR2,
                            SPAYCODE    IN     VARCHAR2,
                            PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_LSTGROUP (PC_RETURN IN OUT T_CURSOR);

    PROCEDURE S_GROUP_LHS (SGLANGUE IN VARCHAR2, PC_RETURN IN OUT T_CURSOR);

    PROCEDURE S_GROUP_RHS (SWGROUPE    IN     LKGROTACAGE.GROCODE%TYPE,
                           SGLANGUE    IN     VARCHAR2,
                           PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_LKGROTACAGE_COUNT (
        SWGROUPE   IN     LKGROTACAGE.GROCODE%TYPE,
        NCOUNT     IN OUT NUMBER);

    PROCEDURE S_LANTAMOLOIFISCTABLE (
        SWACTIVITE     IN     LKAMOLOIDEFAUT.TACCODE%TYPE,
        SWREGIMEFISC   IN     LKAMOLOIDEFAUT.TRFCODE%TYPE,
        SWPAYCODE      IN     LKAMOLOIDEFAUT.PAYCODE%TYPE,
        SWPROFIL       IN     LKAMOLOIDEFAUT.TPGCODE%TYPE,
        SLANGUE        IN     VARCHAR2,
        PC_RETURN      IN OUT T_CURSOR);

    -- Pref on TASks
    PROCEDURE S_TBLFORMALITEFICHE (
        SDESTCODE               TTRPARAM.TTPCODE%TYPE,    --Combo desctination
        SPHACODE                PHASE.PHACODE%TYPE,             -- combo phASe
        SUGECODE                ACTEUR.UGECODE%TYPE,                -- ugeCode
        SWPROFIL                VARCHAR2,                 -- selected tree val
        SWRF                    FORFICHE.FFICODERF%TYPE,
        SWACTPREFFICHE          VARCHAR2, -- value keeps changing from GLOBAL, ''
        SLANGUE          IN     VARCHAR2,
        PC_RETURN        IN OUT T_CURSOR);

    -- No usage found
    /*  PROCEDURE S_JALPERSTATUPDATE(
    swEntiteMaitreJalPerStat IN DOSPHASE.PHADEST%TYPE,
    swStatCode IN DOSPHASE.PHACODE%TYPE,
    colJal IN DOSPHASE.JALCODE%TYPE,
    sLangue IN VARCHAR2,
    PC_RETURN IN OUT T_CURSOR); */
    PROCEDURE S_LKTSMFOR_COUNT (NFORID   IN     LKTSMFOR.FORID%TYPE,
                                NCOUNT   IN OUT NUMBER);

    PROCEDURE S_COMPTASOC_TREE (SGLANGUE    IN     VARCHAR2,
                                SUGECODE    IN     VARCHAR2,
                                PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_LKRELRUL (NACTID      IN     LKRELRUL.ACTID%TYPE,
                          SROLCODE    IN     LKRELRUL.ROLCODE%TYPE,
                          NRELORDRE   IN     LKRELRUL.RELORDRE%TYPE,
                          STACCODE    IN     LKRELRUL.TACCODE%TYPE,
                          SRELCODE    IN     LKRELRUL.RELCODE%TYPE,
                          PC_RETURN   IN OUT T_CURSOR);

    --================= Start Proc migrated on 05/June/2009=========
    PROCEDURE S_TCROLIGNE_TREE (STCRCODE           TCROLIGNE.TCRCODE%TYPE,
                                SGLANGUE    IN     VARCHAR2,
                                PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_REL_CMBRULE (SGLANGUE IN VARCHAR2, PC_RETURN IN OUT T_CURSOR);

    --select plancomptable
    PROCEDURE S_PLANCOMPTABLE (NACTID        IN     NUMBER,
                               SCODECOMPTA   IN     VARCHAR,
                               PC_RETURN     IN OUT T_CURSOR);

    --select CROLIGDETAIL table
    PROCEDURE S_CROLIGDETAIL (STCRCODE      IN     VARCHAR,
                              NTCLORDRE     IN     NUMBER,
                              NCLIORDRE     IN     NUMBER,
                              NACTID        IN     NUMBER,
                              SCJOCOMPTA    IN     VARCHAR,
                              SCODELANGUE   IN     VARCHAR2,
                              PC_RETURN     IN OUT T_CURSOR);

    PROCEDURE S_CROLIGNECOMPTASOC_TREE (
        NACTID              CROLIGNE.ACTID%TYPE,
        SCJOCOMPTA          CROLIGNE.CJOCOMPTA%TYPE,
        SGLANGUE     IN     VARCHAR2,
        PC_RETURN    IN OUT T_CURSOR);

    PROCEDURE S_CROLIGCONDITION (
        STCRCODE            CROLIGCONDITION.TCRCODE%TYPE,
        NTCLORDRE           CROLIGCONDITION.TCLORDRE%TYPE,
        NCLIORDRE           CROLIGCONDITION.CLIORDRE%TYPE,
        NACTID              CROLIGCONDITION.ACTID%TYPE,
        SCJOCOMPTA          CROLIGCONDITION.CJOCOMPTA%TYPE,
        PC_RETURN    IN OUT T_CURSOR);

    PROCEDURE S_CROLIGCONLIGNE (
        STCRCODE            CROLIGCONLIGNE.TCRCODE%TYPE,
        NTCLORDRE           CROLIGCONLIGNE.TCLORDRE%TYPE,
        NCLIORDRE           CROLIGCONLIGNE.CLIORDRE%TYPE,
        NACTID              CROLIGCONLIGNE.ACTID%TYPE,
        SCJOCOMPTA          CROLIGCONLIGNE.CJOCOMPTA%TYPE,
        SCLCID              CROLIGCONLIGNE.CLCID%TYPE,
        SGLANGUE     IN     VARCHAR2,
        PC_RETURN    IN OUT T_CURSOR);

    PROCEDURE S_ACCOUNTSEARCHCRO (
        NACTID              CROJOURNAL.ACTID%TYPE,
        SCJOCOMPTA          CROJOURNAL.CJOCOMPTA%TYPE,
        SLANGUE      IN     VARCHAR2,
        PC_RETURN    IN OUT T_CURSOR);

    PROCEDURE S_LKTCRAGETAC (NACTID             LKTCRAGETAC.ACTID%TYPE,
                             SLANGUE            LANGUE.LANCODE%TYPE,
                             PC_RETURN   IN OUT T_CURSOR);

    -- OR GL LIne Table Population
    PROCEDURE S_TBLCROLIGNE (STCRCODE     IN     CROLIGNE.TCRCODE%TYPE,
                             NTCLORDRE    IN     CROLIGNE.TCLORDRE%TYPE,
                             NACTID       IN     CROLIGNE.ACTID%TYPE,
                             SCJOCOMPTA   IN     CROLIGNE.CJOCOMPTA%TYPE,
                             PC_RETURN    IN OUT T_CURSOR);

    PROCEDURE S_TBLCROLIGNE2 (STCRCODE     IN     CROLIGNE.TCRCODE%TYPE,
                              NTCLORDRE    IN     CROLIGNE.TCLORDRE%TYPE,
                              NACTID       IN     CROLIGNE.ACTID%TYPE,
                              SCJOCOMPTA   IN     CROLIGNE.CJOCOMPTA%TYPE,
                              NCLIORDRE    IN     CROLIGNE.CLIORDRE%TYPE,
                              PC_RETURN    IN OUT T_CURSOR);

    PROCEDURE S_TCRO (PC_RETURN IN OUT T_CURSOR);

    PROCEDURE S_TCROLIGNE (STCRCODE    IN     LANTCRO.TCRCODE%TYPE,
                           SLANGUE     IN     VARCHAR2,
                           PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_CRITERECRO (SLANGUE            LANGUE.LANCODE%TYPE,
                            SUGECODE           UNITEGESTION.UGECODE%TYPE,
                            PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_CCRCHAMP (SCCRCODE           CCRCHAMP.CCRCODE%TYPE,
                          SUGECODE           UNITEGESTION.UGECODE%TYPE,
                          PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_COLCRITERESEARCH (SLANGUE     IN     VARCHAR2,
                                  NROWMIN     IN     INTEGER,
                                  NROWMAX     IN     INTEGER,
                                  PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_CRITERIA_MAPPING_DETAIL ( --  sCchChamp   CCHIMPUTATION.CCHCHAMP%TYPE,
                                         --   sCcrCode    CCHIMPUTATION.CCRCODE%TYPE,
                                         --   nPcoId      PLANCOMPTABLE.PCOID%TYPE,
                                         --   nCimOrdre   CCHIMPUTATION.CIMORDRE%TYPE,
                                         --  sUgeCode    UNITEGESTION.UGECODE%TYPE,
                                         SLANGUE     IN     VARCHAR2,
                                         PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_TCROLIGDETAIL (
        STCRCODE    IN     TCROLIGDETAIL.TCRCODE%TYPE,
        NTCLORDRE   IN     TCROLIGDETAIL.TCLORDRE%TYPE,
        SLANGUE     IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_LENGTHFIELD (
        SWTCRCODE        IN     TCROLIGDETAIL.TCRCODE%TYPE,
        NWTCLORDRE       IN     TCROLIGDETAIL.TCLORDRE%TYPE,
        SWTLDCHAMP       IN     TCROLIGDETAIL.TLDCHAMP%TYPE,
        SWTLDCHAMPTYPE   IN     TCROLIGDETAIL.TLDCHAMPTYPE%TYPE,
        SLANGUE          IN     VARCHAR2,
        PC_RETURN        IN OUT T_CURSOR);

    PROCEDURE S_LONGUEUR (
        SWTCRCODE     IN     TCROLIGDETAIL.TCRCODE%TYPE,
        NWTCLORDRE    IN     TCROLIGDETAIL.TCLORDRE%TYPE,
        SPCHAMP       IN     TCROLIGDETAIL.TLDCHAMP%TYPE,
        SPCHAMPTYPE   IN     TCROLIGDETAIL.TLDCHAMPTYPE%TYPE,
        SLANGUE       IN     VARCHAR2,
        PC_RETURN     IN OUT T_CURSOR);

    PROCEDURE S_CREATIONUTILISATEURINTERDITE (SLANGUE     IN     VARCHAR2,
                                              PC_RETURN   IN OUT T_CURSOR);

    --procedure createOracleuser(usercode varchar2, pASsword varchar2, nResult IN OUT number, sResult IN OUT varchar2);
    PROCEDURE S_UNITEGESTION (SLANGUE IN VARCHAR2, PC_RETURN IN OUT T_CURSOR);

    PROCEDURE S_TBLCRONONDEVERSE (
        SUSERGROUPE          LKGROTACAGE.GROCODE%TYPE,
        SLANGUE       IN     VARCHAR2,
        PC_RETURN     IN OUT T_CURSOR);

    -- Not used
    /*PROCEDURE S_SEARCH_MANBIM
    (
    sgLangue IN VARCHAR2,
    PC_Return IN OUT T_CURSOR
    );*/
    --======================End Proc migrated on 05/June/2009=========
    PROCEDURE COUNT_L1FORMALITE (NFORID   IN     LKTSMFOR.FORID%TYPE,
                                 NVAL     IN OUT NUMBER);

    PROCEDURE EVENT_TBLREPEVENT_DESC (
        STMOMODULE          IN     LANTMOFONCTION.TMOMODULE%TYPE,
        SENTITEMATREEVENT   IN     LANTMOFONCTION.TMOMODULE%TYPE,
        STMFFONCTION        IN     LANTMOFONCTION.TMFFONCTION%TYPE,
        SMTACCODE           IN     TEVENEMENT.TACCODE%TYPE,
        SMTEVDEST           IN     TEVENEMENT.TEVDEST%TYPE,
        SLANGUE             IN     VARCHAR2,
        PC_RETURN           IN OUT T_CURSOR);

    -- Accounting postings on OR items
    PROCEDURE S_CROJOURNAL (NACTID              CROJOURNAL.ACTID%TYPE,
                            SCJOCOMPTA          CROJOURNAL.CJOCOMPTA%TYPE,
                            SLANGUE      IN     VARCHAR2,
                            PC_RETURN    IN OUT T_CURSOR);

    PROCEDURE S_CROLIGAFFECTATION (
        STCRCODE            CROLIGAFFECTATION.TCRCODE%TYPE,
        NACTID              CROLIGAFFECTATION.ACTID%TYPE,
        SCJOCOMPTA          CROLIGAFFECTATION.CJOCOMPTA%TYPE,
        PC_RETURN    IN OUT T_CURSOR);

    -- Procedure for Search Field Account
    PROCEDURE S_ACCOUNTSEARCH (NACTID              CROJOURNAL.ACTID%TYPE,
                               SCJOCOMPTA          CROJOURNAL.CJOCOMPTA%TYPE,
                               SLANGUE      IN     VARCHAR2,
                               PC_RETURN    IN OUT T_CURSOR);

    -- Account selection per generic rules
    PROCEDURE S_ELEMENT_COUNT_CRITERIA_TREE (
        SUGECODE            ACTEUR.UGECODE%TYPE,
        SCCRCODE            CCRCHAMP.CCRCODE%TYPE,
        SLANGUE      IN     VARCHAR2,
        NUM_RETURN   IN OUT NUMBER);

    PROCEDURE S_CRITERIA_RULE_TREE (
        SUGECODE           CRITERECRO.UGECODE%TYPE,
        SLANGUE     IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_CRITERIA_MAPPING_CHILD (
        SCCRCODE           CCHIMPUTATION.CCRCODE%TYPE,
        SUGECODE           CRITERECRO.UGECODE%TYPE,
        SLANGUE     IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_CRITERIA_MAPPING_DETAIL (
        SCCRCODE           CCHIMPUTATION.CCRCODE%TYPE,
        NCIMORDRE          CCHIMPUTATION.CIMORDRE%TYPE,
        SUGECODE           UNITEGESTION.UGECODE%TYPE,
        SLANGUE     IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_CREATE_DETAIL_CHILD_ROW (
        SUGECODE           CRITERECRO.UGECODE%TYPE,
        SCCRCODE           CCRCHAMP.CCRCODE%TYPE,
        SLANGUE     IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_COLCLCDTDEB (STCRCODE              CROLIGNE.TCRCODE%TYPE,
                             SCODECOMPTA           CROLIGNE.CJOCOMPTA%TYPE,
                             NTCLORDRE             CROLIGNE.TCLORDRE%TYPE,
                             NCODESOCIETE          CROLIGNE.ACTID%TYPE,
                             NCLIORDRE             CROLIGNE.CLIORDRE%TYPE,
                             PC_RETURN      IN OUT T_CURSOR);

    PROCEDURE S_COLCLCDTDEBDUMMY (
        STCRCODE              CROLIGNE.TCRCODE%TYPE,
        SCODECOMPTA           CROLIGNE.CJOCOMPTA%TYPE,
        NTCLORDRE             CROLIGNE.TCLORDRE%TYPE,
        NCODESOCIETE          CROLIGNE.ACTID%TYPE,
        NCLIORDRE             CROLIGNE.CLIORDRE%TYPE,
        PC_RETURN      IN OUT T_CURSOR);

    FUNCTION F_GETCLCID (STCRCODE        CROLIGNE.TCRCODE%TYPE,
                         SCODECOMPTA     CROLIGNE.CJOCOMPTA%TYPE,
                         NTCLORDRE       CROLIGNE.TCLORDRE%TYPE,
                         NCODESOCIETE    CROLIGNE.ACTID%TYPE,
                         NCLIORDRE       CROLIGNE.CLIORDRE%TYPE)
        RETURN NUMBER;

    PROCEDURE S_UTILISATEUR_LDAPREFERENCE (
        SUTILDAPREFERENCE   IN     UTILISATEUR.UTILDAPREFERENCE%TYPE,
        PC_RETURN           IN OUT T_CURSOR);

    PROCEDURE S_TYPELIGNEPROV (PC_RETURN IN OUT T_CURSOR);

    --select procedure for FORDESTINATION
    PROCEDURE S_FORDESTINATION (NFORID      IN     FORDESTINATION.FORID%TYPE,
                                PC_RETURN   IN OUT T_CURSOR);

    --select procedure for LKFDERUL
    PROCEDURE S_LKFDERUL (NFORID      IN     LKFDERUL.FORID%TYPE,
                          NFDEORDRE   IN     LKFDERUL.FDEORDRE%TYPE,
                          PC_RETURN   IN OUT T_CURSOR);

    --select procedure for LKFDERUL
    PROCEDURE S_RULE (STARGET     IN     RULE.RULTARGET%TYPE,
                      SLANGUE     IN     LANGUE.LANCODE%TYPE,
                      PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_LBTPGPARAMETERS (
        STOPTABLE          LANTOPTPGPARAM.TOPTABLE%TYPE,
        SLANGUE     IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_LBTPGPARAMETERSBYTPGCODE (
        STOPTABLE          LANTOPTPGPARAM.TOPTABLE%TYPE,
        SLANGUE     IN     VARCHAR2,
        STPGCODE    IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_LANTOPTPGPARAM (
        STOPTABLE          LANTOPTPGPARAM.TOPTABLE%TYPE,
        STPAPARAM          TOPTPGPARAM.TTPPARAM%TYPE,
        STPGCODE           LANTOPTPGPARAM.TPGCODE%TYPE,
        SLANGUE     IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_TOPTPGPARAM (STOPTABLE          TOPTPGPARAM.TOPTABLE%TYPE,
                             STPAPARAM          TOPTPGPARAM.TTPPARAM%TYPE,
                             STPGCODE           LANTOPTPGPARAM.TPGCODE%TYPE,
                             PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_PLANCOMPTABLE (NPCOID             PLANCOMPTABLE.PCOID%TYPE,
                               PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_CMBRULE (SLANGUE            LANRULE.LANCODE%TYPE,
                         PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_RULE_ACCOUNT (NPCOID             PLANCOMPTABLE.PCOID%TYPE,
                              PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_RULE_ROLE (SROLCODE           ROLE.ROLCODE%TYPE,
                           PC_RETURN   IN OUT T_CURSOR);

    -- CASNT-515
    PROCEDURE S_CMBRULEACTEUR (SLANGUE            LANRULE.LANCODE%TYPE,
                               PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_LIST_RULE (SDEST              RULE.RULTARGET%TYPE,
                           PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_CRITERIA_ALL (P_CRIID            CRITERIA.CRIID%TYPE, -- n'est pas utilis?? , juste pour utiliser les cashs
                              PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_CRITERIA_BY_CRIIID (P_CRIID            CRITERIA.CRIID%TYPE,
                                    PC_RETURN   IN OUT T_CURSOR);

    FUNCTION F_VERIFY_RULE (NRULID      NUMBER,
                            NNUMID      NUMBER,
                            SUTICODE    VARCHAR2,
                            SRESULTS    VARCHAR2)
        RETURN NUMBER;

    FUNCTION GET_CRITERE_FULL_VALUES (P_CRIIDFIRST      VARCHAR2,
                                      P_CRICODEFIRST    VARCHAR2,
                                      P_RESULT          VARCHAR2,
                                      NNUMID            NUMBER,
                                      SUTICODE          VARCHAR2,
                                      STEVDEST          VARCHAR2)
        RETURN VARCHAR2;

    FUNCTION GET_CRITERE_JAVA_VALUES (P_CRICODEFIRST    VARCHAR2,
                                      P_RESULT          VARCHAR2)
        RETURN VARCHAR2;

    FUNCTION SPLIT (PC$CHAINE   IN VARCHAR2,
                    PN$POS      IN PLS_INTEGER,
                    PC$SEP      IN VARCHAR2 DEFAULT '|')
        RETURN VARCHAR2;

    FUNCTION GETVALUECRITERIA (NCRIID      CRITERIA.CRIID%TYPE,
                               STARGET     RULE.RULTARGET%TYPE,
                               SUTICODE    UTILISATEUR.UTICODE%TYPE,
                               NNUMID      NUMBER)
        RETURN VARCHAR2;

    PROCEDURE S_L1FORMALITE (NFORID      IN     L1FORMALITE.FORID%TYPE,
                             PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_FORTYPEGESFORMALITE (
        SUGECODE    IN     FORMALITE.UGECODE%TYPE,
        STACCODE    IN     FORMALITE.TACCODE%TYPE,
        SFORDEST    IN     FORMALITE.FORDEST%TYPE,
        SLANCODE    IN     LANGUE.LANCODE%TYPE,
        SFORTYPE    IN     FORMALITE.FORTYPE%TYPE,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_LKTPGTACTCI (STACCODE    IN     LKTPGTACTCI.TACCODE%TYPE,
                             STAGCODE    IN     LKTPGTACTCI.TPGCODE%TYPE,
                             PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_TCALCULINTERET (SLANCODE    IN     VARCHAR2,
                                PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_UTIACTDEFAULT (SUTICODE           UTILISATEUR.UTICODE%TYPE,
                               PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_MAXLTV (P_NAPCODE          NAP.NAPCODE%TYPE,
                        PC_MAXLTV   IN OUT T_CURSOR);

    PROCEDURE S_UTITSM_ROW (SUTICODE           UTILISATEUR.UTICODE%TYPE,
                            SLANCODE           LANDEPARTMENT.LANCODE%TYPE,
                            PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_UTIUSERLINK (SUTICODE           UTILISATEUR.UTICODE%TYPE,
                             PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_UTITSMHIST (SUTICODE           UTITSM.UTICODE%TYPE,
                            PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_DPTCODE (PC_RETURN IN OUT T_CURSOR);

    PROCEDURE S_TWCCODE (SLANGUE            LANTWORKCATEGORY.LANCODE%TYPE,
                         STWCCODE           TWORKCATEGORY.TWCCODE%TYPE,
                         PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_TWCCODE_ALL (SLANGUE            LANTWORKCATEGORY.LANCODE%TYPE,
                             PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_DPTCODE_DPTTYPE (SDPTTYPE           DEPARTMENT.DPTTYPE%TYPE,
                                 PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_WORKQUEUE_COMBO (SLANGUE            LANWORKQUEUE.LANCODE%TYPE,
                                 PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_WORKQUEUE_COMBO_MGT (
        SDPTCODE           UTITSM.TSMTEAMCODE%TYPE,
        SLANGUE            LANWORKQUEUE.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_WORKQUEUE_COMBO_MGT_2 (
        SDPTCODE           UTITSM.TSMTEAMCODE%TYPE,
        SLANGUE            LANWORKQUEUE.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_WORKQUEUE_COMBO_COLLECTOR (
        SDPTCODE    IN     DEPARTMENT.DPTCODE%TYPE,
        SLANGUE            LANWORKQUEUE.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_COLLECTION_CENTER (
        SDPTTYPE    IN     DEPARTMENT.DPTTYPE%TYPE,
        SLANGUE     IN     LANDEPARTMENT.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_COLLECTION_CENTER_SITE_OFF (
        SLANGUE     IN     LANDEPARTMENT.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_MANAGEMENT_GROUP (
        SDPTTYPE      IN     DEPARTMENT.DPTTYPE%TYPE,
        SCODEPARENT   IN     DEPARTMENT.DPTCODEPARENT%TYPE,
        SLANGUE       IN     LANDEPARTMENT.LANCODE%TYPE,
        PC_RETURN     IN OUT T_CURSOR);

    PROCEDURE S_CMBRULE_CODE (SROLCODE    IN     LANROLE.ROLCODE%TYPE,
                              SLANGUE     IN     VARCHAR2,
                              PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_COMPATIBLEEVENT (
        STEVDEST       IN     TEVCOMPATIBILITY.TEVDEST%TYPE,
        STACCODE       IN     TEVCOMPATIBILITY.TACCODE%TYPE,
        STMOMODULE     IN     TEVCOMPATIBILITY.TMOMODULE%TYPE,
        STMFFONCTION   IN     TEVCOMPATIBILITY.TMFFONCTION%TYPE,
        NRETURNCODE    IN OUT NUMBER,
        PC_RETURN      IN OUT T_CURSOR);

    PROCEDURE S_COMPATIBLE_EVENTLIST (
        SLANCODE       IN     LANTEVENEMENT.LANCODE%TYPE,
        STEVDEST       IN     TEVCOMPATIBILITY.TEVDEST%TYPE,
        STACCODE       IN     TEVCOMPATIBILITY.TACCODE%TYPE,
        STMOMODULE     IN     TEVCOMPATIBILITY.TMOMODULE%TYPE,
        STMFFONCTION   IN     TEVCOMPATIBILITY.TMFFONCTION%TYPE,
        PC_RETURN      IN OUT T_CURSOR);

    PROCEDURE S_JALCODES (SUGECODE    IN     TPCTACCONTROLE.UGECODE%TYPE,
                          STPCCODE    IN     TPCTACCONTROLE.TPCCODE%TYPE,
                          STACCODE    IN     TPCTACCONTROLE.TACCODE%TYPE,
                          STPCDEST    IN     TPCTACCONTROLE.TPCDEST%TYPE,
                          SPHACODE    IN     LKPHAJALTTC.PHACODE%TYPE,
                          STPGCODE    IN     LKPHAJALTTC.TPGCODE%TYPE,
                          SPHADEST    IN     LKPHAJALTTC.PHADEST%TYPE,
                          STTCCODE    IN     LKPHAJALTTC.TTCCODE%TYPE,
                          PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_JALCODES_CONTROLSLIST (
        SUGECODE    IN     TPCTACCONTROLE.UGECODE%TYPE,
        STPCCODE    IN     TPCTACCONTROLE.TPCCODE%TYPE,
        STACCODE    IN     TPCTACCONTROLE.TACCODE%TYPE,
        STPCDEST    IN     TPCTACCONTROLE.TPCDEST%TYPE,
        SPHACODE    IN     LKPHAJALTTC.PHACODE%TYPE,
        STPGCODE    IN     LKPHAJALTTC.TPGCODE%TYPE,
        SPHADEST    IN     LKPHAJALTTC.PHADEST%TYPE,
        SLANCODE    IN     LANGUE.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_LINKEDTASKSRULES (NFORID      IN     LKFORRUL.FORID%TYPE,
                                  PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_CONFIGURATIONKEY (PC_RETURN IN OUT T_CURSOR);

    PROCEDURE S_EXPORT_TBLDROITGRP (SLANGUE     IN     VARCHAR2,
                                    NSTART      IN     NUMBER,
                                    PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_EXPORT_TBLDROITUSER (SLANGUE     IN     VARCHAR2,
                                     NSTART      IN     NUMBER,
                                     PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_CALENDAR (SLANGUE            LANCALENDAR.LANCODE%TYPE,
                          PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_REJPRESENTATIONDELAY (
        NREJID             REJPRESENTATIONDELAY.REJID%TYPE,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_GETPOSTLIST (SLANGUE     IN     LANGUE.LANCODE%TYPE,
                             PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_GETSUBPOSTLIST (SLANGUE     IN     LANGUE.LANCODE%TYPE,
                                PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_GETMASTERCATALOGUELIST (SLANGUE     IN     LANGUE.LANCODE%TYPE,
                                        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_GETVARIATIONINDEXLIST (sUGECODE    IN     INDICE.UGECODE%TYPE,
                                       PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_GETCURRENCYLIST (SLANGUE     IN     LANGUE.LANCODE%TYPE,
                                 PC_RETURN   IN OUT T_CURSOR);

    FUNCTION F_UTILDAPREF_BOOLEANVALUE (
        P_USER         UTILISATEUR.UTILDAPREFERENCE%TYPE,
        P_UPRCODE      UTIPREFERENCE.UPRCODE%TYPE,
        NAUTHFLAG   IN NUMBER)
        RETURN NUMBER;

    PROCEDURE S_SELECTAFFECTATIONALL (SLANGUE     IN     LANGUE.LANCODE%TYPE,
                                      PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_SELECTAFFECTATION (
        SLANGUE        IN     LANGUE.LANCODE%TYPE,
        SAFFECTATION   IN     TNOMENCBUDGET.TNBAFFECTATION%TYPE,
        PC_RETURN      IN OUT T_CURSOR);

    PROCEDURE S_GETAFFECTATIONTREE (SLANGUE     IN     LANGUE.LANCODE%TYPE,
                                    PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_GETTNEALL (SUGECODE    IN     TNOMENCEXPLOIT.UGECODE%TYPE,
                           SLANGUE     IN     LANGUE.LANCODE%TYPE,
                           PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_GETTNEBYTNB (sUgeCode    IN     TNOMENCEXPLOIT.UGECODE%TYPE,
                             SLANGUE     IN     LANGUE.LANCODE%TYPE,
                             NTNBID      IN     TNOMENCBUDGET.TNBID%TYPE,
                             PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_GETRUBALL (SLANGUE     IN     LANGUE.LANCODE%TYPE,
                           SUGECODE    IN     RUBRIQUE.UGECODE%TYPE,
                           PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_GETRUBBYTNB (SLANGUE     IN     LANGUE.LANCODE%TYPE,
                             SUGECODE    IN     RUBRIQUE.UGECODE%TYPE,
                             NTNBID      IN     TNOMENCBUDGET.TNBID%TYPE,
                             PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_GETORGALL (SLANGUE     IN     LANGUE.LANCODE%TYPE,
                           PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_GETORGBYTNB (SLANGUE     IN     LANGUE.LANCODE%TYPE,
                             NTNBID      IN     TNOMENCBUDGET.TNBID%TYPE,
                             PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_EXPORT_GROUPEDROITACCES (SLANGUE     IN     VARCHAR2,
                                         PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_ROLELAN (SLANGUE     IN     VARCHAR2,
                         SROLCODE    IN     ROLE.ROLCODE%TYPE,
                         PC_RETURN   IN OUT T_CURSOR);


    PROCEDURE S_LISTE_USER_BRAND (
        P_UTICODE            UTIACTDEFAULT.UTICODE%TYPE,
        P_DEALER             UTIACTDEFAULT.ACTID%TYPE,
        P_LANCODE            LANPAYS.LANCODE%TYPE,
        PC_RESULTAT   IN OUT T_CURSOR);

    PROCEDURE S_LISTE_USER_DEALERSHIP (
        P_UTICODE            UTIACTDEFAULT.UTICODE%TYPE,
        P_NETWORK            UTIACTDEFAULT.UADSALESNETWORK%TYPE,
        P_LANCODE            LANPAYS.LANCODE%TYPE,
        PC_RESULTAT   IN OUT T_CURSOR);

    PROCEDURE S_UTIACTDEFAULT_FILTRED (
        SUTICODE           UTILISATEUR.UTICODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR);

    PROCEDURE S_UTIACTDEFAULT_FILTRED (
        SUTICODE           UTILISATEUR.UTICODE%TYPE,
        SLANGUE            LANTUSPARAM.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR);
END PAV4_SELECTPARGEN;
/
CREATE OR REPLACE PACKAGE BODY TRSGM45.PAV4_SELECTPARGEN
AS
    -- Declaration des exceptions a trapper
    ERR_CHILD_FOUND                       EXCEPTION;
    ERR_PARENT_NOT_FOUND                  EXCEPTION;
    ERR_I_NULL_MANDATORY_KEY              EXCEPTION;
    ERR_U_NULL_MANDATORY_KEY              EXCEPTION;
    -- ASsociation des exceptions avec les erreurs ORACLE
    PRAGMA EXCEPTION_INIT (ERR_PARENT_NOT_FOUND, -2291);
    PRAGMA EXCEPTION_INIT (ERR_CHILD_FOUND, -2292);
    PRAGMA EXCEPTION_INIT (ERR_I_NULL_MANDATORY_KEY, -1400);
    PRAGMA EXCEPTION_INIT (ERR_U_NULL_MANDATORY_KEY, -1407);
    ERR_NO_ROWS_CONST            CONSTANT INTEGER := 1;
    ERR_CHILD_REL_FOUND_CONST    CONSTANT INTEGER := 2259;
    -- Declaration des constantes de codes retours a renvoyer pour LKRELRUL
    ERR_PARENT_RUL_FOUND_CONST   CONSTANT INTEGER := 1044;
    ERR_DUP_RUL_INDEX_CONST      CONSTANT INTEGER := 2258;
    ERR_NULL_RUL_KEY_CONST       CONSTANT INTEGER := 1055;
    ERR_CHILD_RUL_FOUND_CONST    CONSTANT INTEGER := 2259;
    STABLESPACE                           VARCHAR2 (30);
    STEMPTABLESPACE                       VARCHAR2 (30);
    SROLE_MOD                             VARCHAR2 (30);
    SROLE_SEL                             VARCHAR2 (30);
    SCALLINGUSER                          VARCHAR2 (30);

    PROCEDURE S_CROLIGAFFECTATION_COUNT (
        NACTID              CROLIGAFFECTATION.ACTID%TYPE,
        SCJOCOMPTA          CROLIGAFFECTATION.CJOCOMPTA%TYPE,
        STCRCODE            CROLIGAFFECTATION.TCRCODE%TYPE,
        NTCLORDRE           CROLIGAFFECTATION.TCLORDRE%TYPE,
        NCLIORDRE           CROLIGAFFECTATION.CLIORDRE%TYPE,
        NCOUNT       IN OUT NUMBER)
    AS
    BEGIN
        BEGIN
            SELECT COUNT (*)
              INTO NCOUNT
              FROM CROLIGAFFECTATION
             WHERE     ACTID = NACTID
                   AND CJOCOMPTA = SCJOCOMPTA
                   AND TCRCODE = STCRCODE
                   AND TCLORDRE = NTCLORDRE
                   AND CLIORDRE = NCLIORDRE;
        END;
    END S_CROLIGAFFECTATION_COUNT;

    PROCEDURE S_GRADE (PC_RETURN IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR   SELECT DPT.DGRDTSTART,
                                    DPT.DGRCODE,
                                    DPT.DGRPCTCC,
                                    DPT.DGRNBCC,
                                    DPT.DGRORDER,
                                    DPT.DPTCODE
                               FROM DPTGRADE DPT
                              WHERE DPT.DGRDTEND IS NULL
                           ORDER BY DPT.DGRORDER;
    END S_GRADE;

    PROCEDURE S_GRADE_DEPT (SDEPTCODE IN VARCHAR2, PC_RETURN IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT DPT.DGRDTSTART,
                     DPT.DGRCODE,
                     DPT.DGRPCTCC,
                     DPT.DGRNBCC,
                     DPT.DGRORDER,
                     DPT.DPTCODE
                FROM DPTGRADE DPT
               WHERE DPT.DGRDTEND IS NULL AND DPT.DPTCODE = SDEPTCODE
            ORDER BY DPT.DGRORDER;
    END S_GRADE_DEPT;

    PROCEDURE S_GRADE_DEPT_DATE (
        SDEPTCODE     IN     VARCHAR2,
        DDGRDTSTART          DPTGRADE.DGRDTSTART%TYPE,
        PC_RETURN     IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT DPT.DGRDTSTART,
                     DPT.DGRCODE,
                     DPT.DGRPCTCC,
                     DPT.DGRNBCC,
                     DPT.DGRORDER,
                     DPT.DPTCODE
                FROM DPTGRADE DPT
               WHERE     DPT.DGRDTEND IS NULL
                     AND DPT.DPTCODE = SDEPTCODE
                     AND DPT.DGRDTSTART = DDGRDTSTART
            ORDER BY DPT.DGRORDER;
    END S_GRADE_DEPT_DATE;

    PROCEDURE S_GRADE_DATE (DDGRDTSTART          DPTGRADE.DGRDTSTART%TYPE,
                            PC_RETURN     IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT DPT.DGRDTSTART,
                     DPT.DGRCODE,
                     DPT.DGRPCTCC,
                     DPT.DGRNBCC,
                     DPT.DGRORDER,
                     DPT.DPTCODE
                FROM DPTGRADE DPT
               WHERE DPT.DGRDTEND IS NULL AND DPT.DGRDTSTART = DDGRDTSTART
            ORDER BY DPT.DGRORDER;
    END S_GRADE_DATE;

    PROCEDURE S_GRADEHISTORY (SDGRCODE    IN     DPTGRADE.DGRCODE%TYPE,
                              PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT DPT.DPTCODE,
                     DPT.DGRDTSTART,
                     DPT.DGRCODE,
                     DPT.DGRPCTCC,
                     DPT.DGRNBCC,
                     DPT.DGRDTEND,
                     DPT.DGRORDER
                FROM DPTGRADE DPT
               WHERE DPT.DGRCODE = SDGRCODE AND DPT.DGRDTEND IS NOT NULL
            ORDER BY DPT.DGRDTSTART DESC;
    END S_GRADEHISTORY;

    PROCEDURE S_ACCEVGRP_TBLDROITGRP (SGROUPE     IN     VARCHAR2,
                                      SMODULE     IN     VARCHAR2,
                                      SLANGUE     IN     VARCHAR2,
                                      SLIBELLE    IN     VARCHAR2,
                                      PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        DECLARE
            MAXCOUNT   NUMBER;
        BEGIN
            SELECT PSYMAXSELECT INTO MAXCOUNT FROM PARSYSTEME;

            OPEN PC_RETURN FOR
                SELECT TFO.TMFFONCTION
                           AS FONCTIONALITE,
                       LTF.TMFLIBELLE
                           AS LIBELLE,
                       NVL (LGT.GFDMODIFIER, 0)
                           AS MODIFICATION,
                       NVL (LGT.GFDSUPPRIMER, 0)
                           AS SUPPRESSION,
                       NVL (LGT.GFDMODIFIER, 0) * NVL (LGT.GFDSUPPRIMER, 0)
                           AS GLOBAL,
                       LGT.GROCODE
                           AS GROCODE,
                       LGT.TMOMODULE
                           AS TMOMODULE,
                       GRO.GROINTITULE
                           AS GROINTITULE
                  FROM TMOFONCTION     TFO,
                       LKGROTMFDROIT   LGT,
                       LANTMOFONCTION  LTF,
                       GROUPE          GRO
                 WHERE     (LGT.GROCODE = SGROUPE OR SGROUPE IS NULL)
                       AND LGT.TMOMODULE = SMODULE
                       AND LGT.TMOMODULE = TFO.TMOMODULE
                       AND LGT.TMFFONCTION = TFO.TMFFONCTION
                       AND LGT.TMOMODULE = LTF.TMOMODULE
                       AND LGT.TMFFONCTION = LTF.TMFFONCTION
                       AND LTF.LANCODE = SLANGUE
                       AND LGT.GROCODE = GRO.GROCODE
                       AND (NULL IS NULL OR LTF.TMFLIBELLE LIKE NULL)
                       AND ROWNUM < MAXCOUNT
                UNION	
                 SELECT
                   TFO.TMFFONCTION AS FONCTIONALITE,
                   LTF.TMFLIBELLE AS LIBELLE,
                   0 AS modification,
                   0 AS suppression,
                   0 AS GLOBAL,
                   NULL     AS GROCODE,
                   TFO.TMOMODULE   AS TMOMODULE,
	                 NULL
                 FROM
                   TMOFONCTION TFO,
                   TEVENEMENT TEV,
                   LANTMOFONCTION LTF
                 WHERE
	                 TFO.TMOMODULE = SMODULE
	                 AND TEV .tmomodule  = TFO.tmomodule
                   AND TEV.tmffonction  = TFO.tmffonction
                   AND LANCODE  = SLANGUE
                   AND LTF.tmffonction  = TFO.tmffonction
                   AND LTF.tmomodule = TEV .tmomodule	;
        END;
    END S_ACCEVGRP_TBLDROITGRP;

    PROCEDURE S_RUBRIQUE (SFILTRE            RUBACCES.RACACCES%TYPE,
                          SUGECODE           RUBRIQUE.UGECODE%TYPE,
                          SLANGUE            LANGUE.LANCODE%TYPE,
                          PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        DECLARE
            MAXCOUNT   NUMBER;
        BEGIN
            SELECT PSYMAXSELECT INTO MAXCOUNT FROM PARSYSTEME;

            IF (SFILTRE IS NOT NULL)
            THEN
                OPEN PC_RETURN FOR
                      SELECT RUB.RUBID,
                             RUB.RUBCODE,
                             LRU.RUBLIBELLE,
                             LRU.RUBLIBFAC,
                             RUB.RUBFLAGIREXCLU,
                             RUB.RUBDAS,
                             RUB.RUBFLAGORFI,
                             RUB.RUBPROVISION,
                             RUB.TAXCODE,
                             RUB.UGECODE,
                             LRU.RUBHELPTEXT
                        FROM RUBRIQUE RUB, LANRUBRIQUE LRU, RUBACCES RUBAC
                       WHERE     RUB.UGECODE = SUGECODE
                             AND LRU.RUBID(+) = RUB.RUBID
                             AND LRU.LANCODE(+) = SLANGUE
                             AND RUBAC.RUBID = RUB.RUBID
                             AND RACACCES = SFILTRE
                             AND ROWNUM < MAXCOUNT
                    ORDER BY RUB.RUBCODE;
            ELSE
                OPEN PC_RETURN FOR
                      SELECT RUB.RUBID,
                             RUB.RUBCODE,
                             LRU.RUBLIBELLE,
                             LRU.RUBLIBFAC,
                             RUB.RUBFLAGIREXCLU,
                             RUB.RUBDAS,
                             RUB.RUBFLAGORFI,
                             RUB.RUBPROVISION,
                             RUB.TAXCODE,
                             RUB.UGECODE,
                             LRU.RUBHELPTEXT
                        FROM RUBRIQUE RUB, LANRUBRIQUE LRU
                       WHERE     RUB.UGECODE = SUGECODE
                             AND LRU.RUBID(+) = RUB.RUBID
                             AND LRU.LANCODE(+) = SLANGUE
                             AND ROWNUM < MAXCOUNT
                    ORDER BY RUB.RUBCODE;
            END IF;
        END;
    END S_RUBRIQUE;

    PROCEDURE S_RUBRIQUE (sLangue            LANGUE.LANCODE%TYPE,
                          nRubId             RUBRIQUE.RUBID%TYPE,
                          PC_Return   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_Return FOR
            SELECT RUB.RUBID,
                   RUB.RUBCODE,
                   LRU.RUBLIBELLE,
                   LRU.RUBLIBFAC,
                   RUB.RUBFLAGIREXCLU,
                   RUB.RUBDAS,
                   RUB.RUBFLAGORFI,
                   RUB.RUBPROVISION,
                   RUB.TAXCODE,
                   RUB.UGECODE,
                   LRU.RUBHELPTEXT
              FROM RUBRIQUE RUB, LANRUBRIQUE LRU
             WHERE     LRU.LANCODE(+) = sLangue
                   AND LRU.RUBID(+) = RUB.RUBID
                   AND RUB.RUBID = nRubId;
    END S_RUBRIQUE;

    PROCEDURE D_GROUPACCESS (
        STMFFONCTION          LKGROTMFDROIT.TMFFONCTION%TYPE,
        STMOMODULE            LKGROTMFDROIT.TMOMODULE%TYPE,
        SGROCODE              LKGROTMFDROIT.GROCODE%TYPE,
        NRETURNCODE    IN OUT NUMBER)
    AS
    BEGIN
        BEGIN
            DELETE FROM LKGROTMFDROIT
                  WHERE     TMFFONCTION = STMFFONCTION
                        AND TMOMODULE = STMOMODULE
                        AND GROCODE = SGROCODE;

            NRETURNCODE := 0;
        END;
    END D_GROUPACCESS;

    PROCEDURE U_GROUPACCESS (
        SGFDMODIFIER           LKGROTMFDROIT.GFDMODIFIER%TYPE,
        SGFDSUPPRIMER          LKGROTMFDROIT.GFDSUPPRIMER%TYPE,
        STMFFONCTION           LKGROTMFDROIT.TMFFONCTION%TYPE,
        STMOMODULE             LKGROTMFDROIT.TMOMODULE%TYPE,
        SGROCODE               LKGROTMFDROIT.GROCODE%TYPE,
        NRETURNCODE     IN OUT NUMBER)
    AS
    BEGIN
        BEGIN
            UPDATE LKGROTMFDROIT
               SET GFDMODIFIER = SGFDMODIFIER, GFDSUPPRIMER = SGFDSUPPRIMER
             WHERE     TMFFONCTION = STMFFONCTION
                   AND TMOMODULE = STMOMODULE
                   AND GROCODE = SGROCODE;

            NRETURNCODE := 0;
        END;
    END U_GROUPACCESS;

    PROCEDURE S_RUBACCES (NRUBID             RUBACCES.RUBID%TYPE,
                          SLANGUE            LANGUE.LANCODE%TYPE,
                          PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT RAC.RACACCES,
                   LTTR.TTPLIBELLE ALLIBRACACCES,
                   1               ALFLAGRACACCESINCLUS,
                   1               ALFLAGRACACCESINCDEB
              FROM RUBACCES RAC, LANTTRPARAM LTTR
             WHERE     RAC.RUBID = NRUBID
                   AND LTTR.TTRNOM = 'IMPUTANAFILTRE'
                   AND LTTR.TTPCODE = RAC.RACACCES
                   AND LTTR.LANCODE = SLANGUE
            UNION
            SELECT LTTR2.TTPCODE,
                   LTTR2.TTPLIBELLE ALLIBRACACCES,
                   0                ALFLAGRACACCESINCLUS,
                   0                ALFLAGRACACCESINCDEB
              FROM LANTTRPARAM LTTR2
             WHERE     LTTR2.TTRNOM = 'IMPUTANAFILTRE'
                   AND LTTR2.LANCODE = SLANGUE
                   AND LTTR2.TTPCODE NOT IN (SELECT RAC2.RACACCES
                                               FROM RUBACCES RAC2
                                              WHERE RAC2.RUBID = NRUBID)
            ORDER BY 2, 1;
    END S_RUBACCES;

    PROCEDURE S_CMBSECCRE_UNITEGESTION (PC_RETURN IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR   SELECT UGECODE CODE, UGENOM DISPLAYVALUE
                               FROM UNITEGESTION
                           ORDER BY UGECODE;
    END S_CMBSECCRE_UNITEGESTION;

    PROCEDURE S_TMOYENPMT (SLANGUE IN VARCHAR2, PC_RETURN IN OUT T_CURSOR)
    AS
    --sLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT TMP.TMPCODE,
                     LTM.TMPLIBELLE,
                     TMP.DOCID,
                     TMP.TMPFLAGMANUEL,
                     TMP.TMPFLAGFICHIER,
                     TMP.TMPFLAGRIB,
                     TMP.TMPFLAGCASCADE,
                     TMP.TMPFLAGCARD
                FROM TMOYENPMT TMP, LANTMOYENPMT LTM
               WHERE LTM.TMPCODE(+) = TMP.TMPCODE AND LTM.LANCODE(+) = SLANGUE
            ORDER BY TMP.TMPCODE;
    END S_TMOYENPMT;

    --Entries for Internal Tables Screen
    --Entries for Internal Tables Screen
    PROCEDURE S_PARAMORFI_TABLELIST (
        SNAME              LANTTRAITEMENT.TTRLIBELLE%TYPE,
        SCODE              LANTTRAITEMENT.TTRNOM%TYPE,
        SLANCODE           LANGUE.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT LANTTRAITEMENT.TTRNOM,
                     TTRFLAGPREF,
                     TTRLIBELLE,
                     TTRCONTEXT,
                     0
                FROM LANTTRAITEMENT, TTRAITEMENT
               WHERE     LANCODE = SLANCODE
                     AND (SNAME IS NULL OR LANTTRAITEMENT.TTRLIBELLE LIKE SNAME)
                     AND (SCODE IS NULL OR LANTTRAITEMENT.TTRNOM LIKE SCODE)
                     AND TTRAITEMENT.TTRNOM = LANTTRAITEMENT.TTRNOM
            ORDER BY TTRLIBELLE;
    END S_PARAMORFI_TABLELIST;

    PROCEDURE S_PARAMORFI_TABLELCONTENT (
        SNAME              LANTTRPARAM.TTPLIBELLE%TYPE,
        SCODE              LANTTRPARAM.TTPCODE%TYPE,
        STTRNOM     IN     LANTTRPARAM.TTRNOM%TYPE,
        SLANCODE    IN     LANGUE.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT TTPCODE, TTPLIBELLE
                FROM LANTTRPARAM
               WHERE     TTRNOM = STTRNOM
                     AND (SNAME IS NULL OR LANTTRPARAM.TTPLIBELLE LIKE SNAME)
                     AND (SCODE IS NULL OR LANTTRPARAM.TTPCODE LIKE SCODE)
                     AND LANCODE = SLANCODE
            ORDER BY TTPLIBELLE;
    END S_PARAMORFI_TABLELCONTENT;

    --for Exgternal Tables
    PROCEDURE S_PARAMUSER_TABLELCONTENT (
        STUSNOM     IN     TUSPARAM.TUSNOM%TYPE,
        SLANCODE    IN     LANGUE.LANCODE%TYPE,
        SCODE       IN     TUSPARAM.TUPCODE%TYPE,
        SNAME       IN     LANTUSPARAM.TUPLIBELLE%TYPE,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT PU.TUPCODE, PU.TUPFLAGORFI, PL.TUPLIBELLE
                FROM TUSPARAM PU, LANTUSPARAM PL
               WHERE     PU.TUSNOM = STUSNOM
                     AND LANCODE = SLANCODE
                     AND PL.TUSNOM = STUSNOM
                     AND (SNAME IS NULL OR PL.TUPLIBELLE LIKE SNAME)
                     AND (SCODE IS NULL OR PU.TUPCODE LIKE SCODE)
                     AND PL.TUPCODE = PU.TUPCODE
            ORDER BY PU.TUPCODE;
    END S_PARAMUSER_TABLELCONTENT;

    PROCEDURE S_PARAMUSER_TABLELIST (
        SLANCODE           LANGUE.LANCODE%TYPE,
        SNAME              TUSER.TUSNOM%TYPE,
        SCODE              LANTUSER.TUSLIBELLE%TYPE,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        DECLARE
            MAXCOUNT   NUMBER;
        BEGIN
            SELECT PSYMAXSELECT INTO MAXCOUNT FROM PARSYSTEME;

            OPEN PC_RETURN FOR
                  SELECT TUSER.TUSNOM,
                         TUSLIBELLE,
                         TUSLONGUEUR,
                         0
                    FROM TUSER, LANTUSER
                   WHERE     TUSER.TUSNOM = LANTUSER.TUSNOM
                         AND LANCODE = SLANCODE
                         AND (SNAME IS NULL OR TUSER.TUSNOM LIKE SNAME)
                         AND (SCODE IS NULL OR LANTUSER.TUSLIBELLE LIKE SCODE)
                         AND ROWNUM < MAXCOUNT
                ORDER BY TUSLIBELLE;
        END;
    END S_PARAMUSER_TABLELIST;

    PROCEDURE S_SELTBLPROFIL (
        STACCODE                  TPROFILGESTION.TACCODE%TYPE,
        STPGCODEPARENT            TPROFILGESTION.TPGCODEPARENT%TYPE,
        STPGFLAGFACILITY          TPROFILGESTION.TPGFLAGFACILITY%TYPE,
        SLANGUE                   LANGUE.LANCODE%TYPE,
        PC_RETURN          IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT TPG.TPGCODE  PROFIL,
                     LTP.TPGLIBELLE LIBPROFIL,
                     TPG.TACCODE,
                     TPG.TPGDTDEB DTDEB,
                     TPG.TPGDTFIN DTFIN,
                     TPG.TPGMTMINI,
                     TPG.TPGMTMAXI,
                     TPG.TPGDUREEANMINI,
                     TPG.TPGDUREEMOISMINI,
                     TPG.TPGDUREEJOURMINI,
                     TPG.TPGDUREEANMAXI,
                     TPG.TPGDUREEMOISMAXI,
                     TPG.TPGDUREEJOURMAXI,
                     LTP.LANCODE,
                     TPG.TPGFLAGCONSTRUCTION,
                     TPG.TPGREVOLVINGTYPE,
                     TPG.TPGFLAGFACILITY,
                     TPG.TPGFLAGMOBILIER,
                     TPG.TPGFLAGIMMOBILIER,
                     TPG.TPGFLAGGUARANTEECONTRACT,
                     TPG.TPGFLAGLOT,
                     TPG.TPGFACTORTYPE,
                     TPG.TPGWHOLESALETYPE,
                     TPG.TPGCODEPARENT
                FROM TPROFILGESTION TPG, LANTPROFILGESTION LTP
               WHERE     TPG.TACCODE = STACCODE
                     AND TPG.TPGCODE = LTP.TPGCODE
                     AND LTP.LANCODE = SLANGUE
                     AND (   STPGCODEPARENT IS NULL
                          OR TPGCODEPARENT = STPGCODEPARENT)
                     AND (   STPGFLAGFACILITY IS NULL
                          OR TPGFLAGFACILITY = STPGFLAGFACILITY)
            ORDER BY TPG.TPGCODE;
    END S_SELTBLPROFIL;

    PROCEDURE S_ROLDEL_COLROLCODEEXTERNE (SLANGUE     IN     VARCHAR2,
                                          PC_RETURN   IN OUT T_CURSOR)
    AS
    --sLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
            SELECT ROL.ROLCODE     AS CODE,
                   LROL.ROLLIBELLE AS DISPLAYVALUE,
                   0               AS DEFAUT
              FROM ROLE ROL, LANROLE LROL
             WHERE     ROL.ROLCODE = LROL.ROLCODE
                   AND LROL.LANCODE = SLANGUE
                   AND NVL (ROL.ROLFLAGORFI, 0) = 1;
    END S_ROLDEL_COLROLCODEEXTERNE;

    -- Company Options
    PROCEDURE S_TOPTIONSOCIETE (
        STOSCODE           TOPTIONSOCIETE.TOSCODE%TYPE,
        SLANGUE     IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    --slangue lANDocument.lancode%TYPE := pa_global_declare.sglangue;
    BEGIN
        DECLARE
        BEGIN
            OPEN PC_RETURN FOR
                  SELECT TOS.TOSCODE,
                         LTO.TOSLIBELLE,
                         TOS.TOSTYPE,
                         LTP.TTPLIBELLE,
                         TOS.TOSLONGUEUR,
                         TOS.TOSDECIMALE,
                         LTO.TOSHELPTEXT
                    FROM TOPTIONSOCIETE   TOS,
                         LANTOPTIONSOCIETE LTO,
                         LANTTRPARAM      LTP
                   WHERE     LTO.TOSCODE(+) = TOS.TOSCODE
                         AND LTO.LANCODE(+) = SLANGUE
                         AND LTP.TTRNOM(+) = 'TYPECHAMPBIEN'
                         AND LTP.TTPCODE(+) = TOS.TOSTYPE
                         AND LTP.LANCODE(+) = SLANGUE
                         AND TOS.TOSCODE = STOSCODE
                ORDER BY TOS.TOSCODE, LTO.TOSLIBELLE;
        END;
    END S_TOPTIONSOCIETE;

    PROCEDURE S_TOPTIONSOCIETERECORD (SLANGUE     IN     VARCHAR2,
                                      PC_RETURN   IN OUT T_CURSOR)
    AS
    --slangue lANDocument.lancode%TYPE := pa_global_declare.sglangue;
    BEGIN
        DECLARE
        BEGIN
            OPEN PC_RETURN FOR
                  SELECT TOS.TOSCODE,
                         LTO.TOSLIBELLE,
                         TOS.TOSTYPE,
                         LTP.TTPLIBELLE,
                         TOS.TOSLONGUEUR,
                         TOS.TOSDECIMALE,
                         LTO.TOSHELPTEXT
                    FROM TOPTIONSOCIETE   TOS,
                         LANTOPTIONSOCIETE LTO,
                         LANTTRPARAM      LTP
                   WHERE     LTO.TOSCODE(+) = TOS.TOSCODE
                         AND LTO.LANCODE(+) = SLANGUE
                         AND LTP.TTRNOM(+) = 'TYPECHAMPBIEN'
                         AND LTP.TTPCODE(+) = TOS.TOSTYPE
                         AND LTP.LANCODE(+) = SLANGUE
                ORDER BY TOS.TOSCODE, LTO.TOSLIBELLE;
        END;
    END S_TOPTIONSOCIETERECORD;

    PROCEDURE S_AGEOPTION (NACTID             AGEOPTION.ACTID%TYPE,
                           SLANGUE     IN     VARCHAR2,
                           PC_RETURN   IN OUT T_CURSOR)
    AS
    --slangue lANDocument.lancode%TYPE := pa_global_declare.sglangue;
    BEGIN
        DECLARE
        BEGIN
            OPEN PC_RETURN FOR
                SELECT AOP.TOSCODE,
                       AOP.AOPLOGIQUE,
                       AOP.AOPDATE,
                       AOP.AOPNOMBRE,
                       AOP.AOPTEXTE,
                       LTO.TOSLIBELLE,
                       TOS.TOSLONGUEUR,
                       TOS.TOSDECIMALE,
                       TOS.TOSTYPE,
                       LTP.TTPLIBELLE
                  FROM AGEOPTION          AOP,
                       TOPTIONSOCIETE     TOS,
                       LANTOPTIONSOCIETE  LTO,
                       LANTTRPARAM        LTP
                 WHERE     AOP.TOSCODE = TOS.TOSCODE
                       AND AOP.TOSCODE = LTO.TOSCODE
                       AND LTO.LANCODE = SLANGUE
                       AND TOS.TOSTYPE = LTP.TTPCODE(+)
                       AND LTP.TTRNOM(+) = 'TYPECHAMPBIEN'
                       AND LTP.LANCODE(+) = SLANGUE
                       AND AOP.ACTID = NACTID;
        END;
    END S_AGEOPTION;

    -- Policy TYPEs
    PROCEDURE S_PASSTYPEPOLICE (SUGECODE           UNITEGESTION.UGECODE%TYPE,
                                SLANGUE     IN     VARCHAR2,
                                PC_RETURN   IN OUT T_CURSOR)
    AS
    --slangue lANDocument.lancode%TYPE := pa_global_declare.sglangue;
    BEGIN
        DECLARE
        BEGIN
            OPEN PC_RETURN FOR
                  SELECT PTP.PTPTYPE,
                         LTP.TPTLIBELLE,
                         PTP.PTPOBJET,
                         PTP.PTPFLAGDUREEFIXE,
                         PTP.PTPFLAGNEGOCIATION,
                         PTP.PTPNATURE,
                         PTP.PTPCOVERAGE
                    FROM PASSTYPEPOLICE PTP, LANPASSTYPEPOLICE LTP
                   WHERE     PTP.PTPTYPE = LTP.PTPTYPE
                         AND PTP.UGECODE = SUGECODE
                         AND PTP.UGECODE = LTP.UGECODE
                         AND LTP.LANCODE = SLANGUE
                ORDER BY PTP.PTPTYPE;
        END;
    END S_PASSTYPEPOLICE;

    -- == Deliquency
    PROCEDURE S_IMPAYE (NACTID             IMPAYE.ACTID%TYPE,
                        SLANGUE     IN     VARCHAR2,
                        PC_RETURN   IN OUT T_CURSOR)
    AS
    --slangue lANDocument.lancode%TYPE := pa_global_declare.sglangue;
    BEGIN
        DECLARE
        BEGIN
            OPEN PC_RETURN FOR
                  SELECT IMPCODE,
                         A.TUPLIBELLE ALIMPLIBELLE,
                         IMPPROJUD,
                         IMPRELCODE,
                         IMPFLAGDOUTEUX,
                         IMPFLAGAUTO,
                         0          ALIMPFLAGORFI,
                         --  B.RELLIBELLE RelLibelle,
                         B.RELCODE  RELCODE,
                         C.TUPLIBELLE PRODLIBELLE
                    FROM IMPAYE     IMP,
                         LANTUSPARAM A,
                         LANTRELANCE B,
                         LANTUSPARAM C
                   WHERE     A.LANCODE = SLANGUE
                         AND IMP.ACTID = NACTID
                         AND A.TUSNOM = 'IMPAYE'
                         AND A.TUPCODE = IMP.IMPCODE
                         AND B.LANCODE = SLANGUE
                         AND B.RELCODE = IMP.IMPRELCODE
                         AND C.TUSNOM = 'PROJUD'
                         AND C.LANCODE = SLANGUE
                         AND C.TUPCODE = IMP.IMPPROJUD
                ORDER BY B.RELLIBELLE, C.TUPLIBELLE;
        END;
    END S_IMPAYE;

    PROCEDURE S_SELCOUNT (STPGCODE             LKTTPTACTPG.TPGCODE%TYPE,
                          STACCODE             LKTTPTACTPG.TACCODE%TYPE,
                          NRETURNCODE   IN OUT NUMBER)
    AS
    BEGIN
        BEGIN
            SELECT COUNT (TPGCODE)
              INTO NRETURNCODE
              FROM LKTTPTACTPG
             WHERE TPGCODE = STPGCODE AND TACCODE = STACCODE;
        END;
    END S_SELCOUNT;

    PROCEDURE S_ACCEVUSER_TBLDROITUSER (SWUSER      IN     VARCHAR2 --User code
                                                                   ,
                                        SWUGRP      IN     VARCHAR2,
                                        SWMODULE    IN     VARCHAR2 --module code
                                                                   ,
                                        SGLANGUE    IN     VARCHAR2  --lancode
                                                                   ,
                                        NWSTE       IN     NUMBER   --ste code
                                                                 ,
                                        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        DECLARE
            MAXCOUNT   NUMBER;
        BEGIN
            SELECT PSYMAXSELECT INTO MAXCOUNT FROM PARSYSTEME;

            OPEN PC_RETURN FOR
                  SELECT F.TMFFONCTION
                             AS TMFFONCTION,
                         UD.TMOMODULE,
                         UD.UTICODE,
                         GD.GFDMODIFIER
                             AS GFDMODIFIER,
                         GD.GFDSUPPRIMER
                             AS GFDSUPPRIMER,
                         FL.TMFLIBELLE
                             AS LIBELLE,
                         NVL (UD.UADMODIFIER, GD.GFDMODIFIER)
                             AS MODIFICATION,
                         NVL (UD.UADSUPPRIMER, GD.GFDSUPPRIMER)
                             AS SUPPRESSION,
                           NVL (UD.UADSUPPRIMER, GD.GFDSUPPRIMER)
                         * NVL (UD.UADMODIFIER, GD.GFDMODIFIER)
                             AS GLOB
                    FROM TMOFONCTION     F,
                         UTILISATEUR     U,
                         LKGROTMFDROIT   GD,
                         LKUTITMFACGDROIT UD,
                         LANTMOFONCTION  FL
                   WHERE     U.UTICODE = SWUSER
                         AND NVL (F.TMFFLAGEVT, 0) = 1
                         AND UD.UTICODE(+) = SWUSER
                         AND GD.GROCODE(+) = SWUGRP
                         AND F.TMOMODULE = SWMODULE
                         AND GD.TMOMODULE(+) = SWMODULE
                         AND GD.TMFFONCTION(+) = F.TMFFONCTION
                         AND UD.TMOMODULE(+) = SWMODULE
                         AND UD.TMFFONCTION(+) = F.TMFFONCTION
                         AND LANCODE(+) = SGLANGUE
                         AND FL.TMOMODULE(+) = SWMODULE
                         AND FL.TMFFONCTION(+) = F.TMFFONCTION
                         AND UD.ACTID(+) = NWSTE
                         AND ROWNUM < MAXCOUNT
                ORDER BY FL.TMFLIBELLE;
        END;
    END S_ACCEVUSER_TBLDROITUSER;

    PROCEDURE S_ACCEVUSER_TBLDROITUSER_STE (SWUSER      IN     VARCHAR2 --User code
                                                                       ,
                                            SWUGRP      IN     VARCHAR2,
                                            SWMODULE    IN     VARCHAR2 --module code
                                                                       ,
                                            SGLANGUE    IN     VARCHAR2 --lancode
                                                                       ,
                                            PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT F.TMFFONCTION,
                     UD.UTICODE,
                     GD.GFDMODIFIER
                         AS GFDMODIFIER,
                     GD.GFDSUPPRIMER
                         AS GFDSUPPRIMER,
                     FL.TMFLIBELLE,
                     NVL (UD.UFDMODIFIER, GD.GFDMODIFIER)
                         AS MODIFICATION,
                     NVL (UD.UFDSUPPRIMER, GD.GFDSUPPRIMER)
                         AS SUPPRESSION,
                       NVL (UD.UFDSUPPRIMER, GD.GFDSUPPRIMER)
                     * NVL (UD.UFDMODIFIER, GD.GFDMODIFIER)
                         AS GLOB
                FROM TMOFONCTION   F,
                     UTILISATEUR   U,
                     LKGROTMFDROIT GD,
                     LKUTITMFDROIT UD,
                     LANTMOFONCTION FL
               WHERE     U.UTICODE = SWUSER
                     AND NVL (F.TMFFLAGEVT, 0) = 1
                     AND UD.UTICODE(+) = SWUSER
                     AND GD.GROCODE(+) = SWUGRP
                     AND F.TMOMODULE = SWMODULE
                     AND GD.TMOMODULE(+) = SWMODULE
                     AND GD.TMFFONCTION(+) = F.TMFFONCTION
                     AND UD.TMOMODULE(+) = SWMODULE
                     AND UD.TMFFONCTION(+) = F.TMFFONCTION
                     AND LANCODE(+) = SGLANGUE
                     AND FL.TMOMODULE(+) = SWMODULE
                     AND FL.TMFFONCTION(+) = F.TMFFONCTION
            ORDER BY FL.TMFLIBELLE;
    END S_ACCEVUSER_TBLDROITUSER_STE;

    PROCEDURE S_TSECTEURMETIER (
        SCODESECTGESTION          TSECTEURMETIER.TSMSECTGESTION%TYPE,
        SLANGUE            IN     VARCHAR2,
        PC_RETURN          IN OUT T_CURSOR)
    AS
    --sLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
            SELECT TSM.TSMSECTGESTION TSMSECTGESTION,
                   TSM.TSMMETIER      TSMMETIER,
                   LD1.DPTLABEL,
                   LTUS2.TUPLIBELLE   ALTSMLIBMETIER,
                   1                  ALTSMFLAGINCLUS
              FROM TSECTEURMETIER TSM, LANDEPARTMENT LD1, LANTUSPARAM LTUS2
             WHERE                              --LTUS1.TUSNOM = 'SECTEURGEST'
                       LD1.DPTCODE = TSM.TSMSECTGESTION
                   AND LD1.LANCODE = SLANGUE
                   AND LTUS2.TUSNOM = 'METIER'
                   AND LTUS2.TUPCODE = TSM.TSMMETIER
                   AND LTUS2.LANCODE = SLANGUE
                   AND TSM.TSMSECTGESTION = SCODESECTGESTION
            UNION
            SELECT LD1.DPTCODE      TSMSECTGESTION,
                   LTUS2.TUPCODE    TSMMETIER,
                   LD1.DPTLABEL     TUPLIBELLE,
                   LTUS2.TUPLIBELLE ALTSMLIBMETIER,
                   0                ALTSMFLAGINCLUS
              FROM LANDEPARTMENT LD1, LANTUSPARAM LTUS2
             WHERE     LD1.LANCODE = SLANGUE
                   -- AND LTUS1.TUSNOM = 'SECTEURGEST'
                   AND LTUS2.LANCODE = SLANGUE
                   AND LTUS2.TUSNOM = 'METIER'
                   AND LD1.DPTCODE = SCODESECTGESTION
                   AND (LD1.DPTCODE, LTUS2.TUPCODE) NOT IN
                           (SELECT TSM.TSMSECTGESTION, TSM.TSMMETIER
                              FROM TSECTEURMETIER TSM
                             WHERE TSM.TSMSECTGESTION = SCODESECTGESTION);
    END S_TSECTEURMETIER;

    PROCEDURE S_TMPATTRIBUTE (STMPCODE           TMPATTRIBUTE.TMPCODE%TYPE,
                              SLANGUE     IN     VARCHAR2,
                              PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT TMP.TMPCODE     TMPCODE,
                   TMP.TATACCES    TATACCES,
                   LT1.TMPLIBELLE  TMPCODELABEL,
                   LTR2.TTPLIBELLE TATACCESSLABEL,
                   1               TMPFLAGINCLUS
              FROM TMPATTRIBUTE TMP, LANTMOYENPMT LT1, LANTTRPARAM LTR2
             WHERE     LT1.TMPCODE = TMP.TMPCODE
                   AND LT1.LANCODE = SLANGUE
                   AND LTR2.TTRNOM = 'TMPCODEFILTER'
                   AND LTR2.TTPCODE = TMP.TATACCES
                   AND LTR2.LANCODE = SLANGUE
                   AND LT1.TMPCODE = STMPCODE
            UNION
            SELECT LT1.TMPCODE,
                   LTR2.TTPCODE    TATACCES,
                   LT1.TMPLIBELLE  TMPCODELABEL,
                   LTR2.TTPLIBELLE TATACCESSLABEL,
                   0               TMPFLAGINCLUS
              FROM LANTMOYENPMT LT1, LANTTRPARAM LTR2
             WHERE     LT1.LANCODE = SLANGUE
                   AND LTR2.LANCODE = SLANGUE
                   AND LTR2.TTRNOM = 'TMPCODEFILTER'
                   AND LT1.TMPCODE = STMPCODE
                   AND (LT1.TMPCODE, LTR2.TTPCODE) NOT IN
                           (SELECT TMP.TMPCODE, TMP.TATACCES
                              FROM TMPATTRIBUTE TMP
                             WHERE TMP.TMPCODE = STMPCODE);
    END S_TMPATTRIBUTE;

    PROCEDURE S_ROLDELEGATION (SROLCODE    IN     ROLDELEGATION.ROLCODE%TYPE,
                               PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR SELECT RDEDELEGCODE, RDEFLAGORFI, ROLCODE
                             FROM ROLDELEGATION
                            WHERE ROLCODE = SROLCODE;
    END S_ROLDELEGATION;

    PROCEDURE S_ROLE (SROLCODE    IN     ROLE.ROLCODE%TYPE,
                      PC_RETURN   IN OUT T_CURSOR)
    AS
        SLANGUE   LANGUE.LANCODE%TYPE := PA_GLOBAL_DECLARE.SGLANGUE;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT ROL.ROLCODE,
                     ROL.ROLFLAGATTRIBUT,
                     ROL.ROLFLAGENTRANT,
                     ROL.ROLFLAGSORTANT,
                     ROL.ROLFLAGORFI,
                     ROL.ROLCODEEXTERNE,
                     LRO.ROLLIBELLE
                FROM ROLE ROL, LANROLE LRO
               WHERE     ROL.ROLCODE = NVL (SROLCODE, ROL.ROLCODE)
                     AND LRO.ROLCODE(+) = ROL.ROLCODE
                     AND LRO.LANCODE(+) = SLANGUE
            ORDER BY ROL.ROLCODE;
    END S_ROLE;

    PROCEDURE S_TMODULE (STMOMODULE   IN     TMODULE.TMOMODULE%TYPE,
                         SLANGUE      IN     LANTMODULE.LANCODE%TYPE,
                         PC_RETURN    IN OUT T_CURSOR)
    AS
    --        sLangue LANGUE.LANCODE%TYPE := Pa_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT TM.TMOORDRE,
                     TM.TMOMODULE,
                     TM.TMOEXE,
                     TM.TMOFLAGEXTERNE,
                     TM.TMOFLAGDROITSTE,
                     LANTM.TMOLIBELLE,
                     TM.TMOFLAGORFI
                FROM TMODULE TM, LANTMODULE LANTM
               WHERE     TM.TMOMODULE = STMOMODULE
                     AND TM.TMOMODULE = LANTM.TMOMODULE
                     AND LANTM.LANCODE(+) = SLANGUE
            ORDER BY TM.TMOORDRE;
    END S_TMODULE;

    PROCEDURE S_TMOFONCTION (STMOMODULE   IN     TMOFONCTION.TMOMODULE%TYPE,
                             SLANGUE      IN     LANTMOFONCTION.LANCODE%TYPE,
                             PC_RETURN    IN OUT T_CURSOR)
    AS
    --        sLangue LANGUE.LANCODE%TYPE := Pa_Global_Declare.sgLangue;
    BEGIN
        --DECLARE
        --maxCount NUMBER ;
        --BEGIN
        --SELECT PSYMAXSELECT INTO maxCount  FROM PARSYSTEME ;
        OPEN PC_RETURN FOR
              SELECT A.TMOMODULE,
                     A.TMFFONCTION,
                     TMFLIBELLE,
                     TMFFLAGEVT
                FROM TMOFONCTION A, LANTMOFONCTION B
               WHERE     A.TMOMODULE = STMOMODULE
                     AND LANCODE(+) = SLANGUE
                     AND NVL (A.TMFFLAGEVT, 0) = 1
                     AND B.TMFFONCTION(+) = A.TMFFONCTION
                     AND B.TMOMODULE(+) = A.TMOMODULE
                     AND EXISTS
                             (SELECT 1
                                FROM TEVENEMENT C
                               WHERE     C.TMOMODULE = A.TMOMODULE
                                     AND C.TMFFONCTION = A.TMFFONCTION
                                     AND NVL (C.TEVFLAGCONVTOV4, 0) != 0)
            --AND ROWNUM < maxCount
            ORDER BY TMFFONCTION;
    --END ;
    END S_TMOFONCTION;

    PROCEDURE S_REJETMOTIF (SPAYCODE           REJETMOTIF.PAYCODE%TYPE,
                            SUGECODE           REJETMOTIF.UGECODE%TYPE,
                            SLANGUE            LANREJETMOTIF.LANCODE%TYPE,
                            PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT REJ.REJID,
                     REJ.REJMOTIF,
                     LRJ.REJLIBELLE,
                     NVL (REJ.REJFLAGREJETTECHNIQUE, 0)
                         AS REJFLAGREJETTECHNIQUE,
                     REJ.REJMAXREPRESENTATION,
                     REJ.REJMTFRAISREJET,
                     REJ.DEVCODE,
                     REJ.REJPCTFRAISREJET,
                     REJ.RUBID,
                     REJ.TAXCODE,
                     REJ.PAYCODE,
                     TO_CHAR (REJ.CALID),
                     REJ.UGECODE
                FROM REJETMOTIF REJ, LANREJETMOTIF LRJ
               WHERE     REJ.REJID = LRJ.REJID
                     AND REJ.PAYCODE = SPAYCODE
                     AND REJ.UGECODE = SUGECODE
                     AND LRJ.LANCODE = SLANGUE
            ORDER BY REJ.REJMOTIF;
    END S_REJETMOTIF;

    PROCEDURE S_TRELANCE (                    --sgLangue  LANGUE.LANCODE%TYPE,
                          SLANGUE IN VARCHAR2, PC_RETURN IN OUT T_CURSOR)
    AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        DECLARE
        BEGIN
            OPEN PC_RETURN FOR
                  SELECT TRE.RELCODE, LTR.RELLIBELLE
                    FROM TRELANCE TRE, LANTRELANCE LTR
                   WHERE LANCODE = SLANGUE AND TRE.RELCODE = LTR.RELCODE
                ORDER BY TRE.RELCODE;
        END;
    END S_TRELANCE;

    PROCEDURE S_UTILISATEUR (SUTICODE    IN     UTILISATEUR.UTICODE%TYPE,
                             PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT UTILISATEUR.UTICODE,
                     UTINOM,
                     UTIPRENOM,
                     UTITELECOM,
                     GROCODE,
                     UTIFLAGINACTIF,
                     UGECODE,
                     UTIPWD,
                     UTIPWDHASHALGORITHM,
                     UTILOCKED,
                     UTIATTEMPTS,
                     UTICODESUBSTITUTE,
                     UTIPWDDTCHGD,
                     UTIFLAGPERMANENT,
                     UTIFLAGPASSWORD,
                     UTIDTUPD,
                     UTIWHODUNNIT,
                     UTILOCKTIME,
                     UTIDTBIRTH,
                     UTIDTBEG,
                     UTIDTEND,
                     UTILEVEL,
                     DECODE (NVL (UTILOCKED, 'N'), 'N', 0, 1)
                         UTIFLAGLOCKED,
                     UTILEVEL,
                     UTIEXTERNALREFERENCE,
                     UTIPOSITION,
                     UTISUBPOSITION,
                     UTILDAPREFERENCE,
                     UTIPWDSALT,
                     (SELECT MAX (TSMFLAGSUPERVISEUR)
                        FROM UTITSM
                       WHERE UTICODE = UTILISATEUR.UTICODE AND TSMDTEND IS NULL)
                         TSMFLAGLEADER
                FROM UTILISATEUR
               WHERE UTILISATEUR.UTICODE = SUTICODE
            ORDER BY UTINOM;
    END S_UTILISATEUR;

    PROCEDURE S_UTICOORDONNEE (SUTICODE    IN     UTICOORDONNEE.UTICODE%TYPE,
                               PC_RETURN   IN OUT T_CURSOR)
    AS
        SLANGUE   LANDOCUMENT.LANCODE%TYPE := PA_GLOBAL_DECLARE.SGLANGUE;
    BEGIN
        OPEN PC_RETURN FOR
            SELECT LTP.TUPLIBELLE,
                   UCO.UCOREFERENCE,
                   UCO.UCOORDRE,
                   UCO.UTICODE,
                   UCO.UCODOMAIN,
                   LTP.TUPCODE,
                   UCO.UCOTYPE
              FROM UTICOORDONNEE UCO, LANTUSPARAM LTP
             WHERE     UCO.UCOTYPE = LTP.TUPCODE
                   AND LTP.TUSNOM = 'TELTYPE'
                   AND LTP.LANCODE = SLANGUE
                   AND UCO.UTICODE = SUTICODE;
    END S_UTICOORDONNEE;

    PROCEDURE S_UTITSM_ONLY (SUTICODE    IN     UTITSM.UTICODE%TYPE,
                             PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR SELECT UTICODE,
                                  TSMSECTGESTION,
                                  TSMMETIER,
                                  TSMFLAGSUPERVISEUR,
                                  TSMFLAGDEFAUT,
                                  TSMPARTNAME,
                                  TSMCOUNGR,
                                  TSMCOUNEGE,
                                  TSMDTSTART,
                                  TSMDTEND,
                                  TSMINCOMINGPATH,
                                  TSMFLAGLEADER,
                                  TSMTEAMCODE
                             FROM utitsm
                            WHERE UTICODE = SUTICODE;
    END S_UTITSM_ONLY;

    PROCEDURE S_LBPARAMETERS (STOPTABLE          LANTOPPARAM.TOPTABLE%TYPE,
                              SUGECODE    IN     VARCHAR2,
                              SLANGUE     IN     VARCHAR2,
                              PC_RETURN   IN OUT T_CURSOR)
    AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT TPA.TPAPARAM AS CODE, TPA.TPALIBELLE AS DISPLAYVALUE
                FROM LANTOPPARAM TPA
               WHERE     TPA.TOPTABLE = STOPTABLE
                     AND TPA.LANCODE = SLANGUE
                     AND TPA.UGECODE = SUGECODE
            ORDER BY 1;
    END S_LBPARAMETERS;

    PROCEDURE S_ADDITIONALINFO (STOPTABLE          LANTOPPARAM.TOPTABLE%TYPE,
                                STPAPARAM          LANTOPPARAM.TPAPARAM%TYPE,
                                SUGECODE    IN     VARCHAR2,
                                SLANGUE     IN     VARCHAR2,
                                PC_RETURN   IN OUT T_CURSOR)
    AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT TPAAIDE,
                     TPALIBLOGIQUE,
                     TPALIBDATE,
                     TPALIBNOMBRE,
                     TPALIBTEXTE
                FROM LANTOPPARAM
               WHERE     LANCODE = SLANGUE
                     AND TOPTABLE = STOPTABLE
                     AND TPAPARAM = STPAPARAM
                     AND UGECODE = SUGECODE
            ORDER BY TPAPARAM;
    END S_ADDITIONALINFO;

    PROCEDURE S_ADDITIONALINFOPOLULATE (
        STOPTABLE          TOPPARAM.TOPTABLE%TYPE,
        STPAPARAM          TOPPARAM.TPAPARAM%TYPE,
        SUGECODE    IN     VARCHAR2,
        SLANGUE     IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT TPALOGIQUE AS FLAGTPALOGIQUE,
                     TPADATE,
                     TPANOMBRE,
                     TPATEXTE
                FROM TOPPARAM
               WHERE     TOPTABLE = STOPTABLE
                     AND TPAPARAM = STPAPARAM
                     AND UGECODE = SUGECODE
            ORDER BY TPAPARAM;
    END S_ADDITIONALINFOPOLULATE;

    -- For Preference on External Tables Screen
    PROCEDURE S_PREUSERPARAMORFI_ANALYTICAL (
        STUSNOM            TUSPARAM.TUSNOM%TYPE,
        STACCODE           LKTUPTACTPG.TACCODE%TYPE,
        STPGCODE           LKTUPTACTPG.TPGCODE%TYPE,
        SLANGUE            LANGUE.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT NVL (TP.TUPCODE, TT.TUPCODE)  AS REALTUPCODE,
                     TL.TUPLIBELLE,
                     DECODE (TP.TUPCODE, NULL, 0, 1) AS TUPCODEINCLUDE,
                     DECODE (TP.TUPCODE, NULL, 0, 1) AS TUPCODEORIGINAL,
                     NVL (TP.TUGFLAGDEFAUT, 0)     AS TUGFLAGDEFAUT,
                     NVL (TP.TUGORDRE, 0)          AS TUGORDRE
                FROM TUSPARAM TT, LKTUPTACTPG TP, LANTUSPARAM TL
               WHERE     TP.TUPCODE(+) = TT.TUPCODE
                     AND TP.TUSNOM(+) = TT.TUSNOM
                     AND TT.TUSNOM = STUSNOM
                     AND TP.TACCODE(+) = STACCODE
                     AND TP.TPGCODE(+) = STPGCODE
                     AND TT.TUPCODE = TL.TUPCODE
                     AND TT.TUSNOM = TL.TUSNOM
                     AND LANCODE = SLANGUE
            ORDER BY 2;
    END S_PREUSERPARAMORFI_ANALYTICAL;

    PROCEDURE S_PREUSERPARAMORFI_PARAMETER (
        SLANCODE           LANGUE.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT LANTUSER.TUSNOM, TUSLIBELLE
                FROM LANTUSER, TUSER
               WHERE LANCODE = SLANCODE AND TUSER.TUSNOM = LANTUSER.TUSNOM
            ORDER BY TUSLIBELLE;
    END S_PREUSERPARAMORFI_PARAMETER;

    -- For Preference on Internal Tables Screen
    PROCEDURE S_PREPARAMORFI_PARAMETER (
        SLANCODE           LANGUE.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        DECLARE
            MAXCOUNT   NUMBER;
        BEGIN
            OPEN PC_RETURN FOR
                  SELECT LANTTRAITEMENT.TTRNOM,
                         TTRLIBELLE,
                         TTRCONTEXT,
                         0
                    FROM LANTTRAITEMENT, TTRAITEMENT
                   WHERE     LANCODE = SLANCODE
                         AND TTRAITEMENT.TTRNOM = LANTTRAITEMENT.TTRNOM
                         AND TTRFLAGPREF = 1
                ORDER BY TTRLIBELLE;
        END;
    END S_PREPARAMORFI_PARAMETER;

    PROCEDURE S_PREPARAMORFI_VALUES (
        STTRNOM            LKTTPTACTPG.TTRNOM%TYPE,
        STACCODE           LKTTPTACTPG.TACCODE%TYPE,
        STPGCODE           LKTTPTACTPG.TPGCODE%TYPE,
        SLANGUE            LANGUE.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT NVL (TP.TTPCODE, TT.TTPCODE)  AS REALTTPCODE,
                     TL.TTPLIBELLE,
                     DECODE (TP.TTPCODE, NULL, 0, 1) AS TTPCODEINCLUDE,
                     DECODE (TP.TTPCODE, NULL, 0, 1) AS TTPCODEORIGINAL,
                     NVL (TP.TTGFLAGDEFAUT, 0)     AS TTGFLAGDEFAUT,
                     NVL (TP.TTGORDRE, 0)          AS TTGORDRE
                FROM TTRPARAM TT, LKTTPTACTPG TP, LANTTRPARAM TL
               WHERE     TP.TTPCODE(+) = TT.TTPCODE
                     AND TP.TTRNOM(+) = TT.TTRNOM
                     AND TT.TTRNOM = STTRNOM
                     AND TP.TACCODE(+) = STACCODE
                     AND TP.TPGCODE(+) = STPGCODE
                     AND TT.TTPCODE = TL.TTPCODE
                     AND TT.TTRNOM = TL.TTRNOM
                     AND LANCODE = SLANGUE
            ORDER BY 2;
    END S_PREPARAMORFI_VALUES;

    PROCEDURE S_TPARAGRAPHECTL (
        STPCCODE    IN     TPARAGRAPHECTL.TPCCODE%TYPE,
        STPCDEST    IN     TPARAGRAPHECTL.TPCDEST%TYPE,
        SUGECODE    IN     TPCTACCONTROLE.UGECODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR)
    AS
        SLANGUE   LANGUE.LANCODE%TYPE := PA_GLOBAL_DECLARE.SGLANGUE;
    BEGIN
        -- SPA - CFS 55978 - artf1810126 : SSE-Impossible to create a user control - Added UgeCode as In parameter.
        OPEN PC_RETURN FOR
              SELECT SUBSTR (A.TPCCODE, 3) AS TPCCODE,
                     TPCFLAGOBLIG,
                     B.TPCLIBELLE,
                     LTTP.TTPLIBELLE,
                     A.TPCDEST,
                     LTTP.TTPCODE,
                     SUGECODE            AS UGECODE
                FROM TPARAGRAPHECTL A, LANTPARAGRAPHECTL B, LANTTRPARAM LTTP
               WHERE     SUBSTR (A.TPCCODE, 1, 2) = 'U_'
                     AND SUBSTR (A.TPCCODE, 3) = STPCCODE
                     AND A.TPCDEST = STPCDEST
                     AND A.TPCCODE = B.TPCCODE
                     AND A.TPCDEST = B.TPCDEST
                     AND LTTP.TTRNOM = 'DESTINATION'
                     AND LTTP.TTPCODE = A.TPCDEST
                     AND LTTP.LANCODE = SLANGUE
                     AND B.LANCODE = SLANGUE
            ORDER BY A.TPCCODE;
    END S_TPARAGRAPHECTL;

    PROCEDURE S_TPCTACCONTROLE (
        STPCDEST    IN     TPCTACCONTROLE.TPCDEST%TYPE,
        STPCCODE    IN     TPCTACCONTROLE.TPCCODE%TYPE,
        SUGECODE    IN     TPCTACCONTROLE.UGECODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR)
    AS
        SLANGUE   LANGUE.LANCODE%TYPE := PA_GLOBAL_DECLARE.SGLANGUE;
    BEGIN
        -- SPA - CFS 55978 - artf1810126 : SSE-Impossible to create a user control - Added UgeCode as In parameter.
        IF SUGECODE IS NULL
        THEN
            OPEN PC_RETURN FOR
                  SELECT SUBSTR (A.TTCCODE, 3) AS TTCCODE,
                         A.TACCODE,
                         SUBSTR (A.TPCCODE, 3) AS TPCCODE,
                         -- a.tpccode,
                         A.TPCDEST,
                         TACLIBELLE,
                         TTCLIBELLE,
                         TTCMEMO
                    FROM TPCTACCONTROLE A, LANTPCTACCONTROLE B, LANTACTIVITE C
                   WHERE     A.TPCCODE = CONCAT ('U_', STPCCODE)
                         AND A.TPCDEST = STPCDEST
                         AND A.TPCDEST = B.TPCDEST
                         AND B.TPCCODE = A.TPCCODE
                         AND B.TTCCODE = A.TTCCODE
                         AND B.TACCODE = A.TACCODE
                         AND B.LANCODE = SLANGUE
                         AND A.TACCODE = C.TACCODE
                         AND C.LANCODE = SLANGUE
                         AND A.UGECODE IS NULL
                ORDER BY A.TTCCODE, TACLIBELLE;
        ELSE
            OPEN PC_RETURN FOR
                  SELECT SUBSTR (A.TTCCODE, 3) AS TTCCODE,
                         A.TACCODE,
                         SUBSTR (A.TPCCODE, 3) AS TPCCODE,
                         -- a.tpccode,
                         A.TPCDEST,
                         TACLIBELLE,
                         TTCLIBELLE,
                         TTCMEMO
                    FROM TPCTACCONTROLE A, LANTPCTACCONTROLE B, LANTACTIVITE C
                   WHERE     A.TPCCODE = CONCAT ('U_', STPCCODE)
                         AND A.TPCDEST = STPCDEST
                         AND A.TPCDEST = B.TPCDEST
                         AND B.TPCCODE = A.TPCCODE
                         AND B.TTCCODE = A.TTCCODE
                         AND B.TACCODE = A.TACCODE
                         AND B.LANCODE = SLANGUE
                         AND A.TACCODE = C.TACCODE
                         AND C.LANCODE = SLANGUE
                         AND A.UGECODE = SUGECODE
                ORDER BY A.TTCCODE, TACLIBELLE;
        END IF;
    END S_TPCTACCONTROLE;

    PROCEDURE S_ROLVARIABLE (SROLCODE    IN     ROLVARIABLE.ROLCODE%TYPE --, sLangue LANROLVARIABLE.LANCODE%TYPE
                                                                        ,
                             PC_RETURN   IN OUT T_CURSOR)
    AS
        SLANGUE   LANROLVARIABLE.LANCODE%TYPE := PA_GLOBAL_DECLARE.SGLANGUE;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT RVA.RVACODE,
                     RVA.RVATYPE,
                     RVALIBELLE,
                     SROLCODE ROLCODE,
                     RVA.RVAGROUP,
                     LRV.LANCODE,
                     RVA.RVAFLAGMULTIPLE,
                     RVA.RVAFLAGMANDATORY,
                     RVA.RVAFLAGNUMERIC
                FROM ROLVARIABLE RVA, LANROLVARIABLE LRV
               WHERE     RVA.ROLCODE = SROLCODE
                     AND RVA.RVACODE = LRV.RVACODE
                     AND RVA.ROLCODE = LRV.ROLCODE
                     AND LANCODE = SLANGUE
            ORDER BY RVA.RVATYPE, RVA.RVACODE;
    END S_ROLVARIABLE;

    PROCEDURE S_ROLVARVALEUR (SROLCODE    IN     ROLVARVALEUR.ROLCODE%TYPE,
                              SRVACODE    IN     ROLVARVALEUR.RVACODE%TYPE --, sLangue LANROLVARVALEUR.LANCODE%TYPE
                                                                          ,
                              PC_RETURN   IN OUT T_CURSOR)
    AS
        SLANGUE   LANROLVARVALEUR.LANCODE%TYPE := PA_GLOBAL_DECLARE.SGLANGUE;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT RVV.RVVCODE,
                     RVVLIBELLE,
                     SROLCODE ROLCODE,
                     SRVACODE RVACODE,
                     LRV.LANCODE
                FROM ROLVARVALEUR RVV, LANROLVARVALEUR LRV
               WHERE     RVV.ROLCODE = SROLCODE
                     AND RVV.RVACODE = SRVACODE
                     AND RVV.RVVCODE = LRV.RVVCODE
                     AND RVV.RVACODE = LRV.RVACODE
                     AND RVV.ROLCODE = LRV.ROLCODE
                     AND LANCODE = SLANGUE
            ORDER BY RVV.RVVCODE;
    END S_ROLVARVALEUR;

    PROCEDURE S_LKRVVRUL (SROLCODE    IN     ROLVARVALEUR.ROLCODE%TYPE,
                          SRVACODE    IN     ROLVARVALEUR.RVACODE%TYPE,
                          SRVVCODE    IN     ROLVARVALEUR.RVVCODE%TYPE,
                          PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT RULID,
                     SROLCODE ROLCODE,
                     SRVACODE RVACODE,
                     SRVVCODE RVVCODE
                FROM LKRVVRUL
               WHERE     ROLCODE = SROLCODE
                     AND RVACODE = SRVACODE
                     AND RVVCODE = SRVVCODE
            ORDER BY RULID;
    END S_LKRVVRUL;

    PROCEDURE S_BUSTYPE_TREE (SGLANGUE    IN     VARCHAR2,
                              PC_RETURN   IN OUT T_CURSOR)
    AS
    --sgLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT RF.TACCODE,
                     RF.TRFCODE,
                     LL.TACLIBELLE,
                     TL.TTPLIBELLE
                FROM TACREGIMEFISCAL RF, LANTACTIVITE LL, LANTTRPARAM TL
               WHERE     RF.TACCODE NOT IN ('GLOBAL', 'EMPRUNT')
                     AND LL.LANCODE = SGLANGUE
                     AND LL.TACCODE = RF.TACCODE
                     AND TL.TTPCODE = RF.TRFCODE
                     AND TL.TTRNOM = 'CONTRATREGFISC'
                     AND TL.LANCODE(+) = SGLANGUE
            ORDER BY RF.TACCODE, RF.TRFCODE;
    END S_BUSTYPE_TREE;

    PROCEDURE S_TEVENEMENT (SMTACCODE     IN     TEVENEMENT.TACCODE%TYPE,
                            SMTMOMODULE   IN     TEVENEMENT.TMOMODULE%TYPE,
                            SMTEVDEST     IN     TEVENEMENT.TEVDEST%TYPE,
                            SLANGUE       IN     VARCHAR2,
                            PC_RETURN     IN OUT T_CURSOR)
    AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        DECLARE
        BEGIN
            OPEN PC_RETURN FOR
                  SELECT DISTINCT TEV.TMFFONCTION,
                                  LTE.TEVLIBELLE   AS EVLIBELLE,
                                  TEV.TEVFLAGSYNCHRO AS EVSYNCHROORFI,
                                  TEV.TEVORDRE     AS EVORDER,
                                  TEV.PIMCODE,
                                  TEV.TACCODE,
                                  TEV.TEVFLAGUSER,
                                  TEV.TEVDEST,
                                  TEV.TEVFLAGCONTACT,
                                  TEV.TEVFLAGCONTACTUSERCHOICE,
                                  TEV.TMOMODULE,
                                  TEV.TEVFLAG4EYES,
                                  TPH.ALICODE
                    FROM TEVENEMENT TEV, LANTEVENEMENT LTE, TEVPHA TPH
                   WHERE     TEV.TMOMODULE = LTE.TMOMODULE
                         AND TEV.TMFFONCTION = LTE.TMFFONCTION
                         AND TEV.TEVDEST = LTE.TEVDEST
                         AND TEV.TACCODE = LTE.TACCODE
                         AND TPH.TEVDEST = TEV.TEVDEST
                         AND TPH.TMFFONCTION = TEV.TMFFONCTION
                         AND TPH.TMOMODULE = TEV.TMOMODULE
                         AND TPH.TACCODE = TEV.TACCODE
                         AND TEV.TACCODE = SMTACCODE
                         AND TEV.TMOMODULE = SMTMOMODULE
                         AND TEV.TEVDEST = SMTEVDEST
                         AND LTE.LANCODE = SLANGUE
                ORDER BY TEV.TEVORDRE;
        END;
    END S_TEVENEMENT;

    PROCEDURE S_TEVENEMENT (
        STMFFONCTION   IN     TEVENEMENT.TMFFONCTION%TYPE,
        SLANGUE        IN     VARCHAR2,
        PC_RETURN      IN OUT T_CURSOR)
    AS
    BEGIN
        DECLARE
        BEGIN
            OPEN PC_RETURN FOR
                SELECT DISTINCT TEV.TMFFONCTION,
                                LTE.TEVLIBELLE     AS EVENTLABEL,
                                TEV.TEVFLAGSYNCHRO AS EVSYNCHROORFI,
                                TEV.TEVORDRE       AS EVORDER,
                                TEV.PIMCODE,
                                TEV.TACCODE,
                                TEV.TEVFLAGUSER,
                                TEV.TEVDEST,
                                TEV.TEVFLAGCONTACT,
                                TEV.TEVFLAGCONTACTUSERCHOICE,
                                TEV.TMOMODULE,
                                TEV.TEVFLAG4EYES
                  FROM TEVENEMENT TEV, LANTEVENEMENT LTE
                 WHERE     TEV.TMOMODULE = LTE.TMOMODULE
                       AND TEV.TMFFONCTION = LTE.TMFFONCTION
                       AND TEV.TEVDEST = LTE.TEVDEST
                       AND TEV.TACCODE = LTE.TACCODE
                       AND TEV.TMFFONCTION = STMFFONCTION
                       AND LTE.LANCODE = SLANGUE;
        END;
    END S_TEVENEMENT;

    PROCEDURE S_LEGALCATEGORY (SCJUPAYS    IN     CATJURIDIQUE.PAYCODE%TYPE,
                               SLANGUE     IN     VARCHAR2,
                               PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT A.CJUCODE,
                     B.CJULIBELLE,
                     A.CJUTYPE,
                     A.PAYCODE,
                     B.LANCODE
                FROM CATJURIDIQUE A, LANCATJURIDIQUE B
               WHERE     B.CJUCODE(+) = A.CJUCODE
                     AND B.LANCODE(+) = SLANGUE
                     AND A.PAYCODE = SCJUPAYS
                     AND B.PAYCODE = A.PAYCODE
            ORDER BY A.CJUCODE;
    END S_LEGALCATEGORY;

    PROCEDURE S_LANTAMOLOIFISC (SLANGUE            LANGUE.LANCODE%TYPE,
                                --sLangue VARCHAR2,
                                PC_RETURN   IN OUT T_CURSOR)
    AS
    --sLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR   SELECT TLFCODE AS CODE, TLFLIBELLE AS DISPLAYVALUE
                               FROM LANTAMOLOIFISC
                              WHERE LANCODE = SLANGUE
                           ORDER BY 1;
    END S_LANTAMOLOIFISC;

    PROCEDURE S_TLFTRFUSAGE (STACCODE    IN     TLFTRFUSAGE.TACCODE%TYPE,
                             STRFCODE    IN     TLFTRFUSAGE.TRFCODE%TYPE,
                             PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR   SELECT TLFCODE AS CODE, TLFCODE AS DISPLAYVALUE
                               FROM TLFTRFUSAGE
                              WHERE TACCODE = STACCODE AND TRFCODE = STRFCODE
                           ORDER BY 1;
    END S_TLFTRFUSAGE;

    PROCEDURE S_PREFEVENT_LSTPREFEVENTTPG (SACTPREFEVENT   IN     VARCHAR2,
                                           SUGECODE        IN     VARCHAR2,
                                           SLANGUE         IN     VARCHAR2,
                                           PC_RETURN       IN OUT T_CURSOR)
    AS
    --sLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT TPG.TPGCODE
                         AS CODE,
                     (SELECT LTP.TPGLIBELLE
                        FROM LANTPROFILGESTION LTP
                       WHERE     LTP.TPGCODE = TPG.TPGCODE
                             AND LTP.LANCODE = SLANGUE)
                         AS DISPLAYVALUE
                FROM TPROFILGESTION TPG
               WHERE (   (    SACTPREFEVENT = 'GLOBAL'
                          AND TPG.TACCODE = SACTPREFEVENT)
                      OR (    TPG.TACCODE = SACTPREFEVENT
                          AND TPG.TPGCODE IN
                                  (SELECT DISTINCT (TPGCODE)
                                     FROM LKTPGAGE LK, ACTEURGESTION AG
                                    WHERE LK.ACTID = AG.ACTID)))
            ORDER BY TPG.TPGCODE;
    END S_PREFEVENT_LSTPREFEVENTTPG;

    PROCEDURE S_PREFEVENT_LSTPREFEVENTACT (SUGECODE    IN     VARCHAR2, -- SEND FROM BEAN
                                           SLANGUE     IN     VARCHAR2,
                                           PC_RETURN   IN OUT T_CURSOR)
    AS
    --sLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT A.TACCODE AS CODE, B.TACLIBELLE AS DISPLAYVALUE
                FROM TACTIVITE A, LANTACTIVITE B
               WHERE B.LANCODE = SLANGUE AND B.TACCODE = A.TACCODE
            ORDER BY A.TACCODE;
    END S_PREFEVENT_LSTPREFEVENTACT;

    PROCEDURE S_PREEVENT (SPHADEST                 IN     VARCHAR2,
                          SPHAPREFEVENT            IN     VARCHAR2,
                          SACTPREFEVENT            IN     VARCHAR2,
                          STPGPREFEVENT            IN     VARCHAR2,
                          SENTITEMODULEPREFEVENT   IN     VARCHAR2,
                          SLANGUE                  IN     VARCHAR2,
                          PC_RETURN                IN OUT T_CURSOR)
    AS
    --sLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
            SELECT LKT.TMFFONCTION,
                   LTE.TEVLIBELLE,
                   1 LKTFLAGVALUE,
                   1
              FROM LANTEVENEMENT LTE, LKTPGTACTEVPHA LKT
             WHERE     LKT.PHACODE = SPHAPREFEVENT
                   AND LKT.PHADEST = SPHADEST
                   AND LKT.TEVDEST = SPHADEST
                   AND LKT.TMOMODULE = SENTITEMODULEPREFEVENT
                   AND LTE.TACCODE = LKT.TACCODE
                   AND LKT.TPGCODE = STPGPREFEVENT
                   AND LKT.TACCODE = SACTPREFEVENT
                   AND LTE.TEVDEST = LKT.TEVDEST
                   AND LKT.TMFFONCTION = LTE.TMFFONCTION
                   AND LKT.TMOMODULE = LTE.TMOMODULE
                   AND LTE.LANCODE = SLANGUE
            UNION
            SELECT TEV.TMFFONCTION,
                   LTE.TEVLIBELLE,
                   0 LKTFLAGVALUE,
                   0
              FROM LANTEVENEMENT LTE, TEVPHA TEV
             WHERE     TEV.PHACODE = SPHAPREFEVENT
                   AND TEV.PHADEST = SPHADEST
                   AND TEV.TEVDEST = SPHADEST
                   AND TEV.TMOMODULE = SENTITEMODULEPREFEVENT
                   AND LTE.TACCODE = TEV.TACCODE
                   AND TEV.TACCODE = SACTPREFEVENT
                   AND LTE.TEVDEST = TEV.TEVDEST
                   AND TEV.TMFFONCTION = LTE.TMFFONCTION
                   AND LTE.LANCODE = SLANGUE
                   AND TEV.TMFFONCTION NOT IN
                           (SELECT TTT.TMFFONCTION
                              FROM LKTPGTACTEVPHA TTT
                             WHERE     TTT.PHACODE = SPHAPREFEVENT
                                   AND TTT.PHADEST = SPHADEST
                                   AND TTT.TEVDEST = SPHADEST
                                   AND TTT.TMOMODULE = SENTITEMODULEPREFEVENT
                                   AND TTT.TPGCODE = STPGPREFEVENT
                                   AND TTT.TACCODE = SACTPREFEVENT)
            ORDER BY TEVLIBELLE;
    END S_PREEVENT;

    PROCEDURE S_PARAMNORMEPAYS (SLANGUE     IN     VARCHAR2,
                                PC_RETURN   IN OUT T_CURSOR)
    AS
    --sLangue LANGUE.LANCODE%TYPE := Pa_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT PAY.PAYCODE,
                     LPA.PAYLIBELLE,
                     PAY.DEVCODE,
                     PAY.PAYFLAGREGION,
                     PAY.PAYTEL,
                     PAY.PAYFORMATPOST,
                     PAY.PAYNBCARIBAN,
                     PAY.PAYFLAGBANQUE,
                     PAY.PAYFORMATBANQUE,
                     PAY.PAYFLAGGUICHET,
                     PAY.PAYFORMATGUICHET,
                     PAY.PAYFORMATCOMPTE,
                     PAY.PAYFLAGCLERIB,
                     PAY.PAYFORMATCLERIB,
                     PAY.PAYFLAGSIRET,
                     PAY.PAYFORMATSIRET,
                     PAY.PAYREGLEIBAN,
                     LDE.DEVNOM
                FROM PAYS PAY, LANPAYS LPA, LANDEVISE LDE
               WHERE     PAY.PAYCODE(+) = LPA.PAYCODE
                     AND LPA.LANCODE(+) = SLANGUE
                     AND LDE.DEVCODE(+) = PAY.DEVCODE
                     AND LDE.LANCODE(+) = SLANGUE
            ORDER BY PAY.PAYCODE;
    END S_PARAMNORMEPAYS;

    PROCEDURE S_PAYREGION (SPAYCODE    IN     PAYS.PAYCODE%TYPE,
                           SLANGUE     IN     VARCHAR2,
                           PC_RETURN   IN OUT T_CURSOR)
    AS
    --sLangue LANGUE.LANCODE%TYPE := Pa_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT A.PRECODE, B.PRELIBELLE, C.TTPLIBELLE
                FROM LANPAYREGION B, PAYREGION A, LANTTRPARAM C
               WHERE     A.PAYCODE = SPAYCODE
                     AND B.PAYCODE(+) = A.PAYCODE
                     AND A.PRECODE = B.PRECODE(+)
                     AND B.LANCODE(+) = SLANGUE
                     AND C.TTPCODE(+) = A.PRETYPE
                     AND C.TTRNOM(+) = 'TYPAREA'
                     AND C.LANCODE(+) = SLANGUE
            ORDER BY PRECODE;
    END S_PAYREGION;

    PROCEDURE S_STEPSHUTTLE (
        SENTITEMAITREJALPHA          PHASE.PHADEST%TYPE,
        SPHAJAL                      PHAJAL.PHACODE%TYPE,
        STPGJAL                      LKTPGTACPHAJAL.TPGCODE%TYPE,
        SACTJAL                      LKTPGTACPHAJAL.TACCODE%TYPE,
        SLANGUE               IN     VARCHAR2,
        PC_RETURN             IN OUT T_CURSOR)
    AS
    --slangue lANDocument.lancode%TYPE := pa_global_declare.sglangue;
    BEGIN
        DECLARE
        BEGIN
            OPEN PC_RETURN FOR
                SELECT JAL.JALCODE,
                       LJA.JALLIBELLE,
                       1 LKTFLAGVALUE,
                       1,
                       LKT.TPJORDRE,
                       LKT.TPJFLAGDEFAULT
                  FROM LANJALON LJA, PHAJAL JAL, LKTPGTACPHAJAL LKT
                 WHERE     LKT.JALCODE = JAL.JALCODE
                       AND LKT.PHACODE = JAL.PHACODE
                       AND LKT.PHADEST = JAL.PHADEST
                       AND JAL.PHADEST = SENTITEMAITREJALPHA
                       AND JAL.PHACODE = SPHAJAL
                       AND LJA.JALCODE = JAL.JALCODE
                       AND LJA.LANCODE = SLANGUE
                       AND LKT.TPGCODE = STPGJAL
                       AND LKT.TACCODE = SACTJAL
                UNION
                SELECT JAL.JALCODE,
                       LJA.JALLIBELLE,
                       0 LKTFLAGVALUE,
                       0,
                       0 TPJORDRE,
                       0 TPJFLAGDEFAULT
                  FROM LANJALON LJA, PHAJAL JAL
                 WHERE     JAL.PHADEST = SENTITEMAITREJALPHA
                       AND JAL.JALCODE = LJA.JALCODE
                       AND LJA.LANCODE = SLANGUE
                       AND JAL.PHACODE = SPHAJAL
                       AND JAL.JALCODE NOT IN
                               (SELECT DISTINCT LKT.JALCODE
                                  FROM LKTPGTACPHAJAL LKT, PHAJAL PJA
                                 WHERE     LKT.PHACODE = PJA.PHACODE
                                       AND LKT.PHADEST = PJA.PHADEST
                                       AND LKT.JALCODE = PJA.JALCODE
                                       AND LKT.PHACODE = SPHAJAL
                                       AND LKT.PHADEST = SENTITEMAITREJALPHA
                                       AND LKT.TPGCODE = STPGJAL
                                       AND LKT.TACCODE = SACTJAL)
                ORDER BY 5, 2;
        END;
    END S_STEPSHUTTLE;

    PROCEDURE S_NAF (SPAYCODE           PAYS.PAYCODE%TYPE,
                     SPAYS              PAYS.PAYCODE%TYPE,
                     SLANGUE     IN     VARCHAR2,
                     PC_RETURN   IN OUT T_CURSOR)
    AS
    --slangue lANDocument.lancode%TYPE := pa_global_declare.sglangue;
    BEGIN
        DECLARE
        BEGIN
            IF SPAYCODE = SPAYS
            THEN
                OPEN PC_RETURN FOR
                    SELECT A.NAFCODE    AS NAFCODE,
                           B.NAFLIBELLE AS NAFLIBELLE,
                           B.PAYCODE,
                           B.LANCODE
                      FROM LANNAF B, NAF A
                     WHERE     B.NAFCODE(+) = A.NAFCODE
                           AND B.PAYCODE(+) = A.PAYCODE
                           AND B.LANCODE(+) = SLANGUE
                           AND A.PAYCODE = SPAYCODE
                           AND (A.PAYCODE IS NULL OR A.PAYCODE = SPAYCODE);
            ELSE
                OPEN PC_RETURN FOR
                    SELECT A.NAFCODE AS NAFCODE, B.NAFLIBELLE AS NAFLIBELLE
                      FROM LANNAF B, NAF A
                     WHERE     B.NAFCODE(+) = A.NAFCODE
                           AND B.PAYCODE(+) = A.PAYCODE
                           AND B.LANCODE(+) = SLANGUE
                           AND A.PAYCODE = SPAYCODE;
            END IF;
        END;
    END S_NAF;

    PROCEDURE EVENT_TBLREPEVENT_DESC (
        STMOMODULE          IN     LANTMOFONCTION.TMOMODULE%TYPE,
        SENTITEMATREEVENT   IN     LANTMOFONCTION.TMOMODULE%TYPE,
        SLANGUE             IN     VARCHAR2,
        PC_RETURN           IN OUT T_CURSOR)
    AS
    --sLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
            SELECT TMFFONCTION AS CODE,
                   TMFLIBELLE  AS DISPLAYVALUE,
                   TMFLIBELLE  AS OTHERINFO
              FROM LANTMOFONCTION
             WHERE     LANCODE = SLANGUE
                   AND TMOMODULE = STMOMODULE
                   AND SUBSTR (TMFFONCTION, 1, 2) = 'U_'
                   AND TMFFONCTION NOT IN
                           (SELECT TMFFONCTION
                              FROM LANTEVENEMENT
                             WHERE     LANCODE = SLANGUE
                                   AND TMOMODULE = SENTITEMATREEVENT
                                   AND SUBSTR (TMFFONCTION, 1, 2) = 'U_');
    END EVENT_TBLREPEVENT_DESC;

    PROCEDURE EVENT_TBLREPEVENT_DESC (
        STMOMODULE     IN     LANTMOFONCTION.TMOMODULE%TYPE,
        STMFFONCTION   IN     LANTMOFONCTION.TMFFONCTION%TYPE,
        SLANGUE        IN     VARCHAR2,
        PC_RETURN      IN OUT T_CURSOR)
    AS
    --sLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
            SELECT TMFFONCTION AS CODE, TMFLIBELLE AS DISPLAYVALUE
              FROM LANTMOFONCTION
             WHERE     LANCODE = SLANGUE
                   AND TMOMODULE = STMOMODULE
                   AND SUBSTR (TMFFONCTION, 1, 2) = 'U_'
                   AND TMFFONCTION = STMFFONCTION;
    END EVENT_TBLREPEVENT_DESC;

    PROCEDURE S_PHASESLIST (SPCODEDEST    IN     PHASE.PHADEST%TYPE,
                            SMTACCODE     IN     TEVENEMENT.TACCODE%TYPE,
                            SPCODEEVENT   IN     TEVENEMENT.TMFFONCTION%TYPE,
                            SLANGUE       IN     VARCHAR2,
                            PC_RETURN     IN OUT T_CURSOR)
    AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
            SELECT PHA.PHAORDRE,
                   PHA.PHACODE    AS CODE,
                   LPH.PHALIBELLE AS DISPLAYVALUE,
                   1              AS OTHERINFO
              FROM PHASE       PHA,
                   LANPHASE    LPH,
                   TEVENEMENT  TEV,
                   TEVPHA      TPH
             WHERE     PHA.PHADEST = SPCODEDEST
                   AND PHA.PHACODE = LPH.PHACODE
                   AND LPH.LANCODE = SLANGUE
                   AND PHA.PHADEST = LPH.PHADEST
                   AND PHA.PHACODE = TPH.PHACODE
                   AND PHA.PHADEST = TPH.PHADEST
                   AND TEV.TEVDEST = TPH.TEVDEST
                   AND TEV.TMOMODULE = TPH.TMOMODULE
                   AND TEV.TMFFONCTION = TPH.TMFFONCTION
                   AND TEV.TACCODE = SMTACCODE
                   AND TEV.TACCODE = TPH.TACCODE
                   AND TEV.TMFFONCTION = SPCODEEVENT
            UNION
            SELECT PHA.PHAORDRE,
                   PHA.PHACODE,
                   LPH.PHALIBELLE,
                   0 AS OTHERINFO
              FROM PHASE PHA, LANPHASE LPH
             WHERE     PHA.PHADEST = SPCODEDEST
                   AND PHA.PHACODE = LPH.PHACODE
                   AND LPH.LANCODE = SLANGUE
                   AND PHA.PHADEST = LPH.PHADEST
                   AND PHA.PHACODE NOT IN
                           (SELECT TPH.PHACODE
                              FROM TEVPHA TPH, TEVENEMENT TEV
                             WHERE     TPH.TEVDEST = TEV.TEVDEST
                                   AND TPH.TMFFONCTION = TEV.TMFFONCTION
                                   AND TPH.TMOMODULE = TEV.TMOMODULE
                                   AND PHA.PHADEST = TPH.PHADEST
                                   AND TPH.TACCODE = SMTACCODE
                                   AND TPH.TACCODE = TEV.TACCODE
                                   AND TPH.TEVDEST = SPCODEDEST
                                   AND TEV.TMFFONCTION = SPCODEEVENT)
            ORDER BY PHAORDRE;
    END S_PHASESLIST;

    PROCEDURE S_BUSTYPESLIST (SLANGUE IN VARCHAR2, PC_RETURN IN OUT T_CURSOR)
    AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT A.TACCODE AS CODE, B.TACLIBELLE AS DISPLAYVALUE
                FROM TACTIVITE A, LANTACTIVITE B
               WHERE     A.TACCODE != 'GLOBAL'
                     AND B.LANCODE(+) = SLANGUE
                     AND B.TACCODE = A.TACCODE
            ORDER BY A.TACCODE;
    END S_BUSTYPESLIST;

    PROCEDURE S_PRODUCTLIST (
        SWACTPREFRUB   IN     TPROFILGESTION.TACCODE%TYPE,
        SLANGUE        IN     VARCHAR2,
        PC_RETURN      IN OUT T_CURSOR)
    AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT TPG.TPGCODE
                         AS CODE,
                     (SELECT LTP.TPGLIBELLE
                        FROM LANTPROFILGESTION LTP
                       WHERE     LTP.TPGCODE = TPG.TPGCODE
                             AND LTP.LANCODE = SLANGUE)
                         AS DISPLAYVALUE
                FROM TPROFILGESTION TPG
               WHERE     TPG.TACCODE = SWACTPREFRUB
                     AND TPG.TPGCODE IN (SELECT DISTINCT (TPGCODE)
                                           FROM LKTPGAGE LK, ACTEURGESTION AG
                                          WHERE LK.ACTID = AG.ACTID)
            ORDER BY TPG.TPGCODE;
    END S_PRODUCTLIST;

    PROCEDURE S_RELANCE (NACTID      IN     RELANCE.ACTID%TYPE,
                         STACCODE    IN     RELANCE.TACCODE%TYPE,
                         SROLCODE    IN     RELANCE.ROLCODE%TYPE,
                         PC_RETURN   IN OUT T_CURSOR)
    AS
        SLANGUE   LANDOCUMENT.LANCODE%TYPE := PA_GLOBAL_DECLARE.SGLANGUE;
    BEGIN
        DECLARE
        BEGIN
            OPEN PC_RETURN FOR
                  SELECT ACTID,
                         TACCODE,
                         ROLCODE,
                         RELORDRE,
                         RELCODE,
                         RELDELAIGRACE,
                         TPGCODE,
                         DEVCODEFEE,
                         RELMTFEE,
                         RUBIDFEE
                    FROM RELANCE
                   WHERE     ACTID = NACTID
                         AND TACCODE = STACCODE
                         AND ROLCODE = SROLCODE
                ORDER BY RELORDRE;
        END;
    END S_RELANCE;

    PROCEDURE S_LKRELFOR (NACTID      IN     LKRELFOR.ACTID%TYPE,
                          SROLCODE    IN     LKRELFOR.ROLCODE%TYPE,
                          NRELORDRE   IN     LKRELFOR.RELORDRE%TYPE,
                          STACCODE    IN     LKRELFOR.TACCODE%TYPE,
                          SRELCODE    IN     LKRELFOR.RELCODE%TYPE,
                          PC_RETURN   IN OUT T_CURSOR)
    AS
        SLANGUE   LANDOCUMENT.LANCODE%TYPE := PA_GLOBAL_DECLARE.SGLANGUE;
    BEGIN
        DECLARE
        BEGIN
            OPEN PC_RETURN FOR
                SELECT FORID,
                       ACTID,
                       ROLCODE,
                       RELORDRE,
                       TACCODE,
                       RELCODE
                  FROM LKRELFOR
                 WHERE     ACTID = NACTID
                       AND ROLCODE = SROLCODE
                       AND RELORDRE = NRELORDRE
                       AND TACCODE = STACCODE
                       AND RELCODE = SRELCODE;
        END;
    END S_LKRELFOR;

    PROCEDURE S_PAYREGION_TREE (SLANGUE     IN     VARCHAR2,
                                PC_RETURN   IN OUT T_CURSOR)
    AS
    --sLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        DECLARE
            MAXCOUNT   NUMBER;
        BEGIN
            SELECT PSYMAXSELECT INTO MAXCOUNT FROM PARSYSTEME;

            OPEN PC_RETURN FOR
                  SELECT LPRE.PAYCODE,
                         LPAY.PAYLIBELLE,
                         LPRE.PRECODE,
                         LPRE.PRELIBELLE,
                         LPRE.PRETYPE
                    FROM LANPAYREGION LPRE, LANPAYS LPAY
                   WHERE     LPRE.LANCODE = SLANGUE
                         AND LPAY.LANCODE = SLANGUE  --LG 01/04/2003 FSA 11753
                         AND LPRE.PAYCODE = LPAY.PAYCODE
                         AND ROWNUM < MAXCOUNT
                ORDER BY LPAY.PAYLIBELLE, LPRE.PRELIBELLE;
        END;
    END S_PAYREGION_TREE;

    PROCEDURE S_PAYREGDEPT (SPAYCODE           PAYREGDEPT.PAYCODE%TYPE,
                            SPRECODE           PAYREGDEPT.PRECODE%TYPE,
                            SPRETYPE           PAYREGDEPT.PRETYPE%TYPE,
                            PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT PRDDEPT,
                     PRDLIBELLE,
                     PAYCODE,
                     PRECODE,
                     PRETYPE
                FROM PAYREGDEPT
               WHERE     PAYCODE = SPAYCODE
                     AND PRECODE = SPRECODE
                     AND PRETYPE = SPRETYPE
            ORDER BY PRDDEPT;
    END S_PAYREGDEPT;

    PROCEDURE S_PRODUCTSLIST (SMTACCODE   IN     TEVENEMENT.TACCODE%TYPE,
                              SLANGUE     IN     VARCHAR2,
                              PC_RETURN   IN OUT T_CURSOR)
    AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        DECLARE
            SUGECODE   UTILISATEUR.UGECODE%TYPE := F_GETCURRENTUGECODE;
        BEGIN
            OPEN PC_RETURN FOR
                  SELECT DISTINCT
                         LKT.TPGCODE AS CODE, LTP.TPGLIBELLE AS DISPLAYVALUE, 0
                    FROM LKTPGAGE         LKT,
                         TPROFILGESTION   TPG,
                         LANTPROFILGESTION LTP
                   WHERE     LKT.TPGCODE = TPG.TPGCODE
                         AND TPG.TPGCODE = LTP.TPGCODE
                         AND LTP.LANCODE = SLANGUE
                         AND TPG.TACCODE = SMTACCODE
                         AND TPG.TPGCODE IN
                                 (SELECT DISTINCT TPGCODE
                                    FROM LKTPGAGE A, ACTEUR B
                                   WHERE     B.ACTID = A.ACTID
                                         AND B.UGECODE = SUGECODE)
                ORDER BY 1;
        END;
    END S_PRODUCTSLIST;

    PROCEDURE S_TAMOLOIFISC (STLFTYPE    IN     TAMOLOIFISC.TLFCODE%TYPE,
                             SLANGUE     IN     VARCHAR2,
                             PC_RETURN   IN OUT T_CURSOR)
    AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        DECLARE
        BEGIN
            OPEN PC_RETURN FOR SELECT TLFTYPE, TLFFLAGDUREECONT
                                 FROM TAMOLOIFISC
                                WHERE TLFCODE = STLFTYPE;
        END;
    END S_TAMOLOIFISC;

    PROCEDURE S_TRELATION (PC_RETURN IN OUT T_CURSOR)
    AS
        SLANGUE   LANTRELATION.LANCODE%TYPE := PA_GLOBAL_DECLARE.SGLANGUE;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT TRE.TRECODE,
                     LTR.TRELIBELLEASC,
                     LTR.TRELIBELLEDESC,
                     TRE.TREFLAGORFI,
                     TRE.TREFLAGQP,
                     TREFLAGPROPRIETE
                FROM TRELATION TRE, LANTRELATION LTR
               WHERE TRE.TRECODE = LTR.TRECODE AND LTR.LANCODE = SLANGUE
            ORDER BY 1;
    END S_TRELATION;

    PROCEDURE S_TREATTRIBUTE (STRECODE    IN     TREATTRIBUTE.TRECODE%TYPE,
                              PC_RETURN   IN OUT T_CURSOR)
    AS
        SLANGUE   LANTRELATION.LANCODE%TYPE := PA_GLOBAL_DECLARE.SGLANGUE;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT TAT.TATATTRIBUTE, LAT.TATNAME, TAT.TRECODE
                FROM TREATTRIBUTE TAT, LANTREATTRIBUTE LAT
               WHERE     TAT.TRECODE = LAT.TRECODE
                     AND TAT.TATATTRIBUTE = LAT.TATATTRIBUTE
                     AND TAT.TRECODE = STRECODE
                     AND LAT.LANCODE = SLANGUE
            ORDER BY TAT.TATATTRIBUTE;
    END S_TREATTRIBUTE;

    PROCEDURE S_TREPRODETAIL (
        STRECODE        IN     TREPRODETAIL.TRECODE%TYPE,
        STATATTRIBUTE   IN     TREPRODETAIL.TATATTRIBUTE%TYPE,
        PC_RETURN       IN OUT T_CURSOR)
    AS
        SLANGUE   LANTRELATION.LANCODE%TYPE := PA_GLOBAL_DECLARE.SGLANGUE;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT TDE.TDEVALUE,
                     LDE.TDENAME,
                     TDE.TATATTRIBUTE,
                     TDE.TRECODE
                FROM TREPRODETAIL TDE, LANTREPRODETAIL LDE
               WHERE     TDE.TRECODE = STRECODE
                     AND TDE.TATATTRIBUTE = STATATTRIBUTE
                     AND TDE.TATATTRIBUTE = LDE.TATATTRIBUTE
                     AND TDE.TDEVALUE = LDE.TDEVALUE
                     AND TDE.TRECODE = LDE.TRECODE
                     AND LDE.LANCODE = 'EN'
            ORDER BY TDE.TDEVALUE;
    END S_TREPRODETAIL;

    PROCEDURE S_PHACTL_TBLSTATCONTROLE (
        SUGECODE               IN     VARCHAR2,
        SWPARA                 IN     VARCHAR2                 --Paraghra list
                                              ,
        SWACTIV                IN     VARCHAR2                    --Activ list
                                              ,
        SWENTITEMAITREPHACTL   IN     VARCHAR2                  --target combo
                                              ,
        SWPHACTL               IN     VARCHAR2                   --phASe combo
                                              ,
        SWPROFIL               IN     VARCHAR2                  --Profil combo
                                              ,
        SGLANGUE               IN     VARCHAR2,
        PC_RETURN              IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT A.TTCLIBELLE,
                     NVL (B.PTCFLAGACTIF, 0) AS ORFI,
                     NVL (B.PTCFLAGDEFAUT, 0) AS DEFAULTCOL,
                     D.TTPCODE,
                     D.TTPLIBELLE,
                     B.TTCCODE,
                     C.TACLIBELLE,
                     B.TACCODE,
                     B.PHACODE,
                     B.PHADEST
                FROM LANTPCTACCONTROLE A,
                     LKPHATTC         B,
                     LANTACTIVITE     C,
                     LANTTRPARAM      D,
                     TPCTACCONTROLE   E
               WHERE     (E.UGECODE = SUGECODE OR E.UGECODE IS NULL)
                     AND E.TPCCODE = SWPARA
                     AND E.TPCDEST = SWENTITEMAITREPHACTL
                     AND E.TACCODE IN (SWACTIV)
                     AND B.TTCCODE = E.TTCCODE
                     AND B.TACCODE = E.TACCODE
                     AND B.TPCCODE = E.TPCCODE
                     AND B.TPCDEST = E.TPCDEST
                     AND B.PHACODE = SWPHACTL
                     AND B.TACCODE = E.TACCODE
                     AND B.TPGCODE = SWPROFIL
                     AND A.TACCODE = B.TACCODE
                     AND A.TPCCODE = B.TPCCODE
                     AND A.TTCCODE = B.TTCCODE
                     AND A.TPCDEST = B.TPCDEST
                     AND A.TACCODE = B.TACCODE
                     AND A.LANCODE = SGLANGUE
                     AND C.LANCODE = SGLANGUE
                     AND C.TACCODE = B.TACCODE
                     AND D.LANCODE = SGLANGUE
                     AND D.TTRNOM = 'CONTROLSEVERITE'
                     AND D.TTPCODE = TO_CHAR (NVL (B.PTCFLAGUSER, 0))
            ORDER BY A.TTCLIBELLE;
    END S_PHACTL_TBLSTATCONTROLE;

    PROCEDURE S_DLGPARAMNORME_NACE (SGLANGUE           LANGUE.LANCODE%TYPE,
                                    PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT A.NACCODE, B.NACLIBELLE
                FROM LANNACE B, NACE A
               WHERE B.NACCODE(+) = A.NACCODE AND B.LANCODE(+) = SGLANGUE
            ORDER BY NACCODE;
    END S_DLGPARAMNORME_NACE;

    -- For Langue tab
    PROCEDURE S_DLGPARAMNORME_LANGUE (SGLANGUE           LANGUE.LANCODE%TYPE,
                                      PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT LAN.LANCODE, LLG.LANLIBELLE
                FROM LANLANGUE LLG, LANGUE LAN
               WHERE     LLG.LANCODE(+) = LAN.LANCODE
                     AND LLG.LANCODETRAD(+) = SGLANGUE
            ORDER BY LAN.LANCODE;
    END S_DLGPARAMNORME_LANGUE;

    PROCEDURE S_TUSPARAM (SGLANGUE IN VARCHAR2, PC_RETURN IN OUT T_CURSOR)
    AS
    --sgLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR SELECT TUPCODE, TUPLIBELLE
                             FROM LANTUSPARAM
                            WHERE TUSNOM = 'SINNATURE' AND LANCODE = SGLANGUE;
    END S_TUSPARAM;

    PROCEDURE S_TTRPARAM_SINNATURE (SGLANGUE    IN     VARCHAR2,
                                    PC_RETURN   IN OUT T_CURSOR)
    AS
    --sgLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
            SELECT TTR.TTPCODE, LTP.TTPLIBELLE
              FROM TTRPARAM TTR, LANTTRPARAM LTP
             WHERE     TTR.TTRNOM = LTP.TTRNOM
                   AND TTR.TTRNOM = 'ASSURNATURE'
                   AND TTR.TTPCODE = LTP.TTPCODE
                   AND LTP.LANCODE = SGLANGUE;
    END S_TTRPARAM_SINNATURE;

    PROCEDURE S_TTRPARAM_RHS (STUPCODE    IN     LKTUSTTR.TUPCODE%TYPE,
                              SGLANGUE    IN     VARCHAR2,
                              PC_RETURN   IN OUT T_CURSOR)
    AS
    --sgLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
            SELECT TTR.TTPCODE, LTP.TTPLIBELLE
              FROM TTRPARAM TTR, LANTTRPARAM LTP, LKTUSTTR TUT
             WHERE     TTR.TTRNOM = LTP.TTRNOM
                   AND TTR.TTRNOM = 'ASSURNATURE'
                   AND TTR.TTPCODE = LTP.TTPCODE
                   AND LTP.LANCODE = SGLANGUE
                   AND TTR.TTPCODE = TUT.TTPCODE
                   AND TUT.TUSNOM = 'SINNATURE'
                   AND TUT.TUPCODE = STUPCODE
                   AND TUT.TTRNOM = 'ASSURNATURE';
    END S_TTRPARAM_RHS;

    PROCEDURE S_LKTSMFOR_TREE (NFORID      IN     LKTSMFOR.FORID%TYPE,
                               SLANGUE     IN     VARCHAR2,
                               SUSER       IN     VARCHAR2,
                               PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        DECLARE
            MAXCOUNT   NUMBER;
        BEGIN
            SELECT PSYMAXSELECT INTO MAXCOUNT FROM PARSYSTEME;

            OPEN PC_RETURN FOR
                  SELECT FORID,
                         TSMSECTGESTION,
                         TSMMETIER,
                         ALLIBTSMSECTGESTION,
                         ALLIBTSMMETIER,
                         ALFLAGLKTSMFORINCDEB,
                         ALFLAGLKTSMFORINCLUS
                    FROM (SELECT LTF.FORID,
                                 TSM.TSMSECTGESTION
                                     TSMSECTGESTION,
                                 TSM.TSMMETIER
                                     TSMMETIER,
                                 LD3.DPTLABEL
                                     ALLIBTSMSECTGESTION,
                                 LTUS4.TUPLIBELLE
                                     ALLIBTSMMETIER,
                                 0
                                     ALFLAGLKTSMFORINCDEB,
                                 DECODE (FORID, NULL, 0, 1)
                                     ALFLAGLKTSMFORINCLUS
                            FROM TSECTEURMETIER TSM,
                                 LANDEPARTMENT LD3,
                                 LANTUSPARAM   LTUS4,
                                 LKTSMFOR      LTF
                           WHERE     LD3.DPTCODE = TSM.TSMSECTGESTION
                                 AND LTUS4.TUSNOM = 'METIER'
                                 AND LTUS4.TUPCODE = TSM.TSMMETIER
                                 AND LTUS4.LANCODE = SLANGUE
                                 AND LD3.LANCODE = SLANGUE
                                 AND LTF.TSMSECTGESTION(+) = TSM.TSMSECTGESTION
                                 AND LTF.TSMMETIER(+) = TSM.TSMMETIER
                                 AND LTF.FORID(+) = NFORID)
                   WHERE ROWNUM < MAXCOUNT
                ORDER BY ALLIBTSMMETIER;
        END;
    END S_LKTSMFOR_TREE;

    PROCEDURE S_BUSINESSTYPE_LHS (SLANGUE     IN     VARCHAR2,
                                  PC_RETURN   IN OUT T_CURSOR)
    AS
    --sLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
            SELECT A.TACCODE, TACLIBELLE, 0
              FROM TACTIVITE A, LANTACTIVITE TL
             WHERE     A.TACCODE != 'GLOBAL'
                   AND TL.TACCODE(+) = A.TACCODE
                   AND TL.LANCODE = SLANGUE;
    END S_BUSINESSTYPE_LHS;

    PROCEDURE S_BUSINESSTYPE_RHS (NACTID             ACTEUR.ACTID%TYPE,
                                  SLANGUE     IN     VARCHAR2,
                                  PC_RETURN   IN OUT T_CURSOR)
    AS
    --sLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT A.TACCODE, TL.TACLIBELLE, 0
                FROM TACACTGESTION A, LANTACTIVITE TL
               WHERE     ACTID = NACTID
                     AND TL.TACCODE(+) = A.TACCODE
                     AND TL.LANCODE = SLANGUE
            ORDER BY A.TACCODE;
    END S_BUSINESSTYPE_RHS;

    PROCEDURE S_TSECTMET_TREE (SGLANGUE    IN     VARCHAR2,
                               PC_RETURN   IN OUT T_CURSOR)
    AS
    --sgLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        DECLARE
            MAXCOUNT   NUMBER;
        BEGIN
            SELECT PSYMAXSELECT INTO MAXCOUNT FROM PARSYSTEME;

            OPEN PC_RETURN FOR
                  SELECT TSM.TSMSECTGESTION ALTSMSECTGESTION,
                         TSM.TSMMETIER    ALTSMMETIER,
                         LD1.DPTLABEL     ALTSMLIBSECTGESTION,
                         LTUS2.TUPLIBELLE ALTSMLIBMETIER
                    FROM TSECTEURMETIER TSM,
                         LANDEPARTMENT LD1,
                         LANTUSPARAM   LTUS2
                   WHERE     LD1.DPTCODE = TSM.TSMSECTGESTION
                         AND LD1.LANCODE = SGLANGUE
                         --AND LTUS1.TUSNOM = 'SECTEURGEST'
                         AND LTUS2.TUSNOM = 'METIER'
                         AND LTUS2.TUPCODE = TSM.TSMMETIER
                         AND LTUS2.LANCODE = SGLANGUE
                         AND ROWNUM < MAXCOUNT
                ORDER BY TSM.TSMSECTGESTION;
        END;
    END S_TSECTMET_TREE;

    PROCEDURE S_TSECTMETIER_TREE (SGLANGUE    IN     VARCHAR2,
                                  PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        DECLARE
            MAXCOUNT   NUMBER;
        BEGIN
            SELECT PSYMAXSELECT INTO MAXCOUNT FROM PARSYSTEME;

            OPEN PC_RETURN FOR
                SELECT DPT.DPTCODE,
                       LANDPT.DPTLABEL,
                       DPT.DPTCODEPARENT
                           AS DPTCODEPARENT,
                       (SELECT LANDPT2.DPTLABEL
                          FROM LANDEPARTMENT LANDPT2
                         WHERE     DPT.DPTCODEPARENT = LANDPT2.DPTCODE
                               AND LANDPT2.LANCODE = SGLANGUE)
                           AS DPTPARENTLABEL
                  FROM DEPARTMENT DPT, LANDEPARTMENT LANDPT
                 WHERE     DPT.DPTCODE = LANDPT.DPTCODE
                       AND LANDPT.LANCODE = SGLANGUE
                       AND ROWNUM < MAXCOUNT;
        END;
    END S_TSECTMETIER_TREE;

    PROCEDURE S_UTITSM (
        SCODESECTGESTION          TSECTEURMETIER.TSMSECTGESTION%TYPE,
        SCODEMETIER               TSECTEURMETIER.TSMMETIER%TYPE,
        SPUGECODE                 UTILISATEUR.UGECODE%TYPE,
        PC_RETURN          IN OUT T_CURSOR)
    AS
    BEGIN
        DECLARE
            MAXCOUNT   NUMBER;
        BEGIN
            SELECT PSYMAXSELECT INTO MAXCOUNT FROM PARSYSTEME;

            OPEN PC_RETURN FOR
                  SELECT LKT.UTICODE,
                         UTI.UTINOM,
                         LKT.TSMINCOMINGPATH,
                         UTI.UTIPRENOM,
                         LKT.TSMFLAGSUPERVISEUR,
                         LKT.TSMDTSTART,
                         LKT.TSMDTEND,
                         TSMFLAGDEFAUT,
                         TSMSECTGESTION
                             AS DPTCODE,
                         TSMMETIER,
                         GET_UTICODELINKED (LKT.UTICODE,
                                            SCODESECTGESTION,
                                            SCODEMETIER)
                             UTICODELINKED,
                         GET_UTIEXTERNALREFERENCE (LKT.UTICODE)
                             EMPUTIEXTERNALREFERENCE,
                         GET_UTIEXTERNALREFERENCE (
                             GET_UTICODELINKED (LKT.UTICODE,
                                                SCODESECTGESTION,
                                                SCODEMETIER))
                             LEADUTIEXTERNALREFERENCE,
                         (SELECT ULIORDRE
                            FROM UTIUSERLINK
                           WHERE     UTICODE LIKE LKT.UTICODE
                                 AND UTICODELINKED LIKE
                                         GET_UTICODELINKED (LKT.UTICODE,
                                                            SCODESECTGESTION,
                                                            SCODEMETIER))
                             ULIORDRE,
                         TSMCOUNEGE,
                         TSMCOUNGR,
                         TSMPARTNAME,
                         TSMFLAGLEADER,
                         LKT.TSMTEAMCODE,
                         (SELECT UTINOM || ' ' || UTIPRENOM
                            FROM UTILISATEUR
                           WHERE UTICODE LIKE
                                     GET_UTICODELINKED (LKT.UTICODE,
                                                        SCODESECTGESTION,
                                                        SCODEMETIER))
                             PARTLEADNAME
                    FROM UTITSM LKT, UTILISATEUR UTI
                   WHERE     LKT.TSMSECTGESTION IN
                                 (SELECT DPTCODE
                                    FROM DEPARTMENT
                                   WHERE (   DPTCODE = SCODESECTGESTION
                                          OR DPTCODEPARENT = SCODESECTGESTION))
                         AND LKT.TSMMETIER = SCODEMETIER
                         AND LKT.UTICODE = UTI.UTICODE
                         AND UTI.UGECODE = SPUGECODE
                         AND (LKT.TSMDTEND IS NULL OR LKT.TSMDTEND >= SYSDATE)
                         AND ROWNUM < MAXCOUNT
                ORDER BY LKT.UTICODE;
        END;
    END S_UTITSM;

    PROCEDURE S_GESFORMALITE (SUGECODE    IN     FORMALITE.UGECODE%TYPE,
                              STACCODE    IN     FORMALITE.TACCODE%TYPE,
                              SFORDEST    IN     FORMALITE.FORDEST%TYPE,
                              SLANCODE           LANGUE.LANCODE%TYPE,
                              PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT FRM.FORID,
                     FRM.FORCODE,
                     FRM.TACCODE,
                     FRM.FORDEST,
                     FRM.FORFLAGOBLIG,
                     FRM.FORFLAGDOCEMIS,
                     FRM.FORDELAIEMIS,
                     FRM.FORFLAGREPONSE,
                     FRM.FORDELAIREP,
                     FRM.FORFLAGFORRAPPEL,
                     LFO.FORLIBELLE,
                     FRM.FORTYPEDATE,
                     LT1.TTPLIBELLE,
                     FRM.FORMODELANCEMENT,
                     FRM.FORIDRAPPEL,
                     FRM.FORFLAGRECURRENT,
                     FRM.FORJOUR,
                     FRM.FORMOIS,
                     FRM.FORMULTIPLE,
                     FORDELAIREACTIVATION,
                     FRM.FORPERIODE,
                     FRM.FORPRIORITY,
                     FRM.FORPEREMIS,
                     FRM.FORPERACT,
                     FRM.FORPERREP,
                     FRM.FORPERREPONSE,
                     FRM.FORTYPE,
                     FRM.FORTYPEMSG,
                     FRM.ANMID,
                     FRM.FORTELTYPE,
                     FRM.FORFLAGREMINDER,
                     FRM.FORREMMETHOD,
                     FRM.FORREMPERIODBEFORE,
                     FRM.FORREMMULTIPLEBEFORE,
                     FRM.FORREMPERIODAFTER,
                     FRM.FORREMMULTIPLEAFTER,
                     FRM.FORDTFREQUENCYTIME,
                     FRM.FORMESSAGE,
                     FRM.FORPROCRUN,
                     FRM.FORTYPERECURRENCE
                FROM FORMALITE   FRM,
                     LANFORMALITE LFO,
                     LANTTRPARAM LTP,
                     LANTTRPARAM LT1
               WHERE     FRM.UGECODE = SUGECODE
                     AND FRM.TACCODE = STACCODE
                     AND FRM.FORDEST = SFORDEST
                     AND (FRM.FORID = LFO.FORID AND LFO.LANCODE = SLANCODE)
                     AND (    FRM.FORTYPEDATE = LTP.TTPCODE(+)
                          AND LTP.TTRNOM(+) = 'CONTRATDATE'
                          AND LTP.LANCODE(+) = SLANCODE)
                     AND (    FRM.FORMODELANCEMENT = LT1.TTPCODE(+)
                          AND LT1.TTRNOM(+) = 'MODEDECLENCH'
                          AND LT1.LANCODE(+) = SLANCODE)
            ORDER BY LFO.FORLIBELLE;
    END S_GESFORMALITE;

    PROCEDURE S_LINKEDTASKS (SFORDEST    IN     VARCHAR2,
                             STACCODE    IN     VARCHAR2,
                             NFORID      IN     NUMBER,
                             SUGECODE    IN     VARCHAR2,
                             SLANGUE     IN     VARCHAR2,
                             PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        DECLARE
            MAXCOUNT   NUMBER;
        BEGIN
            SELECT PSYMAXSELECT INTO MAXCOUNT FROM PARSYSTEME;

            OPEN PC_RETURN FOR
                  SELECT LF.FORID, LF.FORLIBELLE
                    FROM LANFORMALITE LF, FORMALITE FRM
                   WHERE     FRM.FORDEST = SFORDEST
                         AND FRM.TACCODE = STACCODE
                         AND FRM.UGECODE = SUGECODE
                         AND LF.FORID = FRM.FORID
                         AND LF.FORID != NFORID
                         AND LF.LANCODE(+) = SLANGUE
                         --AND NOT EXISTS (
                         --SELECT FORIDLIEE
                         --FROM L1FORMALITE
                         --WHERE FORID = nForId
                         --AND FORIDLIEE = LF.FORID )
                         --AND NOT EXISTS (
                         --SELECT FORID
                         --FROM L1FORMALITE
                         --WHERE FORIDLIEE = nForId
                         --AND FORID = LF.FORID )
                         AND ROWNUM < MAXCOUNT
                ORDER BY NLSSORT (LF.FORLIBELLE);
        END;
    END S_LINKEDTASKS;

    PROCEDURE S_LINKEDSELECTEDTASKS (NFORID      IN     NUMBER,
                                     SLANGUE     IN     VARCHAR2,
                                     PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT LFO.FORID, LFO.FORLIBELLE
                FROM LANFORMALITE LFO, L1FORMALITE L1F
               WHERE     L1F.FORID = NFORID
                     AND LFO.FORID != NFORID
                     AND L1F.FORIDLIEE = LFO.FORID(+)
                     AND LFO.LANCODE = SLANGUE
            ORDER BY NLSSORT (LFO.FORLIBELLE);
    END S_LINKEDSELECTEDTASKS;

    PROCEDURE S_TSECTMET_SELECTED_TREE (NFORID             LKTSMFOR.FORID%TYPE,
                                        SPUSER             UTITSM.UTICODE%TYPE,
                                        SLANGUE            LANGUE.LANCODE%TYPE,
                                        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT LTF.TSMSECTGESTION,
                   LTF.TSMMETIER,
                   LD1.DPTLABEL     ALLIBTSMSECTGESTION,
                   LTUS2.TUPLIBELLE ALLIBTSMMETIER,
                   1                ALFLAGLKTSMFORINCDEB,
                   1                ALFLAGLKTSMFORINCLUS
              FROM LKTSMFOR LTF, LANDEPARTMENT LD1, LANTUSPARAM LTUS2
             WHERE                              --LTUS1.TUSNOM = 'SECTEURGEST'
                       LD1.DPTCODE = LTF.TSMSECTGESTION
                   AND LD1.LANCODE = SLANGUE
                   AND LTUS2.TUSNOM = 'METIER'
                   AND LTUS2.TUPCODE = LTF.TSMMETIER
                   AND LTUS2.LANCODE = SLANGUE
                   AND LTF.FORID = NFORID
            UNION
            SELECT TSM.TSMSECTGESTION,
                   TSM.TSMMETIER,
                   LD3.DPTLABEL     ALLIBTSMSECTGESTION,
                   LTUS4.TUPLIBELLE ALLIBTSMMETIER,
                   0                ALFLAGLKTSMFORINCDEB,
                   0                ALFLAGLKTSMFORINCLUS
              FROM TSECTEURMETIER  TSM,
                   UTITSM          USM,
                   LANDEPARTMENT   LD3,
                   LANTUSPARAM     LTUS4
             WHERE                              --LTUS3.TUSNOM = 'SECTEURGEST'
                       LD3.DPTCODE = TSM.TSMSECTGESTION
                   AND LD3.LANCODE = SLANGUE
                   AND LTUS4.TUSNOM = 'METIER'
                   AND LTUS4.TUPCODE = TSM.TSMMETIER
                   AND LTUS4.LANCODE = SLANGUE
                   AND (TSM.TSMSECTGESTION, TSM.TSMMETIER) NOT IN
                           (SELECT LTF2.TSMSECTGESTION, LTF2.TSMMETIER
                              FROM LKTSMFOR LTF2, UTITSM USM2
                             WHERE     LTF2.FORID = NFORID
                                   AND USM2.TSMSECTGESTION =
                                       LTF2.TSMSECTGESTION
                                   AND USM2.TSMMETIER = LTF2.TSMMETIER
                                   AND USM2.UTICODE = SPUSER)
                   AND USM.TSMSECTGESTION = TSM.TSMSECTGESTION
                   AND USM.TSMMETIER = TSM.TSMMETIER
                   AND USM.UTICODE = SPUSER;
    END S_TSECTMET_SELECTED_TREE;

    PROCEDURE S_LVNAP_LIST (SLANGUE     IN     LANNAP.LANCODE%TYPE,
                            SPAYCODE    IN     LANNAP.PAYCODE%TYPE,
                            PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR   SELECT NAPCODE, NAPLIBELLE
                               FROM LANNAP
                              WHERE LANCODE = SLANGUE AND PAYCODE = SPAYCODE
                           ORDER BY 1;
    END S_LVNAP_LIST;

    PROCEDURE S_TBLLOINAPACTIV (SACTIVITE     IN     TFUNAP.TACCODE%TYPE,
                                SNAP          IN     TFUNAP.NAPCODE%TYPE,
                                SREGIMEFISC   IN     TFUNAP.TRFCODE%TYPE,
                                SCONTEXTE     IN     TFUNAP.TUNCONTEXTE%TYPE,
                                SPAYCODE      IN     TFUNAP.PAYCODE%TYPE,
                                SLANGUE       IN     VARCHAR2,
                                PC_RETURN     IN OUT T_CURSOR)
    AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT B.TLFLIBELLE,
                     A.TACCODE,
                     A.NAPCODE,
                     B.TLFCODE,
                     A.TUNCONTEXTE,
                     TLF.TLFCODE,
                     TUNMINIAN,
                     A.PAYCODE,
                     A.TRFCODE,
                     TUNMINIMOIS,
                     TUNMAXIAN,
                     TUNMAXIMOIS,
                     TLF.TLFTYPE,
                     TLF.TLFFLAGDUREECONT
                FROM TFUNAP A, LANTAMOLOIFISC B, TAMOLOIFISC TLF
               WHERE     B.TLFCODE = A.TLFCODE
                     AND B.LANCODE = SLANGUE
                     AND A.TACCODE = SACTIVITE
                     AND A.NAPCODE = SNAP
                     AND A.TRFCODE = SREGIMEFISC
                     AND A.TUNCONTEXTE = SCONTEXTE
                     AND TLF.TLFCODE = A.TLFCODE
                     AND A.PAYCODE = SPAYCODE
            ORDER BY 1;
    END S_TBLLOINAPACTIV;

    PROCEDURE S_SHUTTERALLOCATION (
        SWACTPREFRUB   IN     LKTPGTACRUB.TACCODE%TYPE,
        SWPROFILRUB    IN     LKTPGTACRUB.TPGCODE%TYPE,
        SLANGUE        IN     VARCHAR2,
        PC_RETURN      IN OUT T_CURSOR)
    AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        DECLARE
            SUGECODE   UTILISATEUR.UGECODE%TYPE := F_GETCURRENTUGECODE;
        BEGIN
            OPEN PC_RETURN FOR
                SELECT RAS.RUBID,
                       NULL,
                       RL.RUBLIBELLE,
                       1 AS FLAGPREFRIGHT                 --,1 AS FLAGPREFLEFT
                  FROM LKTPGTACRUB RAS, RUBRIQUE RU, LANRUBRIQUE RL
                 WHERE     RU.UGECODE = SUGECODE
                       AND RAS.TPGCODE = SWPROFILRUB
                       AND RAS.TACCODE = SWACTPREFRUB
                       AND RAS.RUBID = RU.RUBID
                       AND RAS.RUBID = RL.RUBID
                       AND RL.LANCODE = SLANGUE
                UNION
                SELECT RU.RUBID,
                       RU.RUBCODE,
                       RL2.RUBLIBELLE,
                       0 AS FLAGPREFRIGHT                 --,0 AS FLAGPREFLEFT
                  FROM RUBRIQUE RU, LANRUBRIQUE RL2
                 WHERE     RU.RUBID = RL2.RUBID
                       AND RU.UGECODE = SUGECODE
                       AND RL2.LANCODE = SLANGUE
                       AND RU.RUBID NOT IN
                               (SELECT RUB.RUBID
                                  FROM LKTPGTACRUB RUB
                                 WHERE     RUB.TPGCODE = SWPROFILRUB
                                       AND RUB.TACCODE = SWACTPREFRUB)
                ORDER BY 3;
        END;
    END S_SHUTTERALLOCATION;

    PROCEDURE S_ASSETCLASS (SLANGUE     IN     VARCHAR2,
                            SPAYCODE    IN     VARCHAR2,
                            PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT A.NAPCODE,
                     B.NAPLIBELLE,
                     A.NAPTXSAUPOUDRAGE,
                     A.NAPTYPE,
                     A.NAPMTDEDUCTIBLECAP,
                     A.DEVCODE,
                     A.PAYCODE,
                     B.LANCODE
                FROM NAP A, LANNAP B
               WHERE     B.NAPCODE(+) = A.NAPCODE
                     AND B.LANCODE(+) = SLANGUE
                     AND A.PAYCODE = SPAYCODE
                     AND B.PAYCODE = A.PAYCODE
            ORDER BY A.NAPCODE;
    END S_ASSETCLASS;

    PROCEDURE S_LSTGROUP (PC_RETURN IN OUT T_CURSOR)
    AS
    BEGIN
        DECLARE
            SUGECODE   UTILISATEUR.UGECODE%TYPE := F_GETCURRENTUGECODE;
        BEGIN
            OPEN PC_RETURN FOR
                  SELECT GROCODE AS CODE, GROINTITULE AS DISPLAYVALUE
                    FROM GROUPE
                   WHERE GROCODE NOT IN (SELECT GROCODE
                                           FROM UTILISATEUR
                                          WHERE UGECODE != SUGECODE)
                ORDER BY GROINTITULE;
        END;
    END S_LSTGROUP;

    PROCEDURE S_GROUP_LHS (SGLANGUE IN VARCHAR2, PC_RETURN IN OUT T_CURSOR)
    AS
    --sgLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        DECLARE
            SUGECODE   UTILISATEUR.UGECODE%TYPE := F_GETCURRENTUGECODE;
        BEGIN
            OPEN PC_RETURN FOR
                SELECT TO_NUMBER (LPAD (A.ACTID, 7))      AS ACTID,
                       ACTLIBCOURT,
                       A.TACCODE,
                       LPAD (A.ACTID, 7) || A.TACCODE     AS CODE,
                       TACLIBELLE,
                       ACTLIBCOURT || ' : ' || TACLIBELLE AS DISPLAYLABEL
                  FROM TACACTGESTION A, ACTEUR, LANTACTIVITE TL
                 WHERE     ACTEUR.UGECODE = SUGECODE
                       AND ACTEUR.ACTID = A.ACTID
                       AND TL.TACCODE(+) = A.TACCODE
                       AND TL.LANCODE = SGLANGUE;
        END;
    END S_GROUP_LHS;

    PROCEDURE S_GROUP_RHS (SWGROUPE    IN     LKGROTACAGE.GROCODE%TYPE,
                           SGLANGUE    IN     VARCHAR2,
                           PC_RETURN   IN OUT T_CURSOR)
    AS
    --sgLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        DECLARE
            SUGECODE   UTILISATEUR.UGECODE%TYPE := F_GETCURRENTUGECODE;
        BEGIN
            OPEN PC_RETURN FOR
                  SELECT TO_NUMBER (LPAD (GAS.ACTID, 7))  AS ACTID,
                         ACTLIBCOURT,
                         GAS.TACCODE,
                         TACLIBELLE,
                         LPAD (GAS.ACTID, 7) || GAS.TACCODE AS CODE,
                         ACTLIBCOURT || ' : ' || TACLIBELLE AS DISPLAYLABEL
                    FROM LKGROTACAGE GAS, ACTEUR, LANTACTIVITE TL
                   WHERE     ACTEUR.UGECODE = SUGECODE
                         AND ACTEUR.ACTID = GAS.ACTID
                         AND TL.TACCODE(+) = GAS.TACCODE
                         AND TL.LANCODE = SGLANGUE
                         AND GAS.GROCODE = SWGROUPE
                ORDER BY ACTLIBCOURT, TACLIBELLE;
        END;
    END S_GROUP_RHS;

    PROCEDURE S_LKGROTACAGE_COUNT (
        SWGROUPE   IN     LKGROTACAGE.GROCODE%TYPE,
        NCOUNT     IN OUT NUMBER)
    AS
    BEGIN
        BEGIN
            SELECT COUNT (*)
              INTO NCOUNT
              FROM LKGROTACAGE
             WHERE GROCODE = SWGROUPE;
        END;
    END S_LKGROTACAGE_COUNT;

    PROCEDURE S_LANTAMOLOIFISCTABLE (
        SWACTIVITE     IN     LKAMOLOIDEFAUT.TACCODE%TYPE,
        SWREGIMEFISC   IN     LKAMOLOIDEFAUT.TRFCODE%TYPE,
        SWPAYCODE      IN     LKAMOLOIDEFAUT.PAYCODE%TYPE,
        SWPROFIL       IN     LKAMOLOIDEFAUT.TPGCODE%TYPE,
        SLANGUE        IN     VARCHAR2,
        PC_RETURN      IN OUT T_CURSOR)
    AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        DECLARE
        BEGIN
            OPEN PC_RETURN FOR
                SELECT 1
                           AS DEFAUTFLAG,
                       1
                           AS DEFAUTDEBFLAG,
                       NAP.NAPCODE,
                       NAP.TLFCODE,
                       LNAP.NAPLIBELLE,
                       LTAM.TLFLIBELLE,
                       TFU.TUNMINIAN,
                       TFU.TUNMINIMOIS,
                       TFU.TUNMAXIAN,
                       TFU.TUNMAXIMOIS,
                       NAP.ALDDUREEAN,
                       NAP.ALDDUREEMOIS,
                       NAP.ALDUSEDYEARDURATION,
                       NAP.ALDUSEDMONTHDURATION,
                          TO_CHAR (NVL (TUNMINIAN, 0))
                       || ' + '
                       || TO_CHAR (NVL (TUNMINIMOIS, 0))
                           AS DUREEMINI,
                          TO_CHAR (NVL (TUNMAXIAN, 0))
                       || ' + '
                       || TO_CHAR (NVL (TUNMAXIMOIS, 0))
                           AS DUREEMAXI,
                       LTP.TTPLIBELLE,
                       TFU.TUNCONTEXTE,
                       NAP.TACCODE,
                       NAP.PAYCODE,
                       TFU.TRFCODE
                  FROM LKAMOLOIDEFAUT  NAP,
                       LANTAMOLOIFISC  LTAM,
                       TFUNAP          TFU,
                       LANNAP          LNAP,
                       LANTTRPARAM     LTP
                 WHERE     LTAM.TLFCODE = TFU.TLFCODE
                       AND LTAM.LANCODE = SLANGUE
                       AND NAP.TACCODE = SWACTIVITE
                       AND NAP.NAPCODE = TFU.NAPCODE
                       AND NAP.TLFCODE = TFU.TLFCODE
                       AND NAP.TUNCONTEXTE = TFU.TUNCONTEXTE
                       AND TFU.TACCODE = SWACTIVITE
                       AND NAP.TPGCODE = SWPROFIL
                       AND LNAP.NAPCODE = TFU.NAPCODE
                       AND LNAP.LANCODE = SLANGUE
                       AND NAP.TRFCODE = SWREGIMEFISC
                       AND TFU.TRFCODE = SWREGIMEFISC
                       AND NAP.PAYCODE = SWPAYCODE
                       AND TFU.PAYCODE = NAP.PAYCODE
                       AND LNAP.PAYCODE = NAP.PAYCODE
                       AND LTP.TTRNOM = 'IASCONTEXTE'
                       AND LTP.TTPCODE = TFU.TUNCONTEXTE
                       AND LTP.LANCODE = SLANGUE
                UNION
                SELECT 0,
                       0,
                       T.NAPCODE,
                       T.TLFCODE,
                       LN.NAPLIBELLE,
                       L.TLFLIBELLE,
                       T.TUNMINIAN,
                       T.TUNMINIMOIS,
                       T.TUNMAXIAN,
                       T.TUNMAXIMOIS,
                       TUNMINIAN,
                       TUNMINIMOIS,
                       TUNMINIAN,
                       TUNMINIMOIS,
                          TO_CHAR (NVL (TUNMINIAN, 0))
                       || ' + '
                       || TO_CHAR (NVL (TUNMINIMOIS, 0)),
                          TO_CHAR (NVL (TUNMAXIAN, 0))
                       || ' + '
                       || TO_CHAR (NVL (TUNMAXIMOIS, 0)),
                       LTP.TTPLIBELLE,
                       T.TUNCONTEXTE,
                       T.TACCODE,
                       LN.PAYCODE,
                       T.TRFCODE
                  FROM LANTAMOLOIFISC  L,
                       TFUNAP          T,
                       LANNAP          LN,
                       LANTTRPARAM     LTP
                 WHERE     L.TLFCODE = T.TLFCODE
                       AND L.LANCODE = SLANGUE
                       AND T.TACCODE(+) = SWACTIVITE
                       AND T.TRFCODE = SWREGIMEFISC
                       AND LN.NAPCODE = T.NAPCODE
                       AND LN.LANCODE = SLANGUE
                       AND LN.PAYCODE = SWPAYCODE
                       AND T.PAYCODE = LN.PAYCODE
                       AND (T.TACCODE,
                            T.TRFCODE,
                            T.TLFCODE,
                            T.NAPCODE,
                            T.TUNCONTEXTE) NOT IN
                               (SELECT TACCODE,
                                       TRFCODE,
                                       TLFCODE,
                                       NAPCODE,
                                       TUNCONTEXTE
                                  FROM LKAMOLOIDEFAUT
                                 WHERE     TACCODE = SWACTIVITE
                                       AND TRFCODE = SWREGIMEFISC
                                       AND TPGCODE = SWPROFIL
                                       AND PAYCODE = SWPAYCODE
                                       AND LKAMOLOIDEFAUT.TUNCONTEXTE =
                                           T.TUNCONTEXTE)
                       AND LTP.TTRNOM = 'IASCONTEXTE'
                       AND LTP.TTPCODE = T.TUNCONTEXTE
                       AND LTP.LANCODE = SLANGUE
                ORDER BY 3, 4;
        END;
    END S_LANTAMOLOIFISCTABLE;

    -- table Query for Pref on tASks
    PROCEDURE S_TBLFORMALITEFICHE (
        SDESTCODE               TTRPARAM.TTPCODE%TYPE,    --Combo desctination
        SPHACODE                PHASE.PHACODE%TYPE,             -- combo phASe
        SUGECODE                ACTEUR.UGECODE%TYPE,                -- ugeCode
        SWPROFIL                VARCHAR2,                 -- selected list val
        SWRF                    FORFICHE.FFICODERF%TYPE,
        SWACTPREFFICHE          VARCHAR2, -- value keeps changing from GLOBAL, ''
        SLANGUE          IN     VARCHAR2,
        PC_RETURN        IN OUT T_CURSOR)
    AS
    --slangue lANDocument.lancode%TYPE := pa_global_declare.sglangue;
    BEGIN
        IF SWACTPREFFICHE = 'GLOBAL'
        THEN
            -- in case of 'GLOBAL' there should not be a filter on TACCODE
            OPEN PC_RETURN FOR
                  SELECT DISTINCT
                         (FRM.FORID),
                         LFO.FORLIBELLE
                             AS FORLIBELLE,
                         FRM.FORFLAGDOCEMIS,
                         FRM.FORFLAGFORRAPPEL,
                         --FRM.FORFLAGOBLIG,
                         --FRM.FORFLAGOBLIG,
                         LF1.FORID
                             AS DOCFORID,
                         LF1.FORLIBELLE
                             AS DOCRAPPEL,                             --Combo
                         FFI.DOCID,
                         LDO.DOCLIBELLE
                             AS DOCEMIS,                               --combo
                         DECODE (FFI.TPGCODE, NULL, 0, 1)
                             AS INCLURE,
                         DECODE (FFI.FFIDELAIEMIS,
                                 NULL, FRM.FORDELAIEMIS,
                                 FFI.FFIDELAIEMIS)
                             AS DE,
                         FRM.FORDELAIREP
                             AS DR,
                         FR1.FORCODE,
                         TO_NUMBER (
                             DECODE (FR1.FORFLAGOBLIG,
                                     NULL, '0',
                                     FR1.FORFLAGOBLIG))
                             AS FORFLAGOBLIG,
                         FRM.FORTYPEDATE,
                         FRM.FORFLAGREPONSE
                    FROM FORMALITE   FRM,
                         LANFORMALITE LFO,
                         LANFORMALITE LF1,
                         FORFICHE    FFI,
                         DOCUMENT    DOC,
                         LANDOCUMENT LDO,
                         L1FORMALITE L1F,
                         FORMALITE   FR1
                   WHERE     FRM.FORDEST = SDESTCODE -- :desination Combo selected value dlgPrefFiche.swForDest
                         AND FRM.UGECODE = SUGECODE
                         AND LFO.FORID = FRM.FORID
                         AND LFO.LANCODE = SLANGUE
                         AND LF1.FORID(+) = FRM.FORIDRAPPEL
                         AND LF1.LANCODE(+) = SLANGUE
                         AND FFI.FORID(+) = FRM.FORID
                         AND FFI.TPGCODE(+) = SWPROFIL --value varies from 'TOUT' AND '' varies on condition  :dlgPrefFiche.swProfil
                         AND FFI.FFICODERF(+) = SWRF                   -- swRF
                         AND FFI.PHADEST(+) = SDESTCODE --:desination Combo selected value  :dlgPrefFiche.swForDest
                         AND FFI.PHACODE(+) = SPHACODE --phASe Combo selected :dlgPrefFiche.swPhaCode
                         AND DOC.DOCID(+) = FFI.DOCID
                         AND LDO.DOCID(+) = FFI.DOCID
                         AND LDO.LANCODE(+) = SLANGUE
                         AND L1F.FORIDLIEE(+) = FRM.FORID
                         AND FR1.FORID(+) = L1F.FORID
                ORDER BY LFO.FORLIBELLE;
        ELSE
            OPEN PC_RETURN FOR
                  SELECT DISTINCT
                         (FRM.FORID),
                         LFO.FORLIBELLE
                             AS FORLIBELLE,
                         FRM.FORFLAGDOCEMIS,
                         FRM.FORFLAGFORRAPPEL,
                         --FRM.FORFLAGOBLIG,
                         --FRM.FORFLAGOBLIG,
                         LF1.FORID
                             AS DOCFORID,
                         LF1.FORLIBELLE
                             AS DOCRAPPEL,                             --Combo
                         FFI.DOCID,
                         LDO.DOCLIBELLE
                             AS DOCEMIS,                               --combo
                         DECODE (FFI.TPGCODE, NULL, 0, 1)
                             AS INCLURE,
                         DECODE (FFI.FFIDELAIEMIS,
                                 NULL, FRM.FORDELAIEMIS,
                                 FFI.FFIDELAIEMIS)
                             AS DE,
                         FRM.FORDELAIREP
                             AS DR,
                         FR1.FORCODE,
                         TO_NUMBER (
                             DECODE (FR1.FORFLAGOBLIG,
                                     NULL, '0',
                                     FR1.FORFLAGOBLIG))
                             AS FORFLAGOBLIG,
                         FRM.FORTYPEDATE,
                         FRM.FORFLAGREPONSE
                    FROM FORMALITE   FRM,
                         LANFORMALITE LFO,
                         LANFORMALITE LF1,
                         FORFICHE    FFI,
                         DOCUMENT    DOC,
                         LANDOCUMENT LDO,
                         L1FORMALITE L1F,
                         FORMALITE   FR1
                   WHERE     FRM.FORDEST = SDESTCODE -- :desination Combo selected value dlgPrefFiche.swForDest
                         AND FRM.TACCODE = SWACTPREFFICHE --:dlgPrefFiche.swActPrefFiche -- value keeps changing from GLOBAL, ''
                         AND FRM.UGECODE = SUGECODE
                         AND LFO.FORID = FRM.FORID
                         AND LFO.LANCODE = SLANGUE
                         AND LF1.FORID(+) = FRM.FORIDRAPPEL
                         AND LF1.LANCODE(+) = SLANGUE
                         AND FFI.FORID(+) = FRM.FORID
                         AND FFI.TPGCODE(+) = SWPROFIL --value varies from 'TOUT' AND '' varies on condition  :dlgPrefFiche.swProfil
                         AND FFI.FFICODERF(+) = SWRF                   -- swRF
                         AND FFI.PHADEST(+) = SDESTCODE --:desination Combo selected value  :dlgPrefFiche.swForDest
                         AND FFI.PHACODE(+) = SPHACODE --phASe Combo selected :dlgPrefFiche.swPhaCode
                         AND DOC.DOCID(+) = FFI.DOCID
                         AND LDO.DOCID(+) = FFI.DOCID
                         AND LDO.LANCODE(+) = SLANGUE
                         AND L1F.FORIDLIEE(+) = FRM.FORID
                         AND FR1.FORID(+) = L1F.FORID
                ORDER BY LFO.FORLIBELLE;
        END IF;
    END S_TBLFORMALITEFICHE;

    -- No usage found
    /*  PROCEDURE S_JALPERSTATUPDATE(
    swEntiteMaitreJalPerStat IN DOSPHASE.PHADEST%TYPE,
    swStatCode IN DOSPHASE.PHACODE%TYPE,
    colJal IN DOSPHASE.JALCODE%TYPE,
    sLangue IN VARCHAR2,
    PC_RETURN IN OUT T_CURSOR) AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
    DECLARE
    BEGIN
    OPEN PC_Return FOR
    SELECT  JALCODE
    FROM  DOSPHASE
    WHERE  PHADEST = swEntiteMaitreJalPerStat
    AND  PHACODE = swStatCode
    AND  JALCODE = colJal
    ;
    END;
    END S_JALPERSTATUPDATE ; */
    -- all proc must be above this line
    -- Company Tree
    PROCEDURE S_COMPTASOC_TREE (SGLANGUE    IN     VARCHAR2,
                                SUGECODE    IN     VARCHAR2,
                                PC_RETURN   IN OUT T_CURSOR)
    AS
    --sgLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT ACG.ACTID ALACTID,
                     ACTLIBCOURT,
                     TUPCODE,
                     TUPLIBELLE
                FROM ACTEURGESTION ACG, ACTEUR ACT, LANTUSPARAM LTUS
               WHERE     ACT.UGECODE = SUGECODE
                     AND ACG.ACTID = ACT.ACTID
                     AND LTUS.LANCODE = SGLANGUE
                     AND LTUS.TUSNOM = 'COMPTACIBLE'
                     AND (NOT EXISTS
                              (SELECT 1
                                 FROM ACTROLE
                                WHERE ACTID = ACT.ACTID AND ROLCODE = 'PROEXT'))
            ORDER BY ACT.ACTID, TUPCODE;
    END S_COMPTASOC_TREE;

    PROCEDURE S_LKTSMFOR_COUNT (NFORID   IN     LKTSMFOR.FORID%TYPE,
                                NCOUNT   IN OUT NUMBER)
    AS
    BEGIN
        BEGIN
            SELECT COUNT (*)
              INTO NCOUNT
              FROM LKTSMFOR
             WHERE FORID = NFORID;
        END;
    END S_LKTSMFOR_COUNT;

    -- Proc migrated on 22/may/2009
    -- LKRELRUL --
    PROCEDURE S_LKRELRUL (NACTID      IN     LKRELRUL.ACTID%TYPE,
                          SROLCODE    IN     LKRELRUL.ROLCODE%TYPE,
                          NRELORDRE   IN     LKRELRUL.RELORDRE%TYPE,
                          STACCODE    IN     LKRELRUL.TACCODE%TYPE,
                          SRELCODE    IN     LKRELRUL.RELCODE%TYPE,
                          PC_RETURN   IN OUT T_CURSOR)
    AS
        SLANGUE   LANDOCUMENT.LANCODE%TYPE := PA_GLOBAL_DECLARE.SGLANGUE;
    BEGIN
        DECLARE
        BEGIN
            OPEN PC_RETURN FOR
                SELECT RULID,
                       ACTID,
                       ROLCODE,
                       RELORDRE,
                       TACCODE,
                       RELCODE
                  FROM LKRELRUL
                 WHERE     ACTID = NACTID
                       AND ROLCODE = SROLCODE
                       AND RELORDRE = NRELORDRE
                       AND TACCODE = STACCODE
                       AND RELCODE = SRELCODE;
        END;
    END S_LKRELRUL;

    --================= Start Proc migrated on 05/June/2009=========
    PROCEDURE S_TCROLIGNE_TREE (STCRCODE           TCROLIGNE.TCRCODE%TYPE,
                                SGLANGUE    IN     VARCHAR2,
                                PC_RETURN   IN OUT T_CURSOR)
    AS
    --sgLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        IF STCRCODE IS NULL
        THEN
            OPEN PC_RETURN FOR
                  SELECT LTCR.TCRCODE,
                         LTCR.TCRCODE || '-' || LTCR.TCRLIBELLE
                             AS DISPLAYVALUE,
                         LTCR.TCRLIBELLE,
                         TCL.TCLORDRE,
                         LTCL.TCLLIBELLE,
                         TCL.TCLSOURCE
                    FROM LANTCRO LTCR, TCROLIGNE TCL, LANTCROLIGNE LTCL
                   WHERE     LTCL.TCLORDRE = TCL.TCLORDRE
                         AND LTCL.TCRCODE = TCL.TCRCODE
                         AND TCL.TCRCODE = LTCR.TCRCODE
                         AND LTCR.LANCODE = SGLANGUE
                         AND LTCL.LANCODE = SGLANGUE
                ORDER BY LTCR.TCRCODE, TCL.TCLORDRE;
        ELSE
            OPEN PC_RETURN FOR
                  SELECT LTCR.TCRCODE,
                         LTCR.TCRLIBELLE,
                         TCL.TCLORDRE,
                         LTCL.TCLLIBELLE,
                         TCL.TCLSOURCE
                    FROM LANTCRO LTCR, TCROLIGNE TCL, LANTCROLIGNE LTCL
                   WHERE     LTCR.TCRCODE = STCRCODE
                         AND LTCL.TCLORDRE = TCL.TCLORDRE
                         AND LTCL.TCRCODE = TCL.TCRCODE
                         AND TCL.TCRCODE = LTCR.TCRCODE
                         AND LTCR.LANCODE = SGLANGUE
                         AND LTCL.LANCODE = SGLANGUE
                ORDER BY LTCR.TCRCODE, TCL.TCLORDRE;
        END IF;
    END S_TCROLIGNE_TREE;

    PROCEDURE S_REL_CMBRULE (SGLANGUE IN VARCHAR2, PC_RETURN IN OUT T_CURSOR)
    AS
    --sgLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
            SELECT RULE.RULID       AS CODEINTEGER,
                   LANRULE.RULLABEL AS DISPLAYVALUE
              FROM RULE, LANRULE
             WHERE LANCODE = SGLANGUE AND RULE.RULID = LANRULE.RULID;
    END S_REL_CMBRULE;

    PROCEDURE S_PLANCOMPTABLE (NACTID        IN     NUMBER,
                               SCODECOMPTA   IN     VARCHAR,
                               PC_RETURN     IN OUT T_CURSOR)
    AS
    BEGIN
        DECLARE
        BEGIN
            OPEN PC_RETURN FOR
                  SELECT PCOID,
                         PCOLIBELLE,
                         PCOCOMPTE,
                         PCOCLASSE,
                         PCOFLAGAGREGE
                    FROM PLANCOMPTABLE
                   WHERE ACTID = NACTID AND PCOCOMPTA = SCODECOMPTA
                ORDER BY PCOCOMPTE;
        END;
    END S_PLANCOMPTABLE;

    --select CROLIGDETAIL table
    PROCEDURE S_CROLIGDETAIL (STCRCODE      IN     VARCHAR,
                              NTCLORDRE     IN     NUMBER,
                              NCLIORDRE     IN     NUMBER,
                              NACTID        IN     NUMBER,
                              SCJOCOMPTA    IN     VARCHAR,
                              SCODELANGUE   IN     VARCHAR2, --sgLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
                              PC_RETURN     IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT CLD.CLDORDRE,
                     CLD.TLDCHAMP,
                     TCD.TLDCHAMPTYPE,
                     TTP.TTPLIBELLE,
                     CLD.CLDLONGUEUR,
                     CLD.CLDCONVERSION
                FROM CROLIGDETAIL CLD, TCROLIGDETAIL TCD, LANTTRPARAM TTP
               WHERE     CLD.TCRCODE = STCRCODE
                     AND CLD.TCLORDRE = NTCLORDRE
                     AND CLD.CLIORDRE = NCLIORDRE
                     AND CLD.ACTID = NACTID
                     AND CLD.CJOCOMPTA = SCJOCOMPTA
                     AND TCD.TCRCODE = STCRCODE
                     AND TCD.TLDCHAMPTYPE = TTP.TTPCODE
                     AND TTP.TTRNOM = 'TYPECHAMP'
                     AND TTP.LANCODE = SCODELANGUE
                     AND TCD.TCLORDRE = NTCLORDRE
                     AND CLD.TLDCHAMP = TCD.TLDCHAMP
            ORDER BY CLD.CLDORDRE;
    END S_CROLIGDETAIL;

    PROCEDURE S_CROLIGNECOMPTASOC_TREE (
        NACTID              CROLIGNE.ACTID%TYPE,
        SCJOCOMPTA          CROLIGNE.CJOCOMPTA%TYPE,
        SGLANGUE     IN     VARCHAR2,
        PC_RETURN    IN OUT T_CURSOR)
    AS
    --sgLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT LTCR.TCRCODE,
                     LTCR.TCRLIBELLE,
                     TCL.TCLORDRE,
                     TCL.TCLORDRE AS STCLORDRE,
                     LTCL.TCLLIBELLE,
                     CLI.CLIORDRE,
                     CLI.CLILIBELLE,
                     CLI.CLIDTDEB
                FROM LANTCRO     LTCR,
                     TCROLIGNE   TCL,
                     LANTCROLIGNE LTCL,
                     CROLIGNE    CLI
               WHERE     LTCR.TCRCODE = TCL.TCRCODE
                     AND TCL.TCRCODE = LTCL.TCRCODE
                     AND TCL.TCLORDRE = LTCL.TCLORDRE
                     AND CLI.TCRCODE = LTCR.TCRCODE
                     AND CLI.TCLORDRE = LTCL.TCLORDRE
                     AND CLI.ACTID = NACTID
                     AND CLI.CJOCOMPTA = SCJOCOMPTA
                     AND LTCR.LANCODE = SGLANGUE
                     AND LTCL.LANCODE = SGLANGUE
            ORDER BY LTCR.TCRCODE, TCL.TCLORDRE, CLI.CLIORDRE;
    END S_CROLIGNECOMPTASOC_TREE;

    PROCEDURE S_CROLIGCONDITION (
        STCRCODE            CROLIGCONDITION.TCRCODE%TYPE,
        NTCLORDRE           CROLIGCONDITION.TCLORDRE%TYPE,
        NCLIORDRE           CROLIGCONDITION.CLIORDRE%TYPE,
        NACTID              CROLIGCONDITION.ACTID%TYPE,
        SCJOCOMPTA          CROLIGCONDITION.CJOCOMPTA%TYPE,
        PC_RETURN    IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT TO_NUMBER (CLC.CLCID) AS NCLCID,
                     CLC.CLCID,
                     CLC.CLCJOURNAL,
                     CLC.CLCDTDEB,
                     CLC.CLCDTFIN,
                     CLC.CLCFLAGGENERIQUE,
                     CLC.PCOID,
                     PCO.PCOCOMPTE,                             -- TD 08/04/01
                     CLC.ACTID,
                     CLC.CLIORDRE,
                     CLC.TCLORDRE,
                     CLC.TCRCODE,
                     CLC.CJOCOMPTA
                FROM CROLIGCONDITION CLC, PLANCOMPTABLE PCO
               WHERE     CLC.TCRCODE = STCRCODE
                     AND CLC.TCLORDRE = NTCLORDRE
                     AND CLC.CLIORDRE = NCLIORDRE
                     AND CLC.ACTID = NACTID
                     AND CLC.CJOCOMPTA = SCJOCOMPTA
                     AND CLC.PCOID = PCO.PCOID(+)
                     AND (   CLC.CLCFLAGGENERIQUE IS NULL
                          OR CLC.CLCFLAGGENERIQUE = 0)
            ORDER BY TO_NUMBER (CLC.CLCID);
    END S_CROLIGCONDITION;

    PROCEDURE S_CROLIGCONLIGNE (
        STCRCODE            CROLIGCONLIGNE.TCRCODE%TYPE,
        NTCLORDRE           CROLIGCONLIGNE.TCLORDRE%TYPE,
        NCLIORDRE           CROLIGCONLIGNE.CLIORDRE%TYPE,
        NACTID              CROLIGCONLIGNE.ACTID%TYPE,
        SCJOCOMPTA          CROLIGCONLIGNE.CJOCOMPTA%TYPE,
        SCLCID              CROLIGCONLIGNE.CLCID%TYPE,
        SGLANGUE     IN     VARCHAR2,
        PC_RETURN    IN OUT T_CURSOR)
    AS
    --sgLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT CCLORDRE,
                     CCLLIEN,
                     TTP1.TTPLIBELLE ALCCLLIENLIB,
                     CCLOPER,
                     TTP2.TTPLIBELLE ALCCLOPERLIB,
                     CCLVALEUR,
                     CCLDTDEB,
                     CCLDTFIN,
                     TLDCHAMP,
                     TLDCHAMP2,
                     ACTID,
                     TCRCODE,
                     CJOCOMPTA,
                     TCLORDRE,
                     CLIORDRE,
                     CLCID
                FROM CROLIGCONLIGNE CCL, LANTTRPARAM TTP1, LANTTRPARAM TTP2
               WHERE     TCRCODE = STCRCODE
                     AND TCLORDRE = NTCLORDRE
                     AND CLIORDRE = NCLIORDRE
                     AND ACTID = NACTID
                     AND CJOCOMPTA = SCJOCOMPTA
                     AND CLCID = SCLCID
                     AND CCLLIEN = TTP1.TTPCODE(+)
                     AND CCLOPER = TTP2.TTPCODE(+)
                     AND TTP1.TTRNOM(+) = 'OPLOG'
                     AND TTP2.TTRNOM(+) = 'OPREL'
                     AND TTP1.LANCODE(+) = SGLANGUE
                     AND TTP2.LANCODE(+) = SGLANGUE
            ORDER BY CCLORDRE;
    END S_CROLIGCONLIGNE;

    PROCEDURE S_ACCOUNTSEARCHCRO (
        NACTID              CROJOURNAL.ACTID%TYPE,
        SCJOCOMPTA          CROJOURNAL.CJOCOMPTA%TYPE,
        SLANGUE      IN     VARCHAR2,
        PC_RETURN    IN OUT T_CURSOR)
    AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR SELECT PLANCOMPTABLE.PCOID,
                                  PLANCOMPTABLE.ACTID,
                                  PLANCOMPTABLE.PCOCOMPTA,
                                  PLANCOMPTABLE.PCOCOMPTE,
                                  PLANCOMPTABLE.PCOLIBELLE,
                                  PLANCOMPTABLE.PCOCLASSE,
                                  PLANCOMPTABLE.PCOFLAGAGREGE
                             FROM PLANCOMPTABLE
                            WHERE PLANCOMPTABLE.ACTID = NACTID;
    -- AND PLANCOMPTABLE.PCOCOMPTA= sCjoCompta;
    END S_ACCOUNTSEARCHCRO;

    PROCEDURE S_LKTCRAGETAC (NACTID             LKTCRAGETAC.ACTID%TYPE,
                             SLANGUE            LANGUE.LANCODE%TYPE,
                             PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        DECLARE
        BEGIN
            OPEN PC_RETURN FOR
                  SELECT LKA.TCRCODE,
                         TCRLIBELLE,
                         LKA.TACCODE,
                         TACLIBELLE
                    FROM LKTCRAGETAC LKA, LANTCRO LTC, LANTACTIVITE LTA
                   WHERE     LKA.ACTID = NACTID
                         AND LTC.TCRCODE(+) = LKA.TCRCODE
                         AND LTC.LANCODE(+) = SLANGUE
                         AND LTA.TACCODE(+) = LKA.TACCODE
                         AND LTA.LANCODE(+) = SLANGUE
                ORDER BY TCRLIBELLE, TACLIBELLE;
        END;
    END S_LKTCRAGETAC;

    -- OR GL LIne Table Population
    PROCEDURE S_TBLCROLIGNE (STCRCODE     IN     CROLIGNE.TCRCODE%TYPE,
                             NTCLORDRE    IN     CROLIGNE.TCLORDRE%TYPE,
                             NACTID       IN     CROLIGNE.ACTID%TYPE,
                             SCJOCOMPTA   IN     CROLIGNE.CJOCOMPTA%TYPE,
                             PC_RETURN    IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT CLIORDRE,
                     CLILIBELLE,
                     CLIDESCRIPTION,
                     CLIDTDEB,
                     CLIDTFIN,
                     ACTID,
                     TCRCODE,
                     CJOCOMPTA,
                     TCLORDRE
                FROM CROLIGNE CLI
               WHERE     TCRCODE = STCRCODE
                     AND TCLORDRE = NTCLORDRE
                     AND ACTID = NACTID
                     AND CJOCOMPTA = SCJOCOMPTA
            ORDER BY TCRCODE, CLIORDRE;
    END S_TBLCROLIGNE;

    PROCEDURE S_TBLCROLIGNE2 (STCRCODE     IN     CROLIGNE.TCRCODE%TYPE,
                              NTCLORDRE    IN     CROLIGNE.TCLORDRE%TYPE,
                              NACTID       IN     CROLIGNE.ACTID%TYPE,
                              SCJOCOMPTA   IN     CROLIGNE.CJOCOMPTA%TYPE,
                              NCLIORDRE    IN     CROLIGNE.CLIORDRE%TYPE,
                              PC_RETURN    IN OUT T_CURSOR)
    AS
    BEGIN
        DECLARE
            NCLCID              CROLIGCONDITION.CLCID%TYPE := NULL;
            NCLCFLAGGENERIQUE   NUMBER := 0;
        BEGIN
            SELECT MAX (CLCID)
              INTO NCLCID
              FROM CROLIGCONDITION CLC
             WHERE     CLCFLAGGENERIQUE = 1
                   AND TCRCODE = STCRCODE
                   AND TCLORDRE = NTCLORDRE
                   AND ACTID = NACTID
                   AND CJOCOMPTA = SCJOCOMPTA
                   AND CLIORDRE = NCLIORDRE;

            IF (NCLCID IS NOT NULL)
            THEN
                SELECT COUNT (*)
                  INTO NCLCFLAGGENERIQUE
                  FROM CROLIGCONLIGNE
                 WHERE     TCRCODE = STCRCODE
                       AND TCLORDRE = NTCLORDRE
                       AND ACTID = NACTID
                       AND CJOCOMPTA = SCJOCOMPTA
                       AND CLIORDRE = NCLIORDRE
                       AND CLCID = NCLCID;
            ELSE
                SELECT NVL (MAX (CLCID), 0)
                  INTO NCLCID
                  FROM CROLIGCONDITION CLC
                 WHERE     TCRCODE = STCRCODE
                       AND TCLORDRE = NTCLORDRE
                       AND ACTID = NACTID
                       AND CJOCOMPTA = SCJOCOMPTA
                       AND CLIORDRE = NCLIORDRE;

                NCLCFLAGGENERIQUE := 0;
                NCLCID := NCLCID + 1;
            END IF;

            OPEN PC_RETURN FOR
                SELECT NCLCID CLCID, NCLCFLAGGENERIQUE CLCFLAGGENERIQUE
                  FROM DUAL;
        END;
    END S_TBLCROLIGNE2;

    PROCEDURE S_TCRO (PC_RETURN IN OUT T_CURSOR)
    AS
        SLANGUE   LANDOCUMENT.LANCODE%TYPE := PA_GLOBAL_DECLARE.SGLANGUE;
    BEGIN
        DECLARE
        BEGIN
            OPEN PC_RETURN FOR
                  SELECT TCR.TCRCODE, LTCR.TCRLIBELLE
                    FROM TCRO TCR, LANTCRO LTCR
                   WHERE TCR.TCRCODE = LTCR.TCRCODE AND LANCODE = SLANGUE
                ORDER BY TCR.TCRCODE;
        END;
    END S_TCRO;

    PROCEDURE S_TCROLIGNE (STCRCODE    IN     LANTCRO.TCRCODE%TYPE,
                           SLANGUE     IN     VARCHAR2,
                           PC_RETURN   IN OUT T_CURSOR)
    AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        DECLARE
        BEGIN
            OPEN PC_RETURN FOR
                  SELECT LTCR.TCRCODE,
                         LTCR.TCRLIBELLE,
                         TCL.TCLORDRE,
                         LTCL.TCLLIBELLE,
                         TCL.TCLSOURCE
                    FROM LANTCRO LTCR, TCROLIGNE TCL, LANTCROLIGNE LTCL
                   WHERE     LTCR.TCRCODE = STCRCODE
                         AND LTCL.TCLORDRE = TCL.TCLORDRE
                         AND LTCL.TCRCODE = TCL.TCRCODE
                         AND TCL.TCRCODE = LTCR.TCRCODE
                         AND LTCR.LANCODE = SLANGUE
                         AND LTCL.LANCODE = SLANGUE
                ORDER BY LTCR.TCRCODE, TCL.TCLORDRE;
        END;
    END S_TCROLIGNE;

    PROCEDURE S_CRITERECRO (SLANGUE            LANGUE.LANCODE%TYPE,
                            SUGECODE           UNITEGESTION.UGECODE%TYPE,
                            PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT CCR.CCRCODE,
                     CCR.UGECODE,
                     LCCR.LANCODE,
                     NVL (LCCR.CCRLIBELLE, ' ') AS CCRLIBELLE
                FROM CRITERECRO CCR, LANCRITERECRO LCCR
               WHERE     LCCR.CCRCODE(+) = CCR.CCRCODE
                     AND LCCR.LANCODE(+) = SLANGUE
                     AND CCR.UGECODE = SUGECODE
                     AND LCCR.UGECODE(+) = CCR.UGECODE
            ORDER BY CCR.CCRCODE;
    END S_CRITERECRO;

    PROCEDURE S_CCRCHAMP (SCCRCODE           CCRCHAMP.CCRCODE%TYPE,
                          SUGECODE           UNITEGESTION.UGECODE%TYPE,
                          PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR SELECT CCHCHAMP, CCRCODE, UGECODE
                             FROM CCRCHAMP
                            WHERE CCRCODE = SCCRCODE AND UGECODE = SUGECODE;
    END S_CCRCHAMP;

    PROCEDURE S_COLCRITERESEARCH (SLANGUE     IN     VARCHAR2,
                                  NROWMIN     IN     INTEGER,
                                  NROWMAX     IN     INTEGER,
                                  PC_RETURN   IN OUT T_CURSOR)
    AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT *
                FROM (SELECT ROWNUM RN,
                             CCHCHAMP,
                             TCRCODE,
                             TLDLIBELLE
                        FROM (  SELECT T.TLDCHAMP     AS CCHCHAMP,
                                       MAX (T.TCRCODE) AS TCRCODE,
                                       MAX (L.TLDLIBELLE) AS TLDLIBELLE
                                  FROM TCROLIGDETAIL T, LANTCROLIGDETAIL L
                                 WHERE     T.TCRCODE = L.TCRCODE
                                       AND T.TCLORDRE = L.TCLORDRE
                                       AND T.TLDCHAMP = L.TLDCHAMP
                                       AND L.LANCODE = SLANGUE
                              GROUP BY T.TLDCHAMP, L.TLDLIBELLE
                              ORDER BY 1))
               WHERE RN BETWEEN NROWMIN AND NROWMAX
            ORDER BY RN;
    END S_COLCRITERESEARCH;

    PROCEDURE S_CRITERIA_MAPPING_DETAIL ( --  sCchChamp   CCHIMPUTATION.CCHCHAMP%TYPE,
                                         --   sCcrCode    CCHIMPUTATION.CCRCODE%TYPE,
                                         --   nPcoId      PLANCOMPTABLE.PCOID%TYPE,
                                         --   nCimOrdre   CCHIMPUTATION.CIMORDRE%TYPE,
                                         --  sUgeCode    UNITEGESTION.UGECODE%TYPE,
                                         SLANGUE     IN     VARCHAR2,
                                         PC_RETURN   IN OUT T_CURSOR)
    AS
    --sLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
            SELECT CCV.CIMOPER, CCV.CIMVALEUR, LTP.TTPLIBELLE
              FROM CCHIMPUTATION CCV, LANTTRPARAM LTP
             WHERE     CCV.CCRCODE = 'CLIENTS'
                   --  AND   CCV.CCHCHAMP = sCchChamp
                   AND CCV.PCOID = 181
                   --   AND   CCV.CIMORDRE= nCimOrdre
                   AND LTP.TTRNOM(+) = 'OPREL'
                   AND LTP.TTPCODE(+) = CCV.CIMOPER
                   AND LTP.LANCODE(+) = SLANGUE
                   AND CCV.UGECODE = '_ORIG_';
    END S_CRITERIA_MAPPING_DETAIL;

    PROCEDURE S_TCROLIGDETAIL (
        STCRCODE    IN     TCROLIGDETAIL.TCRCODE%TYPE,
        NTCLORDRE   IN     TCROLIGDETAIL.TCLORDRE%TYPE,
        SLANGUE     IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        DECLARE
        BEGIN
            OPEN PC_RETURN FOR
                  SELECT TLD.TLDCHAMP,
                         TLD.TLDCHAMPTYPE,
                         TLD.TLDTYPEORACLE,
                         LTLD.TLDLIBELLE,
                         TLD.TLDVALEUR,
                         NVL (TLD.TLDFLAGSTATLIBRE, 0) AS TLDFLAGSTATLIBRE,
                         TLD.SACCODE,
                         TLD.SGECODE,
                         LTLD.TCLORDRE,
                         LTLD.TCRCODE
                    FROM TCROLIGDETAIL TLD, LANTCROLIGDETAIL LTLD
                   WHERE     TLD.TCRCODE = STCRCODE
                         AND LTLD.TCRCODE = STCRCODE
                         AND LTLD.TCLORDRE = NTCLORDRE
                         AND TLD.TCLORDRE = NTCLORDRE
                         AND LTLD.TLDCHAMP = TLD.TLDCHAMP
                         AND LTLD.LANCODE = SLANGUE
                ORDER BY TLD.TLDCHAMPTYPE, TLD.TLDCHAMP;
        END;
    END S_TCROLIGDETAIL;

    PROCEDURE S_LENGTHFIELD (
        SWTCRCODE        IN     TCROLIGDETAIL.TCRCODE%TYPE,
        NWTCLORDRE       IN     TCROLIGDETAIL.TCLORDRE%TYPE,
        SWTLDCHAMP       IN     TCROLIGDETAIL.TLDCHAMP%TYPE,
        SWTLDCHAMPTYPE   IN     TCROLIGDETAIL.TLDCHAMPTYPE%TYPE,
        SLANGUE          IN     VARCHAR2,
        PC_RETURN        IN OUT T_CURSOR)
    AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        DECLARE
        BEGIN
            OPEN PC_RETURN FOR
                SELECT LENGTH (TLDVALEUR) AS FIELDLENGTH
                  FROM TCROLIGDETAIL
                 WHERE     TCRCODE = SWTCRCODE
                       AND TCLORDRE = NWTCLORDRE
                       AND TLDCHAMP = SWTLDCHAMP
                       AND TLDCHAMPTYPE = SWTLDCHAMPTYPE;
        END;
    END S_LENGTHFIELD;

    PROCEDURE S_LONGUEUR (
        SWTCRCODE     IN     TCROLIGDETAIL.TCRCODE%TYPE,
        NWTCLORDRE    IN     TCROLIGDETAIL.TCLORDRE%TYPE,
        SPCHAMP       IN     TCROLIGDETAIL.TLDCHAMP%TYPE,
        SPCHAMPTYPE   IN     TCROLIGDETAIL.TLDCHAMPTYPE%TYPE,
        SLANGUE       IN     VARCHAR2,
        PC_RETURN     IN OUT T_CURSOR)
    AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        DECLARE
        BEGIN
            OPEN PC_RETURN FOR
                SELECT TLDTYPEORACLE
                  FROM TCROLIGDETAIL
                 WHERE     TCRCODE = SWTCRCODE
                       AND TCLORDRE = NWTCLORDRE
                       AND TLDCHAMP = SPCHAMP
                       AND TLDCHAMPTYPE = SPCHAMPTYPE;
        END;
    END S_LONGUEUR;

    PROCEDURE S_CREATIONUTILISATEURINTERDITE (SLANGUE     IN     VARCHAR2,
                                              PC_RETURN   IN OUT T_CURSOR)
    AS
    --slangue lANDocument.lancode%TYPE := pa_global_declare.sglangue;
    BEGIN
        DECLARE
        BEGIN
            OPEN PC_RETURN FOR
                SELECT TPALOGIQUE AS TPALOGIQUEFLAG
                  FROM TOPPARAM
                 WHERE TOPTABLE = 'ORFIOFFICE' AND TPAPARAM = 'SECURITY_DBA';
        END;
    END S_CREATIONUTILISATEURINTERDITE;

    /*
    procedure createOracleuser(usercode varchar2,
    pASsword varchar2,
    nResult IN OUT number,
    sResult IN OUT varchar2) AS
    sUsercode varchar2(32);
    sPASsword varchar2(32);
    sRole varchar2(2000);
    bNotCreated boolean:=false;
    bNoPrivilegeCreate boolean:=false;
    bNoPrivilegeAlter boolean:=false;
    iOptionProfile PLS_INTEGER:=0;
    iCountPASsFlag pls_integer:=0;
    iOptionExpired pls_integer:=0;
    cursor c1 is  select * from sys.dba_role_privs WHERE grantee = sUserCode AND default_role = 'YES' AND granted_role not like '%/_USER' escape '/';
    begin
    if sRole_Mod is null or sRole_sel is null or sTablespace is null or sTempTablespace is null then
    nResult:=1;
    sResult:='PARSYSTEME';
    else
    nResult:=0;
    if upper(substr(usercode,1,1)) not in ('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z') then
    sUsercode:='"'||trim(usercode)||'"';
    else
    sUsercode:=trim(usercode);
    end if;
    spASsword:='"'||trim(pASsword)||'"';
    sUsercode:=upper(sUsercode);
    execute immediate 'select count(*) from systemparameters WHERE spaTYPE=:1 AND spanumbervalue=1' into iOptionExpired using 'ACCOUNT_EXPIRED';
    execute immediate 'select count(*) from systemparameters WHERE spaTYPE=:1 AND spanumbervalue=1' into iOptionProfile using 'CASSIOPAE_PROFILE';
    begin
    execute immediate 'select count(*) from user_tab_columns WHERE table_name=:1 AND column_name=:2' into iCountPASsFlag using 'UTILISATEUR', 'UTIFLAGPASSWORD';
    execute immediate 'create user ' || sUsercode || ' identified by ' || sPASsword ||
    ' default tablespace ' || sTablespace ||
    ' temporary tablespace ' || sTempTablespace;
    exception
    when others then
    -- ORA-00988 invalid pASsword
    -- ORA-01920 user en conflit avec role ou autre user
    -- ORA-01935 Invalid username
    -- ORA-01031 privilieges insuffisants
    if sqlcode = -1920 then
    bNotCreated:=true;
    elsif sqlcode = -988 then
    bNotCreated:=true;
    elsif sqlcode = -1935 then
    bNotCreated:=true;
    elsif sqlcode = -1031 then
    bNotCreated:=true;
    bNoPrivilegeCreate:=true;
    elsif sqlcode = -28003 or sqlcode = -28004 then
    bNotCreated:=true;
    end if;
    nResult:=sqlcode;
    sResult:=sqlerrm;
    end;
    if nResult = 0 then
    begin
    execute immediate 'p_updateutilisateur(:1, upper(trim(:2)))' using sCallingUser, usercode;
    exception when others then null; end;
    if iOptionProfile = 1 then
    begin
    execute immediate 'alter user ' || sUsercode || ' profile cASsiopae';
    exception when others then null; end;
    end if;
    if iOptionExpired = 1 then
    begin
    execute immediate 'alter user ' || sUsercode || ' pASsword expire';
    exception when others then null; end;
    end if;
    end if;
    if nResult in (0, -1920) then
    begin
    execute immediate 'grant ' || sRole_mod || ', ' || sRole_sel || ' to ' || sUsercode;
    exception when others then
    if sqlcode = -1031 then
    bNoPrivilegeAlter:=true;
    end if;
    nResult:=sqlcode;
    sResult:=sqlerrm;
    end;
    end if;
    if nResult in (0, -1920) then
    for c1r in c1 loop
    if sRole is null then
    sRole:=c1r.granted_role;
    else
    sRole:=sRole || ', '|| c1r.granted_role;
    end if;
    end loop;
    if sRole is null then
    sRole:=sRole_sel;
    end if;
    begin
    execute immediate 'alter user ' || sUsercode || ' default role ' || sRole;
    exception when others then
    if sqlcode = -1031 then
    bNoPrivilegeAlter:=true;
    end if;
    nResult:=sqlcode;
    sResult:=sqlerrm;
    end;
    end if;
    end if;
    end createOracleuser;
    */
    PROCEDURE S_UNITEGESTION (SLANGUE IN VARCHAR2, PC_RETURN IN OUT T_CURSOR)
    AS
    --slangue lANDocument.lancode%TYPE := pa_global_declare.sglangue;
    BEGIN
        LOOP
            OPEN PC_RETURN FOR   SELECT UGECODE, UGENOM
                                   FROM UNITEGESTION
                               ORDER BY UGECODE;
        END LOOP;
    END S_UNITEGESTION;

    PROCEDURE S_TBLCRONONDEVERSE (
        SUSERGROUPE          LKGROTACAGE.GROCODE%TYPE,
        SLANGUE       IN     VARCHAR2,
        PC_RETURN     IN OUT T_CURSOR)
    AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
            SELECT CRO.ACTID,
                   ACT.ACTLIBCOURT,
                   CRO.CROID,
                   CRO.TCRCODE,
                   LTC.TCRLIBELLE,
                   CRO.CRODTTRAIT,
                   CRO.CRODTCOMPTABLE,
                   NVL (CRO.CROFLAGNONTRAITE, 0),
                   NVL (CRO.CROFLAGBLOCAGE, 0),
                   CRO.CROCOMMENTBLOCAGE
              FROM CRO, ACTEUR ACT, LANTCRO LTC
             WHERE     ACT.ACTID(+) = CRO.ACTID
                   AND CRO.ACTID IN (SELECT ACTID
                                       FROM LKGROTACAGE
                                      WHERE GROCODE = SUSERGROUPE)
                   AND LTC.TCRCODE(+) = CRO.TCRCODE
                   AND LTC.LANCODE(+) = SLANGUE
                   AND (   NVL (CRO.CROFLAGBLOCAGE, 0) = 1
                        OR NVL (CRO.CROFLAGNONTRAITE, 0) = 1
                        OR CRO.CRODTEXPLOIT IS NULL);
    END S_TBLCRONONDEVERSE;

    -- Not used
    /*PROCEDURE S_SEARCH_MANBIM(
    sgLangue IN VARCHAR2,
    PC_Return IN OUT T_Cursor ) AS
    --sgLangue LANTMOYENPMT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
    OPEN PC_Return FOR
    SELECT DISTINCT
    BIENIMMOBILIER.BIMID,
    BIENIMMOBILIER.BIMIDFEDERATEUR,
    LTP.TUPLIBELLE ,
    BIENIMMOBILIER.BIMNUM ,
    BIENIMMOBILIER.BIMINTITULE ,
    LANTBIENTYPE.TBTLIBELLE ,
    LANTBTNATURE.TBNLIBELLE ,
    LANTBTNATGENRE.TNGLIBELLE ,
    LANTUSPARAM.TUPLIBELLE Tuplibelleusage
    FROM BIENIMMOBILIER,
    LANTBIENTYPE,
    LANTBTNATURE,
    LANTBTNATGENRE,
    LANTUSPARAM ,
    LANTUSPARAM LTP
    WHERE BIENIMMOBILIER.TBTCODE = LANTBTNATURE.TBTCODE (+)
    AND BIENIMMOBILIER.TBNCODE = LANTBTNATURE.TBNCODE (+)
    AND LANTBTNATURE.LANCODE (+) = sgLangue
    AND  BIENIMMOBILIER.TBTCODE = LANTBTNATGENRE.TBTCODE (+)
    AND   BIENIMMOBILIER.TBNCODE = LANTBTNATGENRE.TBNCODE (+)
    AND   BIENIMMOBILIER.TNGCODE = LANTBTNATGENRE.TNGCODE (+)
    AND LANTBTNATGENRE.LANCODE (+) = sgLangue
    AND LANTUSPARAM.TUSNOM (+) = 'BIENDESTINATION'
    AND LANTUSPARAM.LANCODE (+) = sgLangue
    AND f_PlBimUsage(BIENIMMOBILIER.BIMID,NULL) = LANTUSPARAM.TUPCODE (+)
    AND BIENIMMOBILIER.TBTCODE = LANTBIENTYPE.TBTCODE
    AND  LANTBIENTYPE.LANCODE = sgLangue
    AND LTP.LANCODE (+)  = sgLangue
    AND LTP.TUSNOM (+)  = 'SECTEURGEST'
    AND LTP.TUPCODE (+) = BIENIMMOBILIER.BIMSECTEUR
    AND  f_PlBienIsModele( BIENIMMOBILIER.BIMID) = 0;
    END S_SEARCH_MANBIM ;*/
    --================= End Proc migrated on 05/June/2009=========
    PROCEDURE COUNT_L1FORMALITE (NFORID   IN     LKTSMFOR.FORID%TYPE,
                                 NVAL     IN OUT NUMBER)
    AS
    BEGIN
        BEGIN
            SELECT COUNT (FORIDLIEE)
              INTO NVAL
              FROM L1FORMALITE
             WHERE FORIDLIEE = NFORID AND FORID = NFORID;
        -- SELECT COUNT(*) INTO   nCount FROM LKTSMFOR WHERE FORID = nForid;
        END;
    END COUNT_L1FORMALITE;

    PROCEDURE EVENT_TBLREPEVENT_DESC (
        STMOMODULE          IN     LANTMOFONCTION.TMOMODULE%TYPE,
        SENTITEMATREEVENT   IN     LANTMOFONCTION.TMOMODULE%TYPE,
        STMFFONCTION        IN     LANTMOFONCTION.TMFFONCTION%TYPE,
        SMTACCODE           IN     TEVENEMENT.TACCODE%TYPE,
        SMTEVDEST           IN     TEVENEMENT.TEVDEST%TYPE,
        SLANGUE             IN     VARCHAR2,
        PC_RETURN           IN OUT T_CURSOR)
    AS
    --sLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
            SELECT TMFFONCTION AS CODE,
                   TMFLIBELLE  AS DISPLAYVALUE,
                   TMFLIBELLE  AS OTHERINFO
              FROM LANTMOFONCTION
             WHERE     LANCODE = SLANGUE
                   AND TMOMODULE = STMOMODULE
                   AND SUBSTR (TMFFONCTION, 1, 2) = 'U_'
                   AND TMFFONCTION NOT IN
                           (SELECT TMFFONCTION
                              FROM LANTEVENEMENT
                             WHERE     LANCODE = SLANGUE
                                   AND TMOMODULE = SENTITEMATREEVENT
                                   AND SUBSTR (TMFFONCTION, 1, 2) = 'U_')
            UNION
            -- SELECT  TMFFONCTION AS CODE,TMFLIBELLE AS DISPLAYVALUE,TMFLIBELLE AS OTHERINFO FROM  LANTMOFONCTION
            --  WHERE  LANCODE = sLangue
            --  AND TMOMODULE =sTMOMODULE
            --  AND  TMFFONCTION=sTmffonction
            SELECT DISTINCT
                   LAN.TMFFONCTION AS CODE,
                   LTE.TEVLIBELLE  AS DISPLAYVALUE,
                   LAN.TMFLIBELLE  AS OTHERINFO
              FROM LANTMOFONCTION LAN, TEVENEMENT TEV, LANTEVENEMENT LTE
             WHERE     LAN.LANCODE = SLANGUE
                   AND LTE.LANCODE = LAN.LANCODE
                   AND LAN.TMOMODULE = STMOMODULE
                   AND LAN.TMFFONCTION = TEV.TMFFONCTION
                   AND TEV.TMFFONCTION = LTE.TMFFONCTION
                   AND LAN.TMOMODULE = LTE.TMOMODULE
                   AND LAN.TMOMODULE = TEV.TMOMODULE
                   AND TEV.TEVDEST = LTE.TEVDEST
                   AND TEV.TACCODE = LTE.TACCODE
                   AND LAN.TMFFONCTION = STMFFONCTION
                   AND TEV.TACCODE = SMTACCODE
                   AND TEV.TMOMODULE = STMOMODULE
                   AND TEV.TEVDEST = SMTEVDEST;
    --      ORDER BY TMFLIBELLE;
    END EVENT_TBLREPEVENT_DESC;

    -- Accounting postings on OR items
    PROCEDURE S_CROJOURNAL (NACTID              CROJOURNAL.ACTID%TYPE,
                            SCJOCOMPTA          CROJOURNAL.CJOCOMPTA%TYPE,
                            SLANGUE      IN     VARCHAR2,
                            PC_RETURN    IN OUT T_CURSOR)
    AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT CJO.CJOJOURNAL,
                     LTCR.TCRCODE,
                     LTCR.TCRLIBELLE,
                     CJO.ACTID,
                     CJO.CJOCOMPTA
                FROM LANTCRO LTCR, CROJOURNAL CJO
               WHERE     CJO.ACTID = NACTID
                     AND CJO.CJOCOMPTA = SCJOCOMPTA       --tupCode from table
                     AND LANCODE = SLANGUE
                     AND LTCR.TCRCODE = CJO.TCRCODE
            ORDER BY LTCR.TCRCODE;
    END S_CROJOURNAL;

    PROCEDURE S_CROLIGAFFECTATION (
        STCRCODE            CROLIGAFFECTATION.TCRCODE%TYPE,
        NACTID              CROLIGAFFECTATION.ACTID%TYPE,
        SCJOCOMPTA          CROLIGAFFECTATION.CJOCOMPTA%TYPE,
        PC_RETURN    IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT CLI.TCRCODE,
                   CLI.TCLORDRE,
                   CLI.CLIORDRE,
                   CLI.CLILIBELLE,
                   DECODE (CLADEBITCREDIT,
                           'DEBIT', 'D',
                           'CREDIT', 'C',
                           CLADEBITCREDIT)
                       AS CLADEBITCREDIT,
                   --  CLADEBITCREDIT,
                   CLADTDEB,
                   CLADTFIN,
                   CLA.PCOID,
                   PCO.PCOCOMPTE,
                   CLA.CCRCODE,
                   CLA.TLDCHAMP,
                   1
                       ALFLAGINCLUS,
                   1
                       ALFLAGINCLUSDEBUT,
                   CLAJOURNALEXCEPTION
              FROM CROLIGAFFECTATION CLA, PLANCOMPTABLE PCO, CROLIGNE CLI
             WHERE     CLA.TCRCODE = STCRCODE
                   AND CLA.ACTID = NACTID
                   AND CLA.CJOCOMPTA = SCJOCOMPTA
                   AND CLI.TCRCODE = STCRCODE
                   AND CLI.ACTID = NACTID
                   AND CLI.CJOCOMPTA = SCJOCOMPTA
                   AND CLA.TCLORDRE = CLI.TCLORDRE
                   AND CLA.CLIORDRE = CLI.CLIORDRE
                   AND CLA.PCOID = PCO.PCOID
            UNION
            SELECT TCRCODE,
                   TCLORDRE,
                   CLIORDRE,
                   CLILIBELLE,
                   ''             AS CLADEBITCREDIT,
                   TO_DATE (NULL) AS CLADTDEB,
                   TO_DATE (NULL) AS CLADTFIN,
                   0              AS PCOID,
                   ''             AS PCOCOMPTE,
                   ''             AS CCRCODE,
                   ''             AS TLDCHAMP,
                   0              AS ALFLAGINCLUS,
                   0              AS ALFLAGINCLUSDEBUT,
                   TO_CHAR (NULL) AS CLAJOURNALEXCEPTION
              FROM CROLIGNE
             WHERE     TCRCODE = STCRCODE
                   AND ACTID = NACTID
                   AND CJOCOMPTA = SCJOCOMPTA
                   AND (TCRCODE,
                        ACTID,
                        CJOCOMPTA,
                        TCLORDRE,
                        CLIORDRE) NOT IN
                           (SELECT TCRCODE,
                                   ACTID,
                                   CJOCOMPTA,
                                   TCLORDRE,
                                   CLIORDRE
                              FROM CROLIGAFFECTATION)
            ORDER BY 1, 2, 3;
    END S_CROLIGAFFECTATION;

    -- Procedure for Search Field Account
    PROCEDURE S_ACCOUNTSEARCH (NACTID              CROJOURNAL.ACTID%TYPE,
                               SCJOCOMPTA          CROJOURNAL.CJOCOMPTA%TYPE,
                               SLANGUE      IN     VARCHAR2,
                               PC_RETURN    IN OUT T_CURSOR)
    AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        DECLARE
            MAXCOUNT   NUMBER;
        BEGIN
            SELECT PSYMAXSELECT INTO MAXCOUNT FROM PARSYSTEME;

            OPEN PC_RETURN FOR
                SELECT PLANCOMPTABLE.PCOID,
                       PLANCOMPTABLE.PCOCOMPTE,
                       PLANCOMPTABLE.PCOCOMPTA TUPCODE,
                       PLANCOMPTABLE.PCOLIBELLE,
                       PLANCOMPTABLE.PCOCLASSE
                  FROM PLANCOMPTABLE
                 WHERE     PLANCOMPTABLE.ACTID = NACTID
                       AND PLANCOMPTABLE.PCOCOMPTA = SCJOCOMPTA
                       AND ROWNUM < MAXCOUNT;
        END;
    END S_ACCOUNTSEARCH;

    -- Account selection per generic rules
    PROCEDURE S_ELEMENT_COUNT_CRITERIA_TREE (
        SUGECODE            ACTEUR.UGECODE%TYPE,
        SCCRCODE            CCRCHAMP.CCRCODE%TYPE,
        SLANGUE      IN     VARCHAR2,
        NUM_RETURN   IN OUT NUMBER)
    AS
    --sLangue LANDOCUMENT.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        SELECT COUNT (CCH.CCHCHAMP) CCHCHAMP
          INTO NUM_RETURN
          FROM CCRCHAMP CCH, LANCRITERECRO
         WHERE     LANCRITERECRO.CCRCODE = CCH.CCRCODE
               AND CCH.UGECODE = SUGECODE
               AND LANCODE = SLANGUE
               AND CCH.CCRCODE = SCCRCODE;
    END S_ELEMENT_COUNT_CRITERIA_TREE;

    PROCEDURE S_CRITERIA_RULE_TREE (
        SUGECODE           CRITERECRO.UGECODE%TYPE,
        SLANGUE     IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    --sLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT DISTINCT LAN.CCRCODE AS CCRCODE
                FROM CCRCHAMP CCH, LANCRITERECRO LAN
               WHERE     CCH.UGECODE = SUGECODE
                     AND LANCODE = SLANGUE
                     AND CCH.CCRCODE IN
                             (SELECT CCR.CCRCODE
                                FROM CRITERECRO CCR, LANCRITERECRO LCCR
                               WHERE     CCR.CCRCODE = LCCR.CCRCODE
                                     AND LCCR.LANCODE = SLANGUE
                                     AND CCR.UGECODE = SUGECODE
                                     AND CCR.UGECODE = LCCR.UGECODE)
            ORDER BY LAN.CCRCODE;
    END S_CRITERIA_RULE_TREE;

    PROCEDURE S_CRITERIA_MAPPING_CHILD (
        SCCRCODE           CCHIMPUTATION.CCRCODE%TYPE,
        SUGECODE           CRITERECRO.UGECODE%TYPE,
        SLANGUE     IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    --sLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT DISTINCT (CCHIMPUTATION.CIMORDRE) CIMORDRE,
                              CCHIMPUTATION.PCOID    CHVALEURPCOID,
                              PLANCOMPTABLE.PCOCOMPTE,
                              PLANCOMPTABLE.PCOCOMPTA,
                              LANTUSPARAM.TUPLIBELLE,
                              LANTUSPARAM.TUPCODE,
                              ACTEUR.ACTLIBCOURT,
                              PLANCOMPTABLE.ACTID,
                              CCHIMPUTATION.CCRCODE
                FROM CCHIMPUTATION,
                     PLANCOMPTABLE,
                     ACTEUR,
                     LANTUSPARAM
               WHERE     CCHIMPUTATION.CCRCODE = SCCRCODE
                     AND CCHIMPUTATION.PCOID = PLANCOMPTABLE.PCOID
                     AND ACTEUR.ACTID = PLANCOMPTABLE.ACTID
                     AND PLANCOMPTABLE.PCOCOMPTA = LANTUSPARAM.TUPCODE
                     AND LANTUSPARAM.LANCODE = SLANGUE
                     AND LANTUSPARAM.TUSNOM = 'COMPTACIBLE'
                     AND CCHIMPUTATION.UGECODE = SUGECODE
            ORDER BY ACTEUR.ACTLIBCOURT,
                     PLANCOMPTABLE.PCOCOMPTA,
                     PLANCOMPTABLE.PCOCOMPTE;
    END S_CRITERIA_MAPPING_CHILD;

    /*
    PROCEDURE S_CRITERIA_MAPPING_DETAIL(
    sCchChamp   CCHIMPUTATION.CCHCHAMP%TYPE,
    sCcrCode    CCHIMPUTATION.CCRCODE%TYPE,
    nPcoId      PLANCOMPTABLE.PCOID%TYPE,
    nCimOrdre   CCHIMPUTATION.CIMORDRE%TYPE,
    sUgeCode    UNITEGESTION.UGECODE%TYPE,
    PC_Return IN OUT T_Cursor) AS
    sLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
    open PC_Return for
    SELECT CCV.CIMOPER ,
    CCV.CIMVALEUR,
    LTP.TTPLIBELLE
    FROM   CCHIMPUTATION CCV,
    LANTTRPARAM LTP
    WHERE CCV.CCRCODE = sCcrCode
    AND   CCV.CCHCHAMP = sCchChamp
    AND   CCV.PCOID = nPcoId
    AND   CCV.CIMORDRE= nCimOrdre
    AND   LTP.TTRNOM (+) = 'OPREL'
    AND   LTP.TTPCODE (+) = CCV.CIMOPER
    AND   LTP.LANCODE(+) = sLangue
    AND   CCV.UGECODE = sUgeCode;
    END S_CRITERIA_MAPPING_DETAIL;
    */
    PROCEDURE S_CRITERIA_MAPPING_DETAIL (
        SCCRCODE           CCHIMPUTATION.CCRCODE%TYPE,
        NCIMORDRE          CCHIMPUTATION.CIMORDRE%TYPE,
        SUGECODE           UNITEGESTION.UGECODE%TYPE,
        SLANGUE     IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    --sLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
            SELECT CCH.CCRCODE  CCRCODE,
                   CCH.CCHCHAMP CCHCHAMP,
                   ''           AS CIMOPER,
                   ''           AS CIMVALEUR,
                   ''           AS TTPLIBELLE
              FROM CCRCHAMP CCH, LANCRITERECRO
             WHERE     CCH.UGECODE = SUGECODE
                   AND LANCRITERECRO.CCRCODE = CCH.CCRCODE
                   AND LANCODE = SLANGUE
                   AND CCH.CCRCODE = SCCRCODE
                   AND CCH.CCHCHAMP NOT IN
                           (SELECT DISTINCT CCHCHAMP
                              FROM CCHIMPUTATION CCV, LANTTRPARAM LTP
                             WHERE     CCV.CCRCODE = SCCRCODE
                                   AND LTP.TTPCODE(+) = CCV.CIMOPER
                                   AND LTP.LANCODE(+) = SLANGUE
                                   AND CCV.UGECODE = SUGECODE
                                   AND CCV.CIMORDRE = NCIMORDRE)
            UNION
            SELECT CCRCODE,
                   CCHCHAMP,
                   CCV.CIMOPER,
                   CCV.CIMVALEUR,
                   LTP.TTPLIBELLE
              FROM CCHIMPUTATION CCV, LANTTRPARAM LTP
             WHERE     CCV.CCRCODE = SCCRCODE
                   AND LTP.TTRNOM(+) = 'OPREL'
                   AND LTP.TTPCODE(+) = CCV.CIMOPER
                   AND LTP.LANCODE(+) = SLANGUE
                   AND CCV.UGECODE = SUGECODE
                   AND CCV.CIMORDRE = NCIMORDRE;
    END S_CRITERIA_MAPPING_DETAIL;

    PROCEDURE S_CREATE_DETAIL_CHILD_ROW (
        SUGECODE           CRITERECRO.UGECODE%TYPE,
        SCCRCODE           CCRCHAMP.CCRCODE%TYPE,
        SLANGUE     IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    --sLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
            SELECT CCH.CCRCODE              CCRCODE,
                   LANCRITERECRO.CCRLIBELLE CCRLIBELLE,
                   CCH.CCHCHAMP             CCHCHAMP
              FROM CCRCHAMP CCH, LANCRITERECRO
             WHERE     CCH.UGECODE = SUGECODE
                   AND LANCRITERECRO.CCRCODE = CCH.CCRCODE
                   AND LANCODE = SLANGUE
                   AND CCH.CCRCODE = SCCRCODE;
    END S_CREATE_DETAIL_CHILD_ROW;

    PROCEDURE S_COLCLCDTDEB (STCRCODE              CROLIGNE.TCRCODE%TYPE,
                             SCODECOMPTA           CROLIGNE.CJOCOMPTA%TYPE,
                             NTCLORDRE             CROLIGNE.TCLORDRE%TYPE,
                             NCODESOCIETE          CROLIGNE.ACTID%TYPE,
                             NCLIORDRE             CROLIGNE.CLIORDRE%TYPE,
                             PC_RETURN      IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT CLIDTDEB, CLIDTFIN
              FROM CROLIGNE CLI
             WHERE     CLI.TCRCODE = STCRCODE
                   AND CLI.CJOCOMPTA = SCODECOMPTA
                   AND CLI.TCLORDRE = NTCLORDRE
                   AND CLI.ACTID = NCODESOCIETE
                   AND CLI.CLIORDRE = NCLIORDRE;
    END S_COLCLCDTDEB;

    PROCEDURE S_COLCLCDTDEBDUMMY (
        STCRCODE              CROLIGNE.TCRCODE%TYPE,
        SCODECOMPTA           CROLIGNE.CJOCOMPTA%TYPE,
        NTCLORDRE             CROLIGNE.TCLORDRE%TYPE,
        NCODESOCIETE          CROLIGNE.ACTID%TYPE,
        NCLIORDRE             CROLIGNE.CLIORDRE%TYPE,
        PC_RETURN      IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT CLIDTDEB, CLIDTFIN
              FROM CROLIGNE CLI, CROLIGAFFECTATION CLA
             WHERE     CLI.TCRCODE = STCRCODE
                   AND CLI.CJOCOMPTA = SCODECOMPTA
                   AND CLI.TCLORDRE = NTCLORDRE
                   AND CLI.ACTID = NCODESOCIETE
                   AND CLI.CLIORDRE = NCLIORDRE
                   AND CLI.TCRCODE = CLA.TCRCODE
                   AND CLI.CJOCOMPTA = CLA.CJOCOMPTA
                   AND CLI.TCLORDRE = CLA.TCLORDRE
                   AND CLI.ACTID = CLA.ACTID
                   AND CLI.CLIORDRE = CLA.CLIORDRE;
    END S_COLCLCDTDEBDUMMY;

    FUNCTION F_CALCULATE_NO_GUARANTEE (NDOSID     DOSSIER.DOSID%TYPE,
                                       SFILTER    VARCHAR2)
        RETURN NUMBER
    IS
        NNOGUARANTEERV   NUMBER;
    BEGIN
        DECLARE
            NVALUE   NUMBER;
        BEGIN
            SELECT NVL (SUM (NVL (DRE.DREMTBASE, 0)), 0)
              INTO NNOGUARANTEERV
              FROM DOSRUBECHEANCIER DRE, DOSRUBRIQUE DRU
             WHERE     DRE.DOSID = NDOSID
                   AND DRE.DRETYPE = 'LOYER'
                   AND DRU.DOSID = NDOSID
                   AND DRU.DRUORDRE = DRE.DRUORDRE
                   AND DRU.DRUCLASSE = 'A'
                   AND DRU.RUBID IN
                           (SELECT A.RUBID
                              FROM RUBACCES A
                             WHERE     A.RUBID = DRU.RUBID
                                   AND A.RACACCES = SFILTER)
                   AND (   DRE.FACID IS NULL
                        OR F_PLRESTANTFACTURE (DRE.FACID, NULL) != 0);
        EXCEPTION
            WHEN OTHERS
            THEN
                NNOGUARANTEERV := NULL;
        END;

        RETURN NNOGUARANTEERV;
    END F_CALCULATE_NO_GUARANTEE;

    FUNCTION F_CALCULATE_NO_GUARANTEE_RV (NDOSID DOSSIER.DOSID%TYPE)
        RETURN NUMBER
    IS
        NNOGUARANTEERV   NUMBER;
    BEGIN
        DECLARE
            NMAXDRUORDRE   NUMBER;
        BEGIN
            SELECT MAX (DRUORDRE)
              INTO NMAXDRUORDRE
              FROM DOSRUBRIQUE DRQ
             WHERE DRQ.RUBID IN
                       (SELECT RAC.RUBID
                          FROM DOSRUBRIQUE DRU, RUBACCES RAC
                         WHERE     DRU.DOSID = NDOSID
                               AND RAC.RUBID = DRU.RUBID
                               AND RAC.RACACCES = 'ONGRV');

            IF NMAXDRUORDRE IS NULL
            THEN
                NNOGUARANTEERV := 0;
            ELSE
                SELECT SUM (DREMTBASE)
                  INTO NNOGUARANTEERV
                  FROM DOSRUBECHEANCIER DRU
                 WHERE     DRU.DOSID = NDOSID
                       AND DRU.DRUORDRE = NMAXDRUORDRE
                       AND DRU.DRETYPE = 'LOYER';
            END IF;
        EXCEPTION
            WHEN OTHERS
            THEN
                NNOGUARANTEERV := NULL;
        END;

        RETURN NNOGUARANTEERV;
    END F_CALCULATE_NO_GUARANTEE_RV;

    FUNCTION F_GETCLCID (STCRCODE        CROLIGNE.TCRCODE%TYPE,
                         SCODECOMPTA     CROLIGNE.CJOCOMPTA%TYPE,
                         NTCLORDRE       CROLIGNE.TCLORDRE%TYPE,
                         NCODESOCIETE    CROLIGNE.ACTID%TYPE,
                         NCLIORDRE       CROLIGNE.CLIORDRE%TYPE)
        RETURN NUMBER
    IS
        NCLCID   NUMBER;
    BEGIN
        SELECT MAX (CLCID)
          INTO NCLCID
          FROM CROLIGCONDITION
         WHERE     TCRCODE = STCRCODE
               AND CJOCOMPTA = SCODECOMPTA
               AND TCLORDRE = NTCLORDRE
               AND ACTID = NCODESOCIETE
               AND CLIORDRE = NCLIORDRE;

        RETURN NCLCID;
    END F_GETCLCID;

    PROCEDURE S_UTILISATEUR_LDAPREFERENCE (
        SUTILDAPREFERENCE   IN     UTILISATEUR.UTILDAPREFERENCE%TYPE,
        PC_RETURN           IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT UTICODE,
                   UTINOM,
                   UTIPRENOM,
                   UTITELECOM,
                   GROCODE,
                   UTIFLAGINACTIF,
                   UGECODE,
                   UTIPWD,
                   UTILOCKED,
                   UTIATTEMPTS,
                   UTICODESUBSTITUTE,
                   UTIPWDDTCHGD,
                   UTIFLAGPERMANENT,
                   UTIFLAGPASSWORD,
                   UTIDTUPD,
                   UTIWHODUNNIT,
                   UTILOCKTIME,
                   UTIPWDSALT,
                   UTILDAPREFERENCE
              FROM UTILISATEUR
             WHERE UPPER (LTRIM (RTRIM (UTILISATEUR.UTILDAPREFERENCE))) =
                   UPPER (LTRIM (RTRIM (SUTILDAPREFERENCE)));
    END S_UTILISATEUR_LDAPREFERENCE;

    PROCEDURE S_TYPELIGNEPROV (PC_RETURN IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR   SELECT TLPCODE,
                                    TLPCODECONTX,
                                    TLPACCES,
                                    TLPTXPROVDEFAUT,
                                    TLPFLAGSURETE,
                                    TLPMTSURETEDEFAUT,
                                    TLPFLAGPOOLPOSSIBLE,
                                    TLPFLAGPOOLSAISI,
                                    TLPCODECOMPTA,
                                    TLPFLAGFACTURATION,
                                    DEVCODE
                               FROM TTYPELIGNEPROV
                           ORDER BY TLPCODE;
    END S_TYPELIGNEPROV;

    PROCEDURE S_FORDESTINATION (NFORID             FORDESTINATION.FORID%TYPE,
                                PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT FORID,
                   FDEORDRE,
                   TPGCODE,
                   FDEULYSENDER,
                   NVL (FDEUTICODESENDER, FDEGROCODESENDER)
                       AS FDESENDER,
                   FDESECTGESTIONSENDER,
                   FDEMETIERSENDER,
                   FDEULYRECEIVER,
                   NVL (FDEUTICODERECEIVER, FDEGROCODERECEIVER)
                       AS FDERECEIVER,
                   FDESECTGESTIONRECEIVER,
                   FDEMETIERRECEIVER,
                   FDEACTION,
                   FDEPRIORITY
              FROM FORDESTINATION
             WHERE FORID = NFORID;
    END S_FORDESTINATION;

    PROCEDURE S_LKFDERUL (NFORID             LKFDERUL.FORID%TYPE,
                          NFDEORDRE   IN     LKFDERUL.FDEORDRE%TYPE,
                          PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR SELECT FORID, FDEORDRE, RULID
                             FROM LKFDERUL
                            WHERE FORID = NFORID AND FDEORDRE = NFDEORDRE;
    END S_LKFDERUL;

    --stored procedure for populating Rule shuttle in Automatic Task management
    PROCEDURE S_RULE (STARGET     IN     RULE.RULTARGET%TYPE,
                      SLANGUE     IN     LANGUE.LANCODE%TYPE,
                      PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT TO_CHAR (LR.RULID) AS CODE, LR.RULLABEL AS DISPLAYVALUE
              FROM RULE R, LANRULE LR
             WHERE     R.RULID = LR.RULID
                   AND R.RULTARGET = STARGET
                   AND LR.LANCODE = SLANGUE;
    END S_RULE;

    PROCEDURE S_LBTPGPARAMETERS (
        STOPTABLE          LANTOPTPGPARAM.TOPTABLE%TYPE,
        SLANGUE     IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT DISTINCT
                     TTP.TTPPARAM AS CODE, TTP.TTPLIBELLE AS DISPLAYVALUE
                FROM LANTOPTPGPARAM TTP
               WHERE TTP.TOPTABLE = STOPTABLE AND TTP.LANCODE = SLANGUE
            ORDER BY DISPLAYVALUE;
    END S_LBTPGPARAMETERS;

    PROCEDURE S_LBTPGPARAMETERSBYTPGCODE (
        STOPTABLE          LANTOPTPGPARAM.TOPTABLE%TYPE,
        SLANGUE     IN     VARCHAR2,
        STPGCODE    IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        DECLARE
        BEGIN
            IF STPGCODE IS NOT NULL
            THEN
                OPEN PC_RETURN FOR
                      SELECT DISTINCT
                             LANTTP.TTPPARAM AS CODE,
                             LANTTP.TTPLIBELLE AS DISPLAYVALUE
                        FROM LANTOPTPGPARAM LANTTP, TOPTPGPARAM TTP
                       WHERE     LANTTP.TOPTABLE = STOPTABLE
                             AND TTP.TOPTABLE = LANTTP.TOPTABLE
                             AND TTP.TTPPARAM = LANTTP.TTPPARAM
                             AND TTP.TPGCODE = LANTTP.TPGCODE
                             AND TTP.TPGCODE = STPGCODE
                             AND NOT EXISTS
                                     (SELECT NULL
                                        FROM TOPTPGPARAM T, TPROFILGESTION TPG
                                       WHERE     T.TPGCODE = TPG.TPGCODEPARENT
                                             AND TPG.TPGCODE = TTP.TPGCODE
                                             AND T.TOPTABLE = TTP.TOPTABLE
                                             AND T.TTPPARAM = TTP.TTPPARAM
                                             AND T.TTPHIERARCHY = 'NA')
                             AND LANTTP.LANCODE = SLANGUE
                    ORDER BY DISPLAYVALUE;
            ELSE
                OPEN PC_RETURN FOR
                      SELECT DISTINCT
                             LANTTP.TTPPARAM AS CODE,
                             LANTTP.TTPLIBELLE AS DISPLAYVALUE
                        FROM LANTOPTPGPARAM LANTTP, TOPTPGPARAM TTP
                       WHERE     LANTTP.TOPTABLE = STOPTABLE
                             AND TTP.TOPTABLE = LANTTP.TOPTABLE
                             AND TTP.TTPPARAM = LANTTP.TTPPARAM
                             AND TTP.TPGCODE = LANTTP.TPGCODE
                             AND NOT EXISTS
                                     (SELECT NULL
                                        FROM TOPTPGPARAM T, TPROFILGESTION TPG
                                       WHERE     T.TPGCODE = TPG.TPGCODEPARENT
                                             AND TPG.TPGCODE = TTP.TPGCODE
                                             AND T.TOPTABLE = TTP.TOPTABLE
                                             AND T.TTPPARAM = TTP.TTPPARAM
                                             AND T.TTPHIERARCHY = 'NA')
                             AND LANTTP.LANCODE = SLANGUE
                    ORDER BY DISPLAYVALUE;
            END IF;
        END;
    END S_LBTPGPARAMETERSBYTPGCODE;

    PROCEDURE S_LANTOPTPGPARAM (
        STOPTABLE          LANTOPTPGPARAM.TOPTABLE%TYPE,
        STPAPARAM          TOPTPGPARAM.TTPPARAM%TYPE,
        STPGCODE           LANTOPTPGPARAM.TPGCODE%TYPE,
        SLANGUE     IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT TTPAIDE,
                   TTPLIBLOGIQUE,
                   TTPLIBDATE,
                   TTPLIBNOMBRE,
                   TTPLIBTEXTE
              FROM LANTOPTPGPARAM
             WHERE     LANCODE = SLANGUE
                   AND TOPTABLE = STOPTABLE
                   AND TTPPARAM = STPAPARAM
                   AND ROWNUM = 1;
    --AND  TPGCODE = sTPGCODE  ;
    END S_LANTOPTPGPARAM;

    PROCEDURE S_TOPTPGPARAM (STOPTABLE          TOPTPGPARAM.TOPTABLE%TYPE,
                             STPAPARAM          TOPTPGPARAM.TTPPARAM%TYPE,
                             STPGCODE           LANTOPTPGPARAM.TPGCODE%TYPE,
                             PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT TTPLOGIQUE AS FLAGTPLOGIQUE,
                     TTPDATE,
                     TTPNOMBRE,
                     TTPTEXTE,
                     TTPDPTCODE,
                     TTPHIERARCHY
                FROM TOPTPGPARAM
               WHERE     TOPTABLE = STOPTABLE
                     AND TTPPARAM = STPAPARAM
                     AND TPGCODE = STPGCODE
            ORDER BY TTPPARAM;
    END S_TOPTPGPARAM;

    PROCEDURE S_PLANCOMPTABLE (NPCOID             PLANCOMPTABLE.PCOID%TYPE,
                               PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR SELECT PCOID,
                                  PCOLIBELLE,
                                  PCOTYPE,
                                  PCOFLAGINACTIVE,
                                  PCODTSTART,
                                  PCODTEND,
                                  PCOFLAGBALANCE,
                                  PCOFLAGCONTRACT,
                                  PCOFLAGACTOR,
                                  PCOFLAGCOUNTERPART,
                                  PCOFLAGMANAGEMENT,
                                  PCOTYPECOUNTERPART,
                                  PCOTYPEMANAGEMENT,
                                  PCONBDAYMATURITY,
                                  PCOSECTGESTION,
                                  PCOCOMPTE,
                                  PCOCLASSE
                             FROM PLANCOMPTABLE
                            WHERE PCOID = NPCOID;
    END S_PLANCOMPTABLE;

    PROCEDURE S_CMBRULE (SLANGUE            LANRULE.LANCODE%TYPE,
                         PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT RUL.RULID                     AS CODEINTEGER,
                     NVL (LAN.RULLABEL, RUL.RULCODE) AS DISPLAYVALUE
                FROM RULE RUL, LANRULE LAN
               WHERE     RUL.RULTARGET = 'ACCOUNT'
                     AND LAN.RULID(+) = RUL.RULID
                     AND LAN.LANCODE(+) = SLANGUE
            ORDER BY 2;
    END S_CMBRULE;

    PROCEDURE S_RULE_ACCOUNT (NPCOID             PLANCOMPTABLE.PCOID%TYPE,
                              PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT RULID
              FROM CUSTOMSETTING CSE, CUSDEFDATA CDE, CDDRUL CDD
             WHERE     CSE.CSETYPE = 'TABLE'
                   AND CSE.CSETABLE = 'PLANCOMPTABLE'
                   AND CSE.CSEENTITY = 'ACCOUNT'
                   AND CDE.CSEID = CSE.CSEID
                   AND CDE.CDDNUMERICVALUE = NPCOID
                   AND CDD.CSEID = CDE.CSEID
                   AND CDD.CDDORDRE = CDE.CDDORDRE;
    END S_RULE_ACCOUNT;

    PROCEDURE S_HISTOYPLANCOMPTABLE (
        NPCOID             PLANCOMPTABLE.PCOID%TYPE,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT TTA.TTADTMAJ       UPDDATE,
                     TTA.USERNAME       USERNAME,
                     TPD.TPDCOLONNE     FIELD,
                     TPD.TPDANCDATASTRING SOLDVALUE,
                     TPD.TPDNOUDATASTRING SNEWVALUE,
                     TPD.TPDANCDATADATE DOLDVALUE,
                     TPD.TPDNOUDATADATE DNEWVALUE,
                     TPD.TPDANCDATANUMBER NOLDVALUE,
                     TPD.TPDNOUDATANUMBER NNEWVALUE
                FROM TPISTABAUDIT TTA, TPISTABAUDDATA TPD
               WHERE     TTA.TTAID = TPD.TTAID
                     AND TPD.TPDCOLONNE != 'PCOID'
                     AND TTA.TTATABLE = 'PLANCOMPTABLE'
                     AND TTA.TTAID IN (SELECT TPD.TTAID
                                         FROM TPISTABAUDDATA TPD
                                        WHERE TPD.TPDANCDATANUMBER = NPCOID)
            ORDER BY TTA.TTADTMAJ DESC;
    END S_HISTOYPLANCOMPTABLE;

    PROCEDURE S_RULE_ROLE (SROLCODE           ROLE.ROLCODE%TYPE,
                           PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT RULID
              FROM CUSTOMSETTING CSE, CUSDEFDATA CDE, CDDRUL CDD
             WHERE     CSE.CSETYPE = 'TABLE'
                   AND CSE.CSETABLE = 'ROLE'
                   AND CSE.CSEENTITY = 'ACTEUR'
                   AND CDE.CSEID = CSE.CSEID
                   AND CDE.CDDSTRINGVALUE = SROLCODE
                   AND CDD.CSEID = CDE.CSEID
                   AND CDD.CDDORDRE = CDE.CDDORDRE;
    END S_RULE_ROLE;

    -- CASNT-515
    PROCEDURE S_LIST_RULE (SDEST              RULE.RULTARGET%TYPE,
                           PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR SELECT RULID,
                                  RULCODE,
                                  RULTARGET,
                                  RULOPERATOR,
                                  RULLOWERLIMIT,
                                  RULUPPERLIMIT,
                                  RULSTATUS,
                                  CRIIDFIRST,
                                  RULIDFIRST,
                                  RULIDSECOND,
                                  CRIIDSECONDMAX,
                                  CRIIDSECONDMIN,
                                  RULTYPE,
                                  RULFLAGCASSIOPAE
                             FROM RULE
                            WHERE RULTARGET = SDEST;
    END S_LIST_RULE;

    PROCEDURE S_CRITERIA_ALL (P_CRIID            CRITERIA.CRIID%TYPE,
                              PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT CRIID,
                   CRICODE,
                   CRITARGET,
                   CRITABLETOSEARCH,
                   CRICOLUMNTOSEARCH,
                   CRILANDESCRIPTIONCOLUMN,
                   CRIFUNCTION,
                   CRIVALUETYPE,
                   CRIFILTERCLAUSE,
                   CRIPARAMETER,
                   CRITABLESETTING,
                   CRITARGETTABLE,
                   CRITARGETCOLUMN,
                   CRIFLAGCASSIOPAE,
                   CRITABLETYPE
              FROM CRITERIA;
    END S_CRITERIA_ALL;

    PROCEDURE S_CRITERIA_BY_CRIIID (P_CRIID            CRITERIA.CRIID%TYPE,
                                    PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR SELECT CRIID,
                                  CRICODE,
                                  CRITARGET,
                                  CRITABLETOSEARCH,
                                  CRICOLUMNTOSEARCH,
                                  CRILANDESCRIPTIONCOLUMN,
                                  CRIFUNCTION,
                                  CRIVALUETYPE,
                                  CRIFILTERCLAUSE,
                                  CRIPARAMETER,
                                  CRITABLESETTING,
                                  CRITARGETTABLE,
                                  CRITARGETCOLUMN,
                                  CRIFLAGCASSIOPAE
                             FROM CRITERIA
                            WHERE CRIID = P_CRIID;
    END S_CRITERIA_BY_CRIIID;

    FUNCTION F_VERIFY_RULE (NRULID      NUMBER,
                            NNUMID      NUMBER,
                            SUTICODE    VARCHAR2,
                            SRESULTS    VARCHAR2)
        RETURN NUMBER
    IS
        L_RESULT        NUMBER := 0;
        L_CRIIDFIRST    NUMBER;
        L_RULOPERATOR   RULE.RULOPERATOR%TYPE;
        L_CRICODE       CRITERIA.CRICODE%TYPE;
        L_LOWER         VARCHAR2 (100);
        L_UPPER         VARCHAR2 (100);
        L_VAR           VARCHAR2 (2);
        L_VALUE         VARCHAR2 (100);
        L_TYPE          CRITERIA.CRIVALUETYPE%TYPE;
        NLOWER          NUMBER;
        NUPPER          NUMBER;
        NVALUE          NUMBER;
        NRVAVALUE       NUMBER;
        L_RULIDVALUE    RULE.RULID%TYPE;
        L_RVAVALUE      RULVALUE.RVAVALUE%TYPE;

        CURSOR C_RULVALUE
        IS
            SELECT RVAVALUE, RULIDVALUE
              FROM RULVALUE
             WHERE RULID = NRULID;
    BEGIN
        BEGIN
            SELECT R.CRIIDFIRST,
                   R.RULOPERATOR,
                   C.CRICODE,
                   R.RULLOWERLIMIT,
                   R.RULUPPERLIMIT,
                   C.CRIVALUETYPE
              INTO L_CRIIDFIRST,
                   L_RULOPERATOR,
                   L_CRICODE,
                   L_LOWER,
                   L_UPPER,
                   L_TYPE
              FROM RULE R, CRITERIA C
             WHERE C.CRIID = R.CRIIDFIRST AND R.RULID = NRULID;

            IF L_TYPE = 'NUMBER'
            THEN
                BEGIN
                    NLOWER := TO_CHAR (L_LOWER);
                    NUPPER := TO_CHAR (L_UPPER);
                EXCEPTION
                    WHEN OTHERS
                    THEN
                        NLOWER := TO_CHAR (REPLACE (L_LOWER, '.', ','));
                        NUPPER := TO_CHAR (REPLACE (L_UPPER, '.', ','));
                END;
            END IF;

            CASE L_CRICODE
                WHEN 'RGAVDOSS_ET'
                THEN
                    L_VAR := 'ET';
                -- les r??gles doivent ??tre dans RULVALUE et operateur = "IN"
                WHEN 'RGAVDOSS_OU'
                THEN
                    L_VAR := 'OU';
                -- les r??gles doivent ??tre dans RULVALUE et operateur = "IN"
                ELSE
                    L_VAR := NULL;
                    L_VALUE :=
                        GET_CRITERE_FULL_VALUES (L_CRIIDFIRST,
                                                 L_CRICODE,
                                                 SRESULTS,
                                                 NNUMID,
                                                 SUTICODE,
                                                 'AVDOSS');
                    PAV4_TRACE.DEBUG ('l_value : ' || L_VALUE);
            END CASE;

            PAV4_TRACE.DEBUG ('operator : ' || L_RULOPERATOR);

            IF L_TYPE = 'NUMBER'
            THEN
                BEGIN
                    NVALUE := TO_CHAR (L_VALUE);
                EXCEPTION
                    WHEN OTHERS
                    THEN
                        NVALUE := TO_CHAR (REPLACE (L_VALUE, '.', ','));
                END;
            END IF;

            CASE L_RULOPERATOR
                WHEN '='
                THEN
                    CASE L_TYPE
                        WHEN 'STRING'
                        THEN
                            IF TO_CHAR (L_VALUE) = TO_CHAR (L_LOWER)
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                        WHEN 'NUMBER'
                        THEN
                            IF NVALUE = NLOWER
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                        WHEN 'DATE'
                        THEN
                            IF TO_DATE (L_VALUE) = TO_DATE (L_LOWER)
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                        ELSE
                            IF L_VALUE = L_LOWER
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                    END CASE;
                WHEN '>='
                THEN
                    CASE L_TYPE
                        WHEN 'STRING'
                        THEN
                            IF TO_CHAR (L_VALUE) >= TO_CHAR (L_LOWER)
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                        WHEN 'NUMBER'
                        THEN
                            IF NVALUE >= NLOWER
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                        WHEN 'DATE'
                        THEN
                            IF TO_DATE (L_VALUE) >= TO_DATE (L_LOWER)
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                        ELSE
                            IF L_VALUE >= L_LOWER
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                    END CASE;
                WHEN '<='
                THEN
                    CASE L_TYPE
                        WHEN 'STRING'
                        THEN
                            IF TO_CHAR (L_VALUE) <= TO_CHAR (L_LOWER)
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                        WHEN 'NUMBER'
                        THEN
                            IF NVALUE <= NLOWER
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                        WHEN 'DATE'
                        THEN
                            IF TO_DATE (L_VALUE) <= TO_DATE (L_LOWER)
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                        ELSE
                            IF L_VALUE <= L_LOWER
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                    END CASE;
                WHEN '<'
                THEN
                    CASE L_TYPE
                        WHEN 'STRING'
                        THEN
                            IF TO_CHAR (L_VALUE) < TO_CHAR (L_LOWER)
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                        WHEN 'NUMBER'
                        THEN
                            IF NVALUE < NLOWER
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                        WHEN 'DATE'
                        THEN
                            IF TO_DATE (L_VALUE) < TO_DATE (L_LOWER)
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                        ELSE
                            IF L_VALUE < L_LOWER
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                    END CASE;
                WHEN '>'
                THEN
                    CASE L_TYPE
                        WHEN 'STRING'
                        THEN
                            IF TO_CHAR (L_VALUE) > TO_CHAR (L_LOWER)
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                        WHEN 'NUMBER'
                        THEN
                            IF NVALUE > NLOWER
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                        WHEN 'DATE'
                        THEN
                            IF TO_DATE (L_VALUE) > TO_DATE (L_LOWER)
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                        ELSE
                            IF L_VALUE > L_LOWER
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                    END CASE;
                WHEN 'LIKE'
                THEN
                    BEGIN
                        SELECT 1
                          INTO L_RESULT
                          FROM DUAL
                         WHERE L_VALUE LIKE '%' || L_LOWER || '%';
                    EXCEPTION
                        WHEN OTHERS
                        THEN
                            L_RESULT := 0;
                    END;
                WHEN 'BETWEEN'
                THEN
                    CASE L_TYPE
                        WHEN 'STRING'
                        THEN
                            IF     TO_CHAR (L_VALUE) >= TO_CHAR (L_LOWER)
                               AND TO_CHAR (L_VALUE) <= TO_CHAR (L_UPPER)
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                        WHEN 'NUMBER'
                        THEN
                            IF NVALUE >= NLOWER AND NVALUE <= NUPPER
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                        WHEN 'DATE'
                        THEN
                            IF     TO_DATE (L_VALUE) >= TO_DATE (L_LOWER)
                               AND TO_DATE (L_VALUE) <= TO_DATE (L_UPPER)
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                        ELSE
                            IF L_VALUE >= L_LOWER AND L_VALUE <= L_UPPER
                            THEN
                                L_RESULT := 1;
                            ELSE
                                L_RESULT := 0;
                            END IF;
                    END CASE;
                WHEN 'IN'
                THEN
                    PAV4_TRACE.DEBUG (
                        'debut test IN de la RULID : ' || NRULID);

                    OPEN C_RULVALUE;

                    LOOP
                        FETCH C_RULVALUE INTO L_RVAVALUE, L_RULIDVALUE;

                        IF L_TYPE = 'NUMBER'
                        THEN
                            BEGIN
                                NRVAVALUE := TO_CHAR (L_RVAVALUE);
                            EXCEPTION
                                WHEN OTHERS
                                THEN
                                    NRVAVALUE :=
                                        TO_CHAR (
                                            REPLACE (L_RVAVALUE, '.', ','));
                            END;
                        END IF;

                        EXIT WHEN C_RULVALUE%NOTFOUND;

                        IF L_VAR IS NULL
                        THEN
                            -- recup rvavalue de RULVALUE
                            PAV4_TRACE.DEBUG ('rvavalue : ' || L_RVAVALUE);

                            CASE L_TYPE
                                WHEN 'STRING'
                                THEN
                                    IF TO_CHAR (L_VALUE) =
                                       TO_CHAR (L_RVAVALUE)
                                    THEN
                                        L_RESULT := 1;
                                    ELSE
                                        L_RESULT := 0;
                                    END IF;
                                WHEN 'NUMBER'
                                THEN
                                    IF NVALUE = NRVAVALUE
                                    THEN
                                        L_RESULT := 1;
                                    ELSE
                                        L_RESULT := 0;
                                    END IF;
                                WHEN 'DATE'
                                THEN
                                    IF TO_DATE (L_VALUE) =
                                       TO_DATE (L_RVAVALUE)
                                    THEN
                                        L_RESULT := 1;
                                    ELSE
                                        L_RESULT := 0;
                                    END IF;
                                ELSE
                                    IF L_VALUE = L_RVAVALUE
                                    THEN
                                        L_RESULT := 1;
                                    ELSE
                                        L_RESULT := 0;
                                    END IF;
                            END CASE;

                            IF L_RESULT = 1
                            THEN
                                GOTO END_;
                            END IF;
                        ELSIF L_VAR = 'ET'
                        THEN
                            L_RESULT :=
                                F_VERIFY_RULE (L_RULIDVALUE,
                                               NNUMID,
                                               SUTICODE,
                                               SRESULTS);

                            IF L_RESULT = 0
                            THEN
                                GOTO END_;
                            END IF;
                        ELSE                                      --L_VAR='OU'
                            L_RESULT :=
                                F_VERIFY_RULE (L_RULIDVALUE,
                                               NNUMID,
                                               SUTICODE,
                                               SRESULTS);

                            IF L_RESULT = 1
                            THEN
                                GOTO END_;
                            END IF;
                        END IF;
                    END LOOP;

                   <<END_>>
                    CLOSE C_RULVALUE;
                WHEN 'NOTIN'
                THEN
                    PAV4_TRACE.DEBUG (
                        'debut test NOTIN de la RULID : ' || NRULID);

                    OPEN C_RULVALUE;

                    LOOP
                        FETCH C_RULVALUE INTO L_RVAVALUE, L_RULIDVALUE;

                        IF L_TYPE = 'NUMBER'
                        THEN
                            BEGIN
                                NRVAVALUE := TO_CHAR (L_RVAVALUE);
                            EXCEPTION
                                WHEN OTHERS
                                THEN
                                    NRVAVALUE :=
                                        TO_CHAR (
                                            REPLACE (L_RVAVALUE, '.', ','));
                            END;
                        END IF;

                        EXIT WHEN C_RULVALUE%NOTFOUND;

                        IF L_VAR IS NULL
                        THEN
                            -- recup rvavalue de RULVALUE
                            PAV4_TRACE.DEBUG ('rvavalue : ' || L_RVAVALUE);

                            CASE L_TYPE
                                WHEN 'STRING'
                                THEN
                                    IF TO_CHAR (L_VALUE) =
                                       TO_CHAR (L_RVAVALUE)
                                    THEN
                                        L_RESULT := 0;
                                        GOTO END2_;
                                    ELSE
                                        L_RESULT := 1;
                                    END IF;
                                WHEN 'NUMBER'
                                THEN
                                    IF NVALUE = NRVAVALUE
                                    THEN
                                        L_RESULT := 0;
                                        GOTO END2_;
                                    ELSE
                                        L_RESULT := 1;
                                    END IF;
                                WHEN 'DATE'
                                THEN
                                    IF TO_DATE (L_VALUE) =
                                       TO_DATE (L_RVAVALUE)
                                    THEN
                                        L_RESULT := 0;
                                        GOTO END2_;
                                    ELSE
                                        L_RESULT := 1;
                                    END IF;
                                ELSE
                                    IF L_VALUE = L_RVAVALUE
                                    THEN
                                        L_RESULT := 0;
                                        GOTO END2_;
                                    ELSE
                                        L_RESULT := 1;
                                    END IF;
                            END CASE;

                            IF L_RESULT = 0
                            THEN
                                GOTO END2_;
                            END IF;
                        ELSIF L_VAR = 'ET'
                        THEN
                            L_RESULT :=
                                F_VERIFY_RULE (L_RULIDVALUE,
                                               NNUMID,
                                               SUTICODE,
                                               SRESULTS);

                            IF L_RESULT = 1
                            THEN
                                GOTO END2_;
                            END IF;
                        ELSE                                      --L_VAR='OU'
                            L_RESULT :=
                                F_VERIFY_RULE (L_RULIDVALUE,
                                               NNUMID,
                                               SUTICODE,
                                               SRESULTS);

                            IF L_RESULT = 0
                            THEN
                                GOTO END2_;
                            END IF;
                        END IF;
                    END LOOP;

                   <<END2_>>
                    CLOSE C_RULVALUE;
                ELSE
                    L_RESULT := 0;
            END CASE;
        EXCEPTION
            WHEN OTHERS
            THEN
                L_RESULT := 0;
        END;

        RETURN L_RESULT;
    END;

    --
    ------- Get Crit??re Full Values
    --
    FUNCTION GET_CRITERE_FULL_VALUES (P_CRIIDFIRST      VARCHAR2,
                                      P_CRICODEFIRST    VARCHAR2,
                                      P_RESULT          VARCHAR2,
                                      NNUMID            NUMBER,
                                      SUTICODE          VARCHAR2,
                                      STEVDEST          VARCHAR2)
        RETURN VARCHAR2
    IS
        L_VALUE   VARCHAR2 (100);
    BEGIN
        L_VALUE := GET_CRITERE_JAVA_VALUES (P_CRICODEFIRST, P_RESULT);

        IF (L_VALUE IS NULL)
        THEN
            --l_value := getvaluecriteria(P_criidfirst,sTevDest,sUtiCode,nNumId);
            L_VALUE :=
                GETVALUECRITERIA (P_CRIIDFIRST,
                                  STEVDEST,
                                  SUTICODE,
                                  NNUMID);
        END IF;

        RETURN L_VALUE;
    END GET_CRITERE_FULL_VALUES;

    --
    -- GET_CRITERE_JAVA_VALUES
    --
    FUNCTION GET_CRITERE_JAVA_VALUES (P_CRICODEFIRST    VARCHAR2,
                                      P_RESULT          VARCHAR2)
        RETURN VARCHAR2
    AS
        NVALUEFROMJAVA   VARCHAR2 (125) := 'test';
        NVALUE           VARCHAR2 (125);
        NINDEX           NUMBER;
        NCRITERE         VARCHAR2 (125) := '';
    BEGIN
        NINDEX := 1;

        IF (P_RESULT IS NOT NULL)
        THEN
            WHILE NVALUEFROMJAVA IS NOT NULL
            LOOP
                SELECT MAX (PAV4_SELECTPARGEN.SPLIT (P_RESULT, NINDEX, '|'))
                  INTO NVALUEFROMJAVA
                  FROM DUAL;

                PAV4_TRACE.DEBUG ('value R??cup??rer : ' || NVALUEFROMJAVA);

                SELECT MAX (PAV4_SELECTPARGEN.SPLIT (NVALUEFROMJAVA, 1, '='))
                  INTO NCRITERE
                  FROM DUAL;

                NINDEX := NINDEX + 1;
                EXIT WHEN LOWER (NCRITERE) = LOWER (P_CRICODEFIRST);
            END LOOP;

            PAV4_TRACE.DEBUG ('value R??cup??rer : ' || NVALUEFROMJAVA);
            PAV4_TRACE.DEBUG ('Crit??re Code : ' || NCRITERE);

            SELECT MAX (PAV4_SELECTPARGEN.SPLIT (NVALUEFROMJAVA, 2, '='))
              INTO NVALUE
              FROM DUAL;
        END IF;

        PAV4_TRACE.DEBUG ('value final du crit??re: ' || NVALUE);
        RETURN NVALUE;
    END GET_CRITERE_JAVA_VALUES;

    --
    ----- Split Function to split a string and fetch him in values
    --
    FUNCTION SPLIT (PC$CHAINE   IN VARCHAR2,
                    PN$POS      IN PLS_INTEGER,
                    PC$SEP      IN VARCHAR2 DEFAULT '|')
        RETURN VARCHAR2
    IS
        LC$CHAINE   VARCHAR2 (32767) := PC$SEP || PC$CHAINE;
        LI$I        PLS_INTEGER;
        LI$I2       PLS_INTEGER;
    BEGIN
        LI$I :=
            INSTR (LC$CHAINE,
                   PC$SEP,
                   1,
                   PN$POS);

        IF LI$I > 0
        THEN
            LI$I2 :=
                INSTR (LC$CHAINE,
                       PC$SEP,
                       1,
                       PN$POS + 1);

            IF LI$I2 = 0
            THEN
                LI$I2 := LENGTH (LC$CHAINE) + 1;
            END IF;

            RETURN (SUBSTR (LC$CHAINE, LI$I + 1, LI$I2 - LI$I - 1));
        ELSE
            RETURN NULL;
        END IF;
    END;

    FUNCTION GETVALUECRITERIA (NCRIID      CRITERIA.CRIID%TYPE,
                               STARGET     RULE.RULTARGET%TYPE,
                               SUTICODE    UTILISATEUR.UTICODE%TYPE,
                               NNUMID      NUMBER)
        RETURN VARCHAR2
    IS
    BEGIN
        DECLARE
            SRETVAL         VARCHAR2 (2000);
            SFROM           VARCHAR2 (100);
            SFROMDEST       VARCHAR2 (100);
            SIDENTIFIANT    VARCHAR2 (32);
            SATT            VARCHAR2 (2000);
            SWHERE          VARCHAR2 (2000);
            SFUNCTION       CRITERIA.CRIFUNCTION%TYPE;
            SPARAMETER      CRITERIA.CRIPARAMETER%TYPE;
            STABLE          CRITERIA.CRITARGETTABLE%TYPE;
            SCOLUMN         CRITERIA.CRITARGETCOLUMN%TYPE;
            SFILTER         CRITERIA.CRIFILTERCLAUSE%TYPE;
            SVALUETYPE      CRITERIA.CRIVALUETYPE%TYPE;
            SSELECT         VARCHAR2 (5000);
            CURSOR_HANDLE   INTEGER := 0;
            NLIGNE          NUMBER;
        BEGIN
            SELECT CRIFUNCTION,
                   CRIPARAMETER,
                   CRITARGETTABLE,
                   CRITARGETCOLUMN,
                   CRIFILTERCLAUSE,
                   CRIVALUETYPE
              INTO SFUNCTION,
                   SPARAMETER,
                   STABLE,
                   SCOLUMN,
                   SFILTER,
                   SVALUETYPE
              FROM CRITERIA
             WHERE CRIID = NCRIID;

            --recherche la table et l attribut de l identifant  suivant la destination
            IF STARGET IN ('ACTEUR',
                           'BUDGET',
                           'DEPENSE',
                           'DOSSIER',
                           'FACTURE',
                           'MANDAT')
            THEN
                SFROMDEST := STARGET;

                IF STARGET = 'ACTEUR'
                THEN
                    SIDENTIFIANT := 'ACTID';
                ELSIF STARGET = 'BUDGET'
                THEN
                    SIDENTIFIANT := 'BUDID';
                ELSIF STARGET = 'DEPENSE'
                THEN
                    SIDENTIFIANT := 'DEPID';
                ELSIF STARGET = 'DOSSIER'
                THEN
                    SIDENTIFIANT := 'DOSID';
                ELSIF STARGET = 'FACTURE'
                THEN
                    SIDENTIFIANT := 'FACID';
                ELSIF STARGET = 'MANDAT'
                THEN
                    SIDENTIFIANT := 'MANID';
                END IF;
            ELSIF STARGET = 'AVDOSS'
            THEN
                SFROMDEST := 'DOSSIERPROSPECT';
                SIDENTIFIANT := 'DOSID';
            ELSIF STARGET = 'ASSUR'
            THEN
                SFROMDEST := 'ASSURANCE';
                SIDENTIFIANT := 'ASSID';
            ELSIF STARGET = 'BIEN'
            THEN
                SFROMDEST := 'BIENIMMOBILIER';
                SIDENTIFIANT := 'BIMID';
            ELSIF STARGET = 'CHAN'
            THEN
                SFROMDEST := 'CHANTIER';
                SIDENTIFIANT := 'CHAID';
            ELSIF STARGET IN ('COMDE', 'COMRESA', 'COMTRAV')
            THEN
                SFROMDEST := 'COMMANDE';
                SIDENTIFIANT := 'COMID';
            ELSIF STARGET = 'CONEXP'
            THEN
                SFROMDEST := 'CONTRATEXPLOITATION';
                SIDENTIFIANT := 'CEXID';
            ELSIF STARGET = 'CONSULT'
            THEN
                SFROMDEST := 'CONSULTATION';
                SIDENTIFIANT := 'CONID';
            ELSIF STARGET = 'REGLE'
            THEN
                SFROMDEST := 'REGLEMENT';
                SIDENTIFIANT := 'REGID';
            ELSIF STARGET = 'SINIST'
            THEN
                SFROMDEST := 'SINISTRE';
                SIDENTIFIANT := 'SINID';
            ELSIF STARGET = 'SITU'
            THEN
                SFROMDEST := 'DEPENSE';
                SIDENTIFIANT := 'DEPID';
            ELSIF STARGET = 'TRANCHE'
            THEN
                SFROMDEST := 'IMMOTRANCHE';
                SIDENTIFIANT := 'ITRID';
            ELSE
                -- erreur destination non prise en compte
                RETURN SRETVAL;
            END IF;

            SFROM := SFROMDEST;

            IF SFUNCTION IS NOT NULL AND STABLE IS NULL
            THEN
                -- alors exec de la fonction en lui passant le numID
                SSELECT :=
                       'SELECT '
                    || SFUNCTION
                    || '('
                    || NNUMID
                    || ','''
                    || SUTICODE
                    || ''') FROM DUAL';
            ELSE
                IF SFUNCTION IS NOT NULL
                THEN
                    SATT := ' SELECT ';

                    IF SVALUETYPE = 'DATE'
                    THEN
                        SATT := SATT || ' TO_CHAR (' || SFUNCTION;
                    ELSE
                        SATT := SATT || SFUNCTION;
                    END IF;

                    IF SPARAMETER IS NOT NULL
                    THEN
                        SATT := SATT || '(' || SPARAMETER || ')';
                    END IF;

                    IF SVALUETYPE = 'DATE'
                    THEN
                        SATT := SATT || ' , ''DD/MM/YYYY'')';
                    END IF;
                ELSIF STABLE IS NOT NULL
                THEN
                    IF SCOLUMN IS NOT NULL
                    THEN
                        SATT := STABLE || '.' || SCOLUMN;

                        IF SVALUETYPE = 'DATE'
                        THEN
                            SATT :=
                                   ' SELECT TO_CHAR('
                                || SATT
                                || ' , ''DD/MM/YYYY'')';
                        ELSE
                            SATT := ' SELECT ' || SATT;
                        END IF;

                        IF SFROM != STABLE
                        THEN
                            SFROM := SFROM || ',' || STABLE;
                        END IF;
                    ELSE
                        RETURN SRETVAL;
                    --erreur colonne non definie
                    END IF;
                ELSE
                    -- erreur donnee insuffsante
                    RETURN SRETVAL;
                END IF;

                SWHERE :=
                       ' WHERE '
                    || SFROMDEST
                    || '.'
                    || SIDENTIFIANT
                    || ' = '
                    || TO_CHAR (NNUMID);

                IF STARGET = 'AVDOSS'
                THEN
                    SWHERE :=
                           SWHERE
                        || ' AND  DPRVERSION = ( SELECT DPRVERSION FROM V_DEAL WHERE DOSID = '
                        || NNUMID
                        || ')';
                END IF;

                IF SFILTER IS NOT NULL
                THEN
                    SWHERE := SWHERE || ' AND  ' || SFILTER;
                END IF;

                SSELECT := SATT || ' FROM ' || SFROM || SWHERE;
            END IF;

            PAV4_TRACE.DEBUG (SSELECT);

            BEGIN
                CURSOR_HANDLE := DBMS_SQL.OPEN_CURSOR;
                DBMS_SQL.PARSE (CURSOR_HANDLE, SSELECT, DBMS_SQL.NATIVE);
                DBMS_SQL.DEFINE_COLUMN (CURSOR_HANDLE,
                                        1,
                                        SRETVAL,
                                        2000);
                NLIGNE := DBMS_SQL.EXECUTE_AND_FETCH (CURSOR_HANDLE);

                LOOP
                    EXIT WHEN NLIGNE = 0;
                    DBMS_SQL.COLUMN_VALUE (CURSOR_HANDLE, 1, SRETVAL);
                    EXIT;
                END LOOP;
            EXCEPTION
                WHEN OTHERS
                THEN
                    --Erreur sur interpretation
                    DBMS_SQL.CLOSE_CURSOR (CURSOR_HANDLE);
                    RETURN SRETVAL;
            END;

            DBMS_SQL.CLOSE_CURSOR (CURSOR_HANDLE);
            RETURN SRETVAL;
        END;
    END GETVALUECRITERIA;

    PROCEDURE S_CMBRULEACTEUR (SLANGUE            LANRULE.LANCODE%TYPE,
                               PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT RUL.RULID                     AS CODEINTEGER,
                     NVL (LAN.RULLABEL, RUL.RULCODE) AS DISPLAYVALUE
                FROM RULE RUL, LANRULE LAN
               WHERE     RUL.RULTARGET = 'ACTEUR'
                     AND LAN.RULID(+) = RUL.RULID
                     AND LAN.LANCODE(+) = SLANGUE
            ORDER BY 2;
    END S_CMBRULEACTEUR;

    PROCEDURE GET_PAYTEL (NPAYCODE   IN     PAYS.PAYCODE%TYPE,
                          NPAYTEL       OUT PAYS.PAYTEL%TYPE)
    AS
    BEGIN
        BEGIN
            SELECT PAYTEL
              INTO NPAYTEL
              FROM PAYS
             WHERE PAYS.PAYCODE = NPAYCODE;
        END;
    END GET_PAYTEL;

    PROCEDURE S_LISTE_UTITSM_DEPT (SUTICODE           UTITSM.UTICODE%TYPE,
                                   PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR SELECT UTICODE,
                                  TSMSECTGESTION,
                                  TSMMETIER,
                                  TSMFLAGSUPERVISEUR,
                                  TSMFLAGDEFAUT,
                                  TSMPARTNAME,
                                  TSMCOUNGR,
                                  TSMCOUNEGE
                             FROM UTITSM
                            WHERE UTICODE = SUTICODE;
    END S_LISTE_UTITSM_DEPT;

    FUNCTION GET_UTICODELINKED (
        SUTICODE           UTIUSERLINK.UTICODE%TYPE,
        STSMSECTGESTION    UTIUSERLINK.ULISECTGEST%TYPE,
        STSMMETIER         UTIUSERLINK.ULIMETIER%TYPE)
        RETURN VARCHAR2
    IS
        SUTICODELINKED   VARCHAR2 (15);
    BEGIN
        SELECT UTICODELINKED
          INTO SUTICODELINKED
          FROM UTIUSERLINK
         WHERE     ULITYPE LIKE 'MANAGER'
               AND UTICODE LIKE SUTICODE
               AND ULISECTGEST = STSMSECTGESTION
               AND ULIMETIER = STSMMETIER;

        RETURN SUTICODELINKED;
    END GET_UTICODELINKED;

    FUNCTION GET_UTIEXTERNALREFERENCE (SUTICODE UTIUSERLINK.UTICODE%TYPE)
        RETURN VARCHAR2
    IS
        SUTIREF   VARCHAR2 (250);
    BEGIN
        SELECT UTIEXTERNALREFERENCE
          INTO SUTIREF
          FROM UTILISATEUR
         WHERE UTICODE LIKE SUTICODE;

        RETURN SUTIREF;
    END GET_UTIEXTERNALREFERENCE;

    PROCEDURE S_L1FORMALITE (NFORID      IN     L1FORMALITE.FORID%TYPE,
                             PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR SELECT FORID, FORIDLIEE, FO1TYPELINK
                             FROM L1FORMALITE
                            WHERE FORID = NFORID;
    END S_L1FORMALITE;

    PROCEDURE S_CMBTSMSECTGESTION (SLANGUE     IN     VARCHAR2,
                                   PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT DISTINCT DPTCODE AS CODE, DPTLABEL AS DISPLAYVALUE
              FROM LANDEPARTMENT LDE
             WHERE LANCODE = SLANGUE;
    END S_CMBTSMSECTGESTION;

    PROCEDURE S_CMBPOSITION (SDEPTCODE   IN     VARCHAR2,
                             PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT TSMMETIER AS CODE, TSMMETIER AS DISPLAYVALUE
              FROM TSECTEURMETIER
             WHERE TSMSECTGESTION = SDEPTCODE;
    END S_CMBPOSITION;

    PROCEDURE S_CONTACT_PERSON (NACTID IN NUMBER, PC_RETURN IN OUT T_CURSOR)
    AS
        NPSYMAXSELECT   NUMBER;
    BEGIN
        IF NACTID IS NOT NULL
        THEN
            OPEN PC_RETURN FOR
                SELECT TO_CHAR (ACOORDRE) AS CODE, ACONOM AS DISPLAYVALUE
                  FROM ACTCORRESPONDANT
                 WHERE ACTID = NACTID;
        ELSE
            SELECT NVL (PSYMAXSELECT, 100000000)
              INTO NPSYMAXSELECT
              FROM PARSYSTEME;

            OPEN PC_RETURN FOR
                SELECT TO_CHAR (ACOORDRE) AS CODE, ACONOM AS DISPLAYVALUE
                  FROM ACTCORRESPONDANT
                 WHERE ROWNUM < NPSYMAXSELECT;
        END IF;
    END S_CONTACT_PERSON;

    PROCEDURE S_CONTACT_TYPE (NACTID IN NUMBER, PC_RETURN IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR SELECT ATETYPE AS CODE, ATETYPE AS DISPLAYVALUE
                             FROM ACTTELECOM
                            WHERE ACTID = NACTID;
    END S_CONTACT_TYPE;

    PROCEDURE S_ROLE_TYPE (NACTID      IN     NUMBER,
                           SLANCODE    IN     VARCHAR2,
                           PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT ACTROLE.ROLCODE AS CODE, ROLLIBELLE AS DISPLAYVALUE
              FROM ACTROLE, LANROLE
             WHERE     ACTROLE.ROLCODE = LANROLE.ROLCODE
                   AND LANROLE.LANCODE = SLANCODE
                   AND ACTID = NACTID;
    END S_ROLE_TYPE;

    PROCEDURE S_COLPOSITION (PC_RETURN IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT TSMMETIER AS CODE, TSMMETIER AS DISPLAYVALUE
              FROM TSECTEURMETIER;
    END S_COLPOSITION;

    PROCEDURE S_DEPARTMENT (PC_RETURN IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT DPTCODE,
                   DPTCODEPARENT,
                   DPTTYPE,
                   DPTSTATUS,
                   ACTID,
                   DPTGROUP,
                   DPTSIZE,
                   DPTPOST,
                   DPTDTSTART,
                   DPTDTEND,
                   (SELECT UUL.ULIMETIER
                      FROM UTIUSERLINK UUL
                     WHERE     UUL.ULISECTGEST(+) = DPTCODE
                           AND ULIDTEND IS NULL
                           AND ULITYPE(+) = 'MANAGER'
                           AND ROWNUM = 1)
                       POSITION,
                   (SELECT UUL.UTICODELINKED
                      FROM UTIUSERLINK UUL
                     WHERE     UUL.ULISECTGEST(+) = DPTCODE
                           AND ULIDTEND IS NULL
                           AND ULITYPE(+) = 'MANAGER'
                           AND ROWNUM = 1)
                       LEADER
              FROM DEPARTMENT;
    END S_DEPARTMENT;

    PROCEDURE S_LANDEPARTMENT (SDPTCODE    IN     LANDEPARTMENT.DPTCODE%TYPE,
                               SLANCODE    IN     LANDEPARTMENT.LANCODE%TYPE,
                               PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT DPTCODE, LANCODE, DPTLABEL
              FROM LANDEPARTMENT
             WHERE     LANDEPARTMENT.DPTCODE = SDPTCODE
                   AND LANDEPARTMENT.LANCODE = SLANCODE;
    END S_LANDEPARTMENT;

    PROCEDURE S_APPROVALLINE_RULE (
        SRULTARGET   IN     RULE.RULTARGET%TYPE,
        SLANCODE     IN     VARCHAR2,
        SUTICODE     IN     RULPREFERENCE.UTICODE%TYPE,
        PC_RETURN    IN OUT T_CURSOR)
    AS
    BEGIN
        DECLARE
            NCSEID      CUSTOMSETTING.CSEID%TYPE;
            SDPTCODE    DEPARTMENT.DPTCODE%TYPE;
            SPOSITION   UTITSM.TSMMETIER%TYPE;
            NCOUNT      NUMBER;
        BEGIN
            SELECT COUNT (TSMSECTGESTION)
              INTO NCOUNT
              FROM UTITSM
             WHERE     UTICODE = SUTICODE
                   AND TSMFLAGDEFAUT = 1
                   AND TSMDTEND IS NULL;

            IF NCOUNT = 1
            THEN
                SELECT TSMSECTGESTION, TSMMETIER
                  INTO SDPTCODE, SPOSITION
                  FROM UTITSM
                 WHERE     UTICODE = SUTICODE
                       AND TSMFLAGDEFAUT = 1
                       AND TSMDTEND IS NULL;

                BEGIN
                    SELECT CSEID
                      INTO NCSEID
                      FROM CUSTOMSETTING
                     WHERE CSETABLE = 'ASTRUL' AND CSEFLAGTABLEMCD = 1;
                EXCEPTION
                    WHEN OTHERS
                    THEN
                        NCSEID := NULL;
                END;
            END IF;

            OPEN PC_RETURN FOR
                SELECT TO_CHAR (R.RULID) AS CODE, LR.RULLABEL AS DISPLAYVALUE
                  FROM RULE R, LANRULE LR, CSERUL CRU
                 WHERE     R.RULID = LR.RULID
                       AND LR.LANCODE = SLANCODE
                       AND R.RULTARGET = SRULTARGET
                       AND CRU.RULID = R.RULID
                       AND CSEID = NCSEID
                       AND NOT EXISTS
                               (SELECT 1
                                  FROM RULPREFERENCE
                                 WHERE     RULID = R.RULID
                                       AND (CSEID IS NULL OR CSEID = NCSEID)
                                       AND (   DPTCODE IS NULL
                                            OR DPTCODE = SDPTCODE)
                                       AND (   UTICODE IS NULL
                                            OR UTICODE = SUTICODE)
                                       AND (   RPRPOSITION IS NULL
                                            OR RPRPOSITION = SPOSITION));
        END;
    END S_APPROVALLINE_RULE;

    PROCEDURE S_APPROVALSTEP_RULE_ASSIGNED (
        SALICODE    IN     LKASTRUL.ALICODE%TYPE,
        SASTORDER   IN     LKASTRUL.ASTORDER%TYPE,
        SLANCODE    IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT TO_CHAR (R.RULID) AS CODE, LR.RULLABEL AS DISPLAYVALUE
              FROM RULE R, LANRULE LR
             WHERE     R.RULID = LR.RULID
                   AND R.RULID IN
                           (SELECT RULID
                              FROM LKASTRUL
                             WHERE     ALICODE = SALICODE
                                   AND ASTORDER = SASTORDER)
                   AND LR.LANCODE = SLANCODE;
    END S_APPROVALSTEP_RULE_ASSIGNED;

    PROCEDURE S_APPROVALSTEP_RULE (
        SALICODE     IN     LKASTRUL.ALICODE%TYPE,
        SASTORDER    IN     LKASTRUL.ASTORDER%TYPE,
        SRULTARGET   IN     RULE.RULTARGET%TYPE,
        SLANCODE     IN     VARCHAR2,
        SUTICODE     IN     RULPREFERENCE.UTICODE%TYPE,
        PC_RETURN    IN OUT T_CURSOR)
    AS
    BEGIN
        DECLARE
            NCSEID        CUSTOMSETTING.CSEID%TYPE;
            SDPTCODE      DEPARTMENT.DPTCODE%TYPE;
            SPOSITION     UTITSM.TSMMETIER%TYPE;
            NRETURNCODE   NUMBER := 0;
            NCOUNT        NUMBER;
        BEGIN
            SELECT COUNT (TSMSECTGESTION)
              INTO NCOUNT
              FROM UTITSM
             WHERE UTICODE = SUTICODE AND TSMFLAGDEFAUT = 1;

            IF NCOUNT != 0
            THEN
                SELECT TSMSECTGESTION, TSMMETIER
                  INTO SDPTCODE, SPOSITION
                  FROM UTITSM
                 WHERE UTICODE = SUTICODE AND TSMFLAGDEFAUT = 1;

                SELECT MAX (CSEID)
                  INTO NCSEID
                  FROM CUSTOMSETTING
                 WHERE CSETABLE = 'ASTRUL' AND CSEFLAGTABLEMCD = 1;
            END IF;

            OPEN PC_RETURN FOR
                SELECT TO_CHAR (R.RULID) AS CODE, LR.RULLABEL AS DISPLAYVALUE
                  FROM RULE R, LANRULE LR, CSERUL CRU
                 WHERE     R.RULID = LR.RULID
                       AND LR.LANCODE = SLANCODE
                       AND R.RULTARGET = SRULTARGET
                       AND CRU.RULID = R.RULID
                       AND NOT EXISTS
                               (SELECT 1
                                  FROM RULPREFERENCE
                                 WHERE     RULID = R.RULID
                                       AND (CSEID IS NULL OR CSEID = NCSEID)
                                       AND (   DPTCODE IS NULL
                                            OR DPTCODE = SDPTCODE)
                                       AND (   UTICODE IS NULL
                                            OR UTICODE = SUTICODE)
                                       AND (   RPRPOSITION IS NULL
                                            OR RPRPOSITION = SPOSITION));
        EXCEPTION
            WHEN OTHERS
            THEN
                OPEN PC_RETURN FOR SELECT NULL
                                     FROM DUAL
                                    WHERE 1 = 2;
        END;
    END S_APPROVALSTEP_RULE;

    PROCEDURE S_APPROVALLINE_TARGET (   -- sTtrnom IN LANTTRPARAM.TTRNOM%TYPE,
                                     SLANCODE    IN     VARCHAR2,
                                     PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT TTPCODE AS CODE, TTPLIBELLE AS DISPLAYVALUE
              FROM LANTTRPARAM
             WHERE TTRNOM = 'DESTINATION' AND LANCODE = SLANCODE;
    END S_APPROVALLINE_TARGET;

    PROCEDURE S_APPROVALLINE_TARGET_RULE (
        SALICODE    IN     LKALIRUL.ALICODE%TYPE,
        SLANCODE    IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT TTPCODE AS CODE, TTPLIBELLE AS DISPLAYVALUE
              FROM LANTTRPARAM
             WHERE     TTRNOM = 'DESTINATION'
                   AND LANCODE = SLANCODE
                   AND TTPCODE =
                       (SELECT MIN (RULTARGET)
                          FROM RULE
                         WHERE RULE.RULID IN (SELECT RULID
                                                FROM LKALIRUL
                                               WHERE ALICODE = SALICODE));
    END S_APPROVALLINE_TARGET_RULE;

    PROCEDURE S_APPROVALLINE_RULE_ASSIGNED (
        SALICODE    IN     LKALIRUL.ALICODE%TYPE,
        SLANCODE    IN     VARCHAR2,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT TO_CHAR (R.RULID) AS CODE, LR.RULLABEL AS DISPLAYVALUE
              FROM RULE R, LANRULE LR
             WHERE     R.RULID = LR.RULID
                   AND R.RULID IN (SELECT RULID
                                     FROM LKALIRUL
                                    WHERE ALICODE = SALICODE)
                   AND LR.LANCODE = SLANCODE;
    END S_APPROVALLINE_RULE_ASSIGNED;

    PROCEDURE S_APPROVALLINE_CODE (NRULID      IN     RULE.RULID%TYPE,
                                   PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT TO_CHAR (RULID) AS CODE, RULTARGET AS DISPLAYVALUE
              FROM RULE
             WHERE RULID = NRULID;
    END S_APPROVALLINE_CODE;

    PROCEDURE S_TASK (SLANCODE IN VARCHAR2, PC_RETURN IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT A.FORID AS CODEINTEGER, A.FORLIBELLE AS DISPLAYVALUE
              FROM LANFORMALITE A, FORMALITE B
             WHERE     B.FORID = A.FORID
                   AND B.FORTYPE = 'APPROVALLINE'
                   AND A.LANCODE = SLANCODE;
    END S_TASK;

    PROCEDURE S_FORTYPEGESFORMALITE (
        SUGECODE    IN     FORMALITE.UGECODE%TYPE,
        STACCODE    IN     FORMALITE.TACCODE%TYPE,
        SFORDEST    IN     FORMALITE.FORDEST%TYPE,
        SLANCODE           LANGUE.LANCODE%TYPE,
        SFORTYPE    IN     FORMALITE.FORTYPE%TYPE,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT FRM.FORID,
                     FRM.FORCODE,
                     FRM.TACCODE,
                     FRM.FORDEST,
                     FRM.FORFLAGOBLIG,
                     FRM.FORFLAGDOCEMIS,
                     FRM.FORDELAIEMIS,
                     FRM.FORFLAGREPONSE,
                     FRM.FORDELAIREP,
                     FRM.FORFLAGFORRAPPEL,
                     LFO.FORLIBELLE,
                     FRM.FORTYPEDATE,
                     LT1.TTPLIBELLE,
                     FRM.FORMODELANCEMENT,
                     FRM.FORIDRAPPEL,
                     FRM.FORFLAGRECURRENT,
                     FRM.FORJOUR,
                     FRM.FORMOIS,
                     FRM.FORMULTIPLE,
                     FORDELAIREACTIVATION,
                     FRM.FORPERIODE,
                     FRM.FORPRIORITY,
                     FRM.FORPEREMIS,
                     FRM.FORPERACT,
                     FRM.FORPERREP,
                     FRM.FORPERREPONSE,
                     FRM.FORTYPE,
                     FRM.FORTYPEMSG,
                     FRM.ANMID,
                     FRM.FORTELTYPE,
                     FRM.FORMESSAGE
                FROM FORMALITE   FRM,
                     LANFORMALITE LFO,
                     LANTTRPARAM LTP,
                     LANTTRPARAM LT1
               WHERE     FRM.UGECODE = SUGECODE
                     AND FRM.FORTYPE = SFORTYPE
                     AND FRM.TACCODE = STACCODE
                     AND FRM.FORDEST = SFORDEST
                     AND (FRM.FORID = LFO.FORID AND LFO.LANCODE = SLANCODE)
                     AND (    FRM.FORTYPEDATE = LTP.TTPCODE(+)
                          AND LTP.TTRNOM(+) = 'CONTRATDATE'
                          AND LTP.LANCODE(+) = SLANCODE)
                     AND (    FRM.FORMODELANCEMENT = LT1.TTPCODE(+)
                          AND LT1.TTRNOM(+) = 'MODEDECLENCH'
                          AND LT1.LANCODE(+) = SLANCODE)
            ORDER BY LFO.FORLIBELLE;
    END S_FORTYPEGESFORMALITE;

    PROCEDURE S_LKTPGTACTCI (STACCODE    IN     LKTPGTACTCI.TACCODE%TYPE,
                             STAGCODE    IN     LKTPGTACTCI.TPGCODE%TYPE,
                             PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR SELECT *
                             FROM LKTPGTACTCI
                            WHERE TACCODE = STACCODE AND TPGCODE = STAGCODE;
    END S_LKTPGTACTCI;

    PROCEDURE S_TCALCULINTERET (SLANCODE    IN     VARCHAR2,
                                PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT TCAL.TCIID                         CODEINTEGER,
                     NVL (LANTCAL.TCILIBELLE, TCAL.TCIID) AS DISPLAYVALUE
                FROM TCALCULINTERET TCAL, LANTCALCULINTERET LANTCAL
               WHERE TCAL.TCIID = LANTCAL.TCIID AND LANTCAL.LANCODE = SLANCODE
            ORDER BY TCAL.TCIID ASC;
    END S_TCALCULINTERET;

    PROCEDURE S_UTIACTDEFAULT (SUTICODE           UTILISATEUR.UTICODE%TYPE,
                               PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR SELECT UTICODE,
                                  UADORDRE,
                                  TPGCODE,
                                  UADSALESNETWORK,
                                  ACTID,
                                  ROLCODE
                             FROM UTIACTDEFAULT
                            WHERE UTICODE = SUTICODE;
    END S_UTIACTDEFAULT;

    PROCEDURE S_MAXLTV (P_NAPCODE          NAP.NAPCODE%TYPE,
                        PC_MAXLTV   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_MAXLTV FOR SELECT NAPLTV.NLTDTSTART,
                                  NAPLTV.NLTDTEND,
                                  NAPLTV.NLTPCTLTV,
                                  NAPLTV.NAPCODE,
                                  NAPLTV.PAYCODE,
                                  NAPLTV.NLTORDER
                             FROM NAPLTV
                            WHERE NAPLTV.NAPCODE = P_NAPCODE;
    END S_MAXLTV;

    PROCEDURE S_UTITSM_ROW (SUTICODE           UTILISATEUR.UTICODE%TYPE,
                            SLANCODE           LANDEPARTMENT.LANCODE%TYPE,
                            PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT UTICODE,
                   TSMSECTGESTION,
                   TSMMETIER,
                   TSMFLAGSUPERVISEUR,
                   TSMFLAGDEFAUT,
                   TSMPARTNAME,
                   TSMCOUNGR,
                   TSMCOUNEGE,
                   TSMDTEND,
                   LAN.DPTLABEL,
                   LAN.LANCODE
              FROM UTITSM UTI, LANDEPARTMENT LAN
             WHERE     UTICODE = SUTICODE
                   AND UTI.TSMSECTGESTION = LAN.DPTCODE
                   AND LAN.LANCODE = SLANCODE;
    END S_UTITSM_ROW;

    PROCEDURE S_UTIUSERLINK (SUTICODE           UTILISATEUR.UTICODE%TYPE,
                             PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR SELECT UTICODE,
                                  UTICODELINKED,
                                  ULITYPE,
                                  ULIORDRE,
                                  ULIDTBEG,
                                  ULIDTEND,
                                  ULIMETIER,
                                  ULISECTGEST,
                                  ULISALESNETWORK,
                                  TPGCODE
                             FROM UTIUSERLINK
                            WHERE UTICODE = SUTICODE;
    END S_UTIUSERLINK;

    PROCEDURE S_UTITSMHIST (SUTICODE           UTITSM.UTICODE%TYPE,
                            PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR   SELECT TSMSECTGESTION,
                                    TSMMETIER,
                                    TSMFLAGSUPERVISEUR,
                                    TSMFLAGDEFAUT,
                                    TSMPARTNAME,
                                    TSMCOUNGR,
                                    TSMCOUNEGE,
                                    TSMDTSTART,
                                    TSMDTEND
                               FROM UTITSM
                              WHERE UTICODE = SUTICODE AND TSMDTEND IS NOT NULL
                           ORDER BY TSMDTEND ASC;
    END S_UTITSMHIST;

    PROCEDURE S_GETGRECODES (SGLANGUE           LANPHASE.LANCODE%TYPE,
                             PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT LAN.TUPCODE AS CODE, LAN.TUPLIBELLE AS DISPLAYVALUE
              FROM LANTUSPARAM LAN
             WHERE LAN.TUSNOM = 'GRADE' AND LAN.LANCODE = SGLANGUE;
    END S_GETGRECODES;

    PROCEDURE S_DPTCODE (PC_RETURN IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT DPT.DPTCODE AS CODE, LDP.DPTLABEL AS DISPLAYVALUE
              FROM DEPARTMENT DPT, LANDEPARTMENT LDP
             WHERE DPT.DPTCODE = LDP.DPTCODE;
    END S_DPTCODE;

    PROCEDURE S_TWCCODE (SLANGUE            LANTWORKCATEGORY.LANCODE%TYPE,
                         STWCCODE           TWORKCATEGORY.TWCCODE%TYPE,
                         PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT TCA.TWCID AS CODEINTEGER, LTW.TWCLABEL AS DISPLAYVALUE
              FROM TWORKCATEGORY TCA, LANTWORKCATEGORY LTW
             WHERE     LTW.LANCODE = SLANGUE
                   AND TCA.TWCID = LTW.TWCID
                   AND TCA.TWCIDPARENT = (SELECT MAX (TWCID)
                                            FROM TWORKCATEGORY
                                           WHERE TWCCODE = STWCCODE);
    END S_TWCCODE;

    PROCEDURE S_TWCCODE_ALL (SLANGUE            LANTWORKCATEGORY.LANCODE%TYPE,
                             PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT TCA.TWCCODE AS CODE, LTW.TWCLABEL AS DISPLAYVALUE
                FROM TWORKCATEGORY TCA, LANTWORKCATEGORY LTW
               WHERE LTW.LANCODE = SLANGUE AND TCA.TWCID = LTW.TWCID
            ORDER BY 2 ASC;
    END S_TWCCODE_ALL;

    PROCEDURE S_DPTCODE_DPTTYPE (SDPTTYPE           DEPARTMENT.DPTTYPE%TYPE,
                                 PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT DPT.DPTCODE AS CODE, LDP.DPTLABEL AS DISPLAYVALUE
              FROM DEPARTMENT DPT, LANDEPARTMENT LDP
             WHERE DPT.DPTCODE = LDP.DPTCODE AND DPTTYPE = SDPTTYPE;
    END S_DPTCODE_DPTTYPE;

    PROCEDURE S_WORKQUEUE_COMBO (SLANGUE            LANWORKQUEUE.LANCODE%TYPE,
                                 PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT WQUID AS CODEINTEGER, WQULABEL AS DISPLAYVALUE
                FROM LANWORKQUEUE
               WHERE LANCODE = SLANGUE
            ORDER BY 1;
    END S_WORKQUEUE_COMBO;

    PROCEDURE S_WORKQUEUE_COMBO_MGT (
        SDPTCODE           UTITSM.TSMTEAMCODE%TYPE,
        SLANGUE            LANWORKQUEUE.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT WORKQUEUE.WQUID AS CODEINTEGER, WQULABEL AS DISPLAYVALUE
                FROM LANWORKQUEUE, WORKQUEUE
               WHERE     WORKQUEUE.WQUID = LANWORKQUEUE.WQUID
                     AND WORKQUEUE.WQUID IN
                             (SELECT WQUID
                                FROM WORDPT
                               WHERE (   SDPTCODE IS NULL
                                      OR WDPTEAMCODE = SDPTCODE))
                     AND LANCODE = SLANGUE
            ORDER BY 1;
    END S_WORKQUEUE_COMBO_MGT;

    PROCEDURE S_WORKQUEUE_COMBO_MGT_2 (
        SDPTCODE           UTITSM.TSMTEAMCODE%TYPE,
        SLANGUE            LANWORKQUEUE.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT WORKQUEUE.WQUID AS CODEINTEGER, WQULABEL AS DISPLAYVALUE
                FROM LANWORKQUEUE, WORKQUEUE
               WHERE     WORKQUEUE.WQUID = LANWORKQUEUE.WQUID
                     AND WORKQUEUE.WQUID IN
                             (SELECT WQUID
                                FROM WORDPT, LANTUSPARAM
                               WHERE     ('RE' IS NULL OR DPTCODE = 'RE')
                                     AND WDPTEAMCODE = TUPCODE
                                     AND TUSNOM = 'TSMTEAMCODE')
                     AND LANCODE = SLANGUE
            ORDER BY 1;
    END S_WORKQUEUE_COMBO_MGT_2;

    PROCEDURE S_WORKQUEUE_COMBO_COLLECTOR (
        SDPTCODE    IN     DEPARTMENT.DPTCODE%TYPE,
        SLANGUE            LANWORKQUEUE.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT DISTINCT
                     W.WQUID AS CODEINTEGER, LW.WQULABEL AS DISPLAYVALUE
                FROM WORDPT WP, LANWORKQUEUE LW, WORKQUEUE W
               WHERE     W.WQUID = LW.WQUID
                     AND LW.WQUID = WP.WQUID
                     AND W.WQUID = WP.WQUID
                     AND WP.DPTCODE = SDPTCODE
                     AND LW.LANCODE = SLANGUE
            ORDER BY 1;
    END S_WORKQUEUE_COMBO_COLLECTOR;

    PROCEDURE S_COLLECTION_CENTER (
        SDPTTYPE    IN     DEPARTMENT.DPTTYPE%TYPE,
        SLANGUE     IN     LANDEPARTMENT.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT LDE.DPTCODE AS CODE, LDE.DPTLABEL AS DISPLAYVALUE
              FROM DEPARTMENT DEP, LANDEPARTMENT LDE
             WHERE     (   DEP.DPTCODEPARENT IN
                               (SELECT TSMSECTGESTION
                                  FROM UTITSM UTI
                                 WHERE     UTI.UTICODE = 'ORFI'
                                       AND UTI.TSMDTEND IS NULL)
                        OR DEP.DPTCODE IN
                               (SELECT TSMSECTGESTION
                                  FROM UTITSM UTI
                                 WHERE     UTI.UTICODE = 'ORFI'
                                       AND UTI.TSMDTEND IS NULL))
                   AND DEP.DPTTYPE = SDPTTYPE
                   AND DEP.DPTSTATUS = '01'
                   AND LDE.LANCODE = SLANGUE
                   AND LDE.DPTCODE = DEP.DPTCODE;
    END S_COLLECTION_CENTER;

    PROCEDURE S_COLLECTION_CENTER_SITE_OFF (
        SLANGUE     IN     LANDEPARTMENT.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT DISTINCT DPT.DPTCODE AS CODE, LAN.DPTLABEL AS DISPLAYVALUE
              FROM DEPARTMENT DPT, LANDEPARTMENT LAN
             WHERE LAN.DPTCODE = DPT.DPTCODE AND LAN.LANCODE = SLANGUE;
    END S_COLLECTION_CENTER_SITE_OFF;

    PROCEDURE S_MANAGEMENT_GROUP (
        SDPTTYPE      IN     DEPARTMENT.DPTTYPE%TYPE,
        SCODEPARENT   IN     DEPARTMENT.DPTCODEPARENT%TYPE,
        SLANGUE       IN     LANDEPARTMENT.LANCODE%TYPE,
        PC_RETURN     IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT DISTINCT DPT.DPTCODE AS CODE, LAN.DPTLABEL AS DISPLAYVALUE
              FROM DEPARTMENT DPT, LANDEPARTMENT LAN
             WHERE     (SDPTTYPE IS NULL OR DPT.DPTTYPE = SDPTTYPE)
                   AND LAN.DPTCODE = DPT.DPTCODE
                   AND (   SCODEPARENT IS NULL
                        OR DPT.DPTCODEPARENT = SCODEPARENT)
                   AND DPT.DPTSTATUS = '01'
                   AND LAN.LANCODE = SLANGUE;
    END S_MANAGEMENT_GROUP;

    PROCEDURE S_COMPATIBLEEVENT (
        STEVDEST       IN     TEVCOMPATIBILITY.TEVDEST%TYPE,
        STACCODE       IN     TEVCOMPATIBILITY.TACCODE%TYPE,
        STMOMODULE     IN     TEVCOMPATIBILITY.TMOMODULE%TYPE,
        STMFFONCTION   IN     TEVCOMPATIBILITY.TMFFONCTION%TYPE,
        NRETURNCODE    IN OUT NUMBER,
        PC_RETURN      IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT TMFFONCTIONCOMPATIBLE AS TMFFONCTIONCOMPATIBLE,
                   TCOCOMPTYPE           AS TCOCOMPTYPE,
                   TCOORDER
              FROM TEVCOMPATIBILITY
             WHERE     TEVDEST = STEVDEST
                   AND TACCODE = STACCODE
                   AND TMOMODULE = STMOMODULE
                   AND TMFFONCTION = STMFFONCTION;
    END S_COMPATIBLEEVENT;

    PROCEDURE S_COMPATIBLE_EVENTLIST (
        SLANCODE       IN     LANTEVENEMENT.LANCODE%TYPE,
        STEVDEST       IN     TEVCOMPATIBILITY.TEVDEST%TYPE,
        STACCODE       IN     TEVCOMPATIBILITY.TACCODE%TYPE,
        STMOMODULE     IN     TEVCOMPATIBILITY.TMOMODULE%TYPE,
        STMFFONCTION   IN     TEVCOMPATIBILITY.TMFFONCTION%TYPE,
        PC_RETURN      IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT (   TEVDESTCOMPATIBLE
                    || ','
                    || TACCODECOMPATIBLE
                    || ','
                    || TMOMODULECOMPATIBLE
                    || ','
                    || TMFFONCTIONCOMPATIBLE)
                       AS CODE,
                   LTE.TEVLIBELLE
                       AS DISPLAYVALUE,
                   TCO.TCOORDER
                       AS OTHERINFO
              FROM TEVCOMPATIBILITY TCO, LANTEVENEMENT LTE
             WHERE     LANCODE = SLANCODE
                   AND TCO.TEVDEST = LTE.TEVDEST
                   AND TCO.TACCODE = LTE.TACCODE
                   AND TCO.TMOMODULE = LTE.TMOMODULE
                   AND TCO.TMFFONCTION = LTE.TMFFONCTION
                   AND TCO.TEVDEST = STEVDEST
                   AND TCO.TACCODE = STACCODE
                   AND TCO.TMOMODULE = STMOMODULE
                   AND TCO.TMFFONCTION = STMFFONCTION;
    END S_COMPATIBLE_EVENTLIST;

    PROCEDURE S_CMBRULE_CODE (SROLCODE    IN     LANROLE.ROLCODE%TYPE,
                              SLANGUE     IN     VARCHAR2,
                              PC_RETURN   IN OUT T_CURSOR)
    AS
    --sLangue LANGUE.LANCODE%TYPE := PA_Global_Declare.sgLangue;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT ROL.ROLCODE AS CODE, LROL.ROLLIBELLE AS DISPLAYVALUE
                FROM ROLE ROL, LANROLE LROL
               WHERE     ROL.ROLCODE = LROL.ROLCODE
                     AND LROL.LANCODE = SLANGUE
                     AND ROL.ROLCODE = SROLCODE
            ORDER BY 2;
    END S_CMBRULE_CODE;

    PROCEDURE S_JALCODES (SUGECODE    IN     TPCTACCONTROLE.UGECODE%TYPE,
                          STPCCODE    IN     TPCTACCONTROLE.TPCCODE%TYPE,
                          STACCODE    IN     TPCTACCONTROLE.TACCODE%TYPE,
                          STPCDEST    IN     TPCTACCONTROLE.TPCDEST%TYPE,
                          SPHACODE    IN     LKPHAJALTTC.PHACODE%TYPE,
                          STPGCODE    IN     LKPHAJALTTC.TPGCODE%TYPE,
                          SPHADEST    IN     LKPHAJALTTC.PHADEST%TYPE,
                          STTCCODE    IN     LKPHAJALTTC.TTCCODE%TYPE,
                          PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT A.JALCODE AS CODE
              FROM LKPHAJALTTC A, TPCTACCONTROLE E
             WHERE     (E.UGECODE = SUGECODE OR E.UGECODE IS NULL)
                   AND E.TPCCODE = STPCCODE
                   AND E.TPCDEST = STPCDEST
                   AND E.TACCODE IN (STACCODE)
                   AND A.PHACODE = SPHACODE
                   AND A.TPGCODE = STPGCODE
                   AND A.PHADEST = SPHADEST
                   AND A.TTCCODE = STTCCODE
                   AND A.TTCCODE = E.TTCCODE
                   AND A.TACCODE = E.TACCODE
                   AND A.TPCCODE = E.TPCCODE
                   AND A.TPCDEST = E.TPCDEST;
    END S_JALCODES;

    PROCEDURE S_JALCODES_CONTROLSLIST (
        SUGECODE    IN     TPCTACCONTROLE.UGECODE%TYPE,
        STPCCODE    IN     TPCTACCONTROLE.TPCCODE%TYPE,
        STACCODE    IN     TPCTACCONTROLE.TACCODE%TYPE,
        STPCDEST    IN     TPCTACCONTROLE.TPCDEST%TYPE,
        SPHACODE    IN     LKPHAJALTTC.PHACODE%TYPE,
        STPGCODE    IN     LKPHAJALTTC.TPGCODE%TYPE,
        SPHADEST    IN     LKPHAJALTTC.PHADEST%TYPE,
        SLANCODE    IN     LANGUE.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT A.TTCLIBELLE,
                     NVL (B.PJTFLAGACTIF, 0) AS ORFI,
                     NVL (B.PJTFLAGDEFAUT, 0) AS DEFAULTCOL,
                     D.TTPCODE,
                     D.TTPLIBELLE,
                     B.TTCCODE,
                     C.TACLIBELLE,
                     B.TACCODE,
                     B.PHACODE,
                     B.PHADEST,
                     B.JALCODE,
                     F.JALLIBELLE           AS STEP
                FROM LANTPCTACCONTROLE A,
                     LANTACTIVITE     C,
                     LANTTRPARAM      D,
                     TPCTACCONTROLE   E,
                     LKPHAJALTTC      B,
                     LANJALON         F
               WHERE     (E.UGECODE = SUGECODE OR E.UGECODE IS NULL)
                     AND E.TPCCODE = STPCCODE
                     AND F.JALCODE = B.JALCODE
                     AND F.LANCODE = SLANCODE
                     AND E.TPCDEST = STPCDEST
                     AND E.TACCODE IN (STACCODE)
                     AND B.TTCCODE = E.TTCCODE
                     AND B.TACCODE = E.TACCODE
                     AND B.TPCCODE = E.TPCCODE
                     AND B.TPCDEST = E.TPCDEST
                     AND B.PHACODE = SPHACODE
                     AND B.TACCODE = E.TACCODE
                     AND B.TPGCODE = STPGCODE
                     AND A.TACCODE = B.TACCODE
                     AND A.TPCCODE = B.TPCCODE
                     AND A.TTCCODE = B.TTCCODE
                     AND A.TPCDEST = B.TPCDEST
                     AND A.TACCODE = B.TACCODE
                     AND A.LANCODE = SLANCODE
                     AND C.LANCODE = SLANCODE
                     AND C.TACCODE = B.TACCODE
                     AND D.LANCODE = SLANCODE
                     AND D.TTRNOM = 'CONTROLSEVERITE'
                     AND D.TTPCODE = TO_CHAR (NVL (B.PJTFLAGUSER, 0))
            ORDER BY A.TTCLIBELLE;
    END S_JALCODES_CONTROLSLIST;

    PROCEDURE S_LINKEDTASKSRULES (NFORID      IN     LKFORRUL.FORID%TYPE,
                                  PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR SELECT LKF.RULID, LKF.FRULINKTYPE
                             FROM LKFORRUL LKF
                            WHERE LKF.FORID = NFORID;
    END S_LINKEDTASKSRULES;

    PROCEDURE S_CONFIGURATIONKEY (PC_RETURN IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT CKEID,
                   CKETYPE,
                   CKEACTTYPE,
                   CKECONTEXT,
                   UGECODE,
                   CKENAME,
                   UTICODE,
                   CKEWEIGHT,
                   PHADEST,
                   TBTCODE,
                   TACCODE,
                   TBNCODE,
                   TPGCODE,
                   PAYCODE,
                   PHACODE,
                   NAPCODE,
                   CKEROLCODEEXTERNE,
                   ACTID,
                   CKEENTTYPE,
                   GROCODE,
                   CKEUSERPOSITION,
                   CKEDEALTYPE,
                   JALCODE,
                   CKEROLCODEEXTERNE,
                   TWCID,
                   TCACODE,
                   CKETCTCODE,
                   TPGCODEQUOTE
              FROM CONFIGURATIONKEY;
    END S_CONFIGURATIONKEY;

    PROCEDURE S_EXPORT_TBLDROITGRP (SLANGUE     IN     VARCHAR2,
                                    NSTART      IN     NUMBER,
                                    PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        BEGIN
            OPEN PC_RETURN FOR
                SELECT *
                  FROM (SELECT DISTINCT GROUPE,
                                        MODULE,
                                        EVENEMENT,
                                        IMPUTATION,
                                        VALIDER
                          FROM (  SELECT GROUPE,
                                         LTMO.TMOLIBELLE
                                             AS MODULE,
                                         LTEV.TEVLIBELLE
                                             AS EVENEMENT,
                                         DECODE (NVL (GFDMODIFIER, 0),
                                                 0, 'False',
                                                 'True')
                                             AS IMPUTATION,
                                         DECODE (NVL (GFDSUPPRIMER, 0),
                                                 0, 'False',
                                                 'True')
                                             AS VALIDER
                                    FROM ( (SELECT DISTINCT
                                                   GRO.GROCODE
                                                       AS SGROCODE,
                                                   GRO.GROINTITULE
                                                       AS GROUPE,
                                                   TEV.TMFFONCTION
                                                       AS STMFFONCTION,
                                                   TEV.TMOMODULE
                                                       AS STMOMODULE
                                              FROM GROUPE GRO, TEVENEMENT TEV)
                                          LEFT OUTER JOIN LKGROTMFDROIT LK
                                              ON (    LK.GROCODE = SGROCODE
                                                  AND LK.TMFFONCTION =
                                                      STMFFONCTION
                                                  AND LK.TMOMODULE = STMOMODULE)),
                                         LANTMODULE   LTMO,
                                         LANTEVENEMENT LTEV
                                   WHERE     STMFFONCTION = LTEV.TMFFONCTION
                                         AND LTEV.LANCODE = LTMO.LANCODE
                                         AND LTMO.LANCODE = SLANGUE
                                         AND LTMO.TMOMODULE = STMOMODULE
                                ORDER BY 1, 2, 3 ASC));
        END;
    END S_EXPORT_TBLDROITGRP;

    PROCEDURE S_EXPORT_TBLDROITUSER (SLANGUE     IN     VARCHAR2,
                                     NSTART      IN     NUMBER,
                                     PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        BEGIN
            OPEN PC_RETURN FOR
                  SELECT *
                    FROM (SELECT SOCIETE,
                                 UTILISATEUR,
                                 MODULE,
                                 GROUPE_EXECUTER,
                                 GROUPE_VALIDER,
                                 EVENEMENT,
                                 IMPUTATION,
                                 TERMINER,
                                 ROWNUM RN
                            FROM (  SELECT SOCIETE,
                                           SUTINOM || ' ' || SUTIPRENOM
                                               AS UTILISATEUR,
                                           STMOLIBELLE
                                               AS MODULE,
                                           DECODE (NVL (GFDMODIFIER, 0),
                                                   0, 'False',
                                                   'True')
                                               AS GROUPE_EXECUTER,
                                           DECODE (NVL (GFDSUPPRIMER, 0),
                                                   0, 'False',
                                                   'True')
                                               AS GROUPE_VALIDER,
                                           EVENEMENT,
                                           DECODE (NVL (UFDSUPPRIMER, 0),
                                                   0, 'False',
                                                   'True')
                                               AS IMPUTATION,
                                           DECODE (NVL (UFDSUPPRIMER, 0),
                                                   0, 'False',
                                                   'True')
                                               AS TERMINER
                                      FROM (SELECT *
                                              FROM (SELECT DISTINCT
                                                           ACTEUR.ACTLIBCOURT
                                                               AS SOCIETE,
                                                           UTICODE
                                                               AS SUTICODE,
                                                           UTINOM
                                                               AS SUTINOM,
                                                           UTIPRENOM
                                                               AS SUTIPRENOM,
                                                           UTILISATEUR.GROCODE
                                                               AS SGROCODE,
                                                           TMFFONCTION
                                                               AS STMFFONCTION,
                                                           LANTMODULE.TMOMODULE
                                                               AS STMOMODULE,
                                                           LANTMODULE.TMOLIBELLE
                                                               AS STMOLIBELLE,
                                                           TEVLIBELLE
                                                               AS EVENEMENT
                                                      FROM UTILISATEUR,
                                                           LANTEVENEMENT,
                                                           LANTMODULE,
                                                           LKGROTACAGE,
                                                           ACTEUR
                                                     WHERE     LANTEVENEMENT.LANCODE =
                                                               SLANGUE
                                                           AND LANTEVENEMENT.LANCODE =
                                                               LANTMODULE.LANCODE
                                                           AND LANTEVENEMENT.TMOMODULE =
                                                               LANTMODULE.TMOMODULE
                                                           AND LKGROTACAGE.GROCODE =
                                                               UTILISATEUR.GROCODE
                                                           AND LKGROTACAGE.ACTID =
                                                               ACTEUR.ACTID)
                                                   LEFT OUTER JOIN
                                                   LKUTITMFDROIT LK
                                                       ON     LK.UTICODE =
                                                              SUTICODE
                                                          AND LK.TMFFONCTION =
                                                              STMFFONCTION
                                                          AND LK.TMOMODULE =
                                                              STMOMODULE)
                                           LEFT OUTER JOIN LKGROTMFDROIT LK2
                                               ON     LK2.GROCODE = SGROCODE
                                                  AND LK2.TMOMODULE = STMOMODULE
                                                  AND LK2.TMFFONCTION =
                                                      STMFFONCTION
                                  ORDER BY 1,
                                           2,
                                           3,
                                           6 ASC))
                   WHERE RN >= NSTART AND RN <= (NSTART + 9999)
                ORDER BY RN;
        END;
    END S_EXPORT_TBLDROITUSER;

    PROCEDURE S_CALENDAR (SLANGUE            LANCALENDAR.LANCODE%TYPE,
                          PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT TO_CHAR (LCA.CALID) AS Code, LCA.CALNAME AS Displayvalue
                FROM LANCALENDAR LCA
               WHERE LANCODE = SLANGUE
            ORDER BY LCA.CALID;
    END S_CALENDAR;

    PROCEDURE S_REJPRESENTATIONDELAY (
        NREJID             REJPRESENTATIONDELAY.REJID%TYPE,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR SELECT RDE.REJID, RDE.RPDNBDAYS, RDE.RPDORDER
                             FROM REJPRESENTATIONDELAY RDE
                            WHERE NREJID = RDE.REJID; -- and -- REJORDER = SREJORDER;
    END S_REJPRESENTATIONDELAY;

    FUNCTION F_UTILDAPREF_BOOLEANVALUE (
        P_USER         UTILISATEUR.UTILDAPREFERENCE%TYPE,
        P_UPRCODE      UTIPREFERENCE.UPRCODE%TYPE,
        NAUTHFLAG   IN NUMBER)
        RETURN NUMBER
    AS
    BEGIN
        DECLARE
            SUTICODE            UTIPREFERENCE.UTICODE%TYPE;
            nCount              NUMBER := 0;
            P_UPRBOOLEANVALUE   UTIPREFERENCE.UPRBOOLEANVALUE%TYPE := 0;
        BEGIN
            SELECT COUNT (*)
              INTO NCOUNT
              FROM UTILISATEUR
             WHERE UPPER (LTRIM (RTRIM (UTILISATEUR.UTILDAPREFERENCE))) LIKE
                       UPPER ('CN=' || LTRIM (RTRIM (P_USER)) || ',%');

            IF (ncount > 0)
            THEN
                SELECT UTICODE
                  INTO SUTICODE
                  FROM UTILISATEUR
                 WHERE UPPER (LTRIM (RTRIM (UTILISATEUR.UTILDAPREFERENCE))) LIKE
                           UPPER ('CN=' || LTRIM (RTRIM (P_USER)) || ',%');

                IF (SUTICODE != NULL)
                THEN
                    SELECT PAV4_SELECTPILOTAGE.F_UTIPREFERENCE_BOOLEANVALUE (
                               SUTICODE,
                               P_UPRCODE)
                      INTO P_UPRBOOLEANVALUE
                      FROM DUAL;
                END IF;
            ELSE
                IF (NAUTHFLAG = 1)
                THEN
                    SELECT PAV4_SELECTPILOTAGE.F_UTIPREFERENCE_BOOLEANVALUE (
                               P_USER,
                               P_UPRCODE)
                      INTO P_UPRBOOLEANVALUE
                      FROM DUAL;
                ELSE
                    RETURN 0;
                END IF;
            END IF;

            RETURN P_UPRBOOLEANVALUE;
        EXCEPTION
            WHEN OTHERS
            THEN
                RETURN 0;
        END;
    END F_UTILDAPREF_BOOLEANVALUE;

    PROCEDURE S_GETPOSTLIST (SLANGUE     IN     LANGUE.LANCODE%TYPE,
                             PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT T.TESCODE AS CODE, LT.TESLIBELLE AS DISPLAYVALUE
                FROM TEXPLOITSTRUCTURE T
                     JOIN LANTEXPLOITSTRUCTURE LT ON T.TESCODE = LT.TESCODE
               WHERE T.TESTYPE = 'BUDPST' AND LT.LANCODE = SLANGUE
            ORDER BY LT.TESLIBELLE ASC;
    END S_GETPOSTLIST;

    PROCEDURE S_GETSUBPOSTLIST (SLANGUE     IN     LANGUE.LANCODE%TYPE,
                                PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT T.TESCODE AS CODE, LT.TESLIBELLE AS DISPLAYVALUE
                FROM TEXPLOITSTRUCTURE T
                     JOIN LANTEXPLOITSTRUCTURE LT ON T.TESCODE = LT.TESCODE
               WHERE T.TESTYPE = 'BUDSPST' AND LT.LANCODE = SLANGUE
            ORDER BY LT.TESLIBELLE ASC;
    END S_GETSUBPOSTLIST;

    PROCEDURE S_GETMASTERCATALOGUELIST (SLANGUE     IN     LANGUE.LANCODE%TYPE,
                                        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT TNB.TNBID AS CODEINTEGER, LAN.TNBLIBELLE AS DISPLAYVALUE
              FROM TNOMENCBUDGET TNB, LANTNOMENCBUDGET LAN
             WHERE     TNB.TNBID = LAN.TNBID
                   AND TNB.TNBFLAGMASTER = 1
                   AND LAN.LANCODE = SLANGUE;
    END S_GETMASTERCATALOGUELIST;

    PROCEDURE S_GETVARIATIONINDEXLIST (sUGECODE    IN     INDICE.UGECODE%TYPE,
                                       PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR   SELECT I.INDCODE AS CODE, I.INDNOM AS DISPLAYVALUE
                               FROM INDICE I
                              WHERE UGECODE = sUGECODE
                           ORDER BY UPPER (I.INDNOM) ASC;
    END S_GETVARIATIONINDEXLIST;

    PROCEDURE S_GETCURRENCYLIST (SLANGUE     IN     LANGUE.LANCODE%TYPE,
                                 PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT D.DEVCODE AS CODE, LD.DEVNOM AS DISPLAYVALUE
                FROM DEVISE D JOIN LANDEVISE LD ON D.DEVCODE = LD.DEVCODE
               WHERE LD.LANCODE = SLANGUE
            ORDER BY LD.DEVNOM;
    END S_GETCURRENCYLIST;

    PROCEDURE S_SELECTAFFECTATION (
        SLANGUE        IN     LANGUE.LANCODE%TYPE,
        SAFFECTATION   IN     TNOMENCBUDGET.TNBAFFECTATION%TYPE,
        PC_RETURN      IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT T.TNBID,
                     T.TNBAFFECTATION,
                     T.TESCODEPOSTE,
                     T.TESCODESOUSPOSTE,
                     LT.TNBLIBELLE,
                     T.TNBFLAGMASTER,
                     T.TNBIDMASTER,
                     T.TNBTYPEVAR,
                     T.TNBVARDEFAULTPC,
                     T.INDCODE,
                     T.TNBSOURCETYPE,
                     T.TNBFLAGUPDATEABLE,
                     T.TNBMTMIN,
                     T.TNBMTMAX,
                     T.DEVCODE,
                     T.TNBNIVEAUDETAIL,
                     T.TNBUNITEDETAIL
                FROM TNOMENCBUDGET T
                     JOIN LANTNOMENCBUDGET LT ON T.TNBID = LT.TNBID
               WHERE T.TNBAFFECTATION = SAFFECTATION AND LT.LANCODE = SLANGUE
            ORDER BY 5;
    END S_SELECTAFFECTATION;

    PROCEDURE S_SELECTAFFECTATIONALL (SLANGUE     IN     LANGUE.LANCODE%TYPE,
                                      PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT T.TNBID,
                     T.TNBAFFECTATION,
                     T.TESCODEPOSTE,
                     T.TESCODESOUSPOSTE,
                     LT.TNBLIBELLE,
                     T.TNBFLAGMASTER,
                     T.TNBIDMASTER,
                     T.TNBTYPEVAR,
                     T.TNBVARDEFAULTPC,
                     T.INDCODE,
                     T.TNBSOURCETYPE,
                     T.TNBFLAGUPDATEABLE,
                     T.TNBMTMIN,
                     T.TNBMTMAX,
                     T.DEVCODE,
                     T.TNBNIVEAUDETAIL,
                     T.TNBUNITEDETAIL
                FROM TNOMENCBUDGET T
                     JOIN LANTNOMENCBUDGET LT ON T.TNBID = LT.TNBID
               WHERE LT.LANCODE = SLANGUE
            ORDER BY 5;
    END S_SELECTAFFECTATIONALL;

    PROCEDURE S_GETAFFECTATIONTREE (SLANGUE     IN     LANGUE.LANCODE%TYPE,
                                    PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT LTP.TTPCODE, LTP.TTPLIBELLE
              FROM TTRAITEMENT  TT
                   JOIN TTRPARAM TP ON TT.TTRNOM = TP.TTRNOM
                   JOIN LANTTRPARAM LTP
                       ON LTP.TTRNOM = TT.TTRNOM AND LTP.TTPCODE = TP.TTPCODE
             WHERE LTP.LANCODE = SLANGUE AND TT.TTRNOM = 'BUDAFFECTATION';
    END S_GETAFFECTATIONTREE;

    PROCEDURE S_GETTNEALL (SUGECODE    IN     TNOMENCEXPLOIT.UGECODE%TYPE,
                           SLANGUE     IN     LANGUE.LANCODE%TYPE,
                           PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT TNE.TNEID, LTNE.TNELIBELLE
                FROM TNOMENCEXPLOIT TNE
                     JOIN LANTNOMENCEXPLOIT LTNE ON TNE.TNEID = LTNE.TNEID
               WHERE LTNE.LANCODE = SLANGUE AND TNE.UGECODE = SUGECODE
            ORDER BY LTNE.TNELIBELLE;
    END S_GETTNEALL;

    PROCEDURE S_GETTNEBYTNB (sUgeCode    IN     TNOMENCEXPLOIT.UGECODE%TYPE,
                             SLANGUE     IN     LANGUE.LANCODE%TYPE,
                             NTNBID      IN     TNOMENCBUDGET.TNBID%TYPE,
                             PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT TNE.TNEID, LTNE.TNELIBELLE, LK.TNBID
              FROM TNOMENCEXPLOIT  TNE
                   JOIN LANTNOMENCEXPLOIT LTNE ON TNE.TNEID = LTNE.TNEID
                   JOIN LKTNETNB LK ON TNE.TNEID = LK.TNEID
             WHERE     LTNE.LANCODE = SLANGUE
                   AND LK.TNBID = NTNBID
                   AND TNE.UGECODE = sUgeCode;
    END S_GETTNEBYTNB;

    PROCEDURE S_GETRUBALL (SLANGUE     IN     LANGUE.LANCODE%TYPE,
                           SUGECODE    IN     RUBRIQUE.UGECODE%TYPE,
                           PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT RUB.RUBID, LRUB.RUBLIBELLE
                FROM RUBRIQUE RUB
                     JOIN LANRUBRIQUE LRUB ON RUB.RUBID = LRUB.RUBID
               WHERE LRUB.LANCODE = SLANGUE AND RUB.UGECODE = SUGECODE
            ORDER BY LRUB.RUBLIBELLE;
    END S_GETRUBALL;

    PROCEDURE S_GETRUBBYTNB (SLANGUE     IN     LANGUE.LANCODE%TYPE,
                             SUGECODE    IN     RUBRIQUE.UGECODE%TYPE,
                             NTNBID      IN     TNOMENCBUDGET.TNBID%TYPE,
                             PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT RUB.RUBID, LK.TNBID, LRUB.RUBLIBELLE
              FROM RUBRIQUE  RUB
                   JOIN LANRUBRIQUE LRUB ON RUB.RUBID = LRUB.RUBID
                   JOIN LKTNBRUB LK ON RUB.RUBID = LK.RUBID
             WHERE     LRUB.LANCODE = SLANGUE
                   AND RUB.UGECODE = SUGECODE
                   AND LK.TNBID = NTNBID;
    END S_GETRUBBYTNB;

    PROCEDURE S_GETORGALL (SLANGUE     IN     LANGUE.LANCODE%TYPE,
                           PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
              SELECT ORG.ORGCODE, LORG.ORGLIBELLE
                FROM ORGANISATION ORG
                     JOIN LANORGANISATION LORG ON ORG.ORGCODE = LORG.ORGCODE
               WHERE LORG.LANCODE = SLANGUE AND ORG.ORGFLAGBUDGET = 1
            ORDER BY LORG.ORGLIBELLE;
    END S_GETORGALL;

    PROCEDURE S_GETORGBYTNB (SLANGUE     IN     LANGUE.LANCODE%TYPE,
                             NTNBID      IN     TNOMENCBUDGET.TNBID%TYPE,
                             PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT ORG.ORGCODE, LK.TNBID, LORG.ORGLIBELLE
              FROM ORGANISATION  ORG
                   JOIN LANORGANISATION LORG ON ORG.ORGCODE = LORG.ORGCODE
                   JOIN LKTNBORG LK ON ORG.ORGCODE = LK.ORGCODE
             WHERE     LORG.LANCODE = SLANGUE
                   AND ORG.ORGFLAGBUDGET = 1
                   AND LK.TNBID = NTNBID;
    END S_GETORGBYTNB;

    PROCEDURE S_EXPORT_GROUPEDROITACCES (SLANGUE     IN     VARCHAR2,
                                         PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        BEGIN
            OPEN PC_RETURN FOR
                  SELECT GROINTITULE
                             AS GROUPE,
                         ACTLIBCOURT || ' : ' || LANTACTIVITE.TACLIBELLE
                             AS AUTHORISEDBUS
                    FROM GROUPE,
                         LKGROTACAGE,
                         ACTEUR,
                         LANTACTIVITE
                   WHERE     GROUPE.GROCODE = LKGROTACAGE.GROCODE
                         AND ACTEUR.ACTID = LKGROTACAGE.ACTID
                         AND LKGROTACAGE.TACCODE = LANTACTIVITE.TACCODE
                         AND LANTACTIVITE.LANCODE = SLANGUE
                ORDER BY 1 ASC;
        END;
    END S_EXPORT_GROUPEDROITACCES;

    PROCEDURE S_ROLELAN (SLANGUE     IN     VARCHAR2,
                         SROLCODE    IN     ROLE.ROLCODE%TYPE,
                         PC_RETURN   IN OUT T_CURSOR)
    AS
    --SLANGUE LANGUE.LANCODE%TYPE := PA_GLOBAL_DECLARE.SGLANGUE;
    BEGIN
        OPEN PC_RETURN FOR
              SELECT ROL.ROLCODE,
                     ROL.ROLFLAGATTRIBUT,
                     ROL.ROLFLAGENTRANT,
                     ROL.ROLFLAGSORTANT,
                     ROL.ROLFLAGORFI,
                     ROL.ROLCODEEXTERNE,
                     LRO.ROLLIBELLE
                FROM ROLE ROL, LANROLE LRO
               WHERE     ROL.ROLCODE = NVL (SROLCODE, ROL.ROLCODE)
                     AND LRO.ROLCODE(+) = ROL.ROLCODE
                     AND LRO.LANCODE(+) = SLANGUE
            ORDER BY ROL.ROLCODE;
    END S_ROLELAN;


    PROCEDURE S_LISTE_USER_BRAND (
        P_UTICODE            UTIACTDEFAULT.UTICODE%TYPE,
        P_DEALER             UTIACTDEFAULT.ACTID%TYPE,
        P_LANCODE            LANPAYS.LANCODE%TYPE,
        PC_RESULTAT   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RESULTAT FOR
              SELECT DISTINCT UAR.UTICODE AS CODE, ACT.ACTNOM AS DISPLAYVALUE
                FROM UTIACTDEFAULT UAR, ACTEUR ACT, ACTEURGESTION ACG
               WHERE     ACG.ACTID = ACT.ACTID
                     AND UAR.ACTID = ACT.ACTID
                     AND ACT.ACTID IS NOT NULL
            ORDER BY 2;
    END S_LISTE_USER_BRAND;



    PROCEDURE S_LISTE_USER_DEALERSHIP (
        P_UTICODE            UTIACTDEFAULT.UTICODE%TYPE,
        P_NETWORK            UTIACTDEFAULT.UADSALESNETWORK%TYPE,
        P_LANCODE            LANPAYS.LANCODE%TYPE,
        PC_RESULTAT   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RESULTAT FOR
              SELECT DISTINCT
                     UAR.ACTID AS CODEINTEGER, ACT.ACTNOM AS DISPLAYVALUE
                FROM UTIACTDEFAULT UAR, ACTEUR ACT, ACTEURGESTION ACG
               WHERE     ACG.ACTID = ACT.ACTID
                     AND UAR.ACTID = ACT.ACTID
                     AND ACT.ACTID IS NOT NULL
            ORDER BY 2;
    END S_LISTE_USER_DEALERSHIP;


    PROCEDURE S_UTIACTDEFAULT_FILTRED (
        SUTICODE           UTILISATEUR.UTICODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT UTICODE,
                   UADORDRE,
                   TPGCODE,
                   UADSALESNETWORK,
                   ACTID,
                   ROLCODE
              FROM UTIACTDEFAULT
             WHERE     UTICODE = SUTICODE
                   AND (   (    ROLCODE = 'APPORT'
                            AND UADLINKTYPE = 'APPORTMARQUE')
                        OR ROLCODE IN ('CLITREP', 'GARANT'));
    END S_UTIACTDEFAULT_FILTRED;

    PROCEDURE S_UTIACTDEFAULT_FILTRED (
        SUTICODE           UTILISATEUR.UTICODE%TYPE,
        SLANGUE            LANTUSPARAM.LANCODE%TYPE,
        PC_RETURN   IN OUT T_CURSOR)
    AS
    BEGIN
        OPEN PC_RETURN FOR
            SELECT UAC.UTICODE,
                   UAC.UADORDRE,
                   UAC.TPGCODE,
                   UAC.UADSALESNETWORK,
                   --VWTRK-941
                   --SELECT TUPLIBELLE FROM LANTUSPARAM WHERE TUSNOM='SALESNETWORK' AND TUPCODE=UAC.UADSALESNETWORK AND LANCODE=SLANGUE ) AS LIBSALESNETWORK,
                   (SELECT TSNLABEL
                      FROM LANTSALENETWORK
                     WHERE     TSNCODE = UAC.UADSALESNETWORK
                           AND LANCODE = SLANGUE)
                       AS LIBSALESNETWORK,
                   UAC.ACTID,
                   (SELECT ACTLIBCOURT
                      FROM ACTEUR
                     WHERE ACTID = UAC.ACTID)
                       AS ACTLIBCOURT,
                   ROLCODE
              FROM UTIACTDEFAULT UAC
             WHERE     UAC.UTICODE = SUTICODE
                   AND (   (    ROLCODE = 'APPORT'
                            AND UADLINKTYPE = 'APPORTMARQUE')
                        OR ROLCODE IN ('CLITREP', 'GARANT'));
    END S_UTIACTDEFAULT_FILTRED;
END PAV4_SELECTPARGEN;
/