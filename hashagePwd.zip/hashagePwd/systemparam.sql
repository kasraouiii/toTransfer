BEGIN
	    DELETE FROM SYSTEMPARAMETER WHERE SPATYPE = 'SECSPECIALCHAR';
	    INSERT
	    INTO
	        SYSTEMPARAMETER
	        (
            SPACATEGORY
	          , SPAHOST
	          , SPAAPPLICATION
	          , SPATYPE
	          , SPADESCRIPTION
	          , SPASTRINGVALUE
	          , SPANUMBERVALUE
	          , SPADATEVALUE
	          , SPABOOLEANVALUE
	        )
	        VALUES
	        (
	            '2'
	          , NULL
	          , 'CASSIOPEE'
	          , 'SECSPECIALCHAR'
	          , 'SPECIAL CHAR TO USE IN A PASSWORD'
	          , '!"#$%' || CHR(38) || '()''*+,-:;<=>?_@'
	          , NULL
	          , NULL
	          , NULL
	        ) ;
	    COMMIT;
	EXCEPTION
    WHEN OTHERS THEN
	        ROLLBACK;
	END;
	---

	grant execute on sys.dbms_crypto to <TRSGM45>
	
	--
	UPDATE SYSTEMPARAMETER SET SPANUMBERVALUE = -1 WHERE SPAAPPLICATION = 'CASSIOPEE' AND SPATYPE = 'SECCHGDELAY' AND SPACATEGORY = '2';
	
	---
	
	select * from DATATRANSCODING where DTRCODE = 'PWDHASHALGOMAP';--UGECODE='SGM'
	select * from DTRDETAIL where DDECASSIOPEEVALUE = 'SHA-256';
	delete from datatranscoding where DTRCODE = 'PWDHASHALGOMAP' and DTRTYPE = 'INTERNE' and ugecode='_ORIG_';
	delete from DTRDETAIL where dtrid in (select dtrid from datatranscoding where DTRCODE = 'PWDHASHALGOMAP' and DTRTYPE = 'INTERNE' and ugecode='_ORIG_');
	insert into DATATRANSCODING values ('8569', 'PWDHASHALGOMAP','INTERNE', null, 0 , null,null,'SGM', null,null,null ); -- MAX(ITRID)+1
	insert into DTRDETAIL values ('8569','SHA-256','4');